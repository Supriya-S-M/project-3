package com.eh.digitalpathalogy.configserver.vault;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.config.environment.Environment;
import org.springframework.cloud.config.environment.PropertySource;
import org.springframework.cloud.config.server.encryption.EnvironmentEncryptor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.vault.core.VaultOperations;
import org.springframework.vault.core.VaultTransitOperations;
import org.springframework.vault.core.VaultTransitTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TransitEnvironmentDecryptor implements EnvironmentEncryptor {
    private static final Logger log = LoggerFactory.getLogger( TransitEnvironmentDecryptor.class.getName( ) );
    private final VaultTransitOperations transit;
    private final boolean enabled;
    private final String transitKeyName;

    public TransitEnvironmentDecryptor ( VaultOperations vaultOperations, @Value("${configserver.vault.transit.enabled:true}")boolean enabled,
                                         @Value("${spring.cloud.vault.transit.key}")String transitKeyName ) {
        this.transit = new VaultTransitTemplate( vaultOperations, "transit" );
        this.enabled = enabled;
        this.transitKeyName = transitKeyName;
    }

    @Override
    public Environment decrypt ( Environment environment ) {
        if (!enabled || !StringUtils.hasText( transitKeyName)){
            return environment;
        }
        List< PropertySource > sources = environment.getPropertySources();
        for (PropertySource source: sources){
            log.info( "decrypt:: source :: {}", source );
            Map<Object, Object> original = (Map< Object, Object>) source.getSource();
            Map<Object, Object> transformed = new HashMap<>( original.size() );
            boolean changed = false;
            for (Map.Entry<Object, Object> entry: original.entrySet()){
                Object key = entry.getKey( );
                Object value = entry.getValue( );
                Object newValue = maybeDecrypt(value);
                transformed.put( key, newValue );
                if (newValue!=value){
                    changed = true;
                }
            }
            if (changed){
                original.clear();
                original.putAll( transformed );
            }
        }
        return environment;
    }

    private Object maybeDecrypt(Object value){
        if (!( value instanceof String str )){
            return value;
        }
        if (!isVaultTransitCiphertext(str)){
            return value;
        }
        try{
            return transit.decrypt(transitKeyName, str);
        }catch ( Exception e ){
            log.error( "Failed to decrypt Vault Transit cipherText. Returning original value. Cause: {}", e.getMessage( ) );
            return value;
        }
    }

    private boolean isVaultTransitCiphertext(String s){
        return s != null && s.startsWith( "vault:v" );
    }
}
