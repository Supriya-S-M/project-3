package com.eh.digitalpathalogy.configserver.vault;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.vault.core.VaultOperations;
import org.springframework.vault.core.VaultTransitOperations;
import org.springframework.vault.core.VaultTransitTemplate;
import org.springframework.vault.core.VaultVersionedKeyValueOperations;
import org.springframework.vault.support.Versioned;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping( "vault" )
public class TransitVaultWriteController {

    private static final Logger log = LoggerFactory.getLogger( TransitVaultWriteController.class.getName( ) );
    private final VaultTransitOperations transit;
    private final VaultVersionedKeyValueOperations kv;
    private final boolean enabled;
    private final String transitKeyName;
    private static final String DEFAULT_PATH = "application";
    private static final String RESULT_STORED_AS_IS = "stored-as-is";
    private static final String RESULT_ENCRYPTED_STORED = "encrypted-and-stored";
    private static final String STATUS = "status";

    public TransitVaultWriteController ( VaultOperations vaultOperations, @Value( "${configserver.vault.transit.enabled:true}" ) boolean enabled, @Value( "${spring.cloud.vault.transit.key}" ) String transitKeyName, @Value( "${spring.cloud.config.server.vault.backend}" ) String backend ) {
        this.transit = new VaultTransitTemplate( vaultOperations, "transit" );
        this.kv = vaultOperations.opsForVersionedKeyValue( backend );
        this.enabled = enabled;
        this.transitKeyName = transitKeyName;
    }

    @PostMapping( "kv/{path}" )
    public ResponseEntity< Map< String, Object > > writeSecrets ( @PathVariable( "path" ) String path, @RequestBody Map< String, Object > properties ) {

        final String effectivePath = StringUtils.hasText( path ) ? path : DEFAULT_PATH;
        return doWrite( effectivePath, properties );
    }

    @PostMapping( "kv" )
    public ResponseEntity< Map< String, Object > > writeSecretsDefault ( @RequestBody Map< String, Object > properties ) {
        return doWrite( DEFAULT_PATH, properties );
    }

    private ResponseEntity< Map< String, Object > > doWrite ( final String path, final Map< String, Object > propertiesInput ) {
        final Map< String, Object > toStore = new HashMap<>( );
        final Map< String, Object > result = new HashMap<>( );
        for ( Map.Entry< String, Object > e : propertiesInput.entrySet( ) ) {
            final String key = e.getKey( );
            final Object value = e.getValue( );
            if ( !( value instanceof String plainText ) ) {
                toStore.put( key, value );
                result.put( key, RESULT_STORED_AS_IS );
                continue;
            }
            String cipherText = plainText;
            boolean encrypted = false;
            if ( enabled && StringUtils.hasText( transitKeyName ) ) {
                try {
                    cipherText = transit.encrypt( transitKeyName, plainText );
                    encrypted = true;
                } catch ( Exception ex ) {
                    log.error( "Failed to encrypt value for key: {} using transit key : {} ::: {}", key, transitKeyName, ex.getMessage( ) );
                }
            }
            toStore.put( key, cipherText );
            result.put( key, encrypted ? RESULT_ENCRYPTED_STORED : RESULT_STORED_AS_IS );
        }
        try {
            kv.put( path, Versioned.create(toStore) );
            result.put( STATUS, "ok" );
            result.put( "path", path );
            result.put( "count", toStore.size( ) );
            return ResponseEntity.status( HttpStatus.CREATED ).body( result );
        } catch ( Exception ex ) {
            log.error( "Failed to write secrets to Vault at path {} :: {} ", path, ex.getMessage( ) );
            final Map< String, Object > err = new HashMap<>( );
            err.put( STATUS, "error" );
            err.put( "message", ex.getMessage( ) );
            return ResponseEntity.status( HttpStatus.INTERNAL_SERVER_ERROR ).body( err );
        }

    }

    @PatchMapping( "kv/{path}" )
    public ResponseEntity< Map< String, Object > > updateSecrets ( @PathVariable( "path" ) final String path, @RequestBody final Map< String, Object > properties ) {
        final String effectivePath = StringUtils.hasText( path ) ? path : DEFAULT_PATH;
        return doMergeUpdate( effectivePath, properties );
    }

    @PatchMapping( "kv" )
    public ResponseEntity< Map< String, Object > > updateSecretsDefault ( @RequestBody final Map< String, Object > properties ) {
        return doMergeUpdate( DEFAULT_PATH, properties );
    }

    private ResponseEntity< Map< String, Object > > doMergeUpdate ( final String path, final Map< String, Object > propertiesInput ) {
        final Map< String, Object > result = new HashMap<>( );
        Map< String, Object > existing;
        Versioned.Version version = null;

        try {
            final Versioned< Map< String, Object > > current = kv.get( path );
            if ( current != null && current.getData( ) != null ) {
                existing = new HashMap<>( current.getData( ) );
                if ( current.hasMetadata( ) ) {
                    version = current.getMetadata( ).getVersion( );
                }
            } else {
                existing = new HashMap<>( );
            }
        } catch ( Exception ex ) {
            log.error( "Failed to read existing secrets from Vault at path :: {} ::: {}", path, ex.getMessage( ) );
            existing = new HashMap<>( );
        }

        int updated = 0;
        for ( Map.Entry< String, Object > e : propertiesInput.entrySet( ) ) {
            final String key = e.getKey( );
            final Object value = e.getValue( );

            if ( !( value instanceof String plainText ) ) {
                existing.put( key, value );
                result.put( key, RESULT_STORED_AS_IS );
                updated++;
                continue;
            }

            String cipherText = plainText;
            boolean encrypted = false;

            if ( enabled && StringUtils.hasText( transitKeyName ) ) {
                try {
                    cipherText = transit.encrypt( transitKeyName, plainText );
                    encrypted = true;
                } catch ( Exception ex ) {
                    log.error( "Failed to encrypt value for key:: {} using transit key::: {} ::: {}", key, transitKeyName, ex.getMessage( ) );
                }
            }

            existing.put( key, cipherText );
            result.put( key, encrypted ? RESULT_ENCRYPTED_STORED : RESULT_STORED_AS_IS );
            updated++;
        }

        try {
            kv.put( path, Versioned.create( existing, version ) );
            result.put( STATUS, "ok" );
            result.put( "path", path );
            result.put( "count", updated );
            return ResponseEntity.ok( result );
        } catch ( Exception ex ) {
            log.error( "Failed to update secrets in Vault at path:: {}::: {}", path, ex.getMessage( ) );
            final Map< String, Object > err = new HashMap<>( );
            err.put( STATUS, "error" );
            err.put( "message", ex.getMessage( ) );
            return ResponseEntity.status( HttpStatus.INTERNAL_SERVER_ERROR ).body( err );
        }
    }


}
