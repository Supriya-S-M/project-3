package com.eh.digitalpathalogy.configserver.nativefs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@RestController
@RequestMapping( "native" )
public class NativeFileWriteController {
    private static final Logger log = LoggerFactory.getLogger( NativeFileWriteController.class.getName( ) );
    private static final String DEFAULT_APPLICATION = "common";
    private static final String DEFAULT_PROFILE = "default";
    private static final String MESSAGE = "message";
    private static final String STATUS = "status";
    private static final String ERROR = "error";
    private final String baseDir;
    private final Yaml yaml;


    public NativeFileWriteController ( @Value( "${configserver.native.base-dir:/configs}" ) String baseDir ) {
        this.baseDir = baseDir;
        DumperOptions options = new DumperOptions( );
        options.setDefaultFlowStyle( DumperOptions.FlowStyle.BLOCK );
        options.setPrettyFlow( true );
        this.yaml = new Yaml( options );
    }

    @PostMapping
    public ResponseEntity< Map< String, Object > > writePropertiesDefault ( @RequestParam( value = "profile", required = false ) String profile, @RequestBody Map< String, Object > properties ) {
        return doWrite( DEFAULT_APPLICATION, profile, properties );
    }

    @PostMapping( "{application}" )
    public ResponseEntity< Map< String, Object > > writeProperties ( @PathVariable( "application" ) String application, @RequestParam( value = "profile", required = false ) String profile, @RequestBody Map< String, Object > properties ) {
        if ( !StringUtils.hasText( application ) ) {
            return ResponseEntity.badRequest( ).body( Map.of( STATUS, ERROR, MESSAGE, "application must not be empty" ) );
        }

        return doWrite( application, profile, properties );

    }

    @PatchMapping
    public ResponseEntity< Map< String, Object > > patchPropertiesDefault ( @RequestParam( value = "profile", required = false ) final String profile, @RequestBody Map< String, Object > properties ) {
        return doWrite( DEFAULT_APPLICATION, profile, properties );
    }

    @PatchMapping( "{application}" )
    public ResponseEntity< Map< String, Object > > patchProperties ( @PathVariable( "application" ) String application, @RequestParam( value = "profile", required = false ) String profile, @RequestBody Map< String, Object > properties ) {
        if ( !StringUtils.hasText( application ) ) {
            return ResponseEntity.badRequest( ).body( Map.of( STATUS, ERROR, MESSAGE, "application must not be ready" ) );
        }
        return doWrite( application, profile, properties );
    }

    private ResponseEntity< Map< String, Object > > doWrite ( String application, String profile, Map< String, Object > propertiesInput ) {
        String fileName = buildFileName( profile );
        Path appDir = Paths.get( baseDir, application );
        Path filePath = appDir.resolve( fileName );
        try {
            Files.createDirectories( appDir );
            Map< String, Object > existing = loadExistingYaml( filePath );
            Map< String, Object > incoming = toNestedMap( propertiesInput );
            AtomicInteger updatedCount = new AtomicInteger( 0 );
            deepMerge( existing, incoming, updatedCount );
            writeYaml( filePath, existing );

            Map< String, Object > result = new HashMap<>( );
            result.put( STATUS, "ok" );
            result.put( "application", application );
            result.put( "profile", StringUtils.hasText( profile ) ? profile : DEFAULT_PROFILE );
            result.put( "file", filePath.toString( ) );
            result.put( "updated", updatedCount.get( ) );
            result.put( "count", propertiesInput.size( ) );
            return ResponseEntity.status( HttpStatus.CREATED ).body( result );
        } catch ( IOException e ) {
            log.error( "Failed to write YAML to {} :: {}", filePath, e.getMessage( ) );
            return ResponseEntity.status( HttpStatus.INTERNAL_SERVER_ERROR ).body( Map.of( STATUS, ERROR, MESSAGE, e.getMessage( ) ) );
        }
    }


    private String buildFileName ( String profile ) {
        String base = "application";
        if ( StringUtils.hasText( profile ) ) {
            return base + "-" + profile + ".yml";
        }
        return base + ".yml";
    }

    private Map< String, Object > toNestedMap ( Map< String, Object > flat ) {
        Map< String, Object > root = new LinkedHashMap<>( );
        for ( Map.Entry< String, Object > e : flat.entrySet( ) ) {
            String key = e.getKey( );
            Object value = e.getValue( );
            if ( !StringUtils.hasText( key ) ) continue;
            String[] parts = key.split( "\\." );
            Map< String, Object > cursor = root;
            for ( int i = 0; i < parts.length; i++ ) {
                String part = parts[ i ];
                boolean last = ( i == parts.length - 1 );
                if ( last ) {
                    cursor.put( part, value );
                } else {
                    Object next = cursor.get( part );
                    if ( !( next instanceof Map ) ) {
                        Map< String, Object > child = new LinkedHashMap<>( );
                        cursor.put( part, child );
                        cursor = child;
                    } else {
                        cursor = (Map< String, Object >) next;
                    }
                }
            }
        }
        return root;
    }

    private Map< String, Object > loadExistingYaml ( Path filePath ) throws IOException {
        Map< String, Object > existing = new LinkedHashMap<>( );
        if ( Files.exists( filePath ) ) {
            try ( InputStream is = Files.newInputStream( filePath ) ) {
                Object loaded = yaml.load( is );
                if ( loaded instanceof Map< ?, ? > loadedMap ) {
                    Map< String, Object > casted = new LinkedHashMap<>( (Map< String, Object >) loadedMap );
                    existing.putAll( casted );
                }
            }
        }
        return existing;
    }

    private void writeYaml ( Path filePath, Map< String, Object > data ) throws IOException {
        String header = "# Updated by Config Server at " + Instant.now( ) + "\n";
        String dumped = yaml.dump( data );
        try ( OutputStream os = Files.newOutputStream( filePath ) ) {
            os.write( header.getBytes( StandardCharsets.UTF_8 ) );
            os.write( dumped.getBytes( StandardCharsets.UTF_8 ) );
        }
    }

    private void deepMerge ( Map< String, Object > base, Map< String, Object > add, AtomicInteger updatedCount ) {
        for ( Map.Entry< String, Object > e : add.entrySet( ) ) {
            String k = e.getKey( );
            Object v = e.getValue( );
            if ( v instanceof Map< ?, ? > vMap ) {
                Object existing = base.get( k );
                if ( existing instanceof Map< ?, ? > exMap ) {
                    deepMerge( (Map< String, Object >) exMap, (Map< String, Object >) vMap, updatedCount );
                } else {
                    base.put( k, new LinkedHashMap<>( (Map< String, Object >) vMap ) );
                    updatedCount.incrementAndGet( );
                }
            } else {
                final Object prev = base.put( k, v );
                if ( prev == null || !prev.equals( v ) ) {
                    updatedCount.incrementAndGet( );
                }
            }
        }
    }
}
