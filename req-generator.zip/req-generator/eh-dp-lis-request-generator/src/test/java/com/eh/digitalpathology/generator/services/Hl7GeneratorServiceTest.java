package com.eh.digitalpathology.generator.services;

import ca.uhn.hl7v2.HL7Exception;
import com.eh.digitalpathology.generator.config.AppConfig;
import com.eh.digitalpathology.generator.config.Hl7Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

class Hl7GeneratorServiceTest {

    private Hl7Config hl7Config;
    private AppConfig appConfig;

    private Hl7GeneratorService hl7GeneratorService;

    @BeforeEach
    void setUp() throws IOException {
        hl7Config = new Hl7Config();
        appConfig= new AppConfig();
        hl7Config = YamlReader.readYaml("hl7-config.yml" , Hl7Config.class);
        hl7GeneratorService = new Hl7GeneratorService( hl7Config, null );
    }

    @Test
    void createMessage() throws HL7Exception, IOException {
       Map<String, String> hashMap = new HashMap<>();
       hashMap.put("barcode", "395FOE");
       String hl7Message = hl7GeneratorService.createMessage("ORU", hashMap);
       System.out.println(hl7Message);
       Assertions.assertNotNull(hl7Message);
    }


    public void writeHL7ToFile(String filePath, String hl7Message) {
        try ( BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(hl7Message);
            System.out.println("HL7 message successfully written to " + filePath);
        } catch (IOException e) {
            System.err.println("Error writing HL7 message to file: " + e.getMessage());
        }
    }


    @Test
    void createMessageforQBP() throws HL7Exception, IOException {
        Map<String, String> hashMap = new HashMap<>();
        hashMap.put("barcode", "123456");
        String hl7Message = hl7GeneratorService.createMessage("QBP", hashMap);
        System.out.println(hl7Message);
        Assertions.assertNotNull(hl7Message);
    }


}