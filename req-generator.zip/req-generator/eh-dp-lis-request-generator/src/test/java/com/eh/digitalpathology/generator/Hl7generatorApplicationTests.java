package com.eh.digitalpathology.generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class Hl7generatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
