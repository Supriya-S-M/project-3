package com.eh.digitalpathology.generator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
public class PropertiesConfig {

    @Value("${app.message.lis-request}")
    private String lisMessageRequest;
    @Value("${app.message.lis-response}")
    private String lisMessageResponse;

    public String getLisMessageRequest() {
        return lisMessageRequest;
    }


    public String getLisMessageResponse() {
        return lisMessageResponse;
    }

}
