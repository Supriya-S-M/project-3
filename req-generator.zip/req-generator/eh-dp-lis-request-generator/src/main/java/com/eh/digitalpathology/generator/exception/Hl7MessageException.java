package com.eh.digitalpathology.generator.exception;

public class Hl7MessageException extends RuntimeException{

    private final String errorCode;

    private final String errorMessage;

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public Hl7MessageException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.errorMessage = message;
    }
}
