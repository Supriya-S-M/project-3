package com.eh.digitalpathology.generator.services;

import com.eh.digitalpathology.generator.exception.Hl7MessageException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

@Service
@RefreshScope
public class LisResponseListener {
    private static final Logger log = LoggerFactory.getLogger(LisResponseListener.class.getName());
    private final KafkaNotificationProducer kafkaNotificationProducer;

    @Autowired
    public LisResponseListener(KafkaNotificationProducer kafkaNotificationProducer) {
        this.kafkaNotificationProducer = kafkaNotificationProducer;
    }

    @KafkaListener(topics = "${kafka.topic.connect}", groupId = "lis-consumed-group", containerFactory = "kafkaListenerContainerFactory")
    public void handleMicroserviceResponse( ConsumerRecord<String, String> consumerRecord, Acknowledgment ack ) throws Hl7MessageException {
        String key = consumerRecord.key();
        String value = consumerRecord.value( );
        log.info("handleMicroserviceResponse :: key :: {}", key);
        try {
            kafkaNotificationProducer.processingPendingMessages(key, value);
            ack.acknowledge();
        }catch (Exception ex){
            throw new Hl7MessageException("INVALID_ERROR", ex.getMessage());
        }
    }

}
