package com.eh.digitalpathology.generator.model;


public record DicomListenerResponse(String barcode, String sopInstanceUID, String seriesInstanceUID, String deviceSerialNumber) {}
