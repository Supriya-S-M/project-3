package com.eh.digitalpathology.generator.model;

public record Hl7MessageRequest(String hl7Message) { }
