package com.eh.digitalpathology.generator.model;

public record BarcodeInstanceRequest (String barcode, String sopInstanceUid){}
