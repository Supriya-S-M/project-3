package com.eh.digitalpathology.generator.services;

import com.eh.digitalpathology.generator.constants.ApiConstants;
import com.eh.digitalpathology.generator.utils.Hl7MessageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RefreshScope
public class KafkaNotificationProducer {

    @Value("${kafka.topic.enrich}")
    private String enrichTopic;
    private static final Logger log = LoggerFactory.getLogger(KafkaNotificationProducer.class.getName());
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final RedisTemplate<String, String> redisTemplate;
    private static final String CACHE_PREFIX = "request:";

    private final Hl7Service hl7Service;

    @Autowired
    public KafkaNotificationProducer( KafkaTemplate<String, String> kafkaTemplate, RedisTemplate< String, String > redisTemplate, Hl7Service hl7Service) {
        this.kafkaTemplate = kafkaTemplate;
        this.redisTemplate = redisTemplate;
        this.hl7Service = hl7Service;
    }

    public void sendNotification(String topic, String key, String data, boolean isWaiting) {
        if (!isWaiting) {
            try {
                log.info("send notification :: data :: {}, key :: {}", data, key);
                kafkaTemplate.send(topic, key, data);
                log.info("sendNotification:: Message sent successfully to :: {} ", topic);
            } catch (Exception ex) {
                log.error( "Failed to send message to {} : {} ", topic, ex.getMessage( ) );
            }
        } else {
            redisTemplate.opsForList().rightPush(CACHE_PREFIX + key, data);
        }
    }


    public void processingPendingMessages(String key, String value) {
        List<String> messages = redisTemplate.opsForList().range(CACHE_PREFIX + key, 0, -1);
        redisTemplate.delete(key);

        if (messages != null && value.equalsIgnoreCase( "CASE_DATA_STORED" )) {
            for (String message : messages) {
                Map<String, String> extractMessage = Hl7MessageUtils.extractData(message);
                HttpHeaders headers = Hl7MessageUtils.setHeaders(ApiConstants.LIS_CONNECTOR);
                hl7Service.updateStatus(extractMessage.get(ApiConstants.BARCODE), extractMessage.get(ApiConstants.SOP_INSTANCE_ID), headers);
                log.info("processingPendingMessages :: message :: {}", message);
                sendNotification(enrichTopic, key, message, false);
            }
        }else {
            for (String message : messages) {
                Map< String, String > extractMessage = Hl7MessageUtils.extractData( message );
                HttpHeaders headers = Hl7MessageUtils.setHeaders( ApiConstants.NEGATIVE_QUERY );
                hl7Service.updateStatus( extractMessage.get( ApiConstants.BARCODE ), extractMessage.get( ApiConstants.SOP_INSTANCE_ID ), headers );
            }
        }
    }

    public void storePendingMessages(String key, String data) {
        log.info("storePendingMessages:: Storing data for key: {}, {}", key, data);
        redisTemplate.opsForList().rightPush(CACHE_PREFIX + key, data);
    }
}
