package com.eh.digitalpathology.generator.constants;

public class ApiConstants {
    private ApiConstants(){
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
    public static final String MESSAGE_TYPE = "messageType";
    public static final String BARCODE = "barcode";
    public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
    public static final String SOP_INSTANCE_ID = "sopInstanceUID";
    public static final String MESSAGE_GENERATOR = "message-generator";
    public static final String LIS_CONNECTOR = "lis-connector";
    public static final String NEGATIVE_QUERY = "lis-negative";
}
