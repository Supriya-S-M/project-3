package com.eh.digitalpathology.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hl7generatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hl7generatorApplication.class, args);
	}

}
