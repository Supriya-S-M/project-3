package com.eh.digitalpathology.generator.services;

import com.eh.digitalpathology.generator.config.PropertiesConfig;
import com.eh.digitalpathology.generator.constants.ApiConstants;
import com.eh.digitalpathology.generator.enums.ValueStatus;
import com.eh.digitalpathology.generator.exception.Hl7MessageException;
import com.eh.digitalpathology.generator.model.Hl7MessageRequest;
import com.eh.digitalpathology.generator.utils.Hl7MessageUtils;
import jakarta.annotation.PostConstruct;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;

@Service
@RefreshScope
public class KafkaMessageListener {

    private static final Logger log = LoggerFactory.getLogger( KafkaMessageListener.class.getName( ) );
    private final KafkaNotificationProducer kafkaNotificationProducer;
    private final Hl7Service hl7Service;
    private final Hl7GeneratorService hl7GeneratorService;
    private final PropertiesConfig propertiesConfig;

    private final ExecutorService executorService;
    private final ConcurrentMap< String, Future< ? > > inProgressApiCalls = new ConcurrentHashMap<>( );
    private final ConcurrentSkipListSet< String > processedKeys = new ConcurrentSkipListSet<>( );

    @Value("${kafka.topic.enrich}")
    private String enrichTopic;
    @Value("${kafka.topic.lis}")
    private String lisTopic;

    @Autowired
    public KafkaMessageListener ( KafkaNotificationProducer kafkaNotificationProducer, Hl7Service hl7Service, Hl7GeneratorService hl7GeneratorService, PropertiesConfig propertiesConfig, @Qualifier("hl7ExecutorService") ExecutorService executorService ) {
        this.kafkaNotificationProducer = kafkaNotificationProducer;
        this.hl7Service = hl7Service;
        this.hl7GeneratorService = hl7GeneratorService;
        this.propertiesConfig = propertiesConfig;
        this.executorService = executorService;
    }

    @PostConstruct
    public void init(){
        processedKeys.clear();
        inProgressApiCalls.clear();
    }

    @KafkaListener( topics = "${kafka.topic.dcm}", groupId = "metadata-consumer-group", containerFactory = "kafkaListenerContainerFactory" )
    public void listen ( ConsumerRecord< String, String > consumerRecord, Acknowledgment ack ) throws Hl7MessageException {
        String message = consumerRecord.value( );
        Map< String, String > extractData = Hl7MessageUtils.extractData( message );
        log.info( "listen:: Extracted data: {}", extractData );

        if ( extractData == null || extractData.isEmpty( ) ) return;

        if ( extractData.get( ApiConstants.BARCODE ) == null ) {
            throw new Hl7MessageException( "BAD_REQUEST", "barcode cannot be null" );
        }

        try {
            Map< String, Set< String > > response = hl7Service.fetchMessagesAndStatus( extractData.get( ApiConstants.BARCODE ) );
            log.info( "listen :: response :: {}", response );
            ValueStatus status = determineStatus( response );

            switch ( status ) {
                case CASE_DATA_RECEIVED -> {
                    HttpHeaders headers = Hl7MessageUtils.setHeaders( ApiConstants.LIS_CONNECTOR );
                    hl7Service.updateStatus( extractData.get( ApiConstants.BARCODE ), extractData.get( ApiConstants.SOP_INSTANCE_ID ), headers );
                    kafkaNotificationProducer.sendNotification( enrichTopic, extractData.get( ApiConstants.BARCODE ), consumerRecord.value( ), false );
                    ack.acknowledge( );
                }
                case REQUEST_GENERATED -> {
                    HttpHeaders headers = Hl7MessageUtils.setHeaders( ApiConstants.MESSAGE_GENERATOR );
                    hl7Service.updateStatus( extractData.get( ApiConstants.BARCODE ), extractData.get( ApiConstants.SOP_INSTANCE_ID ), headers );
                    kafkaNotificationProducer.storePendingMessages( extractData.get( ApiConstants.BARCODE ), consumerRecord.value( ) );
                    ack.acknowledge( );
                }
                case NONE_PRESENT -> {
                    log.info( "listen:: NON_PRESENT:: lis request :: {}", propertiesConfig.getLisMessageRequest( ) );

                    CompletableFuture< Void > future = queueOrProcessRequest( extractData, consumerRecord );
                    inProgressApiCalls.put( extractData.get( ApiConstants.BARCODE ), future );

                    future.thenRun( ( ) -> {
                        log.info( "Async processing completed for barcode: {}", extractData.get( ApiConstants.BARCODE ) );
                        ack.acknowledge( );
                        inProgressApiCalls.remove( extractData.get( ApiConstants.BARCODE ) );
                    } ).exceptionally( ex -> {
                        log.error( "Async task failed, message not acknowledged", ex );
                        inProgressApiCalls.remove( extractData.get( ApiConstants.BARCODE ) );
                        return null;
                    } );
                }
            }
        } catch ( Exception e ) {
            throw new Hl7MessageException( "INVALID_ERROR", e.getMessage( ) );
        }
    }

    private CompletableFuture<Void> queueOrProcessRequest(Map<String, String> extractData, ConsumerRecord<String, String> consumerRecord) {
        String barcode = extractData.get(ApiConstants.BARCODE);
        log.info("queueOrProcessRequest :: barcode :: {}", barcode);
        log.info("queueOrProcessRequest :: processedKeys :: {}", processedKeys);

        if (processedKeys.contains(barcode)) {
            handleAlreadyProcessing(barcode, extractData, consumerRecord);
            return CompletableFuture.completedFuture(null);
        }

        processedKeys.add(barcode);
        kafkaNotificationProducer.storePendingMessages(barcode, consumerRecord.value());

        String processedMessage;
        try {
            processedMessage = hl7GeneratorService.createMessage(propertiesConfig.getLisMessageRequest(), extractData);
            log.info("queueOrProcessRequest :: processedMessage :: {}", processedMessage);
        } catch (Exception e) {
            handleMessageCreationFailure(barcode, e);
            return CompletableFuture.completedFuture(null);
        }

        return processMessageAsync(barcode, extractData, processedMessage);
    }

    private void handleAlreadyProcessing(String barcode, Map<String, String> extractData, ConsumerRecord<String, String> consumerRecord) {
        log.debug("handleAlreadyProcessing :: already processing, storing pending message");
        HttpHeaders headers = Hl7MessageUtils.setHeaders(ApiConstants.MESSAGE_GENERATOR);
        hl7Service.updateStatus(barcode, extractData.get(ApiConstants.SOP_INSTANCE_ID), headers);
        kafkaNotificationProducer.storePendingMessages(barcode, consumerRecord.value());
    }

    private void handleMessageCreationFailure(String barcode, Exception e) {
        log.error("handleMessageCreationFailure :: Exception occurred while creating message", e);
        kafkaNotificationProducer.sendNotification("email-svc-topic", "QUERY_INCORRECT", barcode, false);
        processedKeys.remove(barcode);
    }

    private CompletableFuture<Void> processMessageAsync(String barcode, Map<String, String> extractData, String processedMessage) {
        return CompletableFuture.runAsync(() -> {
            log.info("processMessageAsync :: inside async task");
            boolean success = retryPersistAndNotify(barcode, extractData, processedMessage);
            processedKeys.remove(barcode);
        }, executorService);
    }

    private boolean retryPersistAndNotify(String barcode, Map<String, String> extractData, String message) {
        int maxRetries = 3;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                Hl7MessageRequest hl7MessageRequest = new Hl7MessageRequest(message);
                log.info("retryPersistAndNotify :: call is made to persist messages");
                String apiResponse = hl7Service.persistsMessages(hl7MessageRequest, Hl7MessageUtils.setHeaders(ApiConstants.MESSAGE_GENERATOR));
                hl7Service.updateStatus(barcode, extractData.get(ApiConstants.SOP_INSTANCE_ID), Hl7MessageUtils.setHeaders(ApiConstants.MESSAGE_GENERATOR));
                kafkaNotificationProducer.sendNotification(lisTopic, barcode, hl7MessageRequest.hl7Message(), false);
                log.info("retryPersistAndNotify :: apiResponse :: {}", apiResponse);
                return true;
            } catch (Exception e) {
                log.error("retryPersistAndNotify :: exception is thrown :: {}", e.getMessage());
                if (attempt == maxRetries) {
                    log.error("retryPersistAndNotify :: Maximum retries reached for keys :: {}", barcode);
                } else {
                    sleepBeforeRetry();
                }
            }
        }
        return false;
    }

    private void sleepBeforeRetry() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }


    private ValueStatus determineStatus ( Map< String, Set< String > > response ) {
        Set< String > valueList = response.get( ApiConstants.MESSAGE_TYPE );
        if ( valueList == null || valueList.isEmpty( ) ) {
            return ValueStatus.NONE_PRESENT;
        }

        boolean firstExists = valueList.stream( ).anyMatch( item -> item.contains( propertiesConfig.getLisMessageRequest( ) ) );
        log.info( "determineStatus :: firstExists :: {}", firstExists );
        boolean secondExists = valueList.stream( ).anyMatch( item -> item.contains( propertiesConfig.getLisMessageResponse( ) ) );
        log.info( "determineStatus :: secondExists :: {}", secondExists );
        if ( firstExists && secondExists ) return ValueStatus.CASE_DATA_RECEIVED;
        if ( !firstExists && !secondExists ) return ValueStatus.NONE_PRESENT;
        return ValueStatus.REQUEST_GENERATED;
    }

}
