package com.eh.digitalpathology.generator.enums;

public enum ValueStatus {
    CASE_DATA_RECEIVED,
    REQUEST_GENERATED,
    NONE_PRESENT
}
