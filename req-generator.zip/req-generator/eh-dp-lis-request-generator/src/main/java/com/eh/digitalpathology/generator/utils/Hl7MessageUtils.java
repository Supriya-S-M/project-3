package com.eh.digitalpathology.generator.utils;

import com.eh.digitalpathology.generator.exception.Hl7MessageException;
import com.eh.digitalpathology.generator.model.DicomListenerResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

public class Hl7MessageUtils {

    private static final Logger log = LoggerFactory.getLogger(Hl7MessageUtils.class.getName());
    private Hl7MessageUtils(){}
    private static final Random RANDOM = new Random();

    public static String getCurrentUTCTime(){
        ZonedDateTime utcTime = ZonedDateTime.now(ZoneOffset.UTC);
        // Format the date and time in yyyyMMddHHmmss format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        return utcTime.format(formatter);
    }

    public static String randomNumber(){
        long currentTimeMillis = System.currentTimeMillis();
        int randomSuffix = RANDOM.nextInt(100000); // Add randomness to the ID
        return "" + currentTimeMillis + randomSuffix;
    }

    public static String generateRandom(){
        return UUID.randomUUID().toString();
    }

    public static HttpHeaders setHeaders(String serviceName){
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Service-Name", serviceName);
        return headers;
    }

    public static Map<String, String> extractData(String consumerRecordValue) {
        log.info("extractData :: Received message: {}", consumerRecordValue);
        if (consumerRecordValue == null || consumerRecordValue.isEmpty()) {
            log.error("extractData :: Received empty message");
            return new HashMap<>();
        }

        ObjectMapper objectMapper = new ObjectMapper();
        DicomListenerResponse dicomListenerResponse;
        try {
            dicomListenerResponse = objectMapper.readValue(consumerRecordValue, DicomListenerResponse.class);
            log.info("extractData :: Extracted dynamic values: {}", dicomListenerResponse);
        } catch (JsonProcessingException e) {
            throw new Hl7MessageException("INVALID_STATUS", e.getMessage());
        }
        return  objectMapper.convertValue(dicomListenerResponse, new TypeReference<>() {});
    }
}
