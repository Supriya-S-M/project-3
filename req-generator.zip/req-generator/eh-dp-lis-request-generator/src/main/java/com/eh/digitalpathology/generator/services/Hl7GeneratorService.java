package com.eh.digitalpathology.generator.services;


import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.*;
import ca.uhn.hl7v2.parser.DefaultModelClassFactory;
import ca.uhn.hl7v2.parser.ModelClassFactory;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;
import com.eh.digitalpathology.generator.config.AppConfig;
import com.eh.digitalpathology.generator.config.Hl7Config;
import com.eh.digitalpathology.generator.exception.Hl7MessageException;
import com.eh.digitalpathology.generator.utils.Hl7MessageUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class Hl7GeneratorService {
    private static final Logger log = LoggerFactory.getLogger( Hl7GeneratorService.class.getName( ) );
    private final Hl7Config hl7Config;
    private final AppConfig appConfig;

    public Hl7GeneratorService ( Hl7Config hl7Config, AppConfig appConfig ) {
        this.hl7Config = hl7Config;
        this.appConfig = appConfig;
    }

    public String createMessage ( String type, Map< String, String > data ) throws HL7Exception, IOException {

        log.info( "createMessage:: create Message :: type :: {}", type );
        //template will get from yaml
        Hl7Config.MessageTemplate template = hl7Config.getMessages( ).get( type.toUpperCase( ) );
        if ( template == null ) {
            throw new IllegalArgumentException( "Invalid hl7 message type: " + type );
        }

        Map< String, String > dynamicValues = fetchDynamicValues( template );
        data.forEach( dynamicValues::putIfAbsent );

        log.info( "create Message :: dynamicValues :: {}", dynamicValues );
        Message message = createDynamicMessage( template, dynamicValues );
        PipeParser parser = new PipeParser( );
        String encodedMessage = parser.encode( message ).replace( "\\T\\", "&" ).replace( "\\S\\", "^" ).replace( "\\R\\", "~" );
        log.info( "createMessage :: Encoded HL7 Message: \n {}", encodedMessage );
        return encodedMessage;
    }

    private Message createDynamicMessage ( Hl7Config.MessageTemplate template, Map< String, String > dynamicValues ) throws HL7Exception, IOException {

        ModelClassFactory factory = new DefaultModelClassFactory( );
        String messageClassName = String.format( "%s_%s", template.getMessageType( ), template.getTriggerEvent( ) );
        String hl7Version = template.getVersion( );
        log.error( "createDynamicMessage:: Attempting to resolve message class:: {} for version: {}", messageClassName, template.getVersion( ) );
        Class< ? extends Message > messageClass = factory.getMessageClass( messageClassName, hl7Version, false );

        Message message = instantiateMessage( messageClass );
        if ( message instanceof AbstractMessage abstractMessage ) {
            abstractMessage.initQuickstart( template.getMessageType( ), template.getTriggerEvent( ), "P" );
        }

        Terser terser = new Terser( message );
        for ( Hl7Config.Segment segmentConfig : template.getSegments( ) ) {
            Structure segment = findSegmentDynamically( message, segmentConfig.getName( ) );
            log.info( "createDynamicMessage :: segment :: {}", segment );
            if ( segment instanceof Segment ) {
                populateSegment( terser, segmentConfig, dynamicValues, message );
            } else {
                throw new HL7Exception( "Segment " + segmentConfig.getName( ) + " not found in message." );
            }
        }
        return message;
    }

    private Message instantiateMessage ( Class< ? extends Message > messageClass ) {
        try {
            return messageClass.getDeclaredConstructor( ).newInstance( );
        } catch ( Exception e ) {
            throw new Hl7MessageException( "EXCEPTION", e.getMessage( ) );
        }
    }

    private Map< String, String > fetchDynamicValues ( Hl7Config.MessageTemplate template ) {
        Map< String, String > dynamicValues = new HashMap<>( );
        Set< String > placeHolders = extractPlaceholdersFromTemplates( template );
        for ( String placeholder : placeHolders ) {
            if ( isUtilityPlaceholder( placeholder ) ) {
                dynamicValues.put( placeholder, resolveUtilityPlaceholder( placeholder ) );
            }
        }
        return dynamicValues;

    }

    private String resolveUtilityPlaceholder ( String placeholder ) {
        return switch ( placeholder ) {
            case "currentDateTime" -> Hl7MessageUtils.getCurrentUTCTime();
            case "messageControl" -> Hl7MessageUtils.randomNumber( );
            case "controlId" -> Hl7MessageUtils.generateRandom( );
            case "sendingApp" -> appConfig.getSendingApp( );
            case "sendingFacility" -> appConfig.getSendingFacility( );
            case "receivingApp" -> appConfig.getReceivingApp( );
            case "receivingFacility" -> appConfig.getReceivingFacility( );
            default -> "";
        };
    }

    private boolean isUtilityPlaceholder ( String placeholder ) {
        return Set.of( "currentDateTime", "messageControl", "controlId", "sendingApp", "sendingFacility", "receivingApp", "receivingFacility" ).contains( placeholder );
    }

    private Set< String > extractPlaceholdersFromTemplates ( Hl7Config.MessageTemplate template ) {
        Set< String > placeHolders = new HashSet<>( );
        Pattern pattern = Pattern.compile( "\\{([^}]+)}" );
        template.getSegments( ).forEach( segment ->
            segment.getFields( ).forEach( field -> {
                Matcher matcher = pattern.matcher( field.getValue( ) );
                while ( matcher.find( ) ) {
                    placeHolders.add( matcher.group( 1 ) );
                }
            } )
         );
        return placeHolders;
    }

    private Structure findSegmentDynamically ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            try {
                Structure segment = group.get( segmentName );
                if ( segment != null ) {
                    return segment;
                }
            } catch ( HL7Exception e ) {
                log.error( "Unable to find segment in group :: {}", e.getMessage( ) );
            }
            for ( String groupName : group.getNames( ) ) {
                Structure nestedStructure = group.get( groupName );
                if ( nestedStructure instanceof Group ) {
                    try {
                        return findSegmentDynamically( nestedStructure, segmentName );
                    } catch ( HL7Exception ex ) {
                        log.error( "Unable to find in segment group {} ", ex.getMessage( ) );
                    }
                }
            }
        }
        throw new HL7Exception( "Segment " + segmentName + " not found in message." );
    }

    private void populateSegment ( Terser terser, Hl7Config.Segment segmentConfig, Map< String, String > dynamicValues, Message message ) throws HL7Exception {
        for ( Hl7Config.Field field : segmentConfig.getFields( ) ) {
            String value = field.getValue( );
            for ( Map.Entry< String, String > dynamicValue : dynamicValues.entrySet( ) ) {
                value = value.replace( "{" + dynamicValue.getKey( ) + "}", dynamicValue.getValue( ) );
            }
            value = value.replaceAll( "\\{[^}]+\\}", "" );
            try {
                String fullPath = getTerserPath( message, segmentConfig.getName( ), field.getPath( ) );
                log.info( "populateSegment :: full path of segment Name:: {}", fullPath );
                if ( field.getPath( ).matches( ".*-\\d+\\.\\d+$" ) ) {
                    // Handle subcomponents
                    String[] parts = field.getPath( ).split( "\\." );
                    String baseField = parts[ 0 ];
                    int subcomponentIndex = Integer.parseInt( parts[ 1 ] );
                    terser.set( baseField + "-" + subcomponentIndex, value );
                } else {
                    terser.set( fullPath, value );
                }

            } catch ( Exception e ) {
                throw new HL7Exception( "Error setting hl7 fields : " + field.getPath( ) + "with value : " + value, e );
            }
        }
    }

    private String getTerserPath ( Message message, String segmentName, String fieldPath ) throws HL7Exception {
        Group parentGroup = findParentGroup( message, segmentName );
        if ( parentGroup == null ) {
            // If the parent group is null, the segment is directly under the root message
            return '/' + fieldPath;
        }
        return '/' + getGroupPath( message, parentGroup ) + '/' + fieldPath;
    }

    private Group findParentGroup ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            for ( String name : group.getNames( ) ) {
                Structure nestedStructure = group.get( name );
                if ( nestedStructure instanceof Group nestedGroup ) {
                    if ( Arrays.asList( nestedGroup.getNames( ) ).contains( segmentName ) ) {
                        return nestedGroup;
                    }
                    Group parentGroup = findParentGroup( nestedGroup, segmentName );
                    if ( parentGroup != null ) {
                        return parentGroup;
                    }
                }
            }
        }
        return null;
    }

    private String getGroupPath ( Message message, Group group ) {
        if ( group.equals( message ) ) {
            return "";
        }
        Group parentGroup = group.getParent( );
        if ( parentGroup == null || parentGroup.equals( message ) ) {
            return group.getName( );
        }
        return getGroupPath( message, parentGroup ) + '/' + group.getName( );
    }

}
