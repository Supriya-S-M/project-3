package com.eh.digitalpathology.generator.services;

import com.eh.digitalpathology.generator.client.DBRestClient;
import com.eh.digitalpathology.generator.constants.ApiConstants;
import com.eh.digitalpathology.generator.exception.Hl7MessageException;
import com.eh.digitalpathology.generator.model.ApiResponse;
import com.eh.digitalpathology.generator.model.BarcodeInstanceRequest;
import com.eh.digitalpathology.generator.model.Hl7MessageRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Set;

@Service
public class Hl7Service {
    private static final Logger log = LoggerFactory.getLogger(Hl7Service.class.getName());
    private final DBRestClient dbRestClient;

    private static final String SEARCH_URL = "hl7/search/barcode/";
    private static final String PERSISTS_URL = "hl7/persists";

    public Hl7Service(DBRestClient dbRestClient) {
        this.dbRestClient = dbRestClient;
    }

    public Map<String, Set<String>> fetchMessagesAndStatus(String barcode) {
        String uri = SEARCH_URL + barcode;
        try {
            return dbRestClient.exchange(HttpMethod.GET, uri, null, new ParameterizedTypeReference<ApiResponse<Map<String, Set<String>>>>() {
                    }, null)
                    .map(ApiResponse::content)
                    .block();
        } catch (Hl7MessageException ex) {
            throw new Hl7MessageException(ex.getErrorCode(), ex.getErrorMessage());
        } catch (Exception e) {
            throw new Hl7MessageException(ApiConstants.UNKNOWN_ERROR, e.getMessage());
        }
    }

    public String updateStatus(String barcode, String sopInstanceUid, HttpHeaders headers) {
        String uri = "dicom/status/instances";
        BarcodeInstanceRequest barcodeInstanceRequest = new BarcodeInstanceRequest(barcode, sopInstanceUid);
        try {
            return dbRestClient.exchange(HttpMethod.PUT, uri, barcodeInstanceRequest, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::status)
                    .block();
        } catch (Hl7MessageException ex) {
            throw new Hl7MessageException(ex.getErrorCode(), ex.getErrorMessage());
        } catch (Exception e) {
            throw new Hl7MessageException(ApiConstants.UNKNOWN_ERROR, e.getMessage());
        }
    }

    public String persistsMessages(Hl7MessageRequest messagesRequest, HttpHeaders headers) {
        try {
            log.debug("persistsMessages:: call is made to persist messages");
            String apiResponse =  dbRestClient.exchange(HttpMethod.POST, PERSISTS_URL, messagesRequest, new ParameterizedTypeReference<ApiResponse<Map<String,String>>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::status)
                    .block();
            log.info("persistsMessages :: apiResponse in Hl7Service :: {}", apiResponse);
            return  apiResponse;
        } catch (Hl7MessageException ex) {
            throw new Hl7MessageException(ex.getErrorCode(), ex.getErrorMessage());
        } catch (Exception e) {
            throw new Hl7MessageException(ApiConstants.UNKNOWN_ERROR, e.getMessage());
        }
    }
}
