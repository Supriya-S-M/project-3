package com.eh.digitalpathology.dicomreceiver.service;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class RedisClient {

    private final RedisTemplate< String, Object > redisTemplate;

    public RedisClient ( RedisTemplate< String, Object > redisTemplate ) {
        this.redisTemplate = redisTemplate;
    }


    public boolean isFileProcessed ( String fileKey ) {
        return Boolean.TRUE.equals(redisTemplate.hasKey(fileKey));
    }

    public void markFileAsProcessed ( String fileKey ) {
        redisTemplate.opsForValue( ).set( fileKey, "processed", java.time.Duration.ofDays( 2 ) );
    }

    /**
     * Try to acquire a lock for a file. Returns true if lock is acquired, false otherwise.
     */
    public boolean tryLockFile ( String fileKey, Duration lockDuration ) {
        Boolean success = redisTemplate.opsForValue( ).setIfAbsent( fileKey + ":lock", "LOCKED", lockDuration );
        return Boolean.TRUE.equals( success );
    }

    /**
     * Release the lock manually if needed.
     */
    public void releaseFileLock ( String fileKey ) {
        redisTemplate.delete( fileKey + ":lock" );
    }

}


