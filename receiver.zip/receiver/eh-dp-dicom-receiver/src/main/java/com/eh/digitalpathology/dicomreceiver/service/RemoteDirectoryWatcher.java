package com.eh.digitalpathology.dicomreceiver.service;

import com.eh.digitalpathology.dicomreceiver.config.SharedFolderConfig;
import com.eh.digitalpathology.dicomreceiver.constants.WatchDirectoryConstant;
import jcifs.CIFSContext;
import jcifs.config.PropertyConfiguration;
import jcifs.context.BaseContext;
import net.idauto.oss.jcifsng.vfs2.provider.SmbFileSystemConfigBuilder;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.auth.StaticUserAuthenticator;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class RemoteDirectoryWatcher {
    private static final Logger logger = LoggerFactory.getLogger( RemoteDirectoryWatcher.class );

    private final SharedFolderConfig sharedFolderConfig;
    private final RemoteDirectoryService remoteDirectoryService;
    private final AtomicInteger processedFileCount = new AtomicInteger( 0 );
    private long lastLogTime = System.currentTimeMillis( );
    private final RedisClient redisClient;
    private final ScheduledExecutorService scheduler;
    private static final String SMB_CLIENT_MAX_VERSION = "SMB311";
    private static final String SMB_CLIENT_MIN_VERSION = "SMB202";

    public RemoteDirectoryWatcher ( SharedFolderConfig sharedFolderConfig, RemoteDirectoryService remoteDirectoryService, RedisClient redisClient, @Qualifier( "remoteDirectoryWatcherScheduledExecutor" ) ScheduledExecutorService scheduler ) {
        this.sharedFolderConfig = sharedFolderConfig;
        this.remoteDirectoryService = remoteDirectoryService;
        this.redisClient = redisClient;
        this.scheduler = scheduler;
    }

    public void watchSharedDirectory ( ) {
        logger.info( "watchSharedDirectory :: Starting directory watch..." );
        try {
            Properties jcifsProperties = new Properties( );
            jcifsProperties.setProperty( WatchDirectoryConstant.SMB_MIN_VERSION, SMB_CLIENT_MIN_VERSION );
            jcifsProperties.setProperty( WatchDirectoryConstant.SMB_MAX_VERSION, SMB_CLIENT_MAX_VERSION );
            CIFSContext jcifsContext = new BaseContext( new PropertyConfiguration( jcifsProperties ) );
            FileSystemOptions options = new FileSystemOptions( );

            if ( !StringUtils.isEmpty( sharedFolderConfig.getUsername( ) ) && !StringUtils.isEmpty( sharedFolderConfig.getPassword( ) ) ) {
                StaticUserAuthenticator auth = new StaticUserAuthenticator( "", sharedFolderConfig.getUsername( ), sharedFolderConfig.getPassword( ) );
                DefaultFileSystemConfigBuilder.getInstance( ).setUserAuthenticator( options, auth );
            }

            SmbFileSystemConfigBuilder.getInstance( ).setCIFSContext( options, jcifsContext );
            String smbUrl = new URIBuilder( ).setScheme( WatchDirectoryConstant.SMB ).setHost( sharedFolderConfig.getServername( ) ).setPath( sharedFolderConfig.getSharepath( ) ).toString( );

            resolveSharedFolder( smbUrl, options );
        } catch ( Exception e ) {
            logger.error( "watchSharedDirectory :: Error initializing watcher for server: {} and share: {}", sharedFolderConfig.getServername( ), sharedFolderConfig.getSharepath( ), e );
        }
    }

    private void resolveSharedFolder ( String smbUrl, FileSystemOptions options ) {
        logger.info( "resolveSharedFolder :: Monitoring directory: {}", smbUrl );
        scheduler.scheduleAtFixedRate( ( ) -> {
            try {
                FileSystemManager fsManager = VFS.getManager( );
                try ( FileObject remoteDirectory = fsManager.resolveFile( smbUrl, options ) ) {
                    scanDirectoryRecursively( remoteDirectory, smbUrl );
                }
            } catch ( Exception e ) {
                logger.error( "resolveSharedFolder :: Error during scheduled scan", e );
            }
        }, 0, 5, TimeUnit.SECONDS );
    }

    private void scanDirectoryRecursively ( FileObject directory, String smbUrl ) {
        try {
            directory.refresh( );
            FileObject[] children = directory.getChildren( );
            for ( FileObject child : children ) {
                if ( child.isHidden( ) ) {
                    logger.debug( "scanDirectoryRecursively :: Skipping hidden item: {}", child.getName( ).getPath( ) );
                    continue;
                }

                if ( child.getType( ) == FileType.FOLDER ) {
                    scanDirectoryRecursively( child, smbUrl );
                } else if ( child.getType( ) == FileType.FILE ) {
                    handleFile( child, smbUrl );
                }
            }

            if ( System.currentTimeMillis( ) - lastLogTime > 60000 ) {
                logger.info( "scanDirectoryRecursively :: Scan Summary: Total processed files: {}", processedFileCount.get( ) );
                lastLogTime = System.currentTimeMillis( );
            }

        } catch ( Exception e ) {
            logger.error( "scanDirectoryRecursively :: Error scanning directory: {}", directory.getName( ), e );
        }
    }

    private void handleFile(FileObject file, String smbUrl) {
        String fileKey = file.getName( ).getPath( );

        if ( !redisClient.isFileProcessed( fileKey ) ) {
            if ( redisClient.tryLockFile( fileKey, Duration.ofMinutes( 2 ) ) && isFileStable( file ) ) {
                try {
                    processedFileCount.incrementAndGet( );
                    logger.info( "handleFile :: New file detected: {}", file.getName( ) );
                    remoteDirectoryService.processFileEvent( file, smbUrl, sharedFolderConfig.getUsername( ), sharedFolderConfig.getPassword( ), sharedFolderConfig.getServername( ), sharedFolderConfig.getSharepath( ) );
                    redisClient.markFileAsProcessed( fileKey );
                } catch ( Exception e ) {
                    logger.error( "handleFile :: Error processing file: {}", fileKey, e );
                } finally {
                    redisClient.releaseFileLock( fileKey );
                }
                // No manual release of lock; let Redis expire it
            } else {
                logger.debug( "handleFile :: File is being processed by another thread: {}", fileKey );
                // Will retry in next scan cycle
            }
        }
    }

    private boolean isFileStable ( FileObject file ) {
        try {
            long size1 = file.getContent( ).getSize( );
            Thread.sleep( 15000 );
            file.refresh( );
            long size2 = file.getContent( ).getSize( );
            return size1 == size2;
        } catch ( Exception e ) {
            Thread.currentThread( ).interrupt( );
            logger.error( "isFileStable :: Error checking file stability", e );
            return false;
        }
    }
}
