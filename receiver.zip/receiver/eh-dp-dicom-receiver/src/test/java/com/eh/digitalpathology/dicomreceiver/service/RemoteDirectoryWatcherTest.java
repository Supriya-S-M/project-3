package com.eh.digitalpathology.dicomreceiver.service;

import com.eh.digitalpathology.dicomreceiver.config.SharedFolderConfig;
import net.idauto.oss.jcifsng.vfs2.provider.SmbFileSystemConfigBuilder;
import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.impl.DefaultFileSystemConfigBuilder;
import org.apache.http.client.utils.URIBuilder;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import java.util.concurrent.*;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RemoteDirectoryWatcherTest {

    @Mock
    private RemoteDirectoryService mockRemoteDirectoryService;
    @Mock
    private RedisClient mockRedisClient;
    @Mock
    private SharedFolderConfig sharedFolderConfig;
    @Mock
    private FileSystemManager fileSystemManager;
    @Mock
    private ScheduledExecutorService scheduledExecutorService;
    @Mock
    private FileObject mockDirectory;

    private RemoteDirectoryWatcher watcher;

    @BeforeEach
    void setup() {
        watcher = new RemoteDirectoryWatcher(sharedFolderConfig, mockRemoteDirectoryService, mockRedisClient, scheduledExecutorService);
    }

    @Test
    void testScanDirectoryRecursively_NewFileProcessed() throws Exception {

        when(sharedFolderConfig.getUsername()).thenReturn("user");
        when(sharedFolderConfig.getPassword()).thenReturn("pass");
        when(sharedFolderConfig.getServername()).thenReturn("server");
        when(sharedFolderConfig.getSharepath()).thenReturn("/path");

        FileObject mockFile = mock(FileObject.class);
        FileName mockName = mock(FileName.class);
        FileContent mockContent = mock(FileContent.class);

        when(mockDirectory.getChildren()).thenReturn(new FileObject[]{mockFile});
        when(mockFile.getType()).thenReturn(FileType.FILE);
        when(mockFile.isHidden()).thenReturn(false);
        when(mockFile.getName()).thenReturn(mockName);
        when(mockName.getPath()).thenReturn("/files/sample.txt");
        when(mockFile.getContent()).thenReturn(mockContent);

        when(mockRedisClient.isFileProcessed(anyString())).thenReturn(false);
        when(mockRedisClient.tryLockFile(anyString(), any())).thenReturn(true);

        ReflectionTestUtils.invokeMethod(watcher, "scanDirectoryRecursively", mockDirectory, "/files");

        verify(mockRedisClient).markFileAsProcessed(anyString());
        verify(mockRemoteDirectoryService).processFileEvent(any(), any(), any(), any(), any(), any());
    }

    @Test
    void testResolveSharedFolder_SuccessfulScheduling() throws Exception {
        String smbUrl = "/server/share";
        FileSystemOptions options = new FileSystemOptions();

        try (MockedStatic<VFS> vfsMock = mockStatic(VFS.class)) {
            vfsMock.when(VFS::getManager).thenReturn(fileSystemManager);
            when(fileSystemManager.resolveFile(smbUrl, options)).thenReturn(mockDirectory);

            when(mockDirectory.getChildren()).thenReturn(new FileObject[0]);

            ArgumentCaptor<Runnable> runnableCaptor = ArgumentCaptor.forClass(Runnable.class);
            when(scheduledExecutorService.scheduleAtFixedRate(
                    runnableCaptor.capture(), eq(0L), eq(5L), eq(TimeUnit.SECONDS)))
                    .thenReturn(mock(ScheduledFuture.class));

            ReflectionTestUtils.invokeMethod(watcher, "resolveSharedFolder", smbUrl, options);
            runnableCaptor.getValue().run();

            verify(fileSystemManager).resolveFile(smbUrl, options);
            verify(scheduledExecutorService).scheduleAtFixedRate(any(Runnable.class),
                    eq(0L), eq(5L), eq(TimeUnit.SECONDS));
        }
    }

    @Test
    void testScanDirectoryRecursively_HiddenFileSkipped() throws Exception {

        FileObject mockHidden = mock(FileObject.class);
        FileName mockHiddenName = mock(FileName.class);

        when(mockDirectory.getChildren()).thenReturn(new FileObject[]{mockHidden});
        when(mockHidden.isHidden()).thenReturn(true);
        when(mockHidden.getName()).thenReturn(mockHiddenName);
        when(mockHiddenName.getPath()).thenReturn("/hidden/.secretFile");
        doNothing().when(mockDirectory).refresh();

        ReflectionTestUtils.invokeMethod(watcher, "scanDirectoryRecursively", mockDirectory, "/hidden");

        verify(mockHidden, never()).getType();
        verify(mockRemoteDirectoryService, never())
                .processFileEvent(any(), any(), any(), any(), any(), any());
    }


    @Test
    void testScanDirectoryRecursively_SubFolderScanned() throws Exception {
        FileObject subFolder = mock(FileObject.class);
        when(mockDirectory.getChildren()).thenReturn(new FileObject[]{subFolder});
        when(subFolder.isHidden()).thenReturn(false);
        when(subFolder.getType()).thenReturn(FileType.FOLDER);
        when(subFolder.getChildren()).thenReturn(new FileObject[0]);

        ReflectionTestUtils.invokeMethod(watcher, "scanDirectoryRecursively", mockDirectory, "/folder");

        verify(subFolder).getChildren();
        verify(mockDirectory).getChildren();
    }

    @Test
    void testWatchSharedDirectory_SuccessFlow() {

        when(sharedFolderConfig.getUsername()).thenReturn("user");
        when(sharedFolderConfig.getPassword()).thenReturn("pass");
        when(sharedFolderConfig.getServername()).thenReturn("server");
        when(sharedFolderConfig.getSharepath()).thenReturn("/share");

        RemoteDirectoryWatcher spyWatcher = Mockito.spy(watcher);
        try (MockedStatic<SmbFileSystemConfigBuilder> smbMock = mockStatic(SmbFileSystemConfigBuilder.class);
             MockedStatic<DefaultFileSystemConfigBuilder> defaultMock = mockStatic(DefaultFileSystemConfigBuilder.class);
             MockedConstruction<URIBuilder> uriBuilderMock = mockConstruction(URIBuilder.class, (builder, context) -> {
                 when(builder.setScheme(any())).thenReturn(builder);
                 when(builder.setHost(any())).thenReturn(builder);
                 when(builder.setPath(any())).thenReturn(builder);
                 when(builder.toString()).thenReturn("/server/share");
             })) {

            SmbFileSystemConfigBuilder smbBuilder = mock(SmbFileSystemConfigBuilder.class);
            DefaultFileSystemConfigBuilder defaultBuilder = mock(DefaultFileSystemConfigBuilder.class);

            smbMock.when(SmbFileSystemConfigBuilder::getInstance).thenReturn(smbBuilder);
            defaultMock.when(DefaultFileSystemConfigBuilder::getInstance).thenReturn(defaultBuilder);
            doNothing().when(smbBuilder).setCIFSContext(any(), any());
            doNothing().when(defaultBuilder).setUserAuthenticator(any(), any());

            spyWatcher.watchSharedDirectory();

            verify(sharedFolderConfig, atLeastOnce()).getUsername();
            verify(sharedFolderConfig, atLeastOnce()).getPassword();
            verify(sharedFolderConfig, atLeastOnce()).getServername();
            verify(sharedFolderConfig, atLeastOnce()).getSharepath();
        }
    }


}

