package com.eh.digitalpathology.dicomreceiver.service;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.nio.file.*;
import java.util.concurrent.*;

import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DirectoryWatcherTest {

    @Mock
    private FileProcessingService fileProcessingService;
    @Mock
    private ExecutorService executorService;

    private DirectoryWatcher directoryWatcher;
    private Path tempDir;

    @BeforeEach
    void setUp() throws IOException {
        executorService = Executors.newSingleThreadExecutor();
        tempDir = Files.createTempDirectory("watcherTest");
        DirectoryWatcher realWatcher = new DirectoryWatcher(fileProcessingService, executorService);
        directoryWatcher = Mockito.spy(realWatcher);
    }

    @AfterEach
    void tearDown()  {
        executorService.shutdownNow();
        FileUtils.deleteQuietly(tempDir.toFile());
    }

    @Test
    void testShouldProcessFileWhenNewFileIsDetected() throws Exception {
        Thread watcherThread = new Thread(() -> {
            try {
                directoryWatcher.directoryLookup(tempDir.toString(), "intermediateStore");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "watcher-daemon");
        watcherThread.setDaemon(true);
        watcherThread.start();

        await().atMost(5, TimeUnit.SECONDS).until(() -> Files.exists(tempDir));

        Path newFile = tempDir.resolve("testFile.txt");
        Files.createFile(newFile);

        await().atMost(20, TimeUnit.SECONDS).untilAsserted(() ->
                verify(fileProcessingService, atLeastOnce())
                        .processFile(any(), eq(tempDir.toString()), eq("intermediateStore"))
        );

        watcherThread.interrupt();
        watcherThread.join(2000);
        assertFalse(watcherThread.isAlive(), "Watcher should be terminated");
    }

    @Test
    void testDirectoryLookup_IgnoresPartialFiles() throws Exception {
        ExecutorService mockExecutor = mock(ExecutorService.class);
        ReflectionTestUtils.setField(directoryWatcher, "executorService", mockExecutor);

        Thread watcherThread = new Thread(() -> {
            try {
                directoryWatcher.directoryLookup(tempDir.toString(), "intermediateStore");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        watcherThread.setDaemon(true);
        watcherThread.start();
        await().atMost(5, TimeUnit.SECONDS).until(() -> Files.exists(tempDir));

        Files.createFile(tempDir.resolve("incomplete.part"));
        Files.createFile(tempDir.resolve("inprogress.filepart"));
        await().during(2, TimeUnit.SECONDS).until(() -> true);
        watcherThread.interrupt();
        watcherThread.join(5000);

        verify(mockExecutor, never()).submit(any(Runnable.class));
    }


}

