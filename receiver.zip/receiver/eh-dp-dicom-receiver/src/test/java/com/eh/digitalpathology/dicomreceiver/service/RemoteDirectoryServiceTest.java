package com.eh.digitalpathology.dicomreceiver.service;


import com.eh.digitalpathology.dicomreceiver.util.CommonUtils;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileName;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RemoteDirectoryServiceTest {

    @Mock
    private File remoteFile;
    private CommonUtils commonUtils;
    private ExecutorService executorService;
    private RemoteDirectoryService service;

    @BeforeEach
    void setup() {
        commonUtils = mock(CommonUtils.class);
        executorService = mock(ExecutorService.class);
        service = new RemoteDirectoryService(commonUtils, executorService);
    }
    @AfterEach
    void tearDown()  {
        executorService.shutdownNow();
    }

    @Test
    void testProcessFileEvent_SubmitsTask_WhenFileIsRegularFile() throws Exception {
        FileObject mockFile = mock(FileObject.class);
        FileName mockName = mock(FileName.class);
        when(mockFile.isFile()).thenReturn(true);
        when(mockFile.getName()).thenReturn(mockName);
        when(mockName.getPath()).thenReturn("/share/testFile.dcm");
        when(executorService.submit(any(Runnable.class))).thenReturn(mock(Future.class));

        assertDoesNotThrow(() ->
                service.processFileEvent(mockFile, "/share", "user", "pass", "server", "sharePath"));

        verify(executorService, times(1)).submit(any(Runnable.class));
    }

    @Test
    void testTryOpenFile_ReturnsFileOnSuccess() throws Exception {
        DiskShare mockShare = mock(DiskShare.class);
        File mockFile = mock(File.class);
        when(mockShare.openFile(anyString(), any(), any(), any(), any(), any()))
                .thenReturn(mockFile);

        var method = RemoteDirectoryService.class
                .getDeclaredMethod("tryOpenFile", DiskShare.class, String.class);
        method.setAccessible(true);

        File result = (File) method.invoke(service, mockShare, "remote/file.dcm");

        assertNotNull(result);
        verify(mockShare, times(1))
                .openFile(anyString(), any(), any(), any(), any(), any());
    }

    @Test
    void testTryOpenFile_ReturnsNullOnException() throws Exception {
        DiskShare mockShare = mock(DiskShare.class);
        when(mockShare.openFile(anyString(), any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("Locked"));

        var method = RemoteDirectoryService.class
                .getDeclaredMethod("tryOpenFile", DiskShare.class, String.class);
        method.setAccessible(true);

        File result = (File) method.invoke(service, mockShare, "locked/file.dcm");
        assertNull(result);
    }


    @Test
    void testEstablishConnectionAndProcessFile_Success() throws Exception {

        try (MockedConstruction<SMBClient> mockClientConstruction = Mockito.mockConstruction(SMBClient.class, (mockClient, context) -> {
            Connection conn = mock(Connection.class);
            Session session = mock(Session.class);
            DiskShare share = mock(DiskShare.class);
            File file = mock(File.class);
            when(file.getInputStream()).thenReturn(new ByteArrayInputStream("mock data".getBytes()));
            when(share.openFile(anyString(), any(), any(), any(), any(), any())).thenReturn(file);
            when(session.connectShare(anyString())).thenReturn(share);
            when(conn.authenticate(any())).thenReturn(session);
            when(mockClient.connect(anyString())).thenReturn(conn);
            when(commonUtils.getLocalStoragePath()).thenReturn(Files.createTempDirectory("copy").toString());})) {

            var maxRetries = RemoteDirectoryService.class.getDeclaredField("maxRetries");
            maxRetries.setAccessible(true);
            maxRetries.set(service, 1L);

            var method = RemoteDirectoryService.class.getDeclaredMethod(
                    "establishConnectionAndProcessFile",
                    String.class, String.class, String.class, String.class, String.class, String.class);
            method.setAccessible(true);

            assertDoesNotThrow(() ->
                    method.invoke(service, "remote/file.dcm", "file.dcm", "user", "pass", "server", "share"));

            SMBClient client = mockClientConstruction.constructed().get(0);
            Connection conn = client.connect("server");
            Session session = conn.authenticate(null);
            DiskShare share = (DiskShare) session.connectShare("share");

            verify(share, atLeastOnce()).openFile(anyString(), any(), any(), any(), any(), any());
        }
    }

    @Test
    void testCopyRemoteFileToLocal_Success() throws Exception {
        File mockRemoteFile = mock(File.class);
        Path tempDir = Files.createTempDirectory("localTestDir");
        Path tempFile = tempDir.resolve("testFile.dcm");

        when(commonUtils.getLocalStoragePath()).thenReturn(tempDir.toString());

        byte[] mockData = "mock data".getBytes();
        InputStream mockInputStream = new ByteArrayInputStream(mockData);
        when(mockRemoteFile.getInputStream()).thenReturn(mockInputStream);

        FileChannel mockChannel = mock(FileChannel.class);
        MockedStatic<FileChannel> fileChannelMock = mockStatic(FileChannel.class);
        fileChannelMock.when(() -> FileChannel.open(eq(tempFile),
                        eq(StandardOpenOption.CREATE), eq(StandardOpenOption.WRITE)))
                .thenReturn(mockChannel);

        Field maxRetriesField = RemoteDirectoryService.class.getDeclaredField("maxRetries");
        maxRetriesField.setAccessible(true);
        maxRetriesField.set(service, 3L);

        Method method = RemoteDirectoryService.class.getDeclaredMethod("copyRemoteFileToLocal", File.class, String.class);
        method.setAccessible(true);
        boolean result = (boolean) method.invoke(service, mockRemoteFile, "testFile.dcm");

        assertTrue(result);
        verify(mockRemoteFile, times(1)).getInputStream();
        fileChannelMock.close();
    }

    @Test
    void testCopyRemoteFileToLocal_RetriesOnFailure() throws Exception {
        File mockFile = mock(File.class);
        when(commonUtils.getLocalStoragePath()).thenReturn(Files.createTempDirectory("local2").toString());

        var method = RemoteDirectoryService.class
                .getDeclaredMethod("copyRemoteFileToLocal", File.class, String.class);
        method.setAccessible(true);

        boolean result = (boolean) method.invoke(service, mockFile, "errorFile.dcm");
        assertFalse(result);
    }

}



