package com.eh.digitalpathology.dicomreceiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class DicomReceiverApplicationTests  {

	@Test
	void contextLoads() {
		// This test ensures that the Spring application context loads successfully.
		// No additional assertions are needed.
	}

}
