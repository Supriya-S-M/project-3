/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * KafkaNotifier service is responsible for sending messages to a specified Kafka topic.
 */

package com.eh.digitalpathology.lis.connector.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaNotifier {
    private static final Logger log = LoggerFactory.getLogger( KafkaNotifier.class );

    private final KafkaTemplate< String, String > kafkaTemplate;

    public KafkaNotifier ( KafkaTemplate< String, String > kafkaTemplate ) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Notify Kafka with the specified topic, key, and message value.
     *
     * @param topic The Kafka topic to which the message will be sent.
     * @param key   The key of the message.
     * @param value The message content (value) to be sent to Kafka.
     */
    public void notify ( String topic, String key, String value ) {
        try {
            // Send the message to the specified Kafka topic
            log.info( "notify :: Sending message to Kafka topic: {}, key: {}", topic, key );

            kafkaTemplate.send( topic, key, value );

            // Log the successful notification
            log.info( "notify :: Message successfully sent to Kafka topic: {}", topic );
        } catch ( Exception e ) {
            log.error( "notify :: Failed to send message to Kafka topic: {}. Error: {}", topic, e.getMessage( ), e );
        }
    }
}

