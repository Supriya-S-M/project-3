/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * AppConstants class contains static final constants used across the application
 */


package com.eh.digitalpathology.lis.connector.constants;

public class AppConstants {
    public static final char START_OF_BLOCK = '\u000b';    // Vertical Tab
    public static final char END_OF_BLOCK = '\u001c';      // File Separator
    public static final char CARRIAGE_RETURN = '\r';       // Carriage Return

    private AppConstants() {
        throw new UnsupportedOperationException("AppConstants is a utility class and cannot be instantiated");
    }
}
