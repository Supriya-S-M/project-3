package com.eh.digitalpathology.lis.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.*;
import ca.uhn.hl7v2.parser.DefaultModelClassFactory;
import ca.uhn.hl7v2.parser.ModelClassFactory;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;
import com.eh.digitalpathology.lis.connector.config.AppConfig;
import com.eh.digitalpathology.lis.connector.config.Hl7Config;
import com.eh.digitalpathology.lis.connector.exceptions.Hl7MessageException;
import com.eh.digitalpathology.lis.connector.utils.Hl7MessageHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AcknowledgeMessageGenerator {

    private static final Logger log = LoggerFactory.getLogger( AcknowledgeMessageGenerator.class.getName( ) );
    private final Hl7Config hl7Config;
    private final AppConfig appConfig;


    public AcknowledgeMessageGenerator ( Hl7Config hl7Config, AppConfig appConfig ) {
        this.hl7Config = hl7Config;
        this.appConfig = appConfig;
    }

    public String createAcknowledgeMessage ( String hl7Message, String messageType, String ackCode ) throws HL7Exception, IOException {

        log.info( "createAcknowledgeMessage :: \n {}", hl7Message );
        PipeParser parser = new PipeParser( );
        Message inputMessage = parser.parse( hl7Message );

        boolean isNegative = isNegativeScenario( inputMessage );
        String templateKey = isNegative ? messageType.toUpperCase( ) + "_NEGATIVE" : messageType.toUpperCase( );

        Hl7Config.MessageTemplate template = hl7Config.getMessages( ).get( templateKey );
        if ( template == null ) {
            throw new IllegalArgumentException( "Invalid hl7 message type: " + messageType );
        }
        if ( isNegative ) {
            List< Hl7Config.Segment > errorSegments = buildErrorSegments( inputMessage );
            template.getSegments( ).addAll( errorSegments );
        }

        Map< String, String > dynamicValues = fetchDynamicValues( inputMessage, template, ackCode );
        Message message = createDynamicMessage( template, dynamicValues, inputMessage );
        parser.getParserConfiguration( ).setEncodeEmptyMandatoryFirstSegments( false );
        String encodedMessage = parser.encode( message ).replace( "\\T\\", "&" ).replace( "\\S\\", "^" ).replace( "\\R\\", "~" );
        log.info( "createMessage :: Encoded HL7 Message: \n {}", encodedMessage );
        return encodedMessage;
    }

    private Map< String, String > fetchDynamicValues ( Message inputMessage, Hl7Config.MessageTemplate template, String ackCode ) {
        Map< String, String > dynamicValues = new HashMap<>( );
        Terser terser = new Terser( inputMessage );
        Set< String > placeHolders = extractPlaceholdersFromTemplates( template );
        for ( String placeholder : placeHolders ) {
            if ( isUtilityPlaceholder( placeholder ) ) {
                dynamicValues.put( placeholder, resolveUtilityPlaceholder( placeholder, ackCode ) );
            } else {
                try {
                    String terserPath = getTerserPath( inputMessage, placeholder.substring( 0, 3 ), placeholder.replace( ".", "-" ) );
                    String value = terser.get( terserPath );
                    if ( value != null ) {
                        dynamicValues.put( placeholder, value );
                    }
                } catch ( HL7Exception ignored ) {
                    // Intentionally ignored: encoding failure is non-critical for this field
                }
            }
        }
        return dynamicValues;

    }

    private String resolveUtilityPlaceholder ( String placeholder, String ackCode ) {
        return switch ( placeholder ) {
            case "currentDateTime" -> ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ofPattern( "yyyyMMddHHmmss" ) );
            case "sendingApp" -> appConfig.getSendingApp( );
            case "sendingFacility" -> appConfig.getSendingFacility( );
            case "receivingApp" -> appConfig.getReceivingApp( );
            case "receivingFacility" -> appConfig.getReceivingFacility( );
            case "messageControlId" -> Hl7MessageHelper.getRandomMessageControlID( );
            case "acknowledgementCode" -> ackCode;

            default -> "";
        };
    }

    private boolean isUtilityPlaceholder ( String placeholder ) {
        return Set.of( "currentDateTime", "sendingFacility", "sendingApp", "messageControlId", "acknowledgementCode", "receivingFacility", "receivingApp" ).contains( placeholder );
    }

    private Set< String > extractPlaceholdersFromTemplates ( Hl7Config.MessageTemplate template ) {
        Set< String > placeHolders = new HashSet<>( );
        Pattern pattern = Pattern.compile( "\\{([^}]+)}" );
        template.getSegments( ).forEach( segment -> {
            if ( !segment.isCopyFromInput( ) && segment.getFields( ) != null ) {
                segment.getFields( ).forEach( field -> {
                    Matcher matcher = pattern.matcher( field.getValue( ) );
                    while ( matcher.find( ) ) {
                        placeHolders.add( matcher.group( 1 ) );
                    }
                } );
            }
        } );
        return placeHolders;
    }

    private Message createDynamicMessage ( Hl7Config.MessageTemplate template, Map< String, String > dynamicValues, Message inputMessage ) throws HL7Exception, IOException {

        ModelClassFactory factory = new DefaultModelClassFactory( );
        String triggerEvent = template.getTriggerEvent( );
        String messageClassName = triggerEvent != null && !triggerEvent.isBlank( ) ? String.format( "%s_%s", template.getMessageType( ), triggerEvent ) : template.getMessageType( );
        String hl7Version = template.getVersion( );
        log.error( "createDynamicMessage:: Attempting to resolve message class:: {} for version: {}", messageClassName, template.getVersion( ) );
        Class< ? extends Message > messageClass = factory.getMessageClass( messageClassName, hl7Version, false );

        Message message = instantiateMessage( messageClass );
        if ( message instanceof AbstractMessage abstractMessage ) {
            if ( triggerEvent == null || triggerEvent.isBlank( ) ) {
                triggerEvent = "O21";
            }
            abstractMessage.initQuickstart( template.getMessageType( ), triggerEvent, "P" );
        }

        Terser terser = new Terser( message );
        for ( Hl7Config.Segment segmentConfig : template.getSegments( ) ) {
            Structure segment = findSegmentDynamically( message, segmentConfig.getName( ) );
            log.info( "createDynamicMessage :: segment :: {}", segment );
            if ( segment instanceof Segment ) {
                if ( segmentConfig.isCopyFromInput( ) ) {
                    copySegmentFromInput( inputMessage, message, segmentConfig.getName( ) );
                    continue;
                }
                populateSegment( terser, segmentConfig, dynamicValues, message );
            } else {
                throw new HL7Exception( "Segment " + segmentConfig.getName( ) + " not found in message." );
            }
        }
        return message;
    }

    private void copySegmentFromInput ( Message inputMessage, Message message, String segmentName ) throws HL7Exception {
        Terser outputTerser = new Terser( message );
        int repetition = 0;

        while ( true ) {
            Segment inputSegment = getSegmentRepetition( inputMessage, segmentName, repetition );
            if ( inputSegment == null ) break;

            copyFieldsFromSegment( inputSegment, outputTerser, segmentName, repetition, message );
            repetition++;
        }
    }

    private void copyFieldsFromSegment ( Segment inputSegment, Terser outputTerser, String segmentName, int repetition, Message message ) throws HL7Exception {
        int numFields = inputSegment.numFields( ) + 1;

        for ( int field = 1; field <= numFields; field++ ) {
            Type[] fieldReps = safelyGetField( inputSegment, field - 1 );
            if ( fieldReps == null ) continue;

            for ( int fieldRep = 0; fieldRep < fieldReps.length; fieldRep++ ) {
                copyFieldValue( fieldReps[ fieldRep ], outputTerser, segmentName, repetition, field - 1, fieldRep, message );
            }
        }
    }

    private Type[] safelyGetField ( Segment segment, int fieldIndex ) {
        try {
            return segment.getField( fieldIndex );
        } catch ( HL7Exception e ) {
            return new Type[ 0 ];
        }
    }

    private void copyFieldValue ( Type fieldType, Terser outputTerser, String segmentName, int repetition, int fieldIndex, int fieldRep, Message message ) throws HL7Exception {
        String fieldPath = String.format( "%s(%d)-%d(%d)", segmentName, repetition, fieldIndex, fieldRep );
        String outputPath = getTerserPath( message, segmentName, fieldPath );

        try {
            String value = fieldType.encode( );
            if ( value != null && !value.isEmpty( ) ) {
                outputTerser.set( outputPath, value );
            }
        } catch ( HL7Exception ignored ) {
            // Intentionally ignored: encoding failure is non-critical for this field
        }
    }


    private Segment getSegmentRepetition ( Message inputMessage, String name, int repetition ) {
        try {
            Group parent = findParentGroup( inputMessage, name );
            if ( parent != null ) {
                Structure[] reps = parent.getAll( name );
                if ( repetition < reps.length && reps[ repetition ] instanceof Segment segment ) {
                    return segment;
                }
            }
        } catch ( HL7Exception e ) {
            return null;
        }
        return null;
    }


    private Message instantiateMessage ( Class< ? extends Message > messageClass ) {
        try {
            return messageClass.getDeclaredConstructor( ).newInstance( );
        } catch ( Exception e ) {
            throw new Hl7MessageException( "EXCEPTION", e.getMessage( ) );
        }
    }

    private Structure findSegmentDynamically ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            try {
                Structure segment = group.get( segmentName );
                if ( segment != null ) {
                    return segment;
                }
            } catch ( HL7Exception e ) {
                log.error( "findSegmentDynamically:: Unable to find segment in group :: {}", e.getMessage( ) );
            }
            for ( String groupName : group.getNames( ) ) {
                Structure nestedStructure = group.get( groupName );
                if ( nestedStructure instanceof Group ) {
                    try {
                        return findSegmentDynamically( nestedStructure, segmentName );
                    } catch ( HL7Exception ex ) {
                        log.error( "findSegmentDynamically :: Unable to find in segment group {} ", ex.getMessage( ) );
                    }
                }
            }
        }
        throw new HL7Exception( "Segment " + segmentName + " not found in message." );
    }

    private void populateSegment ( Terser terser, Hl7Config.Segment segmentConfig, Map< String, String > dynamicValues, Message message ) throws HL7Exception {
        for ( Hl7Config.Field field : segmentConfig.getFields( ) ) {
            String value = field.getValue( );
            for ( Map.Entry< String, String > dynamicValue : dynamicValues.entrySet( ) ) {
                value = value.replace( "{" + dynamicValue.getKey( ) + "}", dynamicValue.getValue( ) );
            }
            value = value.replaceAll( "\\{[^}]+\\}", "" );

            try {
                String fullPath = getTerserPath( message, segmentConfig.getName( ), field.getPath( ) );
                log.info( "populateSegment :: full path of segment Name:: {}", fullPath );
                if ( field.getPath( ).matches( ".*-\\d+\\.\\d+$" ) ) {
                    // Handle subcomponents
                    String[] parts = field.getPath( ).split( "\\." );
                    String baseField = parts[ 0 ];
                    int subcomponentIndex = Integer.parseInt( parts[ 1 ] );
                    terser.set( baseField + "-" + subcomponentIndex, value );
                } else {
                    terser.set( fullPath, value );
                }
            } catch ( Exception e ) {
                throw new HL7Exception( "Error setting hl7 fields : " + field.getPath( ) + "with value : " + value, e );
            }
        }
    }

    private String getTerserPath ( Message message, String segmentName, String fieldPath ) throws HL7Exception {
        Group parentGroup = findParentGroup( message, segmentName );
        if ( parentGroup == null ) {
            // If the parent group is null, the segment is directly under the root message
            return '/' + fieldPath;
        }
        return '/' + getGroupPath( message, parentGroup ) + '/' + fieldPath;
    }

    private Group findParentGroup ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            for ( String name : group.getNames( ) ) {
                Structure nestedStructure = group.get( name );
                if ( nestedStructure instanceof Group nestedGroup ) {
                    if ( Arrays.asList( nestedGroup.getNames( ) ).contains( segmentName ) ) {
                        return nestedGroup;
                    }
                    Group parentGroup = findParentGroup( nestedGroup, segmentName );
                    if ( parentGroup != null ) {
                        return parentGroup;
                    }
                }
            }
        }
        return null;
    }

    private String getGroupPath ( Message message, Group group ) {
        if ( group.equals( message ) ) {
            return "";
        }
        Group parentGroup = group.getParent( );
        if ( parentGroup == null || parentGroup.equals( message ) ) {
            return group.getName( );
        }
        return getGroupPath( message, parentGroup ) + '/' + group.getName( );
    }


    public boolean isNegativeScenario ( Message inputMessage ) {
        try {
            Terser terser = new Terser( inputMessage );

            String messageType = terser.get( getTerserPath( inputMessage, "MSH", "MSH-9-1" ) );
            if ( !"OML".equalsIgnoreCase( messageType ) ) {
                return false; // Skip negative scenario check for non-OML messages
            }

            String orc1 = terser.get( getTerserPath( inputMessage, "ORC", "ORC-1" ) );
            String spm4 = terser.get( getTerserPath( inputMessage, "SPM", "SPM-4" ) );
            String spm11 = terser.get( getTerserPath( inputMessage, "SPM", "SPM-11" ) );

            return "DC".equalsIgnoreCase( orc1 ) || spm4 == null || spm4.isBlank( ) || "NULL".equalsIgnoreCase( spm4 ) || "U".equalsIgnoreCase( spm11 );
        } catch ( HL7Exception e ) {
            log.error( "Error checking negative scenario: {}", e.getMessage( ) );
            return false;
        }
    }

    private List< Hl7Config.Segment > buildErrorSegments ( Message inputMessage ) {
        List< Hl7Config.Segment > errorSegments = new ArrayList<>( );
        Terser terser = new Terser( inputMessage );

        try {
            String orc1 = terser.get( getTerserPath( inputMessage, "ORC", "ORC-1" ) );
            if ( "DC".equalsIgnoreCase( orc1 ) ) {
                errorSegments.add( createErrSegment( "ORC^1^1", "208", "Order control code is 'DC'" ) );
            }

            String spm4 = terser.get( getTerserPath( inputMessage, "SPM", "SPM-4" ) );
            if ( spm4 == null || spm4.isBlank( ) || "NULL".equalsIgnoreCase( spm4 ) ) {
                errorSegments.add( createErrSegment( "SPM^4^1", "207", "Invalid or missing specimen type" ) );
            }

            String spm11 = terser.get( getTerserPath( inputMessage, "SPM", "SPM-11" ) );
            if ( "U".equalsIgnoreCase( spm11 ) ) {
                errorSegments.add( createErrSegment( "SPM^11^1", "209", "Unknown specimen role" ) );
            }

        } catch ( HL7Exception e ) {
            log.error( "Error building ERR segments: {}", e.getMessage( ) );
        }

        return errorSegments;
    }

    private Hl7Config.Segment createErrSegment ( String location, String code, String description ) {
        Hl7Config.Segment errSegment = new Hl7Config.Segment( );
        errSegment.setName( "ERR" );
        List< Hl7Config.Field > fields = new ArrayList<>( );
        Hl7Config.Field error1 = new Hl7Config.Field( );
        error1.setPath( "ERR-1" );
        error1.setValue( location );
        Hl7Config.Field error2 = new Hl7Config.Field( );
        error2.setPath( "ERR-3" );
        error2.setValue( code );
        Hl7Config.Field error3 = new Hl7Config.Field( );
        error3.setPath( "ERR-4" );
        error3.setValue( "E" );
        Hl7Config.Field error4 = new Hl7Config.Field( );
        error4.setPath( "ERR-7" );
        error4.setValue( description );
        fields.add( error1 );
        fields.add( error2 );
        fields.add( error3 );
        fields.add( error4 );
        errSegment.setFields( fields );
        return errSegment;
    }


}
