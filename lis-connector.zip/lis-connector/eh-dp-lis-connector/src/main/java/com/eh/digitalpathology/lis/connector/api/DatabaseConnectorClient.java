package com.eh.digitalpathology.lis.connector.api;

import com.eh.digitalpathology.lis.connector.constants.ApiConstants;
import com.eh.digitalpathology.lis.connector.exceptions.Hl7MessageException;
import com.eh.digitalpathology.lis.connector.models.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class DatabaseConnectorClient {
    private static final Logger log = LoggerFactory.getLogger( DatabaseConnectorClient.class );
    private final DBRestClient dbRestClient;

    @Autowired
    public DatabaseConnectorClient ( DBRestClient dbRestClient ) {
        this.dbRestClient = dbRestClient;

    }

    record HL7MessageStoreRequest(String hl7Message) {
    }

    public String storeHL7Message ( String caseData ) {
        HL7MessageStoreRequest messagesRequest = new HL7MessageStoreRequest( caseData );
        HttpHeaders headers = new HttpHeaders( );
        headers.set( "X-Service-Name", "lis-connector" );
        try {
            log.debug( "persistsMessages:: call is made to persist messages" );
            String barcode = dbRestClient.exchange( HttpMethod.POST, ApiConstants.STORE_HL7_MESSAGE, messagesRequest, new ParameterizedTypeReference< ApiResponse< Map< String, String > > >( ) {
                    }, httpHeaders -> httpHeaders.putAll( headers ) )
                    .map( mapApiResponse -> mapApiResponse.content( ).get( ApiConstants.BARCODE_KEY ) )
                    .block( );
            log.info( "persistsMessages :: apiResponse in Hl7Service :: {}", barcode );
            return barcode;
        } catch ( Hl7MessageException ex ) {
            throw new Hl7MessageException( ex.getErrorCode( ), ex.getErrorMessage( ) );
        } catch ( Exception e ) {
            throw new Hl7MessageException( ApiConstants.UNKNOWN_ERROR, e.getMessage( ) );
        }
    }
}