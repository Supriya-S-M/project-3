/**
 * This class represents a custom checked exception for handling errors related to database connector operations.
 * © 2025 Your Company Name. All rights reserved.
 */

package com.eh.digitalpathology.lis.connector.exceptions;

public class DatabaseConnectorException extends Exception {
    public DatabaseConnectorException(String message) {
        super(message);
    }

    public DatabaseConnectorException(String message, Throwable cause) {
        super(message, cause);
    }
}