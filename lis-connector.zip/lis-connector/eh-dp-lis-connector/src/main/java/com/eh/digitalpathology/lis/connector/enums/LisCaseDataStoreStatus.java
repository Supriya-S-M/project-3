/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * LISCaseDataStoreStatus enum defines the status of storing LIS case data
 * into the database through the database connector service:
 * CASE_DATA_STORED and CASE_DATA_STORE_FAILED, indicating whether the
 * application successfully stored the case data or failed to do so.
 */

package com.eh.digitalpathology.lis.connector.enums;

public enum LisCaseDataStoreStatus {
    CASE_DATA_STORED("Case Data Stored"),
    CASE_DATA_STORE_FAILED("Case Data Store Failed");

    private final String message;

    LisCaseDataStoreStatus(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return message;
    }
}
