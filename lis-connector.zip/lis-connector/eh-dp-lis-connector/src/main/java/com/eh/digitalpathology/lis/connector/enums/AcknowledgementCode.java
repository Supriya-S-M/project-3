package com.eh.digitalpathology.lis.connector.enums;

public enum AcknowledgementCode {
    AA("Application Accept"),    // Message accepted successfully
    AE("Application Error"),     // Error in message processing
    AR("Application Reject"),    // Message rejected
    CA("Commit Accept"),         // Message committed successfully
    CE("Commit Error"),          // Commit-level error
    CR("Commit Reject");         // Commit-level reject

    private final String description;

    AcknowledgementCode(String description) {
        this.description = description;
    }

    /**
     * Get the description of the acknowledgment code.
     *
     * @return Description of the acknowledgment code.
     */
    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return this.name() + " - " + this.description;
    }
}
