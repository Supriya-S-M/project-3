/**
 * Copyright (c) 2025, Company Name
 * All rights reserved.
 * Purpose: This is the main entry point for the LIS Connector application.
 * It initializes and runs the Spring Boot application.
 */

package com.eh.digitalpathology.lis.connector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LisConnectorApplication {
    public static void main(String[] args) {
        SpringApplication.run(LisConnectorApplication.class, args);
    }
}
