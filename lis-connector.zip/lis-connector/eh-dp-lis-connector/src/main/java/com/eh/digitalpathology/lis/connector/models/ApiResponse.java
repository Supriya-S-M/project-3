package com.eh.digitalpathology.lis.connector.models;

public record ApiResponse< T >(String status, T content, String errorCode, String errorMessage) {
}

