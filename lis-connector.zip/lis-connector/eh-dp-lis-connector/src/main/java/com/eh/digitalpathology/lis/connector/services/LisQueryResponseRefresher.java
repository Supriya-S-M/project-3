package com.eh.digitalpathology.lis.connector.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class LisQueryResponseRefresher implements ApplicationListener< RefreshScopeRefreshedEvent > {

    private static final Logger log = LoggerFactory.getLogger( LisQueryResponseRefresher.class.getName( ) );

    private final LisQueryResponseReceiver receiver;

    public LisQueryResponseRefresher ( LisQueryResponseReceiver receiver ) {
        this.receiver = receiver;
    }

    @Override
    public void onApplicationEvent ( RefreshScopeRefreshedEvent event ) {
        log.info( "LisQueryResponseRefresher :: Refresh event received, restarting LIS receiver." );
        receiver.shutdown( );
        receiver.init( );
    }
}

