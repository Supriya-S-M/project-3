package com.eh.digitalpathology.lis.connector.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties( prefix = "lis" )
@RefreshScope
public class LisConfig {
    private String ipAddress;
    private int port;
    private int incomingPort;

    // Getters and Setters
    public String getIpAddress ( ) {
        return ipAddress;
    }

    public void setIpAddress ( String ipAddress ) {
        this.ipAddress = ipAddress;
    }

    public int getPort ( ) {
        return port;
    }

    public void setPort ( int port ) {
        this.port = port;
    }

    public int getIncomingPort ( ) {
        return incomingPort;
    }

    public void setIncomingPort ( int incomingPort ) {
        this.incomingPort = incomingPort;
    }
}
