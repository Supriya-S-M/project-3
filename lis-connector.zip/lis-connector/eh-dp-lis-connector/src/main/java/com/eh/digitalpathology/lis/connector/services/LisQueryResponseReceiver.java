/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * LisQueryResponseReceiver listens for incoming HL7 messages from an external LIS system, processes the messages,
 * stores the data in a database through the database connector service, and sends appropriate notifications to Kafka.
 */

package com.eh.digitalpathology.lis.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.parser.PipeParser;
import com.eh.digitalpathology.lis.connector.api.DatabaseConnectorClient;
import com.eh.digitalpathology.lis.connector.config.AppConfig;
import com.eh.digitalpathology.lis.connector.config.KafkaTopicConfig;
import com.eh.digitalpathology.lis.connector.config.LisConfig;
import com.eh.digitalpathology.lis.connector.constants.AppConstants;
import com.eh.digitalpathology.lis.connector.enums.AcknowledgementCode;
import com.eh.digitalpathology.lis.connector.enums.LisCaseDataStoreStatus;
import com.eh.digitalpathology.lis.connector.utils.Hl7MessageHelper;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;

@Service
public class LisQueryResponseReceiver {
    private static final Logger log = LoggerFactory.getLogger( LisQueryResponseReceiver.class );

    private final DatabaseConnectorClient dbConnectorClient;
    private final KafkaNotifier lisQueryResponseNotifier;
    private final AcknowledgeMessageGenerator acknowledgeMessageGenerator;
    private final KafkaNotifier kafkaNotifier;
    private final LisConfig lisConfig;
    private final AppConfig appConfig;

    private volatile boolean running = true;

    private final ExecutorService lisResponseExecutorService;
    private final KafkaTopicConfig kafkaTopicConfig;

    @PostConstruct
    public void init ( ) {
        log.debug( "init :: LIS Connector Initialization Started." );
        log.debug( "init :: Incoming port configuration for receiving HL7 messages from the LIS: {}", this.lisConfig.getIncomingPort( ) );
        running = true;
        // Start the receiver automatically after initialization
        lisResponseExecutorService.submit( this::startLisReceiver );
    }

    @Autowired
    public LisQueryResponseReceiver ( DatabaseConnectorClient databaseConnectorClient, KafkaNotifier lisQueryResponseNotifier, AcknowledgeMessageGenerator acknowledgeMessageGenerator, KafkaNotifier kafkaNotifier, LisConfig lisConfig, AppConfig appConfig, @Qualifier( "lisResponseExecutorService" ) ExecutorService executorService, KafkaTopicConfig kafkaTopicConfig ) {
        this.dbConnectorClient = databaseConnectorClient;
        this.lisQueryResponseNotifier = lisQueryResponseNotifier;
        this.acknowledgeMessageGenerator = acknowledgeMessageGenerator;
        this.kafkaNotifier = kafkaNotifier;
        this.lisConfig = lisConfig;
        this.appConfig = appConfig;
        this.lisResponseExecutorService = executorService;
        this.kafkaTopicConfig = kafkaTopicConfig;
    }

    // Start the receiver to listen for incoming HL7 messages
    public void startLisReceiver ( ) {
        try ( ServerSocket serverSocket = new ServerSocket( this.lisConfig.getIncomingPort( ) ) ) {
            log.info( "startLisReceiver :: LIS Connector listening for incoming HL7 messages from external LIS system on port {}", this.lisConfig.getIncomingPort( ) );
            // Continuously accept and process incoming connections for HL7 case data
            while ( running ) {
                Socket socket = serverSocket.accept( );
                processIncomingMessagesFromLIS( socket );
            }
        } catch ( Exception e ) {
            log.error( "startLisReceiver :: An error occurred while starting the LIS Connector Service on port {}. Exception: ", lisConfig.getIncomingPort( ), e );
        }
    }

    @PreDestroy
    public void shutdown ( ) {
        running = false;
        log.info( "stopLisReceiver :: LIS Receiver stopped." );
    }

    private void processIncomingMessagesFromLIS ( Socket clientSocket ) {
        try ( InputStream inputStream = clientSocket.getInputStream( ); OutputStream outputStream = clientSocket.getOutputStream( ); BufferedReader reader = new BufferedReader( new InputStreamReader( inputStream, StandardCharsets.UTF_8 ) ); BufferedWriter writer = new BufferedWriter( new OutputStreamWriter( outputStream ) ) ) {
            log.info( "processIncomingMessagesFromLIS :: Starting to read HL7 messages from the socket input stream." );

            // Read and process multiple HL7 messages from the socket input stream
            String hl7MessageWithMLLP;
            while ( ( hl7MessageWithMLLP = readSingleIncomingMessage( reader ) ) != null ) {
                String hl7Message = Hl7MessageHelper.extractHL7FromMLLPMessage( hl7MessageWithMLLP );
                String responseMessage = handleHl7Message( hl7Message );

                String updatedAckMessage = AppConstants.START_OF_BLOCK + responseMessage + AppConstants.END_OF_BLOCK + AppConstants.CARRIAGE_RETURN;

                // Send the acknowledgment to the LIS
                sendAcknowledgment( writer, updatedAckMessage );
            }
        } catch ( IOException | HL7Exception e ) {
            log.error( "processIncomingMessagesFromLIS :: Error while receiving or processing HL7 messages from LIS: ", e );
        }
    }

    private String handleHl7Message ( String hl7Message ) throws HL7Exception, IOException {
        try {

            log.info( "handleHl7Message :: raw hl7 Message :: {}", hl7Message );
            Message parsedMessage = new PipeParser( ).parse( hl7Message );
            log.info( "handleHl7Message :: parsed message :: {} ", parsedMessage );
            boolean isNegative = acknowledgeMessageGenerator.isNegativeScenario( parsedMessage );

            String barcode = dbConnectorClient.storeHL7Message( hl7Message );
            if ( barcode == null || barcode.isEmpty( ) ) {
                kafkaNotifier.notify( kafkaTopicConfig.getEmail( ), "MISSING_BARCODE", null );
                throw new IOException( "Barcode is empty or null" );
            }

            if ( isNegative ) {
                // Send rejection notification
                lisQueryResponseNotifier.notify( kafkaTopicConfig.getConnect( ), barcode, LisCaseDataStoreStatus.CASE_DATA_STORE_FAILED.name( ) );
                kafkaNotifier.notify( kafkaTopicConfig.getEmail( ), "NEGATIVE_QUERY", barcode );

            } else {
                // Send normal notification
                lisQueryResponseNotifier.notify( kafkaTopicConfig.getConnect( ), barcode, LisCaseDataStoreStatus.CASE_DATA_STORED.name( ) );
            }

            String ackCode = isNegative ? AcknowledgementCode.AE.name( ) : AcknowledgementCode.AA.name( );
            String ackMessage = acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, appConfig.getAcknowledgeType( ), ackCode );
            if ( appConfig.getAcknowledgeType( ).equalsIgnoreCase( "ORL" ) ) {
                dbConnectorClient.storeHL7Message( ackMessage );
            }
            return ackMessage;
        } catch ( IOException | HL7Exception ex ) {
            return acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, appConfig.getAcknowledgeType( ), AcknowledgementCode.AE.name( ) );
        }
    }

    private static String readSingleIncomingMessage ( BufferedReader reader ) throws IOException {
        StringBuilder messageBuilder = new StringBuilder( );
        int currentByteRead;
        boolean inMessage = false;
        while ( ( currentByteRead = reader.read( ) ) != -1 ) {
            if ( currentByteRead == AppConstants.START_OF_BLOCK ) {
                // Start a new message when Start Block is encountered
                inMessage = true;
                messageBuilder.setLength( 0 ); // Clear previous message content
            }

            if ( inMessage ) {
                messageBuilder.append( (char) currentByteRead );  // Append the current byte as a character

                // Check if we've reached the End Block
                if ( currentByteRead == AppConstants.END_OF_BLOCK ) {
                    // End of message encountered (End Block)
                    return messageBuilder.toString( );  // Return the message including the End Block
                }
            }
        }
        return null;  // Return null if no more messages are available
    }

    private void sendAcknowledgment ( BufferedWriter writer, String acknowledgmentMessage ) {
        try {
            // Write and flush the acknowledgment message
            writer.write( acknowledgmentMessage );
            writer.flush( );
            log.info( "sendAcknowledgment :: Acknowledgment sent to the LIS." );
        } catch ( IOException e ) {
            log.error( "Error while sending acknowledgment to LIS: ", e );
        }
    }

}