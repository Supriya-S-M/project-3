/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * ApiConstants class contains static final constants used across the application
 * for API endpoints and keys.
 */

package com.eh.digitalpathology.lis.connector.constants;

public class ApiConstants {

    public static final String STORE_HL7_MESSAGE = "hl7/persists";  // Endpoint to store HL7 message
    public static final String BARCODE_KEY = "barcode";
    public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";

    private ApiConstants() {
        throw new UnsupportedOperationException("ApiConstants is a utility class and cannot be instantiated");
    }
}
