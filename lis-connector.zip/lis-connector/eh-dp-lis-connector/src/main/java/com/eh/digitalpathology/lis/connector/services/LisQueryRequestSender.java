/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * LisQueryRequestSender service is responsible for sending HL7 messages to an external LIS (Laboratory Information System)
 * via a socket connection. The message is wrapped according to the MLLP (Minimum Lower Layer Protocol) standard.
 */

package com.eh.digitalpathology.lis.connector.services;

import com.eh.digitalpathology.lis.connector.config.KafkaTopicConfig;
import com.eh.digitalpathology.lis.connector.config.LisConfig;
import com.eh.digitalpathology.lis.connector.utils.Hl7MessageHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;


@Service
public class LisQueryRequestSender {
    private static final Logger log = LoggerFactory.getLogger( LisQueryRequestSender.class );

    private final ExecutorService executorService;
    private final LisConfig lisConfig;
    private final KafkaNotifier kafkaNotifier;
    private final KafkaTopicConfig kafkaTopicConfig;


    @Autowired
    public LisQueryRequestSender ( LisConfig lisConfig, KafkaNotifier kafkaNotifier, @Qualifier( "lisExecutorService" ) ExecutorService executorService, KafkaTopicConfig kafkaTopicConfig ) {
        this.lisConfig = lisConfig;
        this.kafkaNotifier = kafkaNotifier;
        this.executorService = executorService;
        this.kafkaTopicConfig = kafkaTopicConfig;
    }

    public CompletableFuture< Void > sendToLis ( String hl7Message, String barcode ) {
        String mllpMessage = Hl7MessageHelper.getHl7MessageAsPerMllpProtocol( hl7Message );

        return CompletableFuture.runAsync( ( ) -> sendMessage( mllpMessage, barcode ), executorService );
    }

    private void sendMessage ( String hl7Message, String barcode ) {
        log.info( "sendMessage :: LIS Connector is sending HL7 message to external LIS system at {}:{}", lisConfig.getIpAddress( ), lisConfig.getPort( ) );
        int maxRetries = 3;
        int attempt = 0;
        boolean success = false;

        while ( attempt < maxRetries && !success ) {
            attempt++;
            log.info( "sendMessage :: Attempt {} to send message", attempt );
            try ( Socket socket = new Socket( lisConfig.getIpAddress( ), lisConfig.getPort( ) ); OutputStream outputStream = new BufferedOutputStream( socket.getOutputStream( ) ); InputStream inputStream = new BufferedInputStream( socket.getInputStream( ) ) ) {

                socket.setSoTimeout( 300_000 ); // 5 minutes timeout
                outputStream.write( hl7Message.getBytes( ) );
                outputStream.flush( );

                byte[] responseBuffer = new byte[ 8192 ];
                int bytesRead = inputStream.read( responseBuffer );
                if ( bytesRead > 0 ) {
                    String response = new String( responseBuffer, 0, bytesRead );
                    log.info( "sendMessage :: Response received from external LIS system: {}", response );
                    success = true;
                } else {
                    log.warn( "sendMessage :: No response received on attempt {}", attempt );
                }
            } catch ( SocketTimeoutException timeoutEx ) {
                log.warn( "sendMessage :: Timeout occurred on attempt {}", attempt );
            } catch ( IOException ex ) {
                log.error( "Error sending message to LIS system at {}:{} on attempt {}", lisConfig.getIpAddress( ), lisConfig.getPort( ), attempt, ex );
            }
            // Wait 5 minutes before next attempt if not successful
            if ( !success && attempt < maxRetries ) {
                try {
                    log.info( "sendMessage :: Waiting 5 minutes before next attempt..." );
                    Thread.sleep( 300_000 ); // 5 minutes in milliseconds
                } catch ( InterruptedException ie ) {
                    Thread.currentThread( ).interrupt( ); // Restore interrupt status
                    log.warn( "sendMessage :: Sleep interrupted before next attempt" );
                }
            }
        }
        if ( !success ) {
            log.error( "sendMessage :: Failed to receive response after {} attempts", maxRetries );
            kafkaNotifier.notify( kafkaTopicConfig.getEmail( ), "NO_RESPONSE_FROM_LIS", barcode );
        }
    }
}