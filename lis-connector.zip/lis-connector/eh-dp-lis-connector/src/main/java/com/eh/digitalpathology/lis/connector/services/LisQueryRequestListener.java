/**
 * Copyright (c) 2025. CitiusTech, Inc.
 * Service class that listens for HL7 messages from a Kafka topic and delegates
 * the sending of these messages to an external LIS system.
 */

package com.eh.digitalpathology.lis.connector.services;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;


@Service
@RefreshScope
public class LisQueryRequestListener {
    private static final Logger log = LoggerFactory.getLogger( LisQueryRequestListener.class );
    private final LisQueryRequestSender lisQueryRequestSender;

    @Autowired
    public LisQueryRequestListener ( LisQueryRequestSender lisQueryRequestSender ) {
        this.lisQueryRequestSender = lisQueryRequestSender;
    }

    @KafkaListener( topics = "${kafka.topic.lis}", groupId = "lis-consumer-group", containerFactory = "kafkaListenerContainerFactory" )
    public void listen ( ConsumerRecord< String, String > consumerRecord, Acknowledgment ack ) {
        String hl7Message = consumerRecord.value( );
        String barcode = consumerRecord.key( );

        log.info( "listen :: Received HL7 message: {}", hl7Message );
        log.info( "listen :: Barcode: {}", barcode );

        lisQueryRequestSender.sendToLis( hl7Message, barcode ).thenRun( ( ) -> {
            log.info( "LIS message sent successfully for barcode: {}", barcode );
            ack.acknowledge( );
        } ).exceptionally( ex -> {
            log.error( "Failed to send LIS message for barcode: {}", barcode, ex );
            // Optionally notify or retry
            return null;
        } );
    }
}
