package com.eh.digitalpathology.lis.connector.utils;

import com.eh.digitalpathology.lis.connector.constants.AppConstants;

import java.util.Random;

public class Hl7MessageHelper {
    private static final Random RANDOM = new Random( );

    // Private constructor to prevent instantiation
    private Hl7MessageHelper ( ) {
        throw new UnsupportedOperationException( "Hl7MessageHelper is a utility class and cannot be instantiated" );
    }

    /**
     * This method formats an HL7 message according to the MLLP protocol.
     * It wraps the HL7 message with the start block, end block and
     * carriage return to ensure proper transmission.
     *
     * @param hl7Message The HL7 message to be formatted.
     * @return The formatted HL7 message ready for MLLP transmission.
     */
    public static String getHl7MessageAsPerMllpProtocol ( String hl7Message ) {
        return AppConstants.START_OF_BLOCK
                + hl7Message
                + AppConstants.END_OF_BLOCK
                + AppConstants.CARRIAGE_RETURN;
    }

    /**
     * Utility method to extract HL7 message from an MLLP formatted message.
     * Removes the Start Block (0x0B) and End Block (0x1C) and returns the HL7 message.
     *
     * @param mllpMessage The full MLLP message (including Start Block and End Block).
     * @return The extracted HL7 message, or null if the format is invalid.
     */
    public static String extractHL7FromMLLPMessage ( String mllpMessage ) {
        if ( mllpMessage == null || mllpMessage.length( ) < 2 ) {
            // Invalid MLLP message, must have at least Start Block and End Block
            return null;
        }

        // Find the indices of the Start Block and End Block characters
        int startIndex = mllpMessage.indexOf( AppConstants.START_OF_BLOCK );
        int endIndex = mllpMessage.indexOf( AppConstants.END_OF_BLOCK, startIndex );

        // Ensure the message contains both Start Block and End Block
        if ( startIndex == -1 || endIndex == -1 || startIndex >= endIndex ) {
            // Invalid format if Start Block or End Block are not found or not in correct order
            return null;
        }

        // Extract the HL7 message by removing the Start Block and End Block characters
        return mllpMessage.substring( startIndex + 1, endIndex );  // Exclude Start and End Blocks
    }


    public static String getRandomMessageControlID ( ) {
        // Generate a timestamp-based unique ID
        long currentTimeMillis = System.currentTimeMillis( );
        int randomSuffix = RANDOM.nextInt( 100000 ); // Add randomness to the ID
        return "MSG" + currentTimeMillis + randomSuffix;
    }
}
