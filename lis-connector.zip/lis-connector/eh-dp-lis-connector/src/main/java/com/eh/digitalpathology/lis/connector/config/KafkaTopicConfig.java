package com.eh.digitalpathology.lis.connector.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties( prefix = "kafka.topic" )
@RefreshScope
public class KafkaTopicConfig {
    private String connect;
    private String email;

    public String getConnect ( ) {
        return connect;
    }

    public void setConnect ( String connect ) {
        this.connect = connect;
    }

    public String getEmail ( ) {
        return email;
    }

    public void setEmail ( String email ) {
        this.email = email;
    }

}
