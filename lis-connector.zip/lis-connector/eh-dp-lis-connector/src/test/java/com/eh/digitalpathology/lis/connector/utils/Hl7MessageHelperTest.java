package com.eh.digitalpathology.lis.connector.utils;

import com.eh.digitalpathology.lis.connector.constants.AppConstants;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class Hl7MessageHelperTest {
    @Test
    void testGetHl7MessageAsPerMllpProtocol ( ) {
        // Prepare the provided HL7 message
        String hl7Message = "MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4\rOBR|1|FIX-0098|FIX-0098|SLIDESCAN";

        // Expected MLLP-wrapped HL7 message
        String expectedMllpMessage = AppConstants.START_OF_BLOCK
                + hl7Message
                + AppConstants.END_OF_BLOCK
                + AppConstants.CARRIAGE_RETURN;

        // Call the method to test
        String actualMllpMessage = Hl7MessageHelper.getHl7MessageAsPerMllpProtocol( hl7Message );

        // Assert that the actual MLLP-wrapped message matches the expected one
        assertEquals( expectedMllpMessage, actualMllpMessage );
    }

    @Test
    void testRemoveMLLPProtocol ( ) {
        // Prepare the provided MLLP-wrapped OUL HL7 message
        String mllpMessage = AppConstants.START_OF_BLOCK
                + "MSH|^~\\&|POWERPATH||DPIS||20241018152608||OUL^R21|MSG0000530|P|2.4\rPID|||3344556^^^^MR^DEF||Microburst^Milo||19750901|M||Caucasian\rSAC||ACC123456|A\rORC|NW|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718\rOBR|1|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718|ALCB^Alcian blue stain, Ph 2.5|||20241017141820|||||||20241017152532|LIVER^^^LIVER|ABC32^Feelgood^William^U^M.D^Dr.|520555 1234||GT450 IHC, Slide 0145^A2-1\r"
                + AppConstants.END_OF_BLOCK
                + AppConstants.CARRIAGE_RETURN;

        // Expected HL7 message without MLLP protocol
        String expectedHl7Message = "MSH|^~\\&|POWERPATH||DPIS||20241018152608||OUL^R21|MSG0000530|P|2.4\rPID|||3344556^^^^MR^DEF||Microburst^Milo||19750901|M||Caucasian\rSAC||ACC123456|A\rORC|NW|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718\rOBR|1|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718|ALCB^Alcian blue stain, Ph 2.5|||20241017141820|||||||20241017152532|LIVER^^^LIVER|ABC32^Feelgood^William^U^M.D^Dr.|520555 1234||GT450 IHC, Slide 0145^A2-1\r";

        // Call the method to test
        String actualHl7Message = Hl7MessageHelper.extractHL7FromMLLPMessage( mllpMessage );

        // Assert that the actual HL7 message matches the expected one
        assertEquals( expectedHl7Message, actualHl7Message );
    }


}
