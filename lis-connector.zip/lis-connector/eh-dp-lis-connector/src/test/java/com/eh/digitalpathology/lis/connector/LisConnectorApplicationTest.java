package com.eh.digitalpathology.lis.connector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest( properties = "spring.cloud.config.enabled=false" )
class LisConnectorApplicationTest {
    @Test
    void contextLoads ( ) {
        // It is used to check if the Spring application context loads successfully.
    }
}