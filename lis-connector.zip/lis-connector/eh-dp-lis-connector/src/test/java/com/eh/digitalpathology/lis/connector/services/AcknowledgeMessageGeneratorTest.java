package com.eh.digitalpathology.lis.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import com.eh.digitalpathology.lis.connector.config.AppConfig;
import com.eh.digitalpathology.lis.connector.config.Hl7Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

class AcknowledgeMessageGeneratorTest {

    private AppConfig appConfig;

    private AcknowledgeMessageGenerator acknowledgeMessageGenerator;
    private Hl7Config hl7Config;

    @BeforeEach
    void setUp ( ) throws IOException {
        appConfig = new AppConfig( );
        hl7Config = new Hl7Config( );
        hl7Config = YamlReader.readYaml( "acks-config.yml", Hl7Config.class );
        appConfig.setSendingApp( "testABC" );
        appConfig.setSendingFacility( "" );
        appConfig.setReceivingApp( "testXYZ" );
        appConfig.setReceivingFacility( "" );
        acknowledgeMessageGenerator = new AcknowledgeMessageGenerator( hl7Config, appConfig );

    }

    @Test
    void createAcknowledgeMessageTest ( ) throws HL7Exception, IOException {
        String hl7Message = """
                MSH|^~\\&|POWERPATH|LAB|DPIS||20241018152608||OUL^R21|MSG0000530|P|2.4\r
                PID|||3344556^^^^MR^DEF||Microburst^Milo||19750901|M||Caucasian\r
                SAC||ACC123456|A\r
                ORC|NW|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718\r
                OBR|1|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718|ALCB^Alcian blue stain, Ph 2.5|||20241017141820|||||||20241017152532|LIVER^^^LIVER|ABC32^Feelgood^William^U^M.D^Dr.|520555 1234||GT450 IHC, Slide 0145^A2-1
                """;

        String message = acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, "ACK", "AA" );
        System.out.println( message );

    }

    @Test
    void createAcknowledgeMessageORLTest ( ) throws HL7Exception, IOException {
        String hl7Message = """
                MSH|^~\\&|LIS|LAB|DPL|EnrichmentTool|20250131200044||OML^O33^OML_O33|MSG000000151|P|2.5.1|||||||||LAB-80^IHE\r
                PID|1||123123127^^^Endeavour Health&10.1000/182&ISO^MR||25SP_3DHISTECH&&&&SFN^DPIA_TEST^^^^||19700101|M||C41219^Native Hawaiian or other Pacific Islander^NCIt||||||||||||C41219^Islander^NCIt^HL7|||||||||||||337915000^Homo sapiens^SCT\r
                SPM|1|17621&Endeavour Lab&10.1000/183&ISO|SPM-132|119376003^Tissue specimen^SCT||111095003^Formaldehyde^SCT~311731000^Paraffin wax^SCT~12710003^hematoxylin stain^SCT~36879007^Water soluble eosin stain^SCT|65801008^Excision^SCT|71854001^Colon^SCT|||P|||Colon FFPE HE|||202401011035||||||||||433466003^Microscope slide^SCT|||17621^^^Endeavour Health&10.1000/182&ISO|1.23.4344.56789.01022\r
                OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017231||||||F\r
                SAC||17621^^^Endeavour Health^10.1000/182^ISO|17621/19^Endeavour Health^10.1000/182^ISO||||||||||||||||||||||||||||||||||||||||||||433466003^Microscope slide^SCT|GLASS^Glass\r
                ORC||17621/19^Endeavour Health^10.1000/182^ISO|FILL-00100118^Endeavour Lab^10.1000/183^ISO\r
                OBR||17621/19^Endeavour Health^10.1000/182^ISO|FILL-00100118^Endeavour Lab^10.1000/183^ISO|11529-5^Surgical Pathology Study Report^LN\r
                OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017231||||||F\r
                """;

        String message = acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, "ORL", "AA" );
        System.out.println( message );

    }

    @Test
    void createAcknowledgeMessageORLSCCTest ( ) throws HL7Exception, IOException {
        String hl7Message = """
                MSH|^~\\&|SoftPathDx|SCC|EH_ENRICH||20250520135725||OML^O33^OML_O33|250520135725836|P|2.5.1|||AL|NE|||||LAB-80^IHE\r
                PID|||PRAMANAPATIENT2^^^SCC^MR||DPIA_PATH2^^25SP_PRAMANA||19850202|F||2106-3^White^HL70005\r
                SPM|1|SUR-25-27-A-1||119376003^Tissue specimen^SCT||12710003^Hematoxylin stain^SCT~36879007^Water soluble eosin stain^SCT~111095003^Formaldehyde^SCT~311731000^Paraffin wax^SCT|65801008^Excision^SCT|3120008^Pleura^SCT|||P|||Pleura FFPE HE|||202504041425||||||||||433466003^Microscope slide^SCT|||SUR-25-27^DXP|.3.20226\r
                SAC||SUR-25-27|PR-24-1220-A2-1||||||||||||||||||||||||||||||||||||||||||||433466003^Microscope slide^SCT|GLASS\r
                ORC|NW|SUR-25-27-A-1-S1|||||||20250520135725\r
                OBR||SUR-25-27-A-1-S1||104210008^Hematoxylin and eosin stain method^SCT\r
                OBX|1|EI|Study Instance ID||1.2.840.91865.1.25.27\r
                """;

        String message = acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, "ORL", "AA" );
        System.out.println( message );

    }
}