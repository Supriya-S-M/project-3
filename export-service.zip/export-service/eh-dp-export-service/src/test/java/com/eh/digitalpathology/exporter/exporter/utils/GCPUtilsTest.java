package com.eh.digitalpathology.exporter.exporter.utils;

import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.HealthcareApiException;
import com.eh.digitalpathology.exporter.utils.GCPUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GCPUtilsTest {

    private GcpConfig gcpConfig;

    @InjectMocks
    GCPUtils gcpUtils;

    @BeforeEach
    void setUp() {
        gcpConfig = mock(GcpConfig.class);
    }

    @Test
    void testGetAccessToken_BlankCreds() throws HealthcareApiException {
        when(gcpConfig.getCreds()).thenReturn("");
        String result = GCPUtils.getAccessToken(gcpConfig);
        assertEquals("", result);
    }
}