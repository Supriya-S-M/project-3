package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.service.SMBTransferService;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SMBTransferServiceTest {

    private void setField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }

    @Test
    void transferFiles_success() throws Exception {
        ExecutorService executorService = Executors.newSingleThreadExecutor();

        SMBTransferService smbTransferService = new SMBTransferService(executorService);
        setField(smbTransferService, "synapseHost", "host");
        setField(smbTransferService, "synapseUsername", "synapseUsername");
        setField(smbTransferService, "synapsePassword", "synapsePassword");
        setField(smbTransferService, "synapseFolder", "synapseFolder");

        Path sourcPath = Files.createTempDirectory("testSource");
        Path testFile = Files.createTempFile(sourcPath, "file", ".txt");
        Files.writeString(testFile, "test content");

        try (MockedConstruction<SMBClient> mockedClient = mockConstruction(SMBClient.class,
                (mock, context) -> {
                    Connection connection = mock(Connection.class);
                    Session session = mock(Session.class);
                    DiskShare share = mock(DiskShare.class);
                    File remoteFile = mock(File.class);

                    when(mock.connect(anyString())).thenReturn(connection);
                    when(connection.authenticate(any())).thenReturn(session);
                    when(session.connectShare(anyString())).thenReturn(share);
                    when(share.openFile(anyString(), any(), any(), any(), any(), any()))
                            .thenReturn(remoteFile);
                    when(remoteFile.write(any(byte[].class), anyLong(), anyInt(), anyInt())).thenReturn(1024L);

                })) {
            smbTransferService.transferFiles(sourcPath, "STUDY123");

            SMBClient mockedSMBClient = mockedClient.constructed().get(0);
            verify(mockedSMBClient).connect("host");
            assertDoesNotThrow(() -> smbTransferService.transferFiles(sourcPath, "STUDY123"));
        }

        executorService.shutdown();
        Files.deleteIfExists(testFile);
        Files.deleteIfExists(sourcPath);

    }

    @Test
    void transferFiles_failure() throws Exception {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        SMBTransferService smbTransferService = new SMBTransferService(executorService);

        setField(smbTransferService, "synapseHost", "host");
        setField(smbTransferService, "synapseUsername", "synapseUsername");
        setField(smbTransferService, "synapsePassword", "synapsePassword");
        setField(smbTransferService, "synapseFolder", "synapseFolder");

        Path sourcPath = Files.createTempDirectory("testSource");
        Path testFile = Files.createTempFile(sourcPath, "file", ".txt");
        Files.writeString(testFile, "test content");

        try (MockedConstruction<SMBClient> mockedClient = mockConstruction(SMBClient.class,
                (mock, context) -> {
                    Connection connection = mock(Connection.class);
                    File remoteFile = mock(File.class);

                    when(mock.connect(anyString())).thenReturn(connection);
                    when(remoteFile.write(any(byte[].class), anyLong(), anyInt(), anyInt()))
                            .thenThrow(new IOException("Disk write failed"));

                })) {
            ExportServiceException ex = assertThrows(ExportServiceException.class,
                    () -> smbTransferService.transferFiles(sourcPath, "STUDY123"));
            assertTrue(ex.getMessage().contains("Error during file transfer"));
        }
        executorService.shutdown();
        Files.deleteIfExists(testFile);
        Files.deleteIfExists(sourcPath);

    }
}