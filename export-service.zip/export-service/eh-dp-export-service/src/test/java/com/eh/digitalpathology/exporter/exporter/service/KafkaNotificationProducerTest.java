package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.service.KafkaNotificationProducer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class KafkaNotificationProducerTest {

    @InjectMocks
    KafkaNotificationProducer kafkaNotificationProducer;

    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;

    @Test
    void sendNotification() {
        kafkaNotificationProducer.sendNotification("topic1", "key1", "data1");
        verify(kafkaTemplate).send("topic1", "key1", "data1");
    }

    @Test
    void testSendNotification_ExceptionThrown() {
        String topic = "test-topic";
        String key = "test-key";
        String data = "test-data";

        KafkaTemplate<String, String> mockKafkaTemplate = mock(KafkaTemplate.class);
        KafkaNotificationProducer service = new KafkaNotificationProducer(mockKafkaTemplate);

        doThrow(new RuntimeException("Kafka send failed")).when(mockKafkaTemplate).send(topic, key, data);

        service.sendNotification(topic, key, data);
        verify(mockKafkaTemplate).send(topic, key, data);
    }

}