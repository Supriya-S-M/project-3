package com.eh.digitalpathology.exporter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class ExportServiceApplicationTest {
    @Test
    void contextLoads() {
        // It is used to check if the Spring application context loads successfully.
    }
}