package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.dbclient.DBRestClient;
import com.eh.digitalpathology.exporter.exceptions.Hl7MessageException;
import com.eh.digitalpathology.exporter.model.ApiResponse;
import com.eh.digitalpathology.exporter.model.BarcodeInstanceRequest;
import com.eh.digitalpathology.exporter.service.DatabaseService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import reactor.core.publisher.Mono;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class DatabaseServiceTest {

    @Mock
    private DBRestClient dbRestClient;

    @InjectMocks
    private DatabaseService databaseService;

    @Test
    void testGetHttpHeaders() throws Exception {
        Method method = DatabaseService.class.getDeclaredMethod("getHttpHeaders");
        method.setAccessible(true);
        HttpHeaders headers = (HttpHeaders) method.invoke(null);

        assertNotNull(headers, "Headers should not be null");
        assertTrue(headers.containsKey("X-Service-Name"), "Header should contain 'X-Service-Name'");
        assertEquals("exported", headers.getFirst("X-Service-Name"), "Header value should be 'exported'");
    }

    @Test
    void testUpdateStatus_Success() {

        BarcodeInstanceRequest request = new BarcodeInstanceRequest("ABC123", "1.2.3.4.5");
        ApiResponse<String> response = new ApiResponse<>("UPDATED", "Success", null, null);

        when(dbRestClient.exchange(
                eq(HttpMethod.PUT),
                eq("dicom/status/instances"),
                eq(request),
                any(ParameterizedTypeReference.class),
                any()
        )).thenReturn(Mono.just(response));

        String result = databaseService.updateStatus(request);

        assertEquals("UPDATED", result);
        verify(dbRestClient).exchange(
                eq(HttpMethod.PUT),
                eq("dicom/status/instances"),
                eq(request),
                any(ParameterizedTypeReference.class),
                any()
        );
    }

    @Test
    void testUpdateStatus_ThrowsHl7MessageException() {

        BarcodeInstanceRequest request = new BarcodeInstanceRequest("ABC123", "1.2.3.4.5");

        when(dbRestClient.exchange(
                any(),
                anyString(),
                any(),
                any(ParameterizedTypeReference.class),
                any()
        )).thenThrow(new RuntimeException("failure"));

        Hl7MessageException exception = assertThrows(Hl7MessageException.class, () -> {
            databaseService.updateStatus(request);
        });

        assertEquals("INVALID_ERROR", exception.getErrorCode());
        assertTrue(exception.getMessage().contains("failure"));
    }
}