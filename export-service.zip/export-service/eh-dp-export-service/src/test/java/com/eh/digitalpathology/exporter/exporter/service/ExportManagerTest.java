package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.config.DownstreamConfig;
import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.model.ExportMessage;
import com.eh.digitalpathology.exporter.service.ExportManager;
import com.eh.digitalpathology.exporter.service.ExportService;
import com.eh.digitalpathology.exporter.visiopharm.SeriesNotifierService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportManagerTest {

    @Mock
    private ExecutorService executorService;

    @Mock
    private GcpConfig gcpConfig;

    @Mock
    private SeriesNotifierService visiopharmSeriesNotifier;

    @Mock
    private DownstreamConfig downstreamConfig;

    @Mock
    private ExportService exportService;
    @InjectMocks
    private ExportManager exportManager;

    @BeforeEach
    void setup() {
        when(gcpConfig.getDicomWebUrl()).thenReturn("http://localhost:8080");
        lenient().when( downstreamConfig.isVisiopharm() ).thenReturn( true );
        lenient().when( downstreamConfig.isSynapse( ) ).thenReturn( true );
        lenient().when( downstreamConfig.isIbex( ) ).thenReturn( true );

        doAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return null;
        }).when(executorService).execute(any(Runnable.class));


        doAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return CompletableFuture.completedFuture(null);
        }).when(executorService).submit(any(Runnable.class));
    }

    @Test
    void testExportToDownstreamServices_success() throws Exception {

        ExportMessage exportMessage = new ExportMessage(
                "dicomWebUrl",
                "study123",
                "series456", 1,
                List.of("inst1", "inst2"),
                new byte[0],
                "url"
        );

        doNothing().when(exportService).exportInstances(anyString(),
                anyList(),
                any(), any(), anyString(), anyString(), anyString());

        CompletableFuture<Void> future = exportManager.exportToDownstreamServices(exportMessage);
        future.get(2, TimeUnit.SECONDS);

        verify(visiopharmSeriesNotifier, times(1)).notifyVisiopharm(anyString());
        verify(exportService, times(1)).exportInstances(anyString(), anyList(),
                any(), any(), anyString(), anyString(), anyString());
    }

    @Test
    void testExportToDownstreamServices_throwsException() throws Exception {
        ExportMessage exportMessage = new ExportMessage(
                "dicomWebUrl",
                "study123",
                "series456", 1,
                List.of("inst1", "inst2"),
                new byte[0],
                "url"
        );
        doThrow(new ExportServiceException("Test Failure"))
                .when(exportService)
                .exportInstances(anyString(), anyList(), any(), any(),
                        anyString(), anyString(), anyString());

        ExecutionException exception = assertThrows(ExecutionException.class, () ->
                exportManager.exportToDownstreamServices(exportMessage).get(2, TimeUnit.SECONDS));

        assertTrue(exception.getCause() instanceof ExportServiceException);
        verify(exportService, times(1)).exportInstances(anyString(),
                anyList(), any()
                , any(), anyString(), anyString(), anyString());
    }

}
