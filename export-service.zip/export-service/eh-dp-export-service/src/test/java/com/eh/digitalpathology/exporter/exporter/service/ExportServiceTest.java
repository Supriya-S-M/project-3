package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.config.DownstreamConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.exceptions.HealthcareApiException;
import com.eh.digitalpathology.exporter.healthcareapi.HealthcareAPIUtil;
import com.eh.digitalpathology.exporter.model.BarcodeInstanceRequest;
import com.eh.digitalpathology.exporter.model.InstanceInfo;
import com.eh.digitalpathology.exporter.service.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportServiceTest {

    @InjectMocks
    private ExportService exportService;

    @Mock
    private HealthcareAPIUtil healthcareAPIUtil;

    @Mock
    private KafkaNotificationProducer kafkaNotificationProducer;

    @Mock
    private DatabaseService databaseService;

    @Mock
    private ExecutorService executorService;

    @Mock
    SMBTransferService smbTransferService;

    @Mock
    private DownstreamConfig downstreamConfig;

    @Mock
    CloudStorageUploadService cloudStorageUploadService;

    private final String barcode = "barcode123";
    private final String seriesId = "series123";
    private final String dicomWebUrl = "http://dicomweb.com";

    private Path tempDir;
    private String studyUid;
    private ScheduledExecutorService scheduledExecutorService;

    @BeforeEach
    void setup() throws IOException {
        tempDir = Files.createTempDirectory("study123");
        lenient().when( downstreamConfig.isIbex( ) ).thenReturn( true );
        lenient().when( downstreamConfig.isSynapse( ) ).thenReturn( true );
        lenient().when( downstreamConfig.isVisiopharm( ) ).thenReturn( true );
        studyUid = tempDir.toString();
        scheduledExecutorService = mock(ScheduledExecutorService.class);
        ReflectionTestUtils.setField(exportService, "scheduler", scheduledExecutorService);
    }

    @AfterEach
    void cleanup() throws IOException {
        if (tempDir != null && Files.exists(tempDir)) {
            Files.walk(tempDir)
                    .sorted(Comparator.reverseOrder())
                    .map(Path::toFile)
                    .forEach(File::delete);
        }
    }

    @Test
    void testExportInstances_success() throws Exception {
        Files.writeString(Files.createFile(tempDir.resolve("DICOMDIR")), "dummyDicomData");

        InstanceInfo instance = mock(InstanceInfo.class);
        when(instance.instanceId()).thenReturn("instance123");
        List<InstanceInfo> instances = List.of(instance);

        byte[] dicomBytes = "dummyDicomData".getBytes();

        when(executorService.submit(any(Runnable.class))).thenAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return mock(Future.class);
        });

        doNothing().when(healthcareAPIUtil).downloadInstance(instance, studyUid);
        when(databaseService.updateStatus(any(BarcodeInstanceRequest.class))).thenReturn("success");
        lenient().doNothing().when(kafkaNotificationProducer).sendNotification(anyString(), anyString(), anyString());

        exportService.exportInstances(studyUid, instances, dicomBytes, executorService, barcode, seriesId, dicomWebUrl);

        Path expectedZip = Paths.get(studyUid + ".zip");
        assertTrue(Files.exists(expectedZip), "ZIP file should be created");

        try (ZipInputStream zis = new ZipInputStream(Files.newInputStream(expectedZip))) {
            ZipEntry entry = zis.getNextEntry();
            assertNotNull(entry, "ZIP should contain at least one entry");
            assertEquals("DICOMDIR", entry.getName(), "ZIP should contain the correct file");
        }

        verify(smbTransferService).transferFiles(tempDir, studyUid);
        verify(cloudStorageUploadService).upload(studyUid, expectedZip, barcode, seriesId, dicomWebUrl);
        verify(healthcareAPIUtil).downloadInstance(instance, studyUid);
        verify(databaseService).updateStatus(any(BarcodeInstanceRequest.class));
        verify(executorService, times(2)).submit(any(Runnable.class));
    }

    @Test
    void testExport_deleteLocalFiles() throws Exception {
        Path dummyFile = Files.createFile(tempDir.resolve("dummyInstanc.dcm"));
        Files.writeString(dummyFile, "dummyData");
        Path zipFile = Paths.get(studyUid + ".zip");

        InstanceInfo instanceInfo = mock(InstanceInfo.class);
        List<InstanceInfo> instances = List.of(instanceInfo);

        byte[] dicomBytes = "dummyDicomData".getBytes();

        doThrow(new RuntimeException("failure"))
                .when(healthcareAPIUtil)
                .downloadInstance(any(), anyString());

        assertThrows(ExportServiceException.class, () ->
                exportService.exportInstances(
                        studyUid, instances, dicomBytes, executorService,
                        barcode, seriesId, dicomWebUrl
                ));
        assertFalse(Files.exists(dummyFile), "Instance file should be deleted by deleteDownloadedStudies()");
        assertFalse(Files.exists(tempDir), "Study folder file should be deleted by deleteDownloadedStudies()");
        assertFalse(Files.exists(zipFile), "zip file should be deleted by deleteDownloadedStudies()");
    }

    @Test
    void testExport_deleteZip() throws Exception {
        Path dummyFile = Files.createFile(tempDir.resolve("dummyInstanc.dcm"));
        Files.writeString(dummyFile, "dummyData");
        InstanceInfo instanceInfo = mock(InstanceInfo.class);
        when(instanceInfo.instanceId()).thenReturn("12345");
        List<InstanceInfo> instances = List.of(instanceInfo);

        byte[] dicomBytes = "dummyDicomData".getBytes();

        doNothing().when(healthcareAPIUtil).downloadInstance(instanceInfo
                , studyUid);

        when(executorService.submit(any(Runnable.class))).thenAnswer(invocationOnMock -> {
            Runnable task = invocationOnMock.getArgument(0);
            task
                    .run();
            return mock(Future.class);
        });

        ArgumentCaptor<Runnable> zipDeleteCaptor = ArgumentCaptor.forClass(Runnable.class);
        ScheduledFuture<?> scheduledFuture = mock(ScheduledFuture.class);
        when(scheduledExecutorService.schedule(zipDeleteCaptor.capture(), anyLong(), any(TimeUnit.class))).thenAnswer(invocationOnMock -> scheduledFuture);

        when(databaseService.updateStatus(any(BarcodeInstanceRequest.class))).thenReturn("success");
        lenient().doNothing().when(kafkaNotificationProducer)
                .sendNotification(anyString(), anyString(), anyString());
        exportService.exportInstances(studyUid, instances, dicomBytes, executorService, barcode, seriesId, dicomWebUrl);

        zipDeleteCaptor.getValue().run();
        Path expectedZip = Paths.get(studyUid + ".zip");
        assertFalse(Files.exists(expectedZip), "Zip should be deleted");

        verify(healthcareAPIUtil).downloadInstance(instanceInfo, studyUid);
        verify(databaseService).updateStatus(any(BarcodeInstanceRequest.class));
        verify(executorService, times(2)).submit(any(Runnable.class));
        verify(scheduledExecutorService).schedule(any(Runnable.class), eq(10L), eq(TimeUnit.MINUTES));
    }

    @Test
    void testExport_deleteZipIOException() throws Exception {
        Path targetZip = tempDir.resolve("study.zip");
        Files.createFile(targetZip);
        ArgumentCaptor<Runnable> zipDeleteCaptor = ArgumentCaptor.forClass(Runnable.class);
        ScheduledFuture<?> scheduledFuture = mock(ScheduledFuture.class);
        when(scheduledExecutorService.schedule(zipDeleteCaptor.capture(), anyLong(), any(TimeUnit.class))).thenAnswer(invocationOnMock -> scheduledFuture);

        try (var filesMockedStatic = mockStatic(Files.class)) {
            filesMockedStatic.when(() -> Files.deleteIfExists(eq(targetZip)))
                    .thenThrow(new IOException("Test IOException"));

            Method deleteZip = ExportService.class.getDeclaredMethod("deleteDownloadedStudiesZip", Path.class);
            deleteZip.setAccessible(true);
            deleteZip.invoke(exportService, targetZip);
            Runnable zipRunnable = zipDeleteCaptor.getValue();

            zipRunnable.run();
            filesMockedStatic.verify(() -> Files.deleteIfExists(eq(targetZip)));
        }
        verify(scheduledExecutorService).schedule(any(Runnable.class), eq(10L), eq(TimeUnit.MINUTES));
    }


    @Test
    void testExportInstances_healthcareApiException() throws Exception {
        InstanceInfo instance = mock(InstanceInfo.class);
        List<InstanceInfo> instances = List.of(instance);

        doThrow(new HealthcareApiException("API error")).when(healthcareAPIUtil).downloadInstance(any(), any());

        ExportServiceException exception = assertThrows(ExportServiceException.class, () ->
                exportService.exportInstances(studyUid, instances, null, executorService, barcode, seriesId, dicomWebUrl)
        );

        assertTrue(exception.getMessage().contains("HealthcareApiException"));
    }

    @Test
    void testExportInstances_genericExceptionDuringStatusUpdate() throws Exception {
        InstanceInfo instance = mock(InstanceInfo.class);
        lenient().when(instance.instanceId()).thenReturn("instance123");
        List<InstanceInfo> instances = List.of(instance);

        byte[] dicomBytes = "dummyDicomData".getBytes();

        doNothing().when(healthcareAPIUtil).downloadInstance(any(), any());
        lenient().doThrow(new RuntimeException("Unexpected error")).when(databaseService).updateStatus(any());
        lenient().doNothing().when(kafkaNotificationProducer).sendNotification(anyString(), anyString(), anyString());
        lenient().when(executorService.submit(any(Runnable.class))).thenAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return mock(Future.class);
        });

        ExportServiceException exception = assertThrows(ExportServiceException.class, () ->
                exportService.exportInstances(studyUid, instances, dicomBytes, executorService, barcode, seriesId, dicomWebUrl)
        );

        assertTrue(exception.getMessage().contains("Unexpected error"));
    }


    @Test
    void testTransferDicomSeriesToSynapseSharedFolder_exceptionHandled() throws Exception {
        InstanceInfo instance = mock(InstanceInfo.class);
        when(instance.instanceId()).thenReturn("instance123");
        List<InstanceInfo> instances = List.of(instance);
        byte[] dicomBytes = "dummyDicomData".getBytes();

        Files.writeString(Files.createFile(tempDir.resolve("DICOMDIR")), "dummyDicomData");

        doThrow(new RuntimeException("SMB transfer failed"))
                .when(smbTransferService).transferFiles(any(), any());

        when(executorService.submit(any(Runnable.class))).thenAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return mock(Future.class);
        });

        doNothing().when(healthcareAPIUtil).downloadInstance(any(), any());
        when(databaseService.updateStatus(any())).thenReturn("success");
        lenient().doNothing().when(kafkaNotificationProducer).sendNotification(anyString(), anyString(), anyString());
        exportService.exportInstances(studyUid, instances, dicomBytes, executorService, barcode, seriesId, dicomWebUrl);
        verify(smbTransferService).transferFiles(any(), any());
    }

    @Test
    void testUploadDicomSeriesToCloudStorage_exceptionHandled() throws Exception {
        InstanceInfo instance = mock(InstanceInfo.class);
        when(instance.instanceId()).thenReturn("instance123");
        List<InstanceInfo> instances = List.of(instance);
        byte[] dicomBytes = "dummyDicomData".getBytes();

        Files.writeString(Files.createFile(tempDir.resolve("DICOMDIR")), "dummyDicomData");

        doThrow(new RuntimeException("Cloud upload failed"))
                .when(cloudStorageUploadService).upload(any(), any(), any(), any(), any());

        when(executorService.submit(any(Runnable.class))).thenAnswer(invocation -> {
            Runnable task = invocation.getArgument(0);
            task.run();
            return mock(Future.class);
        });

        doNothing().when(healthcareAPIUtil).downloadInstance(any(), any());
        when(databaseService.updateStatus(any())).thenReturn("success");
        lenient().doNothing().when(kafkaNotificationProducer).sendNotification(anyString(), anyString(), anyString());

        exportService.exportInstances(studyUid, instances, dicomBytes, executorService, barcode, seriesId, dicomWebUrl);
        verify(cloudStorageUploadService).upload(any(), any(), any(), any(), any());
    }


}
