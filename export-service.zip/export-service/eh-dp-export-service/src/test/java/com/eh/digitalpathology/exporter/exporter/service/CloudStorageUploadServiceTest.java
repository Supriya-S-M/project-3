package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.service.CloudStorageUploadService;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.WriteChannel;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Bucket;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CloudStorageUploadServiceTest {

    @InjectMocks
    private CloudStorageUploadService cloudStorageUploadService;

    @Mock
    private GcpConfig gcpConfig;

    @Mock
    private Storage storage;

    @Mock
    private Bucket bucket;

    @Mock
    private WriteChannel writeChannel;

    private final String enrichedDicomBucket = "test-bucket";

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(cloudStorageUploadService, "enrichedDicomBucket", enrichedDicomBucket);
    }

    @Test
    void testUpload_SuccessfulUpload() throws Exception {
        String creds = "{\"type\": \"service_account\"}";
        when(gcpConfig.getCreds()).thenReturn(creds);
        when(storage.get(enrichedDicomBucket)).thenReturn(mock(Bucket.class));

        when(storage.get(enrichedDicomBucket)).thenReturn(mock(Bucket.class));
        when(storage.writer(any(BlobInfo.class))).thenReturn(writeChannel);
        when(writeChannel.write(any(ByteBuffer.class))).thenReturn(10);


        Path tempFile = Files.createTempFile("test", ".zip");
        Files.writeString(tempFile, "test content");
        try (MockedStatic<StorageOptions> mockedStorageOpions = mockStatic(StorageOptions.class);
             MockedStatic<ServiceAccountCredentials> mockedCreds = mockStatic(ServiceAccountCredentials.class)) {

            ServiceAccountCredentials credentials = mock(ServiceAccountCredentials.class);
            mockedCreds.when(() -> ServiceAccountCredentials.fromStream(any(InputStream.class)))
                    .thenReturn(credentials);

            StorageOptions.Builder builder = mock(StorageOptions.Builder.class);
            StorageOptions options = mock(StorageOptions.class);


            mockedStorageOpions.when(StorageOptions::newBuilder).thenReturn(builder);
            when(builder.setCredentials(any())).thenReturn(builder);
            when(builder.build()).thenReturn(options);
            when(options.getService()).thenReturn(storage);
            assertDoesNotThrow(() -> cloudStorageUploadService.upload("study123",
                    tempFile, "barcode1", "series1", "http:://dicomweb"));
        }

        verify(storage, times(1)).writer(any(BlobInfo.class));
        verify(writeChannel, atLeastOnce()).write(any(ByteBuffer.class));
    }

    @Test
    void testUpload_IOExceptionDuringWrite() throws Exception {
        String creds = "{\"type\": \"service_account\"}";
        when(gcpConfig.getCreds()).thenReturn(creds);
        when(storage.get(enrichedDicomBucket)).thenReturn(mock(Bucket.class));

        when(storage.get(enrichedDicomBucket)).thenReturn(mock(Bucket.class));
        when(storage.writer(any(BlobInfo.class))).thenReturn(writeChannel);

        Path tempFile = Files.createTempFile("test", ".zip");
        Files.writeString(tempFile, "test content");
        try (MockedStatic<StorageOptions> mockedStorageOpions = mockStatic(StorageOptions.class);
             MockedStatic<ServiceAccountCredentials> mockedCreds = mockStatic(ServiceAccountCredentials.class)) {

            ServiceAccountCredentials credentials = mock(ServiceAccountCredentials.class);
            mockedCreds.when(() -> ServiceAccountCredentials.fromStream(any(InputStream.class)))
                    .thenReturn(credentials);

            StorageOptions.Builder builder = mock(StorageOptions.Builder.class);
            StorageOptions options = mock(StorageOptions.class);


            mockedStorageOpions.when(StorageOptions::newBuilder).thenReturn(builder);
            when(builder.setCredentials(any())).thenReturn(builder);
            when(builder.build()).thenReturn(options);
            when(options.getService()).thenReturn(storage);


            doThrow(new IOException("Disk write failure"))
                    .when(writeChannel)
                    .write(any(ByteBuffer.class));

            ExportServiceException ex = assertThrows(ExportServiceException.class,
                    () -> cloudStorageUploadService.upload("study123",
                            tempFile, "barcode1", "series1", "http:://dicomweb"));

            assertTrue(ex.getMessage().contains("Unable to copy the file into the bucket"));

        }
    }
}