package com.eh.digitalpathology.exporter.exporter.healthcareapi;

import com.eh.digitalpathology.exporter.exceptions.HealthcareApiException;
import com.eh.digitalpathology.exporter.healthcareapi.HealthcareAPIUtil;
import com.eh.digitalpathology.exporter.model.InstanceInfo;
import com.eh.digitalpathology.exporter.utils.GCPUtils;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class HealthcareAPIUtilTest {

    @Mock
    CloseableHttpClient closeableHttpClient;

    @Mock
    CloseableHttpResponse closeableHttpResponse;

    @Mock
    HttpEntity httpEntity;

    @Mock
    StatusLine statusLine;

    @Mock
    InstanceInfo instanceInfo;

    @InjectMocks
    HealthcareAPIUtil healthcareAPIUtil;

    private static final String STUDY_UID = "12345";

    @BeforeEach
    void setUp() {

        when(instanceInfo.instancePath()).thenReturn("https://test.com");
        lenient().when(instanceInfo.instanceId()).thenReturn("instance123");
    }

    @Test
    void testDownloadInstance_success() throws Exception {
        try (MockedStatic<GCPUtils> utilities = Mockito.mockStatic(GCPUtils.class);
             MockedStatic<HttpClients> clients = Mockito.mockStatic(HttpClients.class)) {

            utilities.when(() -> GCPUtils.getAccessToken(any())).thenReturn("mockToken");
            clients.when(HttpClients::createDefault).thenReturn(closeableHttpClient);

            InputStream mockInputStream = new ByteArrayInputStream("dummy".getBytes());
            when(closeableHttpClient.execute(any(HttpGet.class))).thenReturn(closeableHttpResponse);
            when(closeableHttpResponse.getStatusLine()).thenReturn(statusLine);
            when(statusLine.getStatusCode()).thenReturn(200);
            when(closeableHttpResponse.getEntity()).thenReturn(httpEntity);
            when(httpEntity.getContent()).thenReturn(mockInputStream);

            healthcareAPIUtil.downloadInstance(instanceInfo, STUDY_UID);

            Path expectedPath = Paths.get(STUDY_UID, "instance123.dcm");
            assertTrue(Files.exists(expectedPath), "Expected dcm file should be created");
        }

    }

    @Test
    void testDownloadInstance_Exception() throws Exception {
        try (MockedStatic<GCPUtils> utilities = Mockito.mockStatic(GCPUtils.class);
             MockedStatic<HttpClients> clients = Mockito.mockStatic(HttpClients.class)) {

            utilities.when(() -> GCPUtils.getAccessToken(any())).thenReturn("mockToken");
            clients.when(HttpClients::createDefault).thenReturn(closeableHttpClient);

            when(closeableHttpClient.execute(any(HttpGet.class))).thenReturn(closeableHttpResponse);
            HealthcareApiException ex = assertThrows(HealthcareApiException.class,
                    () -> healthcareAPIUtil.downloadInstance(instanceInfo, STUDY_UID));
            assertTrue(ex.getMessage().contains("Unexpected error occurred"));

        }

    }

    @Test
    void testDownloadInstance_IOException() throws Exception {
        try (MockedStatic<GCPUtils> utilities = Mockito.mockStatic(GCPUtils.class);
             MockedStatic<HttpClients> clients = Mockito.mockStatic(HttpClients.class)) {

            utilities.when(() -> GCPUtils.getAccessToken(any())).thenReturn("mockToken");
            clients.when(HttpClients::createDefault).thenReturn(closeableHttpClient);

            when(closeableHttpClient.execute(any(HttpGet.class))).thenThrow(new IOException("IOException"));

            HealthcareApiException ex = assertThrows(HealthcareApiException.class,
                    () -> healthcareAPIUtil.downloadInstance(instanceInfo, STUDY_UID));

            assertTrue(ex.getMessage().contains("IO error occurred"));
        }

    }

    @Test
    void testDownloadInstance_failedWith404() throws Exception {
        try (MockedStatic<GCPUtils> utilities = Mockito.mockStatic(GCPUtils.class);
             MockedStatic<HttpClients> clients = Mockito.mockStatic(HttpClients.class)) {

            utilities.when(() -> GCPUtils.getAccessToken(any())).thenReturn("mockToken");
            clients.when(HttpClients::createDefault).thenReturn(closeableHttpClient);

            when(closeableHttpClient.execute(any(HttpGet.class))).thenReturn(closeableHttpResponse);
            when(closeableHttpResponse.getStatusLine()).thenReturn(statusLine);
            when(statusLine.getStatusCode()).thenReturn(404);

            when(closeableHttpResponse.getEntity()).thenReturn(httpEntity);
            when(httpEntity.getContent()).thenReturn(new ByteArrayInputStream(new byte[0]));

            HealthcareApiException ex = assertThrows(HealthcareApiException.class,
                    () -> healthcareAPIUtil.downloadInstance(instanceInfo, STUDY_UID));
            assertTrue(ex.getMessage().contains("Unexpected error occurred"));

        }

    }


}