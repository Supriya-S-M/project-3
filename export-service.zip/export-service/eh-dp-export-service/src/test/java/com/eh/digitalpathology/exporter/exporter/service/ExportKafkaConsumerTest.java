package com.eh.digitalpathology.exporter.exporter.service;

import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.model.ExportMessage;
import com.eh.digitalpathology.exporter.service.ExportKafkaConsumer;
import com.eh.digitalpathology.exporter.service.ExportManager;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportKafkaConsumerTest {

    @InjectMocks
    private ExportKafkaConsumer exportConsumer;

    @Mock
    private ExportManager exportManager;

    @Mock
    private Acknowledgment acknowledgment;


    @Test
    void testListen_successfulProcessing_acknowledged() throws Exception {
        String key = "testKey";
        ExportMessage exportMessage = new ExportMessage("barcode", "seriesId", "studyId", 1, List.of("inst1"), new byte[0], "url");

        String value = new ObjectMapper().writeValueAsString(exportMessage);
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>("topic", 0, 0L, key, value);

        when(exportManager.exportToDownstreamServices(any())).thenReturn(CompletableFuture.completedFuture(null));

        exportConsumer.listen(consumerRecord, acknowledgment);

        verify(exportManager).exportToDownstreamServices(any());
        verify(acknowledgment, timeout(1000)).acknowledge();
    }

    @Test
    void testListen_emptyMessage_throwsException() {
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>("topic", 0, 0L, "key", "");

        ExportServiceException exception = assertThrows(ExportServiceException.class, () ->
                exportConsumer.listen(consumerRecord, acknowledgment)
        );

        assertEquals("Received empty message ", exception.getMessage());
        verifyNoInteractions(exportManager);
        verifyNoInteractions(acknowledgment);
    }

    @Test
    void testListen_invalidJson_throwsException() {
        ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<>("topic", 0, 0L, "key", "invalid-json");

        ExportServiceException exception = assertThrows(ExportServiceException.class, () ->
                exportConsumer.listen(consumerRecord, acknowledgment)
        );

        assertEquals("Unable to extract data from message", exception.getMessage());
        verifyNoInteractions(exportManager);
        verifyNoInteractions(acknowledgment);
    }
}