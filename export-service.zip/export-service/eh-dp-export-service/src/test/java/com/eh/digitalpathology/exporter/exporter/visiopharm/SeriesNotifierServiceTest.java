package com.eh.digitalpathology.exporter.exporter.visiopharm;

import com.eh.digitalpathology.exporter.visiopharm.SeriesNotifierService;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.lang.reflect.Field;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SeriesNotifierServiceTest {

    @InjectMocks
    SeriesNotifierService seriesNotifierService;

    private static int[] statusCodeProvider() {
        return new int[]{200,404,500};
    }

    @BeforeEach
    void setUp() {
        seriesNotifierService = new SeriesNotifierService();
    }

    @ParameterizedTest
    @MethodSource("statusCodeProvider")
    void testNotifyVisiopharm_successP() throws Exception {
        Field field = SeriesNotifierService.class.getDeclaredField("visiopharmUrl");
        field.setAccessible(true);
        field.set(seriesNotifierService, "http://mockurl.com");
        CloseableHttpResponse mockRes = mock(CloseableHttpResponse.class);
        CloseableHttpClient mockClient = mock(CloseableHttpClient.class);
        StatusLine mockStatusLine = mock(StatusLine.class);

        when(mockClient.execute(any(HttpPost.class))).thenReturn(mockRes);
        when(mockRes.getStatusLine()).thenReturn(mockStatusLine);
        when(mockStatusLine.getStatusCode()).thenReturn(200);
        when(mockRes.getEntity()).thenReturn(new StringEntity("{\"message\":\"ok\"}"));

        try (MockedStatic<HttpClients> mockedStatic = mockStatic(HttpClients.class)) {
            mockedStatic.when(HttpClients::createDefault).thenReturn(mockClient);
            seriesNotifierService.notifyVisiopharm("testSeriesUrl");
        }
        verify(mockClient, times(1)).execute(any(HttpPost.class));

    }

    @Test
    void testNotifyVisiopharm_Exception() throws Exception {
        Field field = SeriesNotifierService.class.getDeclaredField("visiopharmUrl");
        field.setAccessible(true);
        field.set(seriesNotifierService, "http://mockurl.com");
        CloseableHttpClient mockClient = mock(CloseableHttpClient.class);

        when(mockClient.execute(any(HttpPost.class))).thenThrow(new IOException("Connection failed"));

        try (MockedStatic<HttpClients> mockedStatic = mockStatic(HttpClients.class)) {
            mockedStatic.when(HttpClients::createDefault).thenReturn(mockClient);
            seriesNotifierService.notifyVisiopharm("testSeriesUrl");
        }
        verify(mockClient, times(1)).execute(any(HttpPost.class));

    }
}