/**
 * HealthcareAPIUtil class acts as a client for the DICOM Healthcare API, encapsulating
 * the logic for API calls to DICOM stores. It provides a reusable and
 * modular approach for accessing healthcare DICOM data while managing
 * errors through custom exceptions.
 * Author: Pooja Kamble
 */

package com.eh.digitalpathology.exporter.healthcareapi;

import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.HealthcareApiException;
import com.eh.digitalpathology.exporter.model.InstanceInfo;
import com.eh.digitalpathology.exporter.utils.GCPUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class HealthcareAPIUtil {

    private static final Logger logger = LoggerFactory.getLogger(HealthcareAPIUtil.class);
    private final GcpConfig gcpConfig;

    public HealthcareAPIUtil( GcpConfig gcpConfig ) {
        this.gcpConfig = gcpConfig;
    }

    /**
     *This method is used to download all enriched DICOM instances of a study from final dicom store.
     * @param instanceInfo contains data of instance id and instance path
     * @param studyUid study id of DICOM study
     * @throws HealthcareApiException An exception is thrown when the healthcare API fails and throws an exception
     */
    public void downloadInstance(InstanceInfo instanceInfo, String studyUid) throws HealthcareApiException {
        try {
            // Add access token if available
            String accessToken = GCPUtils.getAccessToken(gcpConfig);

            // Prepare HTTP GET request
            HttpGet httpGet = new HttpGet(instanceInfo.instancePath());
            httpGet.setHeader( HttpHeaders.ACCEPT, "application/dicom; transfer-syntax=*");
            if (accessToken != null && !accessToken.isEmpty()) {
                httpGet.setHeader( HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
            }

            try ( CloseableHttpClient httpClient = HttpClients.createDefault();
                  CloseableHttpResponse response = httpClient.execute(httpGet);
                  InputStream inputStream = response.getEntity().getContent()) {

                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    logger.info("downloadInstance :: Successfully retrieved DICOM instance. {}", instanceInfo.instanceId());
                    writeToFile(instanceInfo, studyUid, inputStream);
                } else {
                    throw new HealthcareApiException("downloadInstance :: Failed to retrieve DICOM instance. HTTP status: " + statusCode);
                }
            }
        } catch (IOException e) {
            throw new HealthcareApiException("downloadInstance :: IO error occurred: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new HealthcareApiException("downloadInstance :: Unexpected error occurred: " + e.getMessage(), e);
        }
    }


    /**
     * Writes data to file and stores it in folder with structure study id/series id/instanceId.dcm
     * @param instance instance id of DICOM study
     * @param studyUid study id of DICOM study
     * @param responseInputStream InputStream data containing DICOM data
     * @throws HealthcareApiException An exception is thrown when the healthcare API fails and throws an exception
     */
    private static void writeToFile(InstanceInfo instance, String studyUid, InputStream responseInputStream) throws HealthcareApiException {
        String filename = instance.instanceId() + ".dcm";
        logger.info("writeToFile :: Initiating the download for the instance DICOM file. : {}", filename);
        try {
            Path path = Files.createDirectories(Paths.get(studyUid)).resolve(filename);
            try (OutputStream out = Files.newOutputStream(path)) {
                StreamUtils.copy(responseInputStream, out);
            }
        } catch (IOException e) {
            throw new HealthcareApiException("writeToFile :: Exception occurred while writing instance data to file : ", e);
        } catch (Exception e) {
            throw new HealthcareApiException("writeToFile :: Unexpected exception occurred while writing instance data to file : ", e);
        }
    }
}

