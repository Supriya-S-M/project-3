/**
 * GcpRuntimeConfig class serves as an API wrapper for making REST calls to the GCP Configuration service
 * and get the all variables from runtime config.
 * Author: Pooja Kamble
 * Date: Nov 25, 2024
 */

package com.eh.digitalpathology.exporter.exceptions;

public class GcpRuntimeConfigException extends Exception {
    public GcpRuntimeConfigException(String msg) {
        super(msg);
    }
}