/**
 * ExportServiceException is used to handle errors occurred during export service.
 * This exception is thrown when there are issues encountered while processing data for exporting files
 * encapsulating error messages and underlying causes.
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */

package com.eh.digitalpathology.exporter.exceptions;

public class ExportServiceException extends RuntimeException{
    public ExportServiceException(String message) {
        super(message);
    }

    public ExportServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}