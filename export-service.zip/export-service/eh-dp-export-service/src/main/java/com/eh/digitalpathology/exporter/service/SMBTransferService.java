/**
 * SMBTransferService is used to transfer zip file with instances downloaded to Synapse shared path
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */

package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2CreateOptions;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import com.hierynomus.smbj.share.File;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.*;
import java.util.stream.Stream;

@Service
@RefreshScope
public class SMBTransferService {

    @Value( "${synapse.server.host}" )
    private String synapseHost;

    @Value( "${synapse.server.username}" )
    private String synapseUsername;
    @Value( "${synapse.server.password}" )
    private String synapsePassword;
    @Value( "${synapse.server.folder}" )
    private String synapseFolder;
    @Value( "${project.name}" )
    private String googleProjectName;

    private static final Logger logger = LoggerFactory.getLogger( SMBTransferService.class );
    private final ExecutorService executorService;
    private final Object folderLock = new Object();

    public SMBTransferService ( @Qualifier( "smbExecutorService" ) ExecutorService executorService ) {
        this.executorService = executorService;
    }

    /**
     * This method is used to transfer files through SMB protocol to Synapse shared path
     * <p>
     *
     * @param studyUid study id of DICOM file
     * @throws ExportServiceException This custom exception is thrown when there is any issue occurred while exporting study.
     */

    public void transferFiles ( Path sourcePath, String studyUid ) throws ExportServiceException {
        AuthenticationContext authContext = new AuthenticationContext( synapseUsername, synapsePassword.toCharArray( ), "" );

        List< CompletableFuture< Void > > futures = new ArrayList<>( );
        Set<String> createdFolders = ConcurrentHashMap.newKeySet();

        try ( SMBClient client = new SMBClient( ); Connection connection = client.connect( synapseHost ); Session session = connection.authenticate( authContext ); DiskShare share = (DiskShare) session.connectShare( synapseFolder ) ) {
            // Create studyUid folder if not exists
            createFolderIfNotExists( share, studyUid, createdFolders );

            try ( Stream< Path > fileStream = Files.walk( sourcePath ) ) {
                fileStream.filter( Files::isRegularFile ).forEach( localFile -> {
                    CompletableFuture< Void > future = CompletableFuture.runAsync( ( ) -> {
                        try {
                            String relativePath = sourcePath.relativize( localFile ).toString( ).replace( "\\", "/" );
                            String remoteFilePath = studyUid + '/' + relativePath;

                            // Create parent folders if needed
                            String parentDir = remoteFilePath.contains( "/" ) ? remoteFilePath.substring( 0, remoteFilePath.lastIndexOf( "/" ) ) : "";

                            if ( !parentDir.isEmpty( ) ) {
                                createFolderIfNotExists( share, parentDir, createdFolders );
                            }

                            try ( InputStream is = Files.newInputStream( localFile ); File remoteFile = openRemoteFileForWrite( share, remoteFilePath ) ) {
                                writeToSynapseSharedFolder( is, remoteFile );
                                logger.info( "transferFiles :: File transferred: {}", remoteFilePath );
                            }
                        } catch ( IOException e ) {
                            throw new CompletionException( new ExportServiceException( "Failed to transfer file: " + localFile, e ) );
                        }
                    }, executorService );

                    futures.add( future );
                } );
            }

            // Wait for all tasks to complete
            CompletableFuture.allOf( futures.toArray( new CompletableFuture[ 0 ] ) ).join( );
            logger.info( "transferFiles :: All files transferred successfully to studyUid folder: {}", studyUid );

        } catch ( Exception e ) {
            Thread.currentThread( ).interrupt( );
            throw new ExportServiceException( "Error during file transfer", e );
        }
    }


    private File openRemoteFileForWrite ( DiskShare share, String remoteFilePath ) {
        return share.openFile( remoteFilePath, EnumSet.of( AccessMask.GENERIC_READ, AccessMask.GENERIC_WRITE ), EnumSet.noneOf( FileAttributes.class ), EnumSet.of( SMB2ShareAccess.FILE_SHARE_READ ), SMB2CreateDisposition.FILE_OVERWRITE_IF, EnumSet.noneOf( SMB2CreateOptions.class ) );
    }

    private void createFolderIfNotExists(DiskShare share, String path, Set<String> createdFolders) {
        if (createdFolders.contains(path)) return;

        synchronized (folderLock) {
            if (!createdFolders.contains(path)) {
                if (!share.folderExists(path)) {
                    share.mkdir(path);
                }
                createdFolders.add(path);
            }
        }
    }

    private void writeToSynapseSharedFolder ( InputStream is, File remoteFile ) throws IOException {
        byte[] buffer = new byte[ 8 * 1024 * 1024 ]; // 4MB buffer
        int bytesRead;
        long fileOffset = 0;

        while ( ( bytesRead = is.read( buffer ) ) != -1 ) {
            remoteFile.write( buffer, fileOffset, 0, bytesRead );
            fileOffset += bytesRead;
        }
    }

}

