package com.eh.digitalpathology.exporter.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "downstream.enabled")
@RefreshScope
public class DownstreamConfig {
    private boolean synapse;
    private boolean ibex;
    private boolean visiopharm;

    public boolean isSynapse ( ) {
        return synapse;
    }

    public void setSynapse ( boolean synapse ) {
        this.synapse = synapse;
    }

    public boolean isIbex ( ) {
        return ibex;
    }

    public void setIbex ( boolean ibex ) {
        this.ibex = ibex;
    }

    public boolean isVisiopharm ( ) {
        return visiopharm;
    }

    public void setVisiopharm ( boolean visiopharm ) {
        this.visiopharm = visiopharm;
    }
}
