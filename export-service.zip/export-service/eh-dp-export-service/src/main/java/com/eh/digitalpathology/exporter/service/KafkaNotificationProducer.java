package com.eh.digitalpathology.exporter.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class KafkaNotificationProducer {

    private static final Logger log = LoggerFactory.getLogger(KafkaNotificationProducer.class.getName());
    private final KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public KafkaNotificationProducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendNotification(String topic, String key, String data) {
            try {
                log.info("send notification :: data :: {}, key :: {}", data, key);
                kafkaTemplate.send(topic, key, data);
                log.info("sendNotification:: Message sent successfully to :: {} ", topic);
            } catch (Exception ex) {
                log.error( "Failed to send message to {} : {} ", topic, ex.getMessage( ) );
            }
    }

}
