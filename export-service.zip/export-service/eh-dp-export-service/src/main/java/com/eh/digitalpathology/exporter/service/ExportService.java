/**
 * ExportService is the service class which is responsible for exporting instance.
 * It downloads instances from DICOM store then creates zip folder and further transfers this zip file to CLoud storage and Synapse shared folder
 * Author: Pooja Kamble
 * Date: November 13, 2024
 */

package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.config.DownstreamConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.exceptions.HealthcareApiException;
import com.eh.digitalpathology.exporter.healthcareapi.HealthcareAPIUtil;
import com.eh.digitalpathology.exporter.model.BarcodeInstanceRequest;
import com.eh.digitalpathology.exporter.model.InstanceInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
@RefreshScope
public class ExportService {

    private static final Logger logger = LoggerFactory.getLogger( ExportService.class );
    private final CloudStorageUploadService cloudStorageUploadService;
    private final SMBTransferService smbTransferService;
    private final HealthcareAPIUtil healthcareAPIUtil;
    private final KafkaNotificationProducer kafkaNotificationProducer;
    private final ScheduledExecutorService scheduler;
    private final DatabaseService databaseService;
    private final DownstreamConfig downstreamConfig;

    @Value( "${kafka.topic.email}" )
    private String emailSvcTopic;

    @Autowired
    public ExportService(CloudStorageUploadService cloudStorageUploadService, SMBTransferService smbTransferService, HealthcareAPIUtil healthcareAPIUtil, KafkaNotificationProducer kafkaNotificationProducer, @Qualifier("deleteScheduler") ScheduledExecutorService scheduler, DatabaseService databaseService, DownstreamConfig downstreamConfig) {
        this.cloudStorageUploadService = cloudStorageUploadService;
        this.smbTransferService = smbTransferService;
        this.healthcareAPIUtil = healthcareAPIUtil;
        this.kafkaNotificationProducer = kafkaNotificationProducer;
        this.scheduler = scheduler;
        this.databaseService = databaseService;
        this.downstreamConfig = downstreamConfig;
    }

    /**
     * This method is used to performing export activities on enriched DICOM files
     * 1. Downloads enriched file from final DICOM store
     * 2. Creates ZIP folder of downloaded studies
     * 3. Uploads study to CLoud storage
     * 4. Transfers file to Synapse shared path using SMB protocol
     *
     * @param instances instance id of DICOM file
     * @param studyUid  study id of DICOM file
     * @throws ExportServiceException This custom exception is thrown when there is any issue occurred while exporting study.
     */
    public void exportInstances ( String studyUid, List< InstanceInfo > instances, byte[] dicomBytes, ExecutorService executorService, String barcode, String seriesId, String dicomWebUrl ) throws ExportServiceException {
        Path sourcePath = Paths.get( studyUid );
        Path targetZipFile = Paths.get( sourcePath + ".zip" );
        try {
            for ( InstanceInfo instance : instances ) {
                healthcareAPIUtil.downloadInstance( instance, studyUid );
            }
            logger.info("exportInstances :: Successfully downloaded all instances of the study: {}", studyUid);
            if (dicomBytes != null && dicomBytes.length > 0) {
                Path outputFile = Paths.get(studyUid, "DICOMDIR");
                writeFile(outputFile, dicomBytes, barcode);

                if (downstreamConfig.isSynapse()) {
                    executorService.submit(() -> transferDicomSeriesToSynapseSharedFolder(sourcePath, studyUid));
                }
            } else if (dicomBytes == null) {
                kafkaNotificationProducer.sendNotification(emailSvcTopic, "DICOMDIR_UNAVAILABLE", barcode);
            }

            //zip the file
            createZipFile(sourcePath, targetZipFile);
            logger.info("exportInstances :: The ZIP folder has been successfully created : {}", targetZipFile);
            if (downstreamConfig.isIbex()) {
                executorService.submit(() -> uploadDicomSeriesToCloudStorage(studyUid, targetZipFile, barcode, seriesId, dicomWebUrl));
            }
            logger.info("exportInstances :: Successfully completed the export process for study ID : {}", studyUid);

            for (InstanceInfo instancesMeta : instances) {
                BarcodeInstanceRequest barcodeInstanceRequest = new BarcodeInstanceRequest(barcode, instancesMeta.instanceId());
                databaseService.updateStatus(barcodeInstanceRequest);
            }
        } catch (HealthcareApiException e) {
            throw new ExportServiceException("exportInstances :: HealthcareApiException occurred while exporting study", e);
        } catch (IOException e) {
            throw new ExportServiceException("exportInstances :: IOException occurred while exporting study", e);
        } catch (Exception e) {
            throw new ExportServiceException("exportInstances :: Unexpected error occurred while exporting study", e);
        } finally {
            deleteLocalFiles(sourcePath, targetZipFile);
        }
    }

    private void writeFile(Path outputFile, byte[] dicomBytes, String barcode) {
        try {
            Files.write(outputFile, dicomBytes);
        } catch (Exception e) {
            logger.error("exportInstances :: Error while writing DICOMDIR file ", e);
            kafkaNotificationProducer.sendNotification(emailSvcTopic, "DICOMDIR_UNAVAILABLE", barcode);
        }
    }

    private void createZipFile(Path sourceDir, Path targetZipFile) throws IOException {
        try (ZipOutputStream zs = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(targetZipFile))); Stream<Path> paths = Files.walk(sourceDir)) {
            paths.filter(path -> !Files.isDirectory(path)).forEach(path -> {
                ZipEntry zipEntry = new ZipEntry(sourceDir.relativize(path).toString().replace("\\", "/"));
                try {
                    zs.putNextEntry(zipEntry);
                    try (InputStream is = new BufferedInputStream(Files.newInputStream(path))) {
                        is.transferTo(zs);
                    }
                    zs.closeEntry();
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        }
    }


    private void transferDicomSeriesToSynapseSharedFolder(Path sourcePath, String studyUid) {
        try {
            // Transfer files to SMB shared drive
            logger.info("transferDicomSeriesToSynapseSharedFolder :: Starting the process of transferring files to the SMB shared drive…");
            smbTransferService.transferFiles(sourcePath, studyUid);
        } catch (Exception e) {
            logger.error("transferDicomSeriesToSynapseSharedFolder :: Exception occurred while transferring file to synapse shared folder for study {} with error -{}", studyUid, e);
        }
    }

    private void uploadDicomSeriesToCloudStorage(String studyUid, Path targetZipFile, String barcode, String seriesId, String dicomWebUrl) {
        try {
            // Transfer files to cloud storage
            logger.info("uploadDicomSeriesToCloudStorage :: Starting the process of uploading files to cloud storage…");
            cloudStorageUploadService.upload(studyUid, targetZipFile, barcode, seriesId, dicomWebUrl);
        } catch (Exception e) {
            logger.error("uploadDicomSeriesToCloudStorage :: Exception occurred while uploading file to the bucket for study {} with error -{}", studyUid, e.getMessage());
        }
    }

    private void deleteLocalFiles(Path sourceFolder, Path targetZipFolder) {
        deleteDownloadedStudies(sourceFolder);
        deleteDownloadedStudiesZip(targetZipFolder);
    }


    private void deleteDownloadedStudiesZip(Path targetZipFolder) {
        scheduler.schedule(() -> {
            try {
                Files.deleteIfExists(targetZipFolder);
                logger.info("Successfully deleted the zip folder: {}", targetZipFolder);
            } catch (IOException e) {
                logger.error("deleteDownloadedStudiesZip :: Failed to delete: {}", e.getMessage());
            }
        }, 10, TimeUnit.MINUTES);

    }


    private static void deleteDownloadedStudies(Path sourceFolder) {

        if (Files.exists(sourceFolder)) {
            try (Stream<Path> walk = Files.walk(sourceFolder)) {
                walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.delete(path);
                        logger.info("deleteDownloadedStudies :: Deleted: {}", path);
                    } catch (IOException e) {
                        logger.error("deleteDownloadedStudies :: Failed to delete: {}, :: {}", path, e.getMessage());
                    }
                });
            } catch (IOException e) {
                logger.error("deleteDownloadedStudies :: Failed to delete: {}", e.getMessage());
            }
        }
    }

}
