package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.model.ExportMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

@Service
@RefreshScope
public class ExportKafkaConsumer {

    private static final Logger logger = LoggerFactory.getLogger( ExportKafkaConsumer.class.getName( ) );
    private final ExportManager exportManager;

    public ExportKafkaConsumer ( ExportManager exportManager ) {
        this.exportManager = exportManager;
    }

    @KafkaListener( topics = "${kafka.topic.export}", groupId = "export-consumer-group", containerFactory = "kafkaListenerContainerFactory" )
    public void listen ( ConsumerRecord< String, String > consumerRecord, Acknowledgment ack ) throws ExportServiceException {
        logger.info( "listen :: consumer record value :: {}", consumerRecord.value( ) );
        ExportMessage exportMessage = extractData( consumerRecord );

        exportManager.exportToDownstreamServices( exportMessage ).thenRun( ( ) -> {
            ack.acknowledge( );
            logger.info( "Message with key {} processed and acknowledged", consumerRecord.key( ) );
        } ).exceptionally( ex -> {
            logger.error( "Error during downstream export ", ex );
            // Optionally send to DLQ or retry logic
            return null;
        } );

    }


    public ExportMessage extractData ( ConsumerRecord< String, String > consumerRecord ) throws ExportServiceException {
        logger.info( "extractData :: for eventKey : {}", consumerRecord.key( ) );
        String eventData = consumerRecord.value( );
        if ( eventData == null || eventData.isEmpty( ) ) {
            logger.error( "extractData :: Received empty message" );
            throw new ExportServiceException( "Received empty message " );
        }
        ObjectMapper objectMapper = new ObjectMapper( );
        ExportMessage lisResponse;
        try {
            lisResponse = objectMapper.readValue( eventData, ExportMessage.class );
            logger.info( "extractData :: lisResponse :: {}", lisResponse );
        } catch ( Exception e ) {
            throw new ExportServiceException( "Unable to extract data from message" );
        }
        return lisResponse;
    }

}
