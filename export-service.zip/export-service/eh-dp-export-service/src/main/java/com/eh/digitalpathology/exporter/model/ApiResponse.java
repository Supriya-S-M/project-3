package com.eh.digitalpathology.exporter.model;

public record ApiResponse<T>(String status, T content, String errorCode, String errorMessage) {}


