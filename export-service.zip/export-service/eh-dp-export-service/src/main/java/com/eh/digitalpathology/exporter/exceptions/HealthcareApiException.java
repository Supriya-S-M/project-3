/**
 * HealthcareApiException is used to handle errors related to healthcare API interactions.
 * This exception is thrown when there are issues encountered while communicating
 * with DICOM or HL7 APIs, encapsulating error messages and underlying causes.
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */
package com.eh.digitalpathology.exporter.exceptions;

public class HealthcareApiException extends Exception{
    public HealthcareApiException(String message) {
        super(message);
    }

    public HealthcareApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
