package com.eh.digitalpathology.exporter.model;

import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;

public record ExportMessage(String barcode, String seriesId, String studyId, int instanceCount, List<String> instances,
                            byte[] dicomDirBytes, String dicomWebUrl) {

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ExportMessage other)) return false;
        return Objects.equals(this.barcode, other.barcode)
                && Objects.equals(this.seriesId, other.seriesId)
                && Objects.equals(this.studyId, other.studyId)
                && this.instanceCount == other.instanceCount
                && Objects.equals(this.instances, other.instances)
                && Arrays.equals(this.dicomDirBytes, other.dicomDirBytes)
                && Objects.equals(this.dicomWebUrl, other.dicomWebUrl);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(barcode, seriesId, studyId, instanceCount, instances, dicomWebUrl);
        result = 31 * result + Arrays.hashCode(dicomDirBytes);
        return result;
    }

    @Override
    public String toString() {
        String dicomDirBase64 = (dicomDirBytes == null)
                ? "null"
                : Base64.getEncoder().encodeToString(dicomDirBytes);
        return "ExportMessage{" +
                "barcode='" + barcode + '\'' +
                ", seriesId='" + seriesId + '\'' +
                ", studyId='" + studyId + '\'' +
                ", instanceCount=" + instanceCount +
                ", instances=" + instances +
                ", dicomDirBytes(Base64)=" + dicomDirBase64 +
                ", dicomWebUrl='" + dicomWebUrl + '\'' +
                '}';
    }
}
