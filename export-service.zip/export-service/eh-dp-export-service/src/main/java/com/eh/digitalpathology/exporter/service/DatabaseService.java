package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.dbclient.DBRestClient;
import com.eh.digitalpathology.exporter.exceptions.Hl7MessageException;
import com.eh.digitalpathology.exporter.model.ApiResponse;
import com.eh.digitalpathology.exporter.model.BarcodeInstanceRequest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class DatabaseService {

    private final DBRestClient dbRestClient;

    public DatabaseService(DBRestClient dbRestClient) {
        this.dbRestClient = dbRestClient;
    }

    private static HttpHeaders getHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Service-Name", "exported");
        return headers;
    }

    public String updateStatus(BarcodeInstanceRequest barcodeInstanceRequest) {

        HttpHeaders headers = getHttpHeaders();
        try {
            return dbRestClient.exchange(HttpMethod.PUT, "dicom/status/instances", barcodeInstanceRequest, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::status).block();

        } catch (Exception ex) {
            throw new Hl7MessageException("INVALID_ERROR", ex.getMessage());
        }
    }


}