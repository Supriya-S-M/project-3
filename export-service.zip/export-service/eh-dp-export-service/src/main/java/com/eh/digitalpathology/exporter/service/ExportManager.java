/**
 * NotificationHandler is responsible for processing the notification received through topic subscription.
 * It calls functions which further transfers instances to cloud storage and synapse shared path
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */
package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.config.DownstreamConfig;
import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.eh.digitalpathology.exporter.model.ExportMessage;
import com.eh.digitalpathology.exporter.model.InstanceInfo;
import com.eh.digitalpathology.exporter.visiopharm.SeriesNotifierService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@Service
public class ExportManager {

    private static final Logger logger = LoggerFactory.getLogger( ExportManager.class );
    private final SeriesNotifierService visiopharmSeriesNotifier;
    private final ExportService exportService;
    private final GcpConfig gcpConfig;
    private final DownstreamConfig downstreamConfig;

    private final ExecutorService executorService;

    public ExportManager ( ExportService exportService, SeriesNotifierService visiopharmSeriesNotifier, GcpConfig gcpConfig, DownstreamConfig downstreamConfig, @Qualifier( "exportExecutorService" ) ExecutorService executorService ) {
        this.visiopharmSeriesNotifier = visiopharmSeriesNotifier;
        this.exportService = exportService;
        this.gcpConfig = gcpConfig;
        this.downstreamConfig = downstreamConfig;
        this.executorService = executorService;
    }


    public CompletableFuture< Void > exportToDownstreamServices ( ExportMessage exportMessage ) throws ExportServiceException {

        return CompletableFuture.runAsync( ( ) -> {
            String seriesUrl = String.format( "%s/%s/dicomWeb/studies/%s/series/%s", gcpConfig.getDicomWebUrl( ), exportMessage.dicomWebUrl(), exportMessage.studyId( ), exportMessage.seriesId( ) );
            logger.info( "exportToDownstreamServices :: exporting to various downstream application will start:: {}", seriesUrl );
            if (downstreamConfig.isVisiopharm()) {
                executorService.submit( ( ) -> visiopharmSeriesNotifier.notifyVisiopharm( seriesUrl ) );
            }
            try {
                List< InstanceInfo > instanceInfoList = exportMessage.instances( ).stream( ).map( instance -> {
                    String path = String.format( "%s/instances/%s", seriesUrl, instance );
                    return new InstanceInfo( instance, path );
                } ).toList( );

                exportService.exportInstances( exportMessage.studyId( ), instanceInfoList, exportMessage.dicomDirBytes( ), executorService, exportMessage.barcode( ) ,exportMessage.seriesId(),exportMessage.dicomWebUrl());
            } catch ( ExportServiceException e ) {
                throw new ExportServiceException( "exportToDownstreamServices :: Exception occurred while handling complete notification for series-" + exportMessage.seriesId( ), e );
            }
        }, executorService );
    }

}
