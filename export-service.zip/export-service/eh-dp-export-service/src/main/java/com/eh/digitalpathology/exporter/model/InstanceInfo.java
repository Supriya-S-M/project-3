/**
 * InstanceInfo is used to hold in memory data that is received through notification.
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */

package com.eh.digitalpathology.exporter.model;

public record InstanceInfo(String instanceId, String instancePath) {}

