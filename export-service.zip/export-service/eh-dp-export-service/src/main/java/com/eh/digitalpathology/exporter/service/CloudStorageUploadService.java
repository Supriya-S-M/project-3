/**
 * CloudStorageUploadService is used to transfer zip file with instances downloaded to Cloud storage
 * Author: Pooja Kamble
 * Date: November 05, 2024
 */

package com.eh.digitalpathology.exporter.service;

import com.eh.digitalpathology.exporter.config.GcpConfig;
import com.eh.digitalpathology.exporter.exceptions.ExportServiceException;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.WriteChannel;
import com.google.cloud.storage.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

@Service
@RefreshScope
public class CloudStorageUploadService {

    @Value( "${enriched.dicom.bucket}" )
    private String enrichedDicomBucket;
    private final GcpConfig gcpConfig;
    private static final Logger logger = LoggerFactory.getLogger( CloudStorageUploadService.class );

    public CloudStorageUploadService ( GcpConfig gcpConfig ) {
        this.gcpConfig = gcpConfig;
    }

    /**
     * @param studyUid      study id of DICOM instance
     * @param targetZipFile Path where application downloads enriched DICOM files
     */
    public void upload ( String studyUid, Path targetZipFile, String barcode, String seriesId, String dicomWebUrl ) {
        logger.info( "upload :: Files are being uploaded for Study UID - {} from the designated path.: {}", studyUid, targetZipFile );

        Storage storage = null;
        try {
            storage = StorageOptions.newBuilder( ).setCredentials( ServiceAccountCredentials.fromStream( new ByteArrayInputStream( gcpConfig.getCreds( ).getBytes( StandardCharsets.UTF_8 ) ) ) ).build( ).getService( );
        } catch ( IOException e ) {
            logger.error( "enrichDicomInstance :: unable to get access to storage :: {}", e.getMessage( ) );
        }
        if (storage == null) {
            throw new ExportServiceException( "Unable to access Google Cloud Storage." );
        }

        if (storage.get( enrichedDicomBucket ) == null ) {
            storage.create( BucketInfo.of( enrichedDicomBucket ) );
            logger.info( "upload :: The bucket has been successfully created with the name : {}", enrichedDicomBucket );
        } else {
            logger.info( "upload :: The bucket named {} already exists.", enrichedDicomBucket );
        }


        // Create a BlobId and BlobInfo
        BlobId blobId = BlobId.of( enrichedDicomBucket, studyUid + ".zip" );
        //Add metadata
        Map< String, String > metadata = new HashMap<>( );
        metadata.put( "barcode", barcode );
        metadata.put( "seriesid", seriesId );
        metadata.put( "dicomstoreurl", dicomWebUrl );
        BlobInfo blobInfo = BlobInfo.newBuilder( blobId ).setMetadata( metadata ).build( );


        // Upload the file
        logger.info( "upload :: Transferring the ZIP folder of study UID {} to the GCP bucket. : {}", studyUid, enrichedDicomBucket );

        try ( WriteChannel writer = storage.writer( blobInfo ); FileInputStream input = new FileInputStream( targetZipFile.toFile( ) ) ) {

            byte[] buffer = new byte[ 1048576 ]; // 10 MB buffer
            int limit;
            while ( ( limit = input.read( buffer ) ) >= 0 ) {
                writer.write( ByteBuffer.wrap( buffer, 0, limit ) );
            }
            logger.info( "upload :: File uploaded successfully." );
        } catch ( IOException e ) {
            throw new ExportServiceException( "Unable to copy the file into the bucket: " + e.getMessage( ) );
        }

        logger.info( "upload :: Uploaded the ZIP folder to the GCP bucket {} with the name {}.zip", enrichedDicomBucket, studyUid );
    }
}
