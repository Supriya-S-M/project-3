package com.eh.digitalpathology.exporter.model;


public record BarcodeInstanceRequest(String barcode, String sopInstanceUid){}

