package com.eh.digitalpathology.hl7.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import com.eh.digitalpathology.hl7.connector.config.AppConfig;
import com.eh.digitalpathology.hl7.connector.config.Hl7Config;
import com.eh.digitalpathology.hl7.connector.enums.AcknowledgementCode;
import com.eh.digitalpathology.hl7.connector.utils.Hl7MessageExtractor;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

class AcknowledgeMessageGeneratorTest {


    private AcknowledgeMessageGenerator acknowledgeMessageGenerator;
    private Hl7Config hl7Config;
    private AppConfig appConfig;

    @BeforeEach
    void setUp ( ) throws IOException {
        hl7Config = new Hl7Config( );
        appConfig = new AppConfig();
        hl7Config = YamlReader.readYaml( "acks-config.yml", Hl7Config.class );
        appConfig.setSendingApp( "EHDPIS" );
        appConfig.setSendingFacility( "" );
        appConfig.setReceivingApp( "Synapse" );
        appConfig.setReceivingFacility( "" );
        acknowledgeMessageGenerator = new AcknowledgeMessageGenerator( hl7Config, appConfig );

    }

    @Test
    void createAcknowledgeMessageTest ( ) throws HL7Exception, IOException {
        String hl7Message = """
                MSH|^~\\&|POWERPATH|LAB|DPIS||20241018152608||OUL^R21|MSG0000530|P|2.4\r
                PID|||3344556^^^^MR^DEF||Microburst^Milo||19750901|M||Caucasian\r
                SAC||ACC123456|A\r
                ORC|NW|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718\r
                OBR|1|FIX-0098|1.3.6.1.4.1.36533.12313610024319762671961371995923012218718|ALCB^Alcian blue stain, Ph 2.5|||20241017141820|||||||20241017152532|LIVER^^^LIVER|ABC32^Feelgood^William^U^M.D^Dr.|520555 1234||GT450 IHC, Slide 0145^A2-1
                """;
        String barcode = Hl7MessageExtractor.extractBarcodeFromHl7Message( hl7Message );
        System.out.println(barcode );
        String message = acknowledgeMessageGenerator.createAcknowledgeMessage( hl7Message, "ACK", AcknowledgementCode.AA.name() );
        Assertions.assertFalse( message.isBlank() );

    }





}