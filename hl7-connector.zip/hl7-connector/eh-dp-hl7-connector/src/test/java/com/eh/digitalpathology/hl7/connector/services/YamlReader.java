package com.eh.digitalpathology.hl7.connector.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.IOException;
import java.io.InputStream;

public class YamlReader {

    public static < T > T readYaml ( String filePath, Class< T > valueType ) throws IOException {
        ObjectMapper mapper = new ObjectMapper( new YAMLFactory( ) );
        try ( InputStream inputStream = YamlReader.class.getClassLoader( ).getResourceAsStream( filePath ) ) {
            if ( inputStream == null ) {
                throw new IOException( "File not found: " + filePath );
            }
            return mapper.readValue( inputStream, valueType );
        }
    }
}