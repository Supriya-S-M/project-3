package com.eh.digitalpathology.hl7.connector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class Hl7ConnectorApplicationTest {

    @Test
    void contextLoads() {
        // It is used to check if the Spring application context loads successfully.
    }
}