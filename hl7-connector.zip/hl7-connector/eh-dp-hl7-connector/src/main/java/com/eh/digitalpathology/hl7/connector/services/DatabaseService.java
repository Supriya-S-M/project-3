package com.eh.digitalpathology.hl7.connector.services;

import com.eh.digitalpathology.hl7.connector.client.DBRestClient;
import com.eh.digitalpathology.hl7.connector.constants.ApiConstants;
import com.eh.digitalpathology.hl7.connector.exception.Hl7MessageException;
import com.eh.digitalpathology.hl7.connector.model.ApiResponse;
import com.eh.digitalpathology.hl7.connector.model.Hl7MessageServiceRequest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class DatabaseService {

    private final DBRestClient dbRestClient;

    public DatabaseService ( DBRestClient dbRestClient ) {
        this.dbRestClient = dbRestClient;
    }

    public String fetchHl7Message(String hl7Message, String messageType) throws Hl7MessageException {
        String uri = "hl7/message";
        Hl7MessageServiceRequest hl7MessageRequest = new Hl7MessageServiceRequest(hl7Message, messageType);
        try {
            return dbRestClient.exchange( HttpMethod.POST, uri, hl7MessageRequest, new ParameterizedTypeReference< ApiResponse<String> >() {
                    }, null)
                    .map(ApiResponse::content)
                    .block();
        } catch (Hl7MessageException ex) {
            throw new Hl7MessageException(ex.getErrorCode(), ex.getErrorMessage());
        } catch (Exception e) {
            throw new Hl7MessageException( ApiConstants.UNKNOWN_ERROR, e.getMessage());
        }
    }
}
