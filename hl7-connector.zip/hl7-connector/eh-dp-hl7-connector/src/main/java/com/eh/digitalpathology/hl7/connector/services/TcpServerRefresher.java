package com.eh.digitalpathology.hl7.connector.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.scope.refresh.RefreshScopeRefreshedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class TcpServerRefresher implements ApplicationListener< RefreshScopeRefreshedEvent > {

    private static final Logger log = LoggerFactory.getLogger(TcpServerRefresher.class.getName());

    private final TcpServer tcpServer;

    public TcpServerRefresher(TcpServer tcpServer) {
        this.tcpServer = tcpServer;
    }

    @Override
    public void onApplicationEvent(RefreshScopeRefreshedEvent event) {
        log.info("TcpServerRefresher :: Refresh event received, restarting TcpServer.");
        tcpServer.shutdown();
        tcpServer.init();
    }
}
