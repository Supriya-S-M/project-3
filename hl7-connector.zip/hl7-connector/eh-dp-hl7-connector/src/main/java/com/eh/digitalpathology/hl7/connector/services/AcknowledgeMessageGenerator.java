package com.eh.digitalpathology.hl7.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.*;
import ca.uhn.hl7v2.parser.DefaultModelClassFactory;
import ca.uhn.hl7v2.parser.ModelClassFactory;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;
import com.eh.digitalpathology.hl7.connector.config.AppConfig;
import com.eh.digitalpathology.hl7.connector.config.Hl7Config;
import com.eh.digitalpathology.hl7.connector.exception.Hl7MessageException;
import com.eh.digitalpathology.hl7.connector.utils.Hl7MessageExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AcknowledgeMessageGenerator {

    private static final Logger log = LoggerFactory.getLogger( AcknowledgeMessageGenerator.class.getName( ) );
    private final Hl7Config hl7Config;
    private final AppConfig appConfig;

    public AcknowledgeMessageGenerator ( Hl7Config hl7Config, AppConfig appConfig ) {
        this.hl7Config = hl7Config;
        this.appConfig = appConfig;
    }

    public String createAcknowledgeMessage ( String hl7Message, String messageType, String acknowledgement ) throws HL7Exception, IOException {

        log.info( "createAcknowledgeMessage :: \n {}", hl7Message );
        Hl7Config.MessageTemplate template = hl7Config.getMessages( ).get( messageType.toUpperCase( ) );
        if ( template == null ) {
            throw new IllegalArgumentException( "Invalid hl7 message type: " + messageType );
        }
        PipeParser parser = new PipeParser( );
        Message inputMessage = parser.parse( hl7Message );

        Map< String, String > dynamicValues = fetchDynamicValues( inputMessage, template, acknowledgement );
        Message message = createDynamicMessage( template, dynamicValues, inputMessage );
        parser.getParserConfiguration( ).setEncodeEmptyMandatoryFirstSegments( false );
        String encodedMessage = parser.encode( message ).replace( "\\T\\", "&" ).replace( "\\S\\", "^" ).replace( "\\R\\", "~" );
        log.info( "createMessage :: Encoded HL7 Message: \n {}", encodedMessage );
        return encodedMessage;
    }

    private Map< String, String > fetchDynamicValues ( Message inputMessage, Hl7Config.MessageTemplate template, String acknowledgement ) {
        Map< String, String > dynamicValues = new HashMap<>( );
        Terser terser = new Terser( inputMessage );
        Set< String > placeHolders = extractPlaceholdersFromTemplates( template );
        for ( String placeholder : placeHolders ) {
            if ( isUtilityPlaceholder( placeholder ) ) {
                dynamicValues.put( placeholder, resolveUtilityPlaceholder( placeholder, acknowledgement ) );
            } else {
                try {
                    String value = terser.get( placeholder.replace( ".", "-" ) );
                    if ( value != null ) {
                        dynamicValues.put( placeholder, value );
                    }
                } catch ( HL7Exception ignored ) {
                    //Exception ignored
                }
            }
        }
        return dynamicValues;

    }

    private String resolveUtilityPlaceholder ( String placeholder, String acknowledgement ) {
        return switch ( placeholder ) {
            case "currentDateTime" -> ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ofPattern( "yyyyMMddHHmmss" ) );
            case "sendingApp" -> appConfig.getSendingApp( );
            case "sendingFacility" -> appConfig.getSendingFacility( );
            case "receivingApp" -> appConfig.getReceivingApp( );
            case "receivingFacility" -> appConfig.getReceivingFacility( );
            case "messageControlId" -> Hl7MessageExtractor.getRandomMessageControlID( );
            case "acknowledgementCode" -> acknowledgement;

            default -> "";
        };
    }

    private boolean isUtilityPlaceholder ( String placeholder ) {
        return Set.of( "currentDateTime", "sendingFacility", "sendingApp", "messageControlId", "acknowledgementCode", "receivingApp", "receivingFacility" ).contains( placeholder );
    }

    private Set< String > extractPlaceholdersFromTemplates ( Hl7Config.MessageTemplate template ) {
        Set< String > placeHolders = new HashSet<>( );
        Pattern pattern = Pattern.compile( "\\{([^}]+)}" );
        template.getSegments( ).forEach( segment -> {
            if ( !segment.isCopyFromInput( ) && segment.getFields( ) != null ) {
                segment.getFields( ).forEach( field -> {
                    Matcher matcher = pattern.matcher( field.getValue( ) );
                    while ( matcher.find( ) ) {
                        placeHolders.add( matcher.group( 1 ) );
                    }
                } );
            }
        } );
        return placeHolders;
    }

    private Message createDynamicMessage ( Hl7Config.MessageTemplate template, Map< String, String > dynamicValues, Message inputMessage ) throws HL7Exception, IOException {

        ModelClassFactory factory = new DefaultModelClassFactory( );
        String triggerEvent = template.getTriggerEvent( );
        String messageClassName = triggerEvent != null && !triggerEvent.isBlank( ) ? String.format( "%s_%s", template.getMessageType( ), triggerEvent ) : template.getMessageType( );
        String hl7Version = template.getVersion( );
        log.error( "createDynamicMessage:: Attempting to resolve message class:: {} for version: {}", messageClassName, template.getVersion( ) );
        Class< ? extends Message > messageClass = factory.getMessageClass( messageClassName, hl7Version, false );

        Message message = instantiateMessage( messageClass );
        if ( message instanceof AbstractMessage abstractMessage ) {
            if ( triggerEvent == null || triggerEvent.isBlank( ) ) {
                triggerEvent = "O21";
            }
            abstractMessage.initQuickstart( template.getMessageType( ), triggerEvent, "P" );
        }

        Terser terser = new Terser( message );
        for ( Hl7Config.Segment segmentConfig : template.getSegments( ) ) {
            Structure segment = findSegmentDynamically( message, segmentConfig.getName( ) );
            log.info( "createDynamicMessage :: segment :: {}", segment );
            if ( segment instanceof Segment ) {
                if ( segmentConfig.isCopyFromInput( ) ) {
                    copySegmentFromInput( inputMessage, message, segmentConfig.getName( ) );
                    continue;
                }
                populateSegment( terser, segmentConfig, dynamicValues, message );
            } else {
                throw new HL7Exception( "Segment " + segmentConfig.getName( ) + " not found in message." );
            }
        }
        return message;
    }

    private void copySegmentFromInput ( Message inputMessage, Message message, String segmentName ) throws HL7Exception {
        Terser outputTerser = new Terser( message );

        int repetition = 0;
        while ( true ) {
            Segment inputSegment = getSegmentRepetition( inputMessage, segmentName, repetition );
            if ( inputSegment == null ) break;
            int numFields = inputSegment.numFields( ) + 1;
            for ( int field = 1; field <= numFields; field++ ) {
                Type[] fieldReps;
                try {
                    fieldReps = inputSegment.getField( field - 1 );
                } catch ( HL7Exception e ) {
                    continue;
                }
                for ( int fieldRep = 0; fieldRep < fieldReps.length; fieldRep++ ) {
                    Type fieldType = fieldReps[ fieldRep ];
                    String fieldPath = String.format( "%s(%d)-%d(%d)", segmentName, repetition, field - 1, fieldRep );
                    String outputPath = getTerserPath( message, segmentName, fieldPath );

                    try {
                        String value = fieldType.encode( );
                        if ( value != null && !value.isEmpty( ) ) {
                            outputTerser.set( outputPath, value );
                        }
                    } catch ( HL7Exception ignored ) {
                        //Exception ignored
                    }
                }
            }
            repetition++;
        }
    }

    private Segment getSegmentRepetition ( Message inputMessage, String name, int repetition ) {
        try {
            Group parent = findParentGroup( inputMessage, name );
            if ( parent != null ) {
                Structure[] reps = parent.getAll( name );
                if ( repetition < reps.length && reps[ repetition ] instanceof Segment segment ) {
                    return segment;
                }
            }
        } catch ( HL7Exception e ) {
            return null;
        }
        return null;
    }


    private Message instantiateMessage ( Class< ? extends Message > messageClass ) {
        try {
            return messageClass.getDeclaredConstructor( ).newInstance( );
        } catch ( Exception e ) {
            throw new Hl7MessageException( "EXCEPTION", e.getMessage( ) );
        }
    }

    private Structure findSegmentDynamically ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            try {
                Structure segment = group.get( segmentName );
                if ( segment != null ) {
                    return segment;
                }
            } catch ( HL7Exception e ) {
                log.error( "findSegmentDynamically:: Unable to find segment in group :: {}", e.getMessage( ) );
            }
            for ( String groupName : group.getNames( ) ) {
                Structure nestedStructure = group.get( groupName );
                if ( nestedStructure instanceof Group ) {
                    try {
                        return findSegmentDynamically( nestedStructure, segmentName );
                    } catch ( HL7Exception ex ) {
                        log.error( "findSegmentDynamically :: Unable to find in segment group {} ", ex.getMessage( ) );
                    }
                }
            }
        }
        throw new HL7Exception( "Segment " + segmentName + " not found in message." );
    }

    private void populateSegment ( Terser terser, Hl7Config.Segment segmentConfig, Map< String, String > dynamicValues, Message message ) throws HL7Exception {
        for ( Hl7Config.Field field : segmentConfig.getFields( ) ) {
            String value = field.getValue( );
            for ( Map.Entry< String, String > dynamicValue : dynamicValues.entrySet( ) ) {
                value = value.replace( "{" + dynamicValue.getKey( ) + "}", dynamicValue.getValue( ) );
            }
            value = value.replaceAll( "\\{[^}]+\\}", "" );
            try {
                String fullPath = getTerserPath( message, segmentConfig.getName( ), field.getPath( ) );
                log.info( "populateSegment :: full path of segment Name:: {}", fullPath );
                if ( field.getPath( ).matches( ".*-\\d+\\.\\d+$" ) ) {
                    // Handle subcomponents
                    String[] parts = field.getPath( ).split( "\\." );
                    String baseField = parts[ 0 ];
                    int subcomponentIndex = Integer.parseInt( parts[ 1 ] );
                    terser.set( baseField + "-" + subcomponentIndex, value );
                } else {
                    terser.set( fullPath, value );
                }
            } catch ( Exception e ) {
                throw new HL7Exception( "Error setting hl7 fields : " + field.getPath( ) + "with value : " + value, e );
            }
        }
    }

    private String getTerserPath ( Message message, String segmentName, String fieldPath ) throws HL7Exception {
        Group parentGroup = findParentGroup( message, segmentName );
        if ( parentGroup == null ) {
            // If the parent group is null, the segment is directly under the root message
            return '/' + fieldPath;
        }
        return '/' + getGroupPath( message, parentGroup ) + '/' + fieldPath;
    }

    private Group findParentGroup ( Structure structure, String segmentName ) throws HL7Exception {
        if ( structure instanceof Group group ) {
            for ( String name : group.getNames( ) ) {
                Structure nestedStructure = group.get( name );
                if ( nestedStructure instanceof Group nestedGroup ) {
                    if ( Arrays.asList( nestedGroup.getNames( ) ).contains( segmentName ) ) {
                        return nestedGroup;
                    }
                    Group parentGroup = findParentGroup( nestedGroup, segmentName );
                    if ( parentGroup != null ) {
                        return parentGroup;
                    }
                }
            }
        }
        return null;
    }

    private String getGroupPath ( Message message, Group group ) {
        if ( group.equals( message ) ) {
            return "";
        }
        Group parentGroup = group.getParent( );
        if ( parentGroup == null || parentGroup.equals( message ) ) {
            return group.getName( );
        }
        return getGroupPath( message, parentGroup ) + '/' + group.getName( );
    }
}
