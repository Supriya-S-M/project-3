package com.eh.digitalpathology.hl7.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;
import com.eh.digitalpathology.hl7.connector.enums.AcknowledgementCode;
import com.eh.digitalpathology.hl7.connector.exception.Hl7MessageException;
import com.eh.digitalpathology.hl7.connector.utils.Hl7MessageExtractor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;

@Service
@RefreshScope
public class Hl7MessageHandler {

    @Value( "${kafka.topic.lis}" )
    private String lisTopic;

    @Value( "${app.message.lis-request}" )
    private String hl7MessageType;

    private static final Logger log = LoggerFactory.getLogger( Hl7MessageHandler.class.getName( ) );

    private final DatabaseService dbService;
    private final KafkaNotifier kafkaNotifier;
    private final AcknowledgeMessageGenerator acknowledgeMessageGenerator;
    private final TcpClient tcpClient;

    public Hl7MessageHandler ( DatabaseService dbService, KafkaNotifier kafkaNotifier, AcknowledgeMessageGenerator acknowledgeMessageGenerator, TcpClient tcpClient ) {
        this.dbService = dbService;
        this.kafkaNotifier = kafkaNotifier;
        this.acknowledgeMessageGenerator = acknowledgeMessageGenerator;
        this.tcpClient = tcpClient;
    }


    public String handleMessage ( String rawMessage ) throws IOException, HL7Exception {
        try {
            // Generate ACK early
            String messageType = Hl7MessageExtractor.extractMessageType( rawMessage );
            log.info( "handleMessage :: extracted hl7 Message :: {}", messageType  );
            log.info( "handleMessage :: hl7 message typ from configuration:: {}", hl7MessageType );
            if (!hl7MessageType.equalsIgnoreCase(messageType)) {
                log.info("handleMessage :: ACK message received, skipping processing.");
               return null; // or return an empty string, or a minimal ACK if needed
            }
            String ackMessage = acknowledgeMessageGenerator.createAcknowledgeMessage( rawMessage, "ACK", AcknowledgementCode.AA.name( ) );

            if ( Hl7MessageExtractor.getZIDSegment( rawMessage ) ) {
                String barcode = Hl7MessageExtractor.extractBarcodeFromHl7Message( rawMessage );
                kafkaNotifier.notify( lisTopic, barcode, rawMessage );
                return ackMessage;
            }
            log.info( "handleMessage :: message type :: {}", messageType );

            String hl7Message = dbService.fetchHl7Message( rawMessage, messageType );
            if ( hl7Message.isEmpty( ) ) {
                throw new IOException( "Unable to fetch Message" );
            }
            String updatedHl7Message = updateHl7Message( rawMessage, hl7Message );
            log.info( "handleMessage :: hl7 message from database :: {}", updatedHl7Message );

            // Send TCP message asynchronously
            CompletableFuture.runAsync( ( ) -> {
                try {
                    tcpClient.sendMessage( updatedHl7Message );
                } catch ( Exception e ) {
                    log.error( "TCP send failed: {}", e.getMessage( ) );
                }
            } );
            // Return ACK immediately
            return ackMessage;

        } catch ( IOException | HL7Exception | Hl7MessageException e ) {
            log.error( "handleMessage:: exception occurred while fetching data :: {}", e.getMessage( ) );
            return acknowledgeMessageGenerator.createAcknowledgeMessage( rawMessage, "ACK", AcknowledgementCode.AE.name( ) );
        }
    }

    private String updateHl7Message ( String rawMessage, String hl7Message ) {
        try{
            PipeParser parser = new PipeParser( );
            var originalMessage = parser.parse( rawMessage );
            Terser terser = new Terser( originalMessage );
            String sendingApplication = terser.get( "/MSH-3" );
            String sendingFacility = terser.get( "/MSH-4" );
            String messageControlId = terser.get( "/MSH-10" );
            var messageToUpdate = parser.parse( hl7Message );
            Terser terserToUpdate = new Terser( messageToUpdate );
            terserToUpdate.set( "/MSH-5", sendingApplication );
            terserToUpdate.set( "/MSH-6", sendingFacility );
            terserToUpdate.set( "/MSH-10", messageControlId );
            terserToUpdate.set( "/MSH-7", ZonedDateTime.now( ZoneOffset.UTC ).format( DateTimeFormatter.ofPattern( "yyyyMMddHHmmss" ) ) );
            return parser.encode( messageToUpdate );
        }catch ( HL7Exception e ){
            log.error( "updateHl7Message:: exception occurred while updating hl7 message :: {}", e.getMessage( ) );
        }
        return hl7Message;
    }

}