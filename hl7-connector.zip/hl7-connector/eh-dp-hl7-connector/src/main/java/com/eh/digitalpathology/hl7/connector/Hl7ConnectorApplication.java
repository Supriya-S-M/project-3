package com.eh.digitalpathology.hl7.connector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hl7ConnectorApplication {

    public static void main(String[] args) {
        SpringApplication.run( Hl7ConnectorApplication.class, args);
    }
}
