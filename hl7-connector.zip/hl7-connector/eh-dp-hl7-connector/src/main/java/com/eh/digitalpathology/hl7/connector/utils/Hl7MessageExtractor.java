package com.eh.digitalpathology.hl7.connector.utils;

import ca.uhn.hl7v2.HL7Exception;
import ca.uhn.hl7v2.model.Message;
import ca.uhn.hl7v2.parser.PipeParser;
import ca.uhn.hl7v2.util.Terser;
import com.eh.digitalpathology.hl7.connector.constants.ApiConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

public class Hl7MessageExtractor {

    private static final Logger log = LoggerFactory.getLogger( Hl7MessageExtractor.class.getName( ) );
    private static final Random random = new Random( );

    private Hl7MessageExtractor ( ) {
        // private constructor to prevent instantiation
    }

    public static boolean getZIDSegment ( String hl7Message ) throws HL7Exception {
        PipeParser parser = new PipeParser( );
        Message message = parser.parse( hl7Message );
        log.info( "getZIDSegment ::  message :: {} :: hl7Message :: {}", message, hl7Message );
        Terser terser = new Terser( message );
        try {
            String fieldO = terser.get( "ZID(0)-1" );
            log.info( "getZIDSegment :: field0 :: {} ", fieldO );
            return fieldO != null;
        } catch ( HL7Exception e ) {
            return false;
        }
    }

    public static String extractMessageType ( String hl7Message ) throws HL7Exception {
        PipeParser parser = new PipeParser( );
        Message message = parser.parse( hl7Message );
        log.info( "extractMessageType ::  message :: {} :: hl7Message :: {}", message, hl7Message );
        Terser terser = new Terser( message );
        return terser.get( "/MSH-9-1" );
    }


    public static String getRandomMessageControlID ( ) {
        // Generate a timestamp-based unique ID

        long currentTimeMillis = System.currentTimeMillis( );
        int randomSuffix = random.nextInt( 100000 ); // Add randomness to the ID
        return "" + currentTimeMillis + randomSuffix;
    }

    public static String extractHL7FromMLLPMessage ( String mllpMessage ) {
        if ( mllpMessage == null || mllpMessage.length( ) < 2 ) {
            return null;
        }
        // Find the indices of the Start Block and End Block characters
        int startIndex = mllpMessage.indexOf( ApiConstants.START_OF_BLOCK );
        int endIndex = mllpMessage.indexOf( ApiConstants.END_OF_BLOCK, startIndex );

        // Ensure the message contains both Start Block and End Block
        if ( startIndex == -1 || endIndex == -1 || startIndex >= endIndex ) {
            // Invalid format if Start Block or End Block are not found or not in correct order
            return null;
        }
        // Extract the HL7 message by removing the Start Block and End Block characters
        return mllpMessage.substring( startIndex + 1, endIndex );  // Exclude Start and End Blocks
    }

    public static String extractBarcodeFromHl7Message ( String hl7Message ) {
        try {
            String[] segments = hl7Message.split("[\\r\\n]" );

            for ( String segmentStr : segments ) {
                if ( segmentStr.startsWith( "OBR" ) ) {
                    String[] fields = segmentStr.split( "\\|" );
                    if ( fields.length > 2 ) {
                        return fields[ 2 ]; // OBR-2 is the 3rd field (0-based index)
                    }
                }
            }
        } catch ( Exception e ) {
            log.error( "Error extracting barcode from OBR segment: {}", e.getMessage( ) );
        }
        return null; // Return null if OBR segment or barcode not found
    }

}
