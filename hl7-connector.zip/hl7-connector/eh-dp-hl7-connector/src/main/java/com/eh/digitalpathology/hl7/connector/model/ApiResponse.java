package com.eh.digitalpathology.hl7.connector.model;

public record ApiResponse<T>(String status, T content, String errorCode, String errorMessage) {}
