package com.eh.digitalpathology.hl7.connector.services;

import ca.uhn.hl7v2.HL7Exception;
import com.eh.digitalpathology.hl7.connector.config.TcpConfig;
import com.eh.digitalpathology.hl7.connector.constants.ApiConstants;
import com.eh.digitalpathology.hl7.connector.utils.Hl7MessageExtractor;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;

@Service
public class TcpServer {

    private static final Logger log = LoggerFactory.getLogger( TcpServer.class.getName( ) );

    private final TcpConfig tcpConfig;
    private final Hl7MessageHandler hl7Handler;
    private volatile boolean running = true;
    private final ExecutorService executorService;

    public TcpServer ( TcpConfig tcpConfig, Hl7MessageHandler hl7Handler, @Qualifier( "hl7ResponseExecutorService" ) ExecutorService executorService ) {
        this.tcpConfig = tcpConfig;
        this.hl7Handler = hl7Handler;
        this.executorService = executorService;
    }

    @PostConstruct
    public void init ( ) {
        running = true;
        executorService.submit( this::startHl7Connector );
    }

    @PreDestroy
    public void shutdown ( ) {
        running = false;
        log.info( "shutdown :: TCP server is shutting down." );
    }

    private void startHl7Connector ( ) {
        try ( ServerSocket serverSocket = new ServerSocket( tcpConfig.getIncoming().getPort() ) ) {
            while ( running ) {
                Socket socket = serverSocket.accept( );
                processIncomingMessages( socket );
            }
        } catch ( IOException ex ) {
            log.error( "startHl7Connector :: io exception occurred :: {}", ex.getMessage( ) );
        }
    }

    private void processIncomingMessages ( Socket socket ) {
        try ( InputStream inputStream = socket.getInputStream( ); OutputStream outputStream = socket.getOutputStream( ); BufferedReader reader = new BufferedReader( new InputStreamReader( inputStream, StandardCharsets.UTF_8 ) ); BufferedWriter writer = new BufferedWriter( new OutputStreamWriter( outputStream ) ) ) {
            log.debug( "processIncomingMessages :: Starting to read HL7 messages from the socket input stream." );
            String hl7MessageWithMLLP;
            while ( ( hl7MessageWithMLLP = readSingleIncomingMessage( reader ) ) != null ) {
                String hl7Message = Hl7MessageExtractor.extractHL7FromMLLPMessage( hl7MessageWithMLLP );
                log.info( " processIncomingMessages :: hl7 message has been received from application :: {}", hl7Message );
                String response = hl7Handler.handleMessage( hl7Message );
                if (response == null || response.isEmpty( )) {
                    log.info( "processIncomingMessages :: No response generated for the incoming HL7 message." );
                    continue; // Skip sending acknowledgment if no response is generated
                }
                String updatedMessage = ApiConstants.START_OF_BLOCK + response + ApiConstants.END_OF_BLOCK + ApiConstants.CARRIAGE_RETURN;
                sendAcknowledgment( writer, updatedMessage );
            }
        } catch ( IOException | HL7Exception e ) {
            log.error( "processIncomingMessages :: incoming message :: {}", e.getMessage( ) );
        }
    }

    private void sendAcknowledgment ( BufferedWriter writer, String acknowledgmentMessage ) {
        try {
            // Write and flush the acknowledgment message
            writer.write( acknowledgmentMessage );
            writer.flush( );
            log.info( "sendAcknowledgment :: Acknowledgment sent to the application." );
        } catch ( IOException e ) {
            log.error( "Error while sending acknowledgment to application: ", e );
        }
    }

    private static String readSingleIncomingMessage ( BufferedReader reader ) throws IOException {
        StringBuilder messageBuilder = new StringBuilder( );
        int currentByteRead;
        boolean inMessage = false;
        while ( ( currentByteRead = reader.read( ) ) != -1 ) {
            if ( currentByteRead == ApiConstants.START_OF_BLOCK ) {
                // Start a new message when Start Block is encountered
                inMessage = true;
                messageBuilder.setLength( 0 ); // Clear previous message content
            }
            if ( inMessage ) {
                messageBuilder.append( (char) currentByteRead );  // Append the current byte as a character
                // Check if we've reached the End Block
                if ( currentByteRead == ApiConstants.END_OF_BLOCK ) {
                    // End of message encountered (End Block)
                    return messageBuilder.toString( );  // Return the message including the End Block
                }
            }
        }
        return null;  // Return null if no more messages are available
    }
}
