package com.eh.digitalpathology.hl7.connector.services;

import com.eh.digitalpathology.hl7.connector.config.TcpConfig;
import com.eh.digitalpathology.hl7.connector.constants.ApiConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.Socket;
import java.net.SocketTimeoutException;

@Service
public class TcpClient {

    private static final Logger log = LoggerFactory.getLogger( TcpClient.class.getName( ) );

    private final TcpConfig tcpConfig;

    public TcpClient ( TcpConfig tcpConfig ) {
        this.tcpConfig = tcpConfig;
    }

    public void sendMessage ( String hl7Message ) {
        log.info( "sendMessage :: Hl7 Connector is sending HL7 message to external LIS system at {}:{}", tcpConfig.getHost( ).getAddress( ), tcpConfig.getHost( ).getPort( ) );
        String hl7WithMllp = getHl7MessageAsPerMllpProtocol( hl7Message );
        int maxRetries = 3;
        int attempt = 0;
        boolean success = false;

        while ( attempt < maxRetries && !success ) {
            attempt++;
            log.info( "sendMessage :: Attempt {} to send message", attempt );
            try ( Socket socket = new Socket( tcpConfig.getHost( ).getAddress( ), tcpConfig.getHost( ).getPort( ) ); OutputStream outputStream = new BufferedOutputStream( socket.getOutputStream( ) ); InputStream inputStream = new BufferedInputStream( socket.getInputStream( ) ) ) {

                socket.setSoTimeout( 300_000 ); // 5 minutes timeout
                outputStream.write( hl7WithMllp.getBytes( ) );
                outputStream.flush( );

                byte[] responseBuffer = new byte[ 8192 ];
                int bytesRead = inputStream.read( responseBuffer );
                if ( bytesRead > 0 ) {
                    String response = new String( responseBuffer, 0, bytesRead );
                    log.info( "sendMessage :: Response received from external LIS system: {}", response );
                    success = true;
                } else {
                    log.warn( "sendMessage :: No response received on attempt {}", attempt );
                }
            } catch ( SocketTimeoutException timeoutEx ) {
                log.warn( "sendMessage :: Timeout occurred on attempt {}", attempt );
            } catch ( IOException ex ) {
                log.error( "Error sending message to LIS system at {}:{} on attempt {}", tcpConfig.getHost( ).getAddress( ), tcpConfig.getHost( ).getPort( ), attempt, ex );
            }
            // Wait 5 minutes before next attempt if not successful
            if ( !success && attempt < maxRetries ) {
                try {
                    log.info( "sendMessage :: Waiting 5 minutes before next attempt..." );
                    Thread.sleep( 300_000 ); // 5 minutes in milliseconds
                } catch ( InterruptedException ie ) {
                    Thread.currentThread( ).interrupt( ); // Restore interrupt status
                    log.warn( "sendMessage :: Sleep interrupted before next attempt" );
                }
            }
        }
        if ( !success ) {
            log.error( "sendMessage :: Failed to receive response after {} attempts", maxRetries );
        }
    }

    public String getHl7MessageAsPerMllpProtocol ( String hl7Message ) {
        return ApiConstants.START_OF_BLOCK + hl7Message + ApiConstants.END_OF_BLOCK + ApiConstants.CARRIAGE_RETURN;
    }
}
