package com.eh.digitalpathology.hl7.connector.model;

public record Hl7MessageServiceRequest (String hl7Message, String messageType) {}
