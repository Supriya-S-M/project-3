package com.eh.digitalpathology.hl7.connector.config;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "acknowledgement")
public class Hl7Config {
    private static final Logger log = LoggerFactory.getLogger(Hl7Config.class.getName());
    private Map<String, MessageTemplate> messages = new HashMap<>();

    public Map<String, MessageTemplate> getMessages() {
        return messages;
    }

    public void setMessages(Map<String, MessageTemplate> messages) {
        this.messages = messages;
    }

    public static class MessageTemplate {
        private String messageType;
        private String triggerEvent;
        private String version;
        private List<Segment> segments;

        public String getMessageType() {
            return messageType;
        }

        public void setMessageType(String messageType) {
            this.messageType = messageType;
        }

        public String getTriggerEvent() {
            return triggerEvent;
        }

        public void setTriggerEvent(String triggerEvent) {
            this.triggerEvent = triggerEvent;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public List<Segment> getSegments() {
            return segments;
        }

        public void setSegments(List<Segment> segments) {
            this.segments = segments;
        }
    }

    public static class Segment {
        private String name;
        private  List<Field> fields;
        private boolean copyFromInput;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<Field> getFields() {
            return fields;
        }

        public void setFields(List<Field> fields) {
            this.fields = fields;
        }

        public boolean isCopyFromInput() {
            return copyFromInput;
        }

        public void setCopyFromInput(boolean copyFromInput) {
            this.copyFromInput = copyFromInput;
        }
    }
    public static class Field {
        private String path;
        private String value;

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    @PostConstruct
    public void init(){
        log.error( "init :: Hl7Config loaded :: {}", messages );
    }
}
