package com.eh.digitalpathology.hl7.connector.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "message.config")
@RefreshScope
public class AppConfig {
    private String sendingApp;
    private String sendingFacility;
    private String receivingApp;
    private String receivingFacility;

    public String getSendingApp ( ) {
        return sendingApp;
    }

    public void setSendingApp ( String sendingApp ) {
        this.sendingApp = sendingApp;
    }

    public String getSendingFacility ( ) {
        return sendingFacility;
    }

    public void setSendingFacility ( String sendingFacility ) {
        this.sendingFacility = sendingFacility;
    }

    public String getReceivingApp ( ) {
        return receivingApp;
    }

    public void setReceivingApp ( String receivingApp ) {
        this.receivingApp = receivingApp;
    }

    public String getReceivingFacility ( ) {
        return receivingFacility;
    }

    public void setReceivingFacility ( String receivingFacility ) {
        this.receivingFacility = receivingFacility;
    }
}
