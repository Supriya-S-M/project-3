package com.eh.digitalpathology.hl7.connector.constants;

public class ApiConstants {
    private ApiConstants (){
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
    public static final String UNKNOWN_ERROR = "UNKNOWN_ERROR";
    public static final char START_OF_BLOCK = '\u000b';    // Vertical Tab
    public static final char END_OF_BLOCK = '\u001c';      // File Separator
    public static final char CARRIAGE_RETURN = '\r';       // Carriage Return


}
