const { mongo, hcaPrefix } = require('../config/config');
const { getDb } = require('../database/dbContext');

async function generateLaunchUrlsCase(accessionNumber) {
  const db = getDb();
  const dicomCollection = db.collection(mongo.collections.dicomInstances);
  const scannerCollection = db.collection(mongo.collections.slideScanner);

  const caseInstances = await dicomCollection.aggregate([
    { $match: { caseNumber: accessionNumber } },
    {
      $group: {
        _id: "$seriesInstanceUid",
        actualStudyInstanceUid: { $first: "$actualStudyInstanceUid" },
        deviceSerialNumber: { $first: "$deviceSerialNumber" }
      }
    },
    {
      $project: {
        _id: 0,
        seriesInstanceUid: "$_id",
        actualStudyInstanceUid: 1,
        deviceSerialNumber: 1
      }
    }
  ]).toArray();

  if (!caseInstances || caseInstances.length === 0) {
    return { error: 404, message: `No DICOM instances found for case ${accessionNumber}` };
  }

  const deviceSerialNumber = caseInstances[0].deviceSerialNumber;

  const scannerData = await scannerCollection.findOne(
    { deviceSerialNumber },
    { projection: { dicomStore: 1, _id: 0 } }
  );

  if (!scannerData || !scannerData.dicomStore) {
    return { error: 404, message: `DICOM Store not found for scanner ${deviceSerialNumber}` };
  }

  const launchUrls = caseInstances.map(({ seriesInstanceUid, actualStudyInstanceUid }) => {
    const rawUrl = `DICOMweb:${hcaPrefix}/${scannerData.dicomStore}/dicomWeb/studies/${actualStudyInstanceUid}/series/${seriesInstanceUid}`;
    const encodedUrl = Buffer.from(rawUrl).toString('base64');
    return `VIS:${encodedUrl}`;
  });

  console.log(`Generated ${launchUrls.length} unique launch URLs for case ${accessionNumber}`);

  return { launchUrls };
}

module.exports = { generateLaunchUrlsCase };