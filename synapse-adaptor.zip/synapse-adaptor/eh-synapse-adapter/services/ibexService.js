const fetch = require('node-fetch');
const { ibex } = require('../config/config');

async function fetchCase(accessionNumber) {
  const url = `${ibex.baseUrl}cases/${accessionNumber}`;
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-API-KEY': ibex.apiKey
    }
  });

  const headers = {};
  response.headers.forEach((value, name) => headers[name] = value);
  const body = await response.text();

  return { status: response.status, headers, body };
}

module.exports = { fetchCase };