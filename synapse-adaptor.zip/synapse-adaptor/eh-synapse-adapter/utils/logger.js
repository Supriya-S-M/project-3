module.exports = {
  info: console.log,
  warn: console.warn,
  error: console.error
};