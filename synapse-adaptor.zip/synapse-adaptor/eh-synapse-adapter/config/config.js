require('dotenv').config();

const requiredEnvVars = [
  'IBEX_API_BASE',
  'IBEX_API_KEY',
  'MONGO_URI'
];

const missingVars = requiredEnvVars.filter(key => !process.env[key]);

if (missingVars.length > 0) {
  console.error(`Missing required environment variables: ${missingVars.join(', ')}`);
  process.exit(1);
}

module.exports = {
  port: process.env.PORT || 3000,
  ibex: {
    baseUrl: process.env.IBEX_API_BASE,
    apiKey: process.env.IBEX_API_KEY
  },
  mongo: {
    uri: process.env.MONGO_URI,
    dbName: 'enrich_db',
    collections: {
      slideScanner: 'slide_scanner',
      dicomInstances: 'dicom_instances'
    }
  },
  hcaPrefix: 'https://healthcare.googleapis.com/v1'
};