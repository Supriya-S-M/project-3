import { minify } from "terser";
import { minify as minifyHTML } from "html-minifier-terser";
import fs from "fs";
import path from "path";

const publicDir = path.resolve("public");
const jsFiles = fs.readdirSync(publicDir).filter(f => f.endsWith(".js"));

for (const jsFile of jsFiles) {
  const fullPath = path.join(publicDir, jsFile);
  const jsCode = fs.readFileSync(fullPath, "utf8");
  const minified = await minify(jsCode, { compress: true, mangle: true });
  const minFileName = jsFile.replace(/\.js$/, ".min.js");

  fs.writeFileSync(path.join(publicDir, minFileName), minified.code);

  console.log(`JS minified: ${jsFile} → ${minFileName}`);
  fs.unlinkSync(fullPath);
  console.log(`Removed original JS: ${jsFile}`);
}

const htmlFiles = fs.readdirSync(publicDir).filter(f => f.endsWith(".html"));

for (const htmlFile of htmlFiles) {

  const htmlPath = path.join(publicDir, htmlFile);
  let html = fs.readFileSync(htmlPath, "utf8");
  html = html.replace(/(<script\s+[^>]*src=["'])([^"']+)\.js(["'][^>]*><\/script>)/g, '$1$2.min.js$3');

  const htmlMin = await minifyHTML(html, {

    collapseWhitespace: true,
    removeComments: true,
    minifyCSS: true,
    minifyJS: true,
  });

  fs.writeFileSync(htmlPath, htmlMin);
  console.log(`HTML minified and updated: ${htmlFile}`);
}
 