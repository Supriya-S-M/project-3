const config = require('./config/config');
const logger = require('./utils/logger');
const { connectToMongo } = require('./database/connection');
const app = require('./app');

app.listen(config.port, () => {
  logger.info(`Server running at Port:${config.port}`);
});

connectToMongo();