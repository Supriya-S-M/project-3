(function () {
    let openedVisiopharmWindows = [];

    async function openVisiopharmCase(accessionNumber) {

        if (!accessionNumber || typeof accessionNumber !== 'string') {
            console.warn("Invalid accession number provided.");
            alert("Invalid case identifier. Please check and try again.");
            return;
        }

        try {
            const response = await fetch(`/api/visiopharm/case/${accessionNumber}`);

            if (response.status === 404) {
                console.warn(`Visiopharm case not found: ${accessionNumber}`);
                alert("No Visiopharm case found for the provided accession number.");
                return;
            }

            if (!response.ok) {
                console.error(`API error (${response.status}): ${response.statusText}`);
                alert("Unable to retrieve Visiopharm case. Please try again later or contact support.");
                return;
            }
            let { launch_urls: launchUrls } = await response.json();
            if (!launchUrls || !Array.isArray(launchUrls) || launchUrls.length === 0) {
                console.warn("Missing, invalid, or empty array for Visiopharm URLs in response.");
                alert("Visiopharm case URLS are unavailable or invalid. Please try again later.");
                return;
            }

            let firstWindow = window.open(launchUrls[0], "_blank");
            openedVisiopharmWindows.push(firstWindow);

            for(let i = 1; i < launchUrls.length; i++) {
                const newWindow = window.open(launchUrls[i], "_blank");
                if (newWindow) {
                    openedVisiopharmWindows.push(newWindow);
                    console.log(`Opened Visiopharm case: ${launchUrls[i]}`);
                }
            }
            
            setTimeout(() => {
                for (let i = 1; i < openedVisiopharmWindows.length; i++) {
                    if (!openedVisiopharmWindows[i].closed) {
                        openedVisiopharmWindows[i].close();
                        console.log(`Closed Visiopharm case: ${launchUrls[i]}`);
                    }
                }
            }, 3000);


        } catch (error) {
            console.error(`Unexpected error while opening Visiopharm case (${accessionNumber}):`, error);
            alert("An unexpected error occurred. Please try again later or contact support.");
        }
    }

    function closeAllVisiopharmCases() {
		openedVisiopharmWindows.forEach(win => {
			if (win && !win.closed) {
				win.close();
			}
		});
		openedVisiopharmWindows = [];
		console.log("All Visiopharm case windows closed.");
	}

    window.addEventListener("message", function (event) {
        const { eventName, sessionId, accessionNumber, isPrior } = event.data;

        console.log("Received message:", event);

        if (eventName === "UserLogin") {
            _sessionId = sessionId;
        } else if (eventName === "UserLogout") {
            closeAllVisiopharmCases();
        } else if (eventName === "CaseOpened") {
            openVisiopharmCase(accessionNumber);
        } else if (eventName === "CustomCaseEventFired") {
            //openVisiopharmCase(accessionNumber);
        } else if (eventName === "CaseClosed") {
            closeAllVisiopharmCases();
        } else {
            console.warn(`Unhandled event: ${eventName}`);
        }
    }, false);
})();
