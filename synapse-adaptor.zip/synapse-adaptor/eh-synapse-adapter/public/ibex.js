(function() {
	let openedIbexWindows = [];

	async function openIbexCase(accessionNumber) {

		if (!accessionNumber || typeof accessionNumber !== 'string') {
			console.warn("Invalid accession number provided.");
			alert("Invalid case identifier. Please check and try again.");
			return;
		}

		try {
			const response = await fetch(`/api/ibex/case/${encodeURIComponent(accessionNumber)}`);

			if (response.status === 404) {
				console.warn(`IBEX case not found: ${accessionNumber}`);
				alert("No IBEX case found for the provided accession number.");
				return;
			}

			if (!response.ok) {
				console.error(`API error (${response.status}): ${response.statusText}`);
				alert("Unable to retrieve IBEX case. Please try again later or contact support.");
				return;
			}

			let { ibex_url: ibexUrl } = await response.json();
			if (!ibexUrl || typeof ibexUrl !== 'string') {
				console.warn("Missing or invalid IBEX URL in response.");
				alert("IBEX case URL is unavailable. Please try again later.");
				return;
			}

			//ibexUrl = transformIbexUrl(ibexUrl);

			const newWindow = window.open(ibexUrl, "_blank");
			if (newWindow) {
				openedIbexWindows.push(newWindow);
				console.log(`Opened IBEX case: ${ibexUrl}`);
			}
		} catch (error) {
			console.error(`Unexpected error while opening IBEX case (${accessionNumber}):`, error);
			alert("An unexpected error occurred. Please try again later or contact support.");
		}
	}

	function closeAllIbexCases() {
		openedIbexWindows.forEach(win => {
			if (win && !win.closed) {
				win.close();
			}
		});
		openedIbexWindows = [];
		console.log("All IBEX case windows closed.");
	}

	window.addEventListener("message", function(event) {
		const { eventName, sessionId, accessionNumber, isPrior } = event.data;

		console.log("Received message:", event);

		if (eventName === "UserLogin") {
			_sessionId = sessionId;

		} else if (eventName === "UserLogout") {
			closeAllIbexCases();
		} else if (eventName === "CaseOpened") {

		} else if (eventName === "CustomCaseEventFired") {
			openIbexCase(accessionNumber);
		} else if (eventName === "CaseClosed") {
			if (!isPrior) {
				closeAllIbexCases();
			}
		} else {
			console.warn(`Unhandled event: ${eventName}`);
		}
	}, false);
})();