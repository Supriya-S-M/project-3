const { generateLaunchUrlsCase } = require('../../services/visiopharmService');

jest.mock('../../config/config', () => ({
  mongo: {
    collections: {
      dicomInstances: 'dicomInstances',
      slideScanner: 'slideScanner',
    },
  },
  hcaPrefix: 'hca://prefix',
}));

jest.mock('../../database/dbContext', () => ({
  getDb: jest.fn(),
}));

const { getDb } = require('../../database/dbContext');

describe('generateLaunchUrlsCase', () => {
  const mockDicomCollection = {
    find: jest.fn(),
  };

  const mockScannerCollection = {
    findOne: jest.fn(),
  };

  const mockDb = {
    collection: jest.fn((name) => {
      if (name === 'dicomInstances') return mockDicomCollection;
      if (name === 'slideScanner') return mockScannerCollection;
    }),
  };

  beforeEach(() => {
    jest.clearAllMocks();
    getDb.mockReturnValue(mockDb);
  });

  it('should return 404 if no DICOM instances are found', async () => {
    mockDicomCollection.find.mockReturnValue({
      toArray: jest.fn().mockResolvedValue([]),
    });

    const result = await generateLaunchUrlsCase('CASE123');
    expect(result).toEqual({
      error: 404,
      message: 'No DICOM instances found for case CASE123',
    });
  });

  it('should return 404 if scanner data is missing', async () => {
    mockDicomCollection.find.mockReturnValue({
      toArray: jest.fn().mockResolvedValue([
        {
          actualStudyInstanceUid: 'study1',
          seriesInstanceUid: 'series1',
          deviceSerialNumber: 'scanner123',
        },
      ]),
    });

    mockScannerCollection.findOne.mockResolvedValue(null);

    const result = await generateLaunchUrlsCase('CASE123');
    expect(result).toEqual({
      error: 404,
      message: 'DICOM Store not found for scanner scanner123',
    });
  });

  it('should return launch URLs for valid case and scanner data', async () => {
    mockDicomCollection.find.mockReturnValue({
      toArray: jest.fn().mockResolvedValue([
        {
          actualStudyInstanceUid: 'study1',
          seriesInstanceUid: 'series1',
          deviceSerialNumber: 'scanner123',
        },
        {
          actualStudyInstanceUid: 'study1',
          seriesInstanceUid: 'series1',
          deviceSerialNumber: 'scanner123',
        },
        {
          actualStudyInstanceUid: 'study2',
          seriesInstanceUid: 'series2',
          deviceSerialNumber: 'scanner123',
        },
      ]),
    });

    mockScannerCollection.findOne.mockResolvedValue({
      dicomStore: 'storeABC',
    });

    const result = await generateLaunchUrlsCase('CASE123');

    const expectedUrls = [
      `VIS:${Buffer.from('DICOMweb:hca://prefix/storeABC/dicomWeb/studies/study1/series/series1').toString('base64')}`,
      `VIS:${Buffer.from('DICOMweb:hca://prefix/storeABC/dicomWeb/studies/study2/series/series2').toString('base64')}`,
    ];

    expect(result).toEqual({ launchUrls: expectedUrls });
  });
});