const fetch = require('node-fetch');
const { fetchCase } = require('../../services/ibexService');
const { Response, Headers } = jest.requireActual('node-fetch');

jest.mock('node-fetch');

jest.mock('../../config/config', () => ({
  ibex: {
    baseUrl: 'https://ibex.example.com/',
    apiKey: 'test-api-key'
  }
}));

describe('fetchCase (ibexService)', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return case data with status 200', async () => {
    const mockBody = JSON.stringify({
      id: 'test_id',
      ibex_url: 'test_url',
      actual_slides_num: 1,
      expected_slides_num: 0,
      owner: 'Pathologist',
      tissues: ['prostate'],
      created_at: '2025-10-10T23:55:26.921719+00:00',
      updated_at: '2025-10-10T23:55:26.924210+00:00'
    });

    const mockHeaders = new Headers({ 'Content-Type': 'application/json' });
    const mockResponse = new Response(mockBody, {
      status: 200,
      headers: mockHeaders
    });

    fetch.mockResolvedValue(mockResponse);

    const result = await fetchCase('MJV123');

    expect(result.status).toBe(200);
    expect(result.headers['content-type']).toContain('application/json');
    expect(result.body).toBe(mockBody);
  });

  it('should return 404 when case is not found', async () => {
    const mockBody = JSON.stringify({
      detail: 'Case MJV123 was not found.',
      status: 404,
      title: 'Not Found',
      type: 'about:blank'
    });

    const mockHeaders = new Headers({ 'Content-Type': 'application/json' });
    const mockResponse = new Response(mockBody, {
      status: 404,
      headers: mockHeaders
    });

    fetch.mockResolvedValue(mockResponse);

    const result = await fetchCase('MJV123');

    expect(result.status).toBe(404);
    expect(result.headers['content-type']).toContain('application/json');
    expect(result.body).toBe(mockBody);
  });

  it('should throw error on fetch failure', async () => {
    fetch.mockRejectedValue(new Error('Network error'));

    await expect(fetchCase('MJV123')).rejects.toThrow('Network error');
  });
});
