const { connectToMongo } = require('../../database/connection');
const { MongoClient } = require('mongodb');

const mockConnect = jest.fn();
const mockDb = jest.fn().mockReturnValue('mockDb');

jest.mock('mongodb', () => ({
  MongoClient: jest.fn(() => ({
    connect: mockConnect,
    db: mockDb,
  })),
}));

jest.mock('../../config/config', () => ({
  mongo: {
    uri: 'mongodb://localhost:27017',
    dbName: 'testDB',
  },
}));

jest.mock('../../database/dbContext', () => ({
  setDb: jest.fn(),
}));

jest.mock('../../utils/logger', () => ({
  info: jest.fn(),
  error: jest.fn(),
}));

const logger = require('../../utils/logger');
const { setDb } = require('../../database/dbContext');

describe('connectToMongo', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should connect to MongoDB and set the database', async () => {
    await connectToMongo();

    expect(MongoClient).toHaveBeenCalledWith('mongodb://localhost:27017');
    expect(mockConnect).toHaveBeenCalled();
    expect(mockDb).toHaveBeenCalledWith('testDB');
    expect(setDb).toHaveBeenCalledWith('mockDb');
    expect(logger.info).toHaveBeenCalledWith('MongoDB connected.');
  });

  it('should log error if connection fails', async () => {
    mockConnect.mockRejectedValueOnce(new Error('Connection failed'));

    await connectToMongo();

    expect(logger.error).toHaveBeenCalledWith('MongoDB connection failed:', 'Connection failed');
  });
});