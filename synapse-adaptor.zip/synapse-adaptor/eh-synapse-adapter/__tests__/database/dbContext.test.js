describe('dbContext', () => {
  afterEach(() => {
    jest.resetModules();
  });

  it('should throw an error if getDb is called before setDb', () => {
    const { getDb } = require('../../database/dbContext');
    expect(() => getDb()).toThrow('Database is not initialized.');
  });

  it('should return the database after setDb is called', () => {
    const mockDb = { name: 'mockDatabase' };
    const { setDb, getDb } = require('../../database/dbContext');

    setDb(mockDb);
    const result = getDb();

    expect(result).toBe(mockDb);
  });

  it('should allow overwriting the database with a new value', () => {
    const firstDb = { name: 'firstDb' };
    const secondDb = { name: 'secondDb' };
    const { setDb, getDb } = require('../../database/dbContext');

    setDb(firstDb);
    expect(getDb()).toBe(firstDb);

    setDb(secondDb);
    expect(getDb()).toBe(secondDb);
  });
});