const request = require('supertest');
const express = require('express');

jest.mock('../../controllers/visiopharmController', () => ({
  getVisiopharmCase: jest.fn((req, res) => {
    res.status(200).json({ source: 'visiopharm', accession: req.params.accessionNumber });
  }),
}));

const router = require('../../routes/routes');

const app = express();
app.use(router);

describe('Visiopharm route', () => {
  it('should route /api/visiopharm/case/:accessionNumber to getVisiopharmCase', async () => {
    const res = await request(app).get('/api/visiopharm/case/VIS123');
    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ source: 'visiopharm', accession: 'VIS123' });
  });
});