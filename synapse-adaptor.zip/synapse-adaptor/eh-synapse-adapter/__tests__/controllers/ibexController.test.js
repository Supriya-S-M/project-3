const request = require('supertest');
const express = require('express');
const { getIbexCase } = require('../../controllers/ibexController');
const ibexService = require('../../services/ibexService');

jest.mock('../../services/ibexService');

const app = express();
app.get('/ibex/:accessionNumber', getIbexCase);

describe('GET /ibex/:accessionNumber', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });


  it('should return case data with status 200', async () => {
    const mockBody = JSON.stringify({
      id: 'test_id',
      ibex_url: 'test_url',
      actual_slides_num: 1,
      expected_slides_num: 0,
      owner: 'Pathologist',
      tissues: ['prostate'],
      created_at: '2025-10-10T23:55:26.921719+00:00',
      updated_at: '2025-10-10T23:55:26.924210+00:00'
    });

    ibexService.fetchCase.mockResolvedValue({
      status: 200,
      headers: { 'Content-Type': 'application/json' },
      body: mockBody
    });

    const res = await request(app).get('/ibex/MJV123');

    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toContain('application/json');
    expect(res.text).toBe(mockBody);
    expect(ibexService.fetchCase).toHaveBeenCalledWith('MJV123');
  });

  it('should return 404 if case is not found', async () => {
    const mockBody = JSON.stringify({
      detail: 'Case MJV123 was not found.',
      status: 404,
      title: 'Not Found',
      type: 'about:blank'
    });

    ibexService.fetchCase.mockResolvedValue({
      status: 404,
      headers: { 'Content-Type': 'application/json' },
      body: mockBody
    });

    const res = await request(app).get('/ibex/MJV123');

    expect(res.statusCode).toBe(404);
    expect(res.headers['content-type']).toContain('application/json');
    expect(res.text).toBe(mockBody);
  });

  it('should return 500 on internal error', async () => {
    ibexService.fetchCase.mockRejectedValue(new Error('Unexpected failure'));

    const res = await request(app).get('/ibex/FAIL');

    expect(res.statusCode).toBe(500);
    expect(res.body).toEqual({ error: 'Internal server error' });
  });
});