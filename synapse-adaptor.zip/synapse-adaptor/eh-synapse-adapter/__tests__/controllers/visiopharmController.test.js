const request = require('supertest');
const express = require('express');

const { getVisiopharmCase } = require('../../controllers/visiopharmController');
const visiopharmService = require('../../services/visiopharmService');

jest.mock('../../services/visiopharmService');

const app = express();
app.get('/visiopharm/:accessionNumber', getVisiopharmCase);

describe('GET /visiopharm/:accessionNumber', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  it('should return launch URLs on success', async () => {
    const mockUrls = ['http://example.com/case1', 'http://example.com/case2'];
    visiopharmService.generateLaunchUrlsCase.mockResolvedValue({ launchUrls: mockUrls });

    const res = await request(app).get('/visiopharm/ABC123');

    expect(res.statusCode).toBe(200);
    expect(res.body).toEqual({ launch_urls: mockUrls });
    expect(visiopharmService.generateLaunchUrlsCase).toHaveBeenCalledWith('ABC123');
  });

  it('should return 404 if case is not found', async () => {
    visiopharmService.generateLaunchUrlsCase.mockResolvedValue({
      error: 404,
      message: 'Case not found'
    });

    const res = await request(app).get('/visiopharm/NOTFOUND');

    expect(res.statusCode).toBe(404);
    expect(res.body).toEqual({ error: 'Case not found' });
  });

  it('should return 503 if database is not initialized', async () => {
    visiopharmService.generateLaunchUrlsCase.mockRejectedValue(new Error('Database is not initialized'));

    const res = await request(app).get('/visiopharm/DBERROR');

    expect(res.statusCode).toBe(503);
    expect(res.body).toEqual({
      error: 'Service temporarily unavailable. Please try again later or contact support if the issue persists.'
    });
  });

  it('should return 500 for other internal errors', async () => {
    visiopharmService.generateLaunchUrlsCase.mockRejectedValue(new Error('Unexpected failure'));

    const res = await request(app).get('/visiopharm/FAIL');

    expect(res.statusCode).toBe(500);
    expect(res.body).toEqual({ error: 'Internal server error' });
  });
});