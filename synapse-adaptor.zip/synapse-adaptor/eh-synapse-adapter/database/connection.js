const { MongoClient } = require('mongodb');
const config = require('../config/config');
const { setDb } = require('./dbContext');
const logger = require('../utils/logger');

async function connectToMongo() {
  try {
    const client = new MongoClient(config.mongo.uri);
    await client.connect();
    const database = client.db(config.mongo.dbName);
    setDb(database);
    logger.info('MongoDB connected.');
  } catch (err) {
    logger.error('MongoDB connection failed:', err.message);
  }
}

module.exports = { connectToMongo };