let db = null;

function setDb(database) {
  db = database;
}

function getDb() { 
  if (!db) { 
    throw new Error('Database is not initialized.');
  }
  return db;
}

module.exports = {
  setDb,
  getDb
};