const { generateLaunchUrlsCase } = require('../services/visiopharmService');

async function getVisiopharmCase(req, res) {
  try {
    const { accessionNumber } = req.params;
    const result = await generateLaunchUrlsCase(accessionNumber);

    if (result.error === 404) {
      return res.status(404).json({ error: result.message });
    }

    res.json({ launch_urls: result.launchUrls });
  } catch (err) {
    if (err.message.includes('Database is not initialized')) {
      return res.status(503).json({ error: 'Service temporarily unavailable. Please try again later or contact support if the issue persists.' });
    }
    console.error(`Visiopharm error for ${req.params.accessionNumber}:`, err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { getVisiopharmCase };