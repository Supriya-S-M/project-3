const { fetchCase } = require('../services/ibexService');

async function getIbexCase(req, res) {
  try {
    const { accessionNumber } = req.params;
    const { status, headers, body } = await fetchCase(accessionNumber);

    res.status(status);
    Object.entries(headers).forEach(([key, value]) => res.setHeader(key, value));
    res.send(body);
  } catch (err) {
    console.error('IBEX fetch error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { getIbexCase };