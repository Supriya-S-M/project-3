const express = require('express');
const router = express.Router();
const { getIbexCase } = require('../controllers/ibexController');
const { getVisiopharmCase } = require('../controllers/visiopharmController');

router.get('/api/ibex/case/:accessionNumber', getIbexCase);
router.get('/api/visiopharm/case/:accessionNumber',getVisiopharmCase);

module.exports = router;