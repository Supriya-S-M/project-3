package com.eh.digiatalpathalogy.admin.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.ReactiveRedisTemplate;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class RedisEntityStore {


    private static final Logger log = LoggerFactory.getLogger(RedisEntityStore.class);

    private final ReactiveRedisTemplate<String, Object> redisTemplate;
    private final ObjectMapper objectMapper;

    public RedisEntityStore(ReactiveRedisTemplate<String, Object> redisTemplate,
                            ObjectMapper objectMapper) {
        this.redisTemplate = redisTemplate;
        this.objectMapper = objectMapper;
    }

    public <T> Mono<Boolean> save(String key, T value) {
        if (key == null || value == null) {
            log.warn("Attempted to save null key or value");
            return Mono.just(false);
        }

        return redisTemplate.opsForValue().set(key, value)
                .doOnSuccess(success -> log.debug("Saved [{}] to Redis with key: {}", value.getClass().getSimpleName(), key))
                .doOnError(e -> log.error("Failed to save [{}] to Redis with key: {}", value.getClass().getSimpleName(), key, e));
    }

    public <T> Mono<T> findByKey(String key, Class<T> type) {
        if (key == null) {
            log.warn("Attempted to fetch [{}] with null key", type.getSimpleName());
            return Mono.empty();
        }

        return redisTemplate.opsForValue().get(key)
                .map(obj -> objectMapper.convertValue(obj, type))
                .doOnNext(val -> log.debug("Fetched [{}] from Redis with key: {}", type.getSimpleName(), key))
                .doOnError(e -> log.error("Failed to fetch [{}] from Redis with key: {}", type.getSimpleName(), key, e));
    }

    public <T> Mono<T> findByKeyWithFallback(String key, Supplier<Mono<T>> dbSupplier, Class<T> type) {
        if (key == null) {
            log.warn("Attempted to fetch [{}] with null key", type.getSimpleName());
            return Mono.empty();
        }

        return redisTemplate.opsForValue().get(key)
                .map(obj -> objectMapper.convertValue(obj, type))
                .flatMap(cached -> {
                    log.info("Cache hit: [{}] found in Redis with key: {}", type.getSimpleName(), key);
                    return Mono.just(cached);
                })
                .switchIfEmpty(
                        dbSupplier.get()
                                .flatMap(fresh -> redisTemplate.opsForValue().set(key, fresh)
                                        .thenReturn(fresh))
                                .doOnSuccess(val -> log.info("Cache miss: fetched [{}] from DB and cached with key: {}", type.getSimpleName(), key))
                                .doOnError(e -> log.error("Failed to fetch [{}] from DB for key: {}", type.getSimpleName(), key, e))
                )
                .doOnError(e -> log.error("Error fetching [{}] from Redis with key: {}", type.getSimpleName(), key, e));
    }

    public <T> Mono<List<T>> findByPatternWithFallback(String patternPrefix,
                                                       Predicate<T> filter,
                                                       Supplier<Flux<T>> dbSupplier,
                                                       Function<T, String> keyExtractor,
                                                       Class<T> type) {
        String pattern = patternPrefix + "*";
        return redisTemplate.keys(pattern)
                .collectList()
                .flatMapMany(Flux::fromIterable)
                .flatMap(key -> redisTemplate.opsForValue().get(key)
                        .map(obj -> objectMapper.convertValue(obj, type))
                        .filter(filter)
                        .onErrorResume(e -> {
                            log.error("Error fetching [{}] for key: {}", type.getSimpleName(), key, e);
                            return Mono.empty();
                        }))
                .collectList()
                .flatMap(cachedList -> {
                    if (!cachedList.isEmpty()) {
                        log.info("Cache hit: {} [{}] items found by pattern", cachedList.size(), type.getSimpleName());
                        return Mono.just(cachedList);
                    }
                    log.warn("Cache miss: fetching [{}] from DB by pattern", type.getSimpleName());
                    return dbSupplier.get()
                            .collectList()
                            .flatMap(freshList -> Flux.fromIterable(freshList)
                                    .flatMap(item -> {
                                        String key = patternPrefix + keyExtractor.apply(item);
                                        return redisTemplate.opsForValue().set(key, item);
                                    })
                                    .then(Mono.just(freshList)));
                });
    }

    public Mono<Boolean> deleteByKey(String key) {
        if (key == null) {
            log.warn("Attempted to delete null key");
            return Mono.just(false);
        }

        return redisTemplate.delete(key)
                .map(deleted -> deleted > 0)
                .doOnSuccess(success -> {
                    if (Boolean.TRUE.equals(success)) {
                        log.info("Deleted entry from Redis with key: {}", key);
                    } else {
                        log.warn("No entry found to delete with key: {}", key);
                    }
                })
                .doOnError(e -> log.error("Failed to delete entry from Redis with key: {}", key, e));
    }

    public Mono<Boolean> deleteKeysByPattern(String pattern) {
        if (pattern == null || pattern.trim().isEmpty()) {
            log.warn("Attempted to delete keys with null or empty pattern");
            return Mono.just(false);
        }
        return redisTemplate.keys(pattern)
                .flatMap(redisTemplate::delete).count()
                .map(count -> {
                    log.info("Total keys deleted for pattern '{}': {}", pattern, count);
                    return count > 0;
                })
                .onErrorResume(e -> {
                    log.error("Failed to delete keys by pattern '{}': {}", pattern, e.getMessage(), e);
                    return Mono.just(false);
                });
    }

    public Mono<Map<String, Object>> findByPattern(String patternPrefix) {
        String pattern = patternPrefix + "*";

        return redisTemplate.keys(pattern)
                .collectList()
                .flatMapMany(Flux::fromIterable)
                .flatMap(key -> redisTemplate.opsForValue().get(key)
                        .map(value -> Map.entry(key, value))
                        .onErrorResume(e -> {
                            log.error("Error fetching value for key: {}", key, e);
                            return Mono.empty();
                        }))
                .collectMap(Map.Entry::getKey, Map.Entry::getValue);
    }

    public Mono<Map<String, Object>> fetchApplicationConfig(String appName) {
        String key = String.format("config::%s", appName);

        return redisTemplate.opsForValue().get(key)
                .flatMap(value -> Mono.just((Map<String, Object>) value))
                .switchIfEmpty(Mono.defer(() -> {
                    log.warn("No value found for key: {}", key);
                    return Mono.just(Collections.emptyMap());
                }))
                .doOnSuccess(resultMap -> {
                    if (resultMap.isEmpty()) {
                        log.warn("Empty config map retrieved for key: {}", key);
                    } else {
                        log.info("Successfully retrieved config map for key: {}", key);
                    }
                })
                .doOnError(e -> log.error("Error retrieving config for key: {}", key, e));
    }

}
