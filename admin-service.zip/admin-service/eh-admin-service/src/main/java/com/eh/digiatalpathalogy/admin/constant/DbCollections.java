package com.eh.digiatalpathalogy.admin.constant;

public final class DbCollections {
    private DbCollections() {
    }

    public static final String QA_SLIDE = "qa_slide";
    public static final String SLIDE_SCANNER = "slide_scanner";
    public static final String SLIDE_ANALYSIS_REPORT = "slide_analysis_reports";
    public static final String HOSPITAL_METADATA_COLLECTION = "hospital_metadata";
    public static final String AUTH_USER = "auth_users";
}
