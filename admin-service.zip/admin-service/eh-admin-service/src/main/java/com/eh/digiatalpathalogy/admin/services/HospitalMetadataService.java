package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.model.HospitalMetadata;
import com.eh.digiatalpathalogy.admin.repository.MongoOperations;
import com.eh.digiatalpathalogy.admin.util.RedisEntityStore;
import org.bson.Document;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;

import static com.eh.digiatalpathalogy.admin.constant.DbCollections.HOSPITAL_METADATA_COLLECTION;
import static com.eh.digiatalpathalogy.admin.constant.RedisCacheKey.METADATA_HOSPITAL;

@Service
public class HospitalMetadataService {

    private final RedisEntityStore redisStore;
    private final MongoOperations mongoOperations;

    public HospitalMetadataService(RedisEntityStore redisStore, MongoOperations mongoOperations) {
        this.redisStore = redisStore;
        this.mongoOperations = mongoOperations;
    }

    public Mono<HospitalMetadata> getHospitalMetadata() {
        return redisStore.findByKey(METADATA_HOSPITAL, HospitalMetadata.class)
                .switchIfEmpty(fetchFromMongoAndCache());
    }

    private Mono<HospitalMetadata> fetchFromMongoAndCache() {
        return mongoOperations.find(new Query(), Document.class, HOSPITAL_METADATA_COLLECTION)
                .collectList()
                .map(docs -> {
                    List<String> hospitalNames = docs.stream()
                            .filter(doc -> "hospital_name".equalsIgnoreCase(doc.getString("type")))
                            .flatMap(doc -> ((List<String>) doc.get("value")).stream())
                            .distinct()
                            .toList();

                    List<String> locations = docs.stream()
                            .filter(doc -> "hospital_location".equalsIgnoreCase(doc.getString("type")))
                            .flatMap(doc -> ((List<String>) doc.get("value")).stream())
                            .distinct()
                            .toList();

                    return new HospitalMetadata(hospitalNames, locations);
                })
                .flatMap(metadata -> redisStore.save(METADATA_HOSPITAL, metadata).thenReturn(metadata));
    }


}
