package com.eh.digiatalpathalogy.admin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import org.springframework.data.annotation.Id;

@JsonIgnoreProperties(ignoreUnknown = true)
public record SlideScanner(@Id String id, String deviceId, String deviceSerialNumber, @NotBlank String name,
                           @NotBlank String model,
                           @NotBlank String location,
                           @NotBlank String department, @NotBlank String dicomStore, @NotBlank String aeTitle,
                           String port, String hospitalName, String ipAddress, String vendor) {
}
