package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.client.ConfigurationClient;
import com.eh.digiatalpathalogy.admin.config.ConfigStore;
import com.eh.digiatalpathalogy.admin.config.EnrichmentToolConfig;
import com.eh.digiatalpathalogy.admin.exception.HttpRequestException;
import com.eh.digiatalpathalogy.admin.model.ConfigPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.stream.Collectors;

import static com.eh.digiatalpathalogy.admin.config.ConfigStore.flatMapAppMapping;
import static com.eh.digiatalpathalogy.admin.constant.EnrichmentToolConstant.*;

@Service
public class EnrichmentToolService {

    private static final Logger log = LoggerFactory.getLogger(EnrichmentToolService.class);

    private final ConfigurationClient configurationClient;
    private final ConfigStore configStore;
    private final EnrichmentToolConfig toolConfig;

    public EnrichmentToolService(ConfigurationClient configurationClient, ConfigStore configStore, EnrichmentToolConfig toolConfig) {
        this.configurationClient = configurationClient;
        this.configStore = configStore;
        this.toolConfig = toolConfig;
    }

    public Mono<Map<String, Object>> getApplicationConfig(String application) {
        if (SYNAPSE.equalsIgnoreCase(application)) {
            return getSynapseConfig();
        }
        return configStore.getAllPropertiesForApplication(application);
    }

    private Mono<Map<String, Object>> getSynapseConfig() {

        Map<String, Map<String, String>> mappings = toolConfig.getApplications().get(SYNAPSE).getMappings();
        Set<String> expectedKeys = mappings.values().stream()
                .flatMap(innerMap -> innerMap.keySet().stream()).collect(Collectors.toSet());

        return Flux.fromIterable(mappings.entrySet())
                .flatMap(entry -> configStore.getAllPropertiesForApplication(entry.getKey())) // returns Mono<Map<String,Object>>
                .reduce(new HashMap<>(), (acc, map) -> {
                    acc.putAll(map);
                    return acc;
                })
                .map(fullMap -> {
                    Map<String, Object> filteredMap = new HashMap<>();
                    expectedKeys.forEach(key -> {
                        if (fullMap.containsKey(key)) {
                            filteredMap.put(key, fullMap.get(key));
                        }
                    });
                    return filteredMap;
                });
    }

    private Map<String, Object> handleLisResponse(String application, Map<String, Map<String, Object>> payload) {

        Map<String, Object> lisConnectorRequest = null;
        if (application.equalsIgnoreCase(EH_DICOM_ENRICHER)) {
            String lisRequest = null;
            String acknowledgeType = null;
            String lisResponse = payload.get(COMMON).get("app.message.lis-response").toString();
            if (lisResponse.equalsIgnoreCase("OUL")) {
                lisRequest = "ORU";
                acknowledgeType = "ACK";
            } else if (lisResponse.equalsIgnoreCase("OML")) {
                lisRequest = "QBP";
                acknowledgeType = "ORL";
            }
            payload.get(COMMON).put("app.message.lis-request", lisRequest);
            lisConnectorRequest = Map.of("app-config.acknowledge-type", acknowledgeType);
        }
        return lisConnectorRequest;
    }

    private Map<String, Map<String, Object>> prepareUpdateRequestPayload(
            EnrichmentToolConfig.AppMapping appMapping,
            Map<String, Object> payload) {
        return appMapping.getMappings().entrySet().stream()
                .map(categoryEntry -> {
                    Map<String, Object> inner = categoryEntry.getValue().entrySet().stream()
                            .filter(mappingEntry -> payload.containsKey(mappingEntry.getKey()))
                            .collect(Collectors.toMap(Map.Entry::getValue,
                                    mappingEntry -> handleDataType(mappingEntry.getKey(), payload.get(mappingEntry.getKey())),
                                    (a, b) -> b,
                                    LinkedHashMap::new
                            ));
                    return new AbstractMap.SimpleEntry<>(categoryEntry.getKey(), inner);
                })
                .filter(e -> !e.getValue().isEmpty())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b) -> b, LinkedHashMap::new
                ));
    }

    private Object handleDataType(String key, Object value) {
        if (ARRAY_FIELDS.contains(key)) {
            if (value instanceof List<?>) {
                return ((List<?>) value).stream()
                        .map(String::valueOf)
                        .collect(Collectors.joining(","));
            } else if (value.getClass().isArray()) {
                return Arrays.stream((Object[]) value)
                        .map(String::valueOf)
                        .collect(Collectors.joining(","));
            }
        }
        return value;
    }

    private Mono<Boolean> isValidPayload(String application, Map<String, Object> payload) {
        if (application == null || application.isBlank()) {
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST, "Application is null or blank."));
        }
        if (payload == null) {
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST, "Payload cannot be null."));
        }
        if (toolConfig == null || toolConfig.getApplications() == null) {
            return Mono.error(new HttpRequestException(HttpStatus.INTERNAL_SERVER_ERROR, "toolConfig is not initialized."));
        }

        EnrichmentToolConfig.AppMapping appMapping = toolConfig.getApplications().get(application);
        if (appMapping == null) {
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST, "Unknown application: " + application));
        }

        Map<String, String> mappings = flatMapAppMapping(appMapping);
        if (mappings == null || mappings.isEmpty()) {
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST,
                    "No mappings configured for application: " + application));
        }

        Set<String> allowedKeys = mappings.keySet();
        Set<String> extraKeys = new LinkedHashSet<>(payload.keySet());
        extraKeys.removeAll(allowedKeys);

        if (!extraKeys.isEmpty()) {
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST,
                    String.format("Extra/unknown keys in payload for '%s': %s. Allowed keys: %s",
                            application, extraKeys, allowedKeys)));
        }

        return Mono.just(Boolean.TRUE);
    }

    private Mono<Map<String, Object>> updateSingleCategory(String application, Map.Entry<String, Map<String, Object>> entry) {
        ConfigPayload request = new ConfigPayload(entry.getKey(), entry.getValue());
        return configurationClient.updateConfig(application, null, request);
    }

    private Mono<Map<String, Object>> handleEnrichmentServiceUpdate(Map<String, Map<String, Object>> updatePayload, String application) {
        Map<String, Object> lisConnectorRequest = handleLisResponse(application, updatePayload);

        return Flux.fromIterable(updatePayload.entrySet())
                .flatMapSequential(entry -> updateSingleCategory(application, entry))
                .collectList()
                .flatMap(results -> {
                    Map<String, Object> merged = new LinkedHashMap<>();
                    results.forEach(merged::putAll);

                    Mono<Void> lisUpdate = Mono.empty();
                    if (Objects.nonNull(lisConnectorRequest)) {
                        ConfigPayload lisPayload = new ConfigPayload(SOURCE_NATIVE, lisConnectorRequest);
                        lisUpdate = configurationClient.updateConfig(EH_LIS_CONNECTOR, null, lisPayload)
                                .doOnSuccess(v -> log.info("Configuration for 'eh-lis-connector' updated successfully"))
                                .doOnError(ex -> log.error("Failed to update configuration for 'eh-lis-connector'", ex)).then();
                    }

                    return lisUpdate
                            .then(configurationClient.busRefresh())
                            .thenReturn(merged);
                })
                .doOnSuccess(cp -> log.info("Configuration for '{}' updated successfully (all categories)", application))
                .doOnError(ex -> log.error("Failed to update configuration for '{}' (one or more categories)", application, ex));
    }

    private Mono<Map<String, Object>> handleGenericAppUpdate(Map<String, Map<String, Object>> updatePayload, String application) {
        return Flux.fromIterable(updatePayload.entrySet())
                .flatMapSequential(entry -> updateSingleCategory(application, entry))
                .collectList()
                .flatMap(results -> {
                    Map<String, Object> merged = new LinkedHashMap<>();
                    results.forEach(merged::putAll);
                    return configurationClient.busRefresh().thenReturn(merged);
                })
                .doOnSuccess(cp -> log.info("Configuration for '{}' updated successfully (all categories)", application))
                .doOnError(ex -> log.error("Failed to update configuration for '{}' (one or more categories)", application, ex));
    }

    public Mono<Map<String, Object>> updateAppConfig(String application, Map<String, Object> payload) {

        if (SYNAPSE.equalsIgnoreCase(application)) {
            return updateSynapse(payload);
        }

        return isValidPayload(application, payload)
                .then(Mono.defer(() -> {
                    EnrichmentToolConfig.AppMapping appMapping = toolConfig.getApplications().get(application);
                    Map<String, Map<String, Object>> updatePayload = prepareUpdateRequestPayload(appMapping, payload);

                    if (updatePayload == null || updatePayload.isEmpty()) {
                        return Mono.just(Collections.emptyMap());
                    }

                    if (EH_DICOM_ENRICHER.equalsIgnoreCase(application)) {
                        return handleEnrichmentServiceUpdate(updatePayload, application);
                    } else {
                        return handleGenericAppUpdate(updatePayload, application);
                    }
                }));
    }

    private Mono<Map<String, Object>> updateSynapse(Map<String, Object> payload) {


        Map<String, Object> hl7Payload = new HashMap<>();
        Map<String, Object> exportPayload = new HashMap<>();

        Set<String> hl7Keys = toolConfig.getApplications().get(SYNAPSE).getMappings().get(EH_HL7_CONNECTOR).keySet();
        Set<String> exportKeys = toolConfig.getApplications().get(SYNAPSE).getMappings().get(EH_EXPORT_SERVICE).keySet();

        payload.keySet().forEach(key -> {
            if (hl7Keys.contains(key)) {
                hl7Payload.put(key, payload.get(key));
            } else if (exportKeys.contains(key)) {
                exportPayload.put(key, payload.get(key));
            }
        });

        return updateAppConfig(EH_HL7_CONNECTOR, hl7Payload)
                .then(updateAppConfig(EH_EXPORT_SERVICE, exportPayload));
    }

}
