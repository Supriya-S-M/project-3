package com.eh.digiatalpathalogy.admin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.annotation.Id;

@JsonIgnoreProperties(ignoreUnknown = true)
public record User(@Id String id, String username, String password) {
}
