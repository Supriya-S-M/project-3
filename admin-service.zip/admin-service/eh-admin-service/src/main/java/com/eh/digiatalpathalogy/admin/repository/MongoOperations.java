package com.eh.digiatalpathalogy.admin.repository;

import com.mongodb.MongoException;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.time.Duration;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class MongoOperations {

    private final ReactiveMongoTemplate mongoTemplate;
    private final Duration initialDelay = Duration.ofSeconds(1);

    @Autowired
    public MongoOperations(ReactiveMongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    private Retry buildRetry() {
        int maxAttempts = 3;
        return Retry.backoff(maxAttempts, initialDelay)
                .filter(MongoException.class::isInstance);
    }

    public <T> Mono<T> save(T entity, String collectionName) {
        return mongoTemplate.insert(entity, collectionName)
                .retryWhen(buildRetry());
    }

    public <T> Flux<T> find(Query query, Class<T> clazz, String collectionName) {
        return mongoTemplate.find(query, clazz, collectionName)
                .retryWhen(buildRetry());
    }

    public Mono<Set<String>> getCollectionNames() {
        return mongoTemplate.getCollectionNames()
                .collect(Collectors.toSet())
                .retryWhen(buildRetry());
    }

    public <T> Mono<T> findAndModify(Query query, Update update, Class<T> clazz, String collectionName) {
        return mongoTemplate.findAndModify(query, update,
                        FindAndModifyOptions.options().returnNew(true).upsert(false),
                        clazz, collectionName)
                .retryWhen(buildRetry());
    }

    public <T> Mono<T> findOne(Query query, Class<T> clazz, String collectionName) {
        return mongoTemplate.findOne(query, clazz, collectionName)
                .retryWhen(buildRetry());
    }

    public <T> Mono<Boolean> upsert(Query query, Update update, Class<T> entityClass, String collectionName) {
        return mongoTemplate.upsert(query, update, entityClass, collectionName)
                .map(UpdateResult::wasAcknowledged)
                .retryWhen(buildRetry());
    }

    public <T> Mono<Boolean> delete(Query query, Class<T> clazz, String collectionName) {
        return mongoTemplate.remove(query, clazz, collectionName)
                .map(DeleteResult::wasAcknowledged)
                .retryWhen(buildRetry());
    }



}
