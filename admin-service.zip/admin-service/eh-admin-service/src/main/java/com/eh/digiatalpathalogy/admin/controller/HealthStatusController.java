package com.eh.digiatalpathalogy.admin.controller;

import com.eh.digiatalpathalogy.admin.client.HealthTargetsProperties;
import com.eh.digiatalpathalogy.admin.model.PingResult;
import com.eh.digiatalpathalogy.admin.services.PingService;
import org.springframework.boot.actuate.health.CompositeHealth;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.boot.actuate.health.Status;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RestController
public class HealthStatusController {

    private final HealthEndpoint healthEndpoint;
    private final HealthTargetsProperties props;
    private final PingService pingService;


    public HealthStatusController ( HealthEndpoint healthEndpoint, HealthTargetsProperties props, PingService pingService ) {
        this.healthEndpoint = healthEndpoint;
        this.props = props;
        this.pingService = pingService;
    }

    @GetMapping( "api/health/status" )
    public Map< String, Object > getHealthStatus ( ) {
        Map< String, Object > response = new HashMap<>( );
        response.put( "timestamp", Instant.now( ).toString( ) );

        HealthComponent health = healthEndpoint.health( );
        Map< String, Object > dependencies = new HashMap<>( );

        dependencies.put( "mongodb", findStatus( health, "mongo", "mongodb" ) );
        dependencies.put( "redis", findStatus( health, "customRedisConnectionFactory" ) );
        dependencies.put( "kafka", findStatus( health, "kafka" ) );
        response.put( "dependencies", dependencies );

        CompletableFuture< List< PingResult > > servicesF = CompletableFuture.supplyAsync( ( ) -> pingService.pingAllHttp( props.getMicroservices( ) ) );
        CompletableFuture< List< PingResult > > thirdF = CompletableFuture.supplyAsync( ( ) -> pingService.pingAllIcmp( props.getThirdParties( ) ) );
        CompletableFuture.allOf( servicesF, thirdF ).join( );
        response.put( "microservices", servicesF.join( ) );
        response.put( "thirdParties", thirdF.join( ) );

        return response;
    }

    private String status ( Status s ) {
        return s == null ? "UNKNOWN" : s.getCode( );
    }

    private Status statusOf ( HealthComponent component ) {
        try {
            return component.getStatus( );
        } catch ( Exception e ) {
            return Status.UNKNOWN;
        }
    }

    private String findStatus ( HealthComponent component, String... nameHints ) {
        String s = findStatusRecursive( component, nameHints );
        return s == null ? "UNKNOWN" : s;
    }

    private String findStatusRecursive ( HealthComponent component, String... nameHints ) {
        if ( component instanceof CompositeHealth ch ) {
            for ( Map.Entry< String, HealthComponent > entry : ch.getComponents( ).entrySet( ) ) {
                String name = entry.getKey( );
                HealthComponent child = entry.getValue( );
                if ( matches( name, nameHints ) ) {
                    return status( statusOf( child ) );
                }
                String nested = findStatusRecursive( child, nameHints );
                if ( nested != null ) {
                    return nested;
                }
            }
        }
        return null;
    }

    private boolean matches ( String name, String... hints ) {
        if ( name == null ) return false;
        String n = name.toLowerCase( );
        for ( String h : hints ) {
            if ( h == null ) continue;
            String hl = h.toLowerCase( );
            if ( n.equals( hl ) || n.contains( hl ) ) {
                return true;
            }
        }
        return false;
    }
}
