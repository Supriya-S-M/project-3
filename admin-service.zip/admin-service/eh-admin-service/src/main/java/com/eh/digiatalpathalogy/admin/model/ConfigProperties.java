package com.eh.digiatalpathalogy.admin.model;

public class ConfigProperties {

    private String gcpDicomBaseUrl;

    public String getGcpDicomBaseUrl() {
        return gcpDicomBaseUrl;
    }

    public void setGcpDicomBaseUrl(String gcpDicomBaseUrl) {
        this.gcpDicomBaseUrl = gcpDicomBaseUrl;
    }
}
