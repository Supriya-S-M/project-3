package com.eh.digiatalpathalogy.admin.model;

public record SlideAnalysisRequest(String slideId,String activationCode, String dicomSeriesPath) {}
