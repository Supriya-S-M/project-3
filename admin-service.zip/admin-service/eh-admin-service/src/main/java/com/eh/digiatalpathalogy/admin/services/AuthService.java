package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.exception.HttpRequestException;
import com.eh.digiatalpathalogy.admin.model.User;
import com.eh.digiatalpathalogy.admin.repository.MongoOperations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import static com.eh.digiatalpathalogy.admin.constant.DbCollections.AUTH_USER;

@Service
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    private final MongoOperations mongoOperations;

    public AuthService(MongoOperations mongoOperations) {
        this.mongoOperations = mongoOperations;
    }

    public Mono<Boolean> authenticate(User request) {
        HttpRequestException autError = new HttpRequestException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        return mongoOperations.findOne(Query.query(Criteria.where("username").is(request.username())), User.class, AUTH_USER)
                .switchIfEmpty(Mono.error(autError))
                .map(dbUser -> {
                    if (!dbUser.password().equals(request.password())) {
                        throw autError;
                    }
                    return true;
                });
    }

    public Mono<User> register(User user) {
        return mongoOperations.save(user, AUTH_USER)
                .doOnSuccess(saved ->
                        log.info("User registered successfully with username: {}", saved.username()))
                .onErrorMap(DuplicateKeyException.class, ex -> {
                    log.warn("Duplicate username detected: {}", user.username(), ex);
                    return new HttpRequestException(
                            HttpStatus.CONFLICT,
                            "User with username '" + user.username() + "' already exists."
                    );
                })
                .doOnError(e ->
                        log.error("Failed to register user {}: {}", user.username(), e.getMessage(), e));
    }

}