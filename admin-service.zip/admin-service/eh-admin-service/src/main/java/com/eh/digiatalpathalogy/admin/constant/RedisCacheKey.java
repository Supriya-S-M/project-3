package com.eh.digiatalpathalogy.admin.constant;

public class RedisCacheKey {
    private RedisCacheKey() {
    }

    public static final String SLIDE_BARCODE_PREFIX = "slide::barcode::";
    public static final String ANALYSIS_ID_PREFIX = "report::analysisId::";
    public static final String SCANNER_DEVICE_PREFIX = "scanner::deviceSerialNumber::";
    public static final String METADATA_HOSPITAL = "metadata::";

}
