package com.eh.digiatalpathalogy.admin.exception;

public class RemoteServiceException extends RuntimeException {

    private static final String DEFAULT_ERROR_CODE = "Remote Server Error.";
    private final String errorCode;

    public RemoteServiceException(String message) {
        super(message);
        this.errorCode = DEFAULT_ERROR_CODE;
    }

    public RemoteServiceException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = DEFAULT_ERROR_CODE;
    }

    public String getErrorCode() {
        return errorCode;
    }

}
