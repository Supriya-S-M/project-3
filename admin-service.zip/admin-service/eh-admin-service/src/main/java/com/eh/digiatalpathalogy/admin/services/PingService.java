package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.client.HealthTargetsProperties;
import com.eh.digiatalpathalogy.admin.model.PingResult;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class PingService {

    private final HttpClient httpClient;
    private final HealthTargetsProperties props;


    public PingService (HealthTargetsProperties props ) {
        this.httpClient = HttpClient.newBuilder().connectTimeout( props.getConnectionTimeout() ).build();
        this.props = props;
    }

    public List<PingResult> pingAllHttp( List< HealthTargetsProperties.Target > targets ){
        List< CompletableFuture< PingResult > > futures = targets.stream().map(this::pingHttp).toList( );
        CompletableFuture.allOf( futures.toArray(CompletableFuture[]::new) ).join();
        return futures.stream( ).map( CompletableFuture::join ).collect( Collectors.toList( ) );
    }

    public List<PingResult> pingAllIcmp( List< HealthTargetsProperties.Target > targets ){
        List< PingResult > results = new ArrayList<>( );
        for ( HealthTargetsProperties.Target target : targets ) {
           results.add(pingIcmp(target));
        }
        return results;
    }

    private CompletableFuture<PingResult> pingHttp( HealthTargetsProperties.Target target ){
        try{
            HttpRequest.Builder builder = HttpRequest.newBuilder().uri( URI.create( target.getUrl() ) ).timeout( props.getReadTimeout() ).GET();
            for( Map.Entry<String, String> e: target.getHeaders().entrySet()){
                builder.header( e.getKey(), e.getValue() );
            }
            HttpRequest request = builder.build();
            Instant start = Instant.now();
            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.discarding()).<PingResult>handle((resp, ex) -> {
                long latency = Duration.between( start, Instant.now( )).toMillis();
                if (ex != null){
                    return new PingResult().down( target.getName(), target.getUrl( ), null, latency, ex.getClass().getSimpleName() + ": " + ex.getMessage() );
                }
                int status  = resp.statusCode();
                boolean up = status >= 200 && status < 300;
                return new PingResult( up? "UP":"DOWN", target.getUrl(), target.getName(), status, latency, null );
            });
        } catch (Exception e){
            return CompletableFuture.completedFuture( new PingResult( ).down( target.getName( ), target.getUrl( ), null, 0, e.getClass( ).getSimpleName( ) + ": " + e.getMessage( ) ) );
        }
    }

    private PingResult pingIcmp ( HealthTargetsProperties.Target target ){
        String original = target.getUrl( );
        String host = extractHost( original );
        List<String> command = new ArrayList<>( );
        command.add( "ping" );
        command.add( "-c" );
        command.add( "1" );
        command.add( "-W" );
        long seconds = Math.max( 1, props.getReadTimeout( ).toSeconds( ) );
        command.add( String.valueOf( seconds ) );
        command.add( host );

        Instant start = Instant.now( );
        try {
            ProcessBuilder pb = new ProcessBuilder( command );
            Process process = pb.start( );
            boolean finished = process.waitFor( Math.max( 1, props.getReadTimeout( ).toSeconds( ) ), TimeUnit.SECONDS );
            long latency = Duration.between( start, Instant.now( ) ).toMillis( );
            if ( !finished ) {
                process.destroyForcibly();
                return new PingResult( ).down( target.getName( ), original, null, latency, "Timeout" );
            }
            int exit = process.exitValue();
            if ( exit == 0 ) {
                return new PingResult( "UP", original,target.getName(), 0, latency, null );
            } else {
                String stdErr = readStream( process.getErrorStream( ) );
                String stdOut = readStream( process.getInputStream( ) );
                String err = (stdErr  != null && !stdErr.isBlank()) ? stdErr : stdOut;
                return new PingResult( ).down( target.getName( ), original, null, latency, err == null ? "Non-zero exit" : trim( err ) );
            }
        }catch ( Exception e ){
            long latency = Duration.between( start, Instant.now( ) ).toMillis( );
            return new PingResult( ).down( target.getName( ), original, null, latency, e.getClass( ).getSimpleName( ) + ": " + e.getMessage( ) );
        }
    }

    private String readStream( InputStream is ){
        try( BufferedReader br = new BufferedReader( new InputStreamReader( is ) ) ){
            StringBuilder sb = new StringBuilder( );
            String line;
            while ( ( line = br.readLine( ) ) != null ) {
                sb.append( line ).append( "\n" );
            }
            return sb.toString( ).trim( );
        } catch ( Exception e ){
            return null;
        }
    }
    private String trim(String s ){
        if (s == null) return null;
        return s.length() <= 300 ? s: s.substring( 0, 300 );
    }

    private String extractHost(String value){
        try {
            URI uri = URI.create( value );
            if ( uri.getHost( ) != null ) {
                return uri.getHost( );
            }
        }catch (Exception ignored){}

        String v = value;
        int idx = v.indexOf( "://" );
        if (idx > 0) v = v.substring( idx + 3 );
        int slash = v.indexOf( '/' );
        if (slash > 0) v = v.substring( 0, slash );
        int at = v.indexOf( '@' );
        if (at >= 0) v = v.substring( at + 1 );
        return v;

    }
}
