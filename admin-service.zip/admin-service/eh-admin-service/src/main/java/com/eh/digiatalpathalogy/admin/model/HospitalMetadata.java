package com.eh.digiatalpathalogy.admin.model;

import java.util.List;

public class HospitalMetadata {

    private List<String> locations;
    private List<String> names;

    public HospitalMetadata(List<String> locations, List<String> names) {
        this.locations = locations;
        this.names = names;
    }

    public HospitalMetadata() {
    }

    public List<String> getLocations() {
        return locations;
    }

    public void setLocations(List<String> locations) {
        this.locations = locations;
    }

    public List<String> getNames() {
        return names;
    }

    public void setNames(List<String> names) {
        this.names = names;
    }
}
