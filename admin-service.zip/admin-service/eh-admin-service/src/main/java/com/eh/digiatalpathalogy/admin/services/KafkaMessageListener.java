package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.model.SlideAnalysisMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
@RefreshScope
public class KafkaMessageListener {

    private static final Logger log = LoggerFactory.getLogger(KafkaMessageListener.class);

    private final SlideAnalysisReportService slideAnalysisReportService;
    private final ObjectMapper objectMapper;

    public KafkaMessageListener(SlideAnalysisReportService slideAnalysisReportService, ObjectMapper objectMapper) {
        this.slideAnalysisReportService = slideAnalysisReportService;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(topics = "${kafka.topic.qa-slide}")
    public void listen(ConsumerRecord<String, String> consumerRecord) {
        String message = consumerRecord.value();
        try {
            SlideAnalysisMessage slideAnalysisMessage = objectMapper.readValue(message, SlideAnalysisMessage.class);

            if (Objects.isNull(slideAnalysisMessage)) {
                log.warn("Parsed SlideAnalysisMessage is null. Skipping processing.");
                return;
            }
            log.info("Received message - StudyUID: {}, SeriesUID: {}, Device Serial Number: {}, Barcode: {}",
                    slideAnalysisMessage.studyInstanceUid(), slideAnalysisMessage.seriesInstanceUid(), slideAnalysisMessage.deviceSerialNumber(), slideAnalysisMessage.barcodeValue());
            slideAnalysisReportService.processAnalysisRequest(slideAnalysisMessage).subscribe();
        } catch (JsonProcessingException e) {
            log.error("Failed to parse SlideAnalysisMessage JSON: {}", message, e);
        } catch (Exception e) {
            log.error("Failed to parse message from topic '{}': {}", consumerRecord.topic(), message, e);
        }
    }

}
