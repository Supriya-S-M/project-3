package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.config.ConfigStore;
import com.eh.digiatalpathalogy.admin.exception.HttpRequestException;
import com.eh.digiatalpathalogy.admin.exception.ResourceNotFoundException;
import com.eh.digiatalpathalogy.admin.model.QaSlide;
import com.eh.digiatalpathalogy.admin.model.QaSlideDetails;
import com.eh.digiatalpathalogy.admin.repository.MongoOperations;
import com.eh.digiatalpathalogy.admin.util.RedisEntityStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static com.eh.digiatalpathalogy.admin.constant.ConfigKeys.DEFAULT_APPLICATION;
import static com.eh.digiatalpathalogy.admin.constant.ConfigKeys.PATH_QA_DICOM_STORE;
import static com.eh.digiatalpathalogy.admin.constant.DbCollections.QA_SLIDE;
import static com.eh.digiatalpathalogy.admin.constant.RedisCacheKey.SLIDE_BARCODE_PREFIX;

@Service
public class QaSlideService {

    private static final Logger log = LoggerFactory.getLogger(QaSlideService.class);

    private static final String ERROR_MSG = "Slide not found with barcode: ";
    private final MongoOperations mongoOperations;
    private final RedisEntityStore redisStore;
    private final ConfigStore configStore;

    public QaSlideService(RedisEntityStore redisStore, MongoOperations mongoOperations, ConfigStore configStore) {
        this.redisStore = redisStore;
        this.mongoOperations = mongoOperations;
        this.configStore = configStore;
    }

    public Flux<QaSlide> listAll() {

        return redisStore.findByPatternWithFallback(SLIDE_BARCODE_PREFIX, qaSlide -> true,
                        () -> mongoOperations.find(new Query(), QaSlide.class, QA_SLIDE),
                        QaSlide::barcode, QaSlide.class)
                .flatMapMany(Flux::fromIterable)
                .doOnSubscribe(sub -> log.debug("Initiating listAll operation"))
                .doOnComplete(() -> log.debug("Completed listAll operation"));
    }

    public Mono<QaSlide> create(QaSlide slide) {
        QaSlide qaSlide = new QaSlide(null, slide.barcode(), slide.activationCode());
        return mongoOperations.save(qaSlide, QA_SLIDE)
                .flatMap(saved -> redisStore.deleteKeysByPattern(SLIDE_BARCODE_PREFIX + "*")
                        .thenReturn(saved))
                .doOnSuccess(saved ->
                        log.info("Slide created successfully with barcode: {}", saved.barcode()))
                .onErrorMap(DuplicateKeyException.class, ex -> {
                    log.warn("Duplicate barcode detected: {}", slide.barcode(), ex);
                    return new HttpRequestException(
                            HttpStatus.CONFLICT,
                            "Slide with barcode '" + slide.barcode() + "' already exists.");
                })
                .doOnError(e ->
                        log.error("Failed to create slide with barcode {}: {}", slide.barcode(), e.getMessage(), e));
    }

    public Mono<QaSlide> updateByBarcode(String barcode, QaSlide slide) {

        Update update = new Update()
                .set("activationCode", slide.activationCode());
        return mongoOperations.findAndModify(buildBarcodeQuery(barcode), update, QaSlide.class, QA_SLIDE)
                .switchIfEmpty(Mono.error(new ResourceNotFoundException(ERROR_MSG + barcode)))
                .flatMap(updated -> {
                    String key = SLIDE_BARCODE_PREFIX + updated.barcode();
                    return redisStore.deleteByKey(key).thenReturn(updated);
                })
                .doOnSuccess(updated -> log.info("Slide updated successfully for barcode: {}", updated.barcode()))
                .doOnError(e -> log.error("Failed to update slide with barcode {}: {}", barcode, e.getMessage(), e));
    }

    public Mono<Boolean> deleteByBarcode(String barcode) {
        String key = SLIDE_BARCODE_PREFIX + barcode;
        return mongoOperations.delete(buildBarcodeQuery(barcode), QaSlide.class, QA_SLIDE)
                .flatMap(result -> {
                    if (Boolean.TRUE.equals(result)) {
                        return redisStore.deleteByKey(key).thenReturn(true);
                    } else {
                        return Mono.error(new ResourceNotFoundException(ERROR_MSG + barcode));
                    }
                })
                .doOnSuccess(v -> log.info("Slide deleted successfully with barcode: {}", barcode))
                .doOnError(e -> log.error("Failed to delete slide with barcode {}: {}", barcode, e.getMessage(), e));
    }

    public Mono<QaSlide> getByBarcode(String barcode) {

        String barcodeKey = SLIDE_BARCODE_PREFIX + barcode;
        return redisStore.findByKeyWithFallback(
                        barcodeKey,
                        () -> findByBarcode(barcode)
                                .switchIfEmpty(Mono.error(new ResourceNotFoundException(ERROR_MSG + barcode))), QaSlide.class)
                .doOnSuccess(slide -> log.info("Slide retrieved successfully for barcode: {}", barcode))
                .doOnError(e -> log.error("Failed to retrieve slide with barcode {}: {}", barcode, e.getMessage(), e));
    }

    private Mono<QaSlide> findByBarcode(String barcode) {
        return mongoOperations.findOne(buildBarcodeQuery(barcode), QaSlide.class, QA_SLIDE);
    }

    private Query buildBarcodeQuery(String barcode) {
        return Query.query(Criteria.where("barcode").is(barcode));
    }

    public Mono<String> getPathQaDicomStoreUrl() {
        return configStore.get(PATH_QA_DICOM_STORE, DEFAULT_APPLICATION);
    }

    public Mono<QaSlideDetails> qaSlideDetails() {
        log.info("Fetching QA Slide Details..");
        return getPathQaDicomStoreUrl()
                .switchIfEmpty(Mono.error(new Exception("Dicom Web Url not found.")))
                .zipWith(listAll().collectList())
                .map(tuple -> new QaSlideDetails(tuple.getT1(), tuple.getT2()))
                .doOnError(error -> log.error("Failed to build QADetails", error));
    }

}
