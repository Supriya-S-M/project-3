package com.eh.digiatalpathalogy.admin.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import org.springframework.data.annotation.Id;

@JsonIgnoreProperties(ignoreUnknown = true)
public record QaSlide(@Id String id, String barcode, @NotBlank String activationCode) {
}
