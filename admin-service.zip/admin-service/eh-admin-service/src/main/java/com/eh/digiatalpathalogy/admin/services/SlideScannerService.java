package com.eh.digiatalpathalogy.admin.services;

import com.eh.digiatalpathalogy.admin.exception.HttpRequestException;
import com.eh.digiatalpathalogy.admin.exception.ResourceNotFoundException;
import com.eh.digiatalpathalogy.admin.model.SlideScanner;
import com.eh.digiatalpathalogy.admin.repository.MongoOperations;
import com.eh.digiatalpathalogy.admin.util.RedisEntityStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;

import static com.eh.digiatalpathalogy.admin.constant.DbCollections.SLIDE_SCANNER;
import static com.eh.digiatalpathalogy.admin.constant.RedisCacheKey.SCANNER_DEVICE_PREFIX;

@Service
public class SlideScannerService {

    private static final Logger log = LoggerFactory.getLogger(SlideScannerService.class);
    private static final String ERROR_MSG = "Slide Scanner not found with Device :serial Number ";

    private final RedisEntityStore redisStore;
    private final DicomStoreService dicomStoreService;
    private final MongoOperations mongoOperations;

    public SlideScannerService(MongoOperations mongoOperations,
                               RedisEntityStore redisStore, DicomStoreService dicomStoreService) {
        this.mongoOperations = mongoOperations;
        this.redisStore = redisStore;
        this.dicomStoreService = dicomStoreService;
    }

    public Flux<SlideScanner> list() {
        return redisStore.findByPatternWithFallback(SCANNER_DEVICE_PREFIX, slideScanner -> true,
                        () -> mongoOperations.find(new Query(), SlideScanner.class, SLIDE_SCANNER),
                        SlideScanner::deviceSerialNumber, SlideScanner.class)
                .flatMapMany(Flux::fromIterable)
                .doOnSubscribe(sub -> log.debug("Starting retrieval of all slide scanners"))
                .doOnComplete(() -> log.debug("Completed retrieval of all slide scanners"));
    }

    public Mono<SlideScanner> getByDeviceSerialNumber(String deviceSerialNumber) {
        String deviceKey = SCANNER_DEVICE_PREFIX + deviceSerialNumber;
        return redisStore.findByKeyWithFallback(deviceKey, () ->
                        findByDeviceSerialNumber(deviceSerialNumber)
                                .switchIfEmpty(Mono.error(new ResourceNotFoundException("Slide scanner not found with DeviceSerialNumber ID: " + deviceSerialNumber))), SlideScanner.class)
                .doOnSuccess(scanner -> log.info("Slide scanner retrieved successfully: DeviceSerialNumber={}", deviceSerialNumber))
                .doOnError(error -> log.error("Failed to retrieve slide scanner with DeviceSerialNumber={}: {}", deviceSerialNumber, error.getMessage(), error));
    }

    public Mono<SlideScanner> create(SlideScanner slideScanner) {
        SlideScanner scanner = copyScanner(slideScanner);
        return mongoOperations.save(scanner, SLIDE_SCANNER)
                .flatMap(saved -> redisStore.deleteKeysByPattern(SCANNER_DEVICE_PREFIX + "*")
                        .thenReturn(saved))
                .doOnSuccess(saved ->
                        log.info("Slide scanner created: DeviceSerialNumber={}", saved.deviceSerialNumber()))
                .onErrorMap(DuplicateKeyException.class, ex -> {
                    log.warn("Duplicate entry: DeviceSerialNumber={}", slideScanner.deviceSerialNumber(), ex);
                    return new HttpRequestException(
                            HttpStatus.CONFLICT,
                            "Slide scanner with the same Device SerialNumber or ID already exists.");
                })
                .doOnError(error ->
                        log.error("Slide scanner creation failed: {}", error.getMessage(), error));
    }

    private SlideScanner copyScanner(SlideScanner slideScanner) {
        return new SlideScanner(null, slideScanner.deviceId(), slideScanner.deviceSerialNumber(),
                slideScanner.name(), slideScanner.model(), slideScanner.location(), slideScanner.department(),
                slideScanner.dicomStore(), slideScanner.aeTitle(), slideScanner.port(),
                slideScanner.hospitalName(), slideScanner.ipAddress(), slideScanner.vendor());
    }


    public Mono<SlideScanner> updateByDeviceSerialNumber(String deviceSerialNumber, SlideScanner slideScanner) {

        Query query = Query.query(Criteria.where("deviceSerialNumber").is(deviceSerialNumber));
        Update update = buildSlideScannerUpdate(slideScanner);
        return mongoOperations.findAndModify(query, update, SlideScanner.class, SLIDE_SCANNER)
                .switchIfEmpty(Mono.error(new ResourceNotFoundException("Slide scanner not found with DeviceID: " + deviceSerialNumber)))
                .flatMap(updated -> {
                    String key = SCANNER_DEVICE_PREFIX + updated.deviceSerialNumber();
                    return redisStore.deleteByKey(key).thenReturn(updated);
                })
                .doOnSuccess(updated -> log.info("Slide scanner updated successfully: DeviceSerialNumber={}", updated.deviceSerialNumber()))
                .doOnError(error -> log.error("Failed to update slide scanner with DeviceSerialNumber={}: {}", deviceSerialNumber, error.getMessage(), error));
    }

    private Mono<SlideScanner> findByDeviceSerialNumber(String deviceSerialNumber) {
        return mongoOperations.findOne(buildDeviceSerialNumberQuery(deviceSerialNumber), SlideScanner.class, SLIDE_SCANNER);
    }

    public Mono<Map<String, List<String>>> fetchDatasetsWithDicomStores() {
        log.info("Fetching datasets with DICOM stores");
        return Mono.just(dicomStoreService.getAllDatasetsWithDicomStores())
                .doOnError(error -> log.error("Error fetching datasets with DICOM stores: {}", error.getMessage(), error));
    }

    private Update buildSlideScannerUpdate(SlideScanner slideScanner) {
        return new Update()
                .set("name", slideScanner.name())
                .set("model", slideScanner.model())
                .set("location", slideScanner.location())
                .set("department", slideScanner.department())
                .set("dicomStore", slideScanner.dicomStore())
                .set("aeTitle", slideScanner.aeTitle())
                .set("hospitalName", slideScanner.hospitalName())
                .set("ipAddress", slideScanner.ipAddress())
                .set("port", slideScanner.port())
                .set("vendor", slideScanner.vendor());
    }

    public Mono<Void> clearCache() {
        return redisStore.deleteKeysByPattern(SCANNER_DEVICE_PREFIX + "*")
                .then(redisStore.deleteKeysByPattern("slide::barcode::*"))
                .then(redisStore.deleteKeysByPattern("report::analysisId::*"))
                .then(redisStore.deleteKeysByPattern("config::*"))
                .then();
    }

    public Mono<Boolean> deleteByDeviceSerialNumber(String deviceSerialNumber) {
        String key = SCANNER_DEVICE_PREFIX + deviceSerialNumber;
        return mongoOperations.delete(buildDeviceSerialNumberQuery(deviceSerialNumber), SlideScanner.class, SLIDE_SCANNER)
                .flatMap(result -> {
                    if (Boolean.TRUE.equals(result)) {
                        return redisStore.deleteByKey(key).thenReturn(true);
                    } else {
                        return Mono.error(new ResourceNotFoundException(ERROR_MSG + deviceSerialNumber));
                    }
                })
                .doOnSuccess(v -> log.info("Slide Scanner deleted successfully with deviceSerialNumber: {}", deviceSerialNumber))
                .doOnError(e -> log.error("Failed to delete slide scanner with deviceSerialNumber {}: {}", deviceSerialNumber, e.getMessage(), e));
    }

    private Query buildDeviceSerialNumberQuery(String deviceSerialNumber) {
        return Query.query(Criteria.where("deviceSerialNumber").is(deviceSerialNumber));
    }

}


