package com.eh.digiatalpathalogy.admin.config;

import com.eh.digiatalpathalogy.admin.client.ConfigurationClient;
import com.eh.digiatalpathalogy.admin.exception.InternalServerException;
import com.eh.digiatalpathalogy.admin.exception.ResourceNotFoundException;
import com.eh.digiatalpathalogy.admin.model.AppConfiguration;
import com.eh.digiatalpathalogy.admin.model.ConfigPropertySource;
import com.eh.digiatalpathalogy.admin.util.RedisEntityStore;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static com.eh.digiatalpathalogy.admin.constant.ConfigKeys.*;
import static com.eh.digiatalpathalogy.admin.constant.EnrichmentToolConstant.ARRAY_FIELDS;

/**
 * ConfigStore is responsible for managing configuration values.
 * It fetches configuration from a remote ConfigurationClient, caches it in Redis,
 * and provides reactive access to configuration values.
 * It supports automatic refresh on startup and lazy refresh when a key is missing.
 */
@RefreshScope
@Component
public class ConfigStore {

    private static final Logger log = LoggerFactory.getLogger(ConfigStore.class);

    private final ConfigurationClient configurationClient;
    private final RedisEntityStore redisStore;
    private final ObjectMapper objectMapper;
    private final EnrichmentToolConfig toolConfig;

    /**
     * Tracks in-flight refresh operations to avoid duplicate config loads
     * for the same application-profile combination.
     */
    private final Map<String, Mono<Map<String, Object>>> inFlightRefresh = new ConcurrentHashMap<>();

    public ConfigStore(ConfigurationClient configurationClient, RedisEntityStore redisStore,
                       ObjectMapper objectMapper, EnrichmentToolConfig toolConfig) {
        this.configurationClient = configurationClient;
        this.redisStore = redisStore;
        this.objectMapper = objectMapper;
        this.toolConfig = toolConfig;
    }

    /**
     * Retrieves a configuration value from Redis or refreshes all configs if not found.
     */
    private <T> Mono<T> getInternal(String redisKey, Class<T> type, String application, String profile) {
        String path = configByApplication(application).get(redisKey);
        if (path == null) {
            return Mono.error(new IllegalArgumentException(
                    "Unknown redisKey '" + redisKey + "'. Register it in ConfigKeys.REDIS_TO_CONFIG_KEYS"));
        }

        return redisStore.findByKey(redisKey, type)
                .switchIfEmpty(
                        refreshAllInternal(application, profile)
                                .flatMap(all -> toTyped(all.get(redisKey), type)
                                        .switchIfEmpty(Mono.error(new NoSuchElementException(
                                                "Key '" + redisKey + "' (path '" + path + "') not found after refresh for app="
                                                        + application + ", profile=" + profile)))))
                .doOnSuccess(v -> log.debug("Resolved '{}' => {}", redisKey, v))
                .doOnError(e -> log.error("Failed to resolve key '{}' (app={}, profile={})",
                        redisKey, application, profile, e));
    }

    /**
     * Refreshes all configuration values for a given application and profile.
     * Ensures only one refresh is in-flight per app-profile combination.
     */
    private Mono<Map<String, Object>> refreshAllInternal(String application, String profile) {
        String inFlightKey = application + "|" + profile;
        Mono<Map<String, Object>> existing = inFlightRefresh.get(inFlightKey);
        if (existing != null) return existing;

        Mono<Map<String, Object>> loader = configurationClient.loadConfiguration(application, profile)
                .flatMap(cn -> extractAllMappedValues(application, cn))
                .flatMap(values -> writeAllToRedis(values).thenReturn(values))
                .doOnSubscribe(s -> log.info("Refreshing ALL config for (app={}, profile={})", application, profile))
                .doFinally(sig -> inFlightRefresh.remove(inFlightKey))
                .cache();

        inFlightRefresh.put(inFlightKey, loader);
        return loader;
    }

    /**
     * Extracts mapped config values from the loaded configuration.
     */
    @SuppressWarnings("unchecked")
    private Mono<Map<String, Object>> extractAllMappedValues(String application, Map<String, Object> config) {
        List<Map<String, Object>> propertySources =
                (List<Map<String, Object>>) config.get("propertySources");

        if (propertySources == null || propertySources.isEmpty()) {
            log.warn("No propertySources found in configuration.");
            return Mono.just(Collections.emptyMap());
        }

        Map<String, String> applicationConfig = configByApplication(application);

        Map<String, Object> pathToValue = new HashMap<>();
        for (Map<String, Object> entry : propertySources) {
            Map<String, Object> source = (Map<String, Object>) entry.get("source");
            if (source == null) continue;
            for (String path : applicationConfig.values()) {
                if (source.containsKey(path) && !pathToValue.containsKey(path)) {
                    pathToValue.put(path, source.get(path));
                }
            }
        }

        Map<String, Object> redisKeyToValue = applicationConfig.entrySet().stream()
                .filter(e -> pathToValue.containsKey(e.getValue()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> pathToValue.get(e.getValue())
                ));

        log.debug("Extracted {} mapped values from config.", redisKeyToValue.size());
        return Mono.just(redisKeyToValue);
    }

    /**
     * Writes all config values to Redis.
     */
    private Mono<Void> writeAllToRedis(Map<String, Object> redisKeyToValue) {
        if (redisKeyToValue.isEmpty()) return Mono.empty();

        return Flux.fromIterable(redisKeyToValue.entrySet())
                .filter(e -> e.getValue() != null)
                .flatMap(e -> redisStore.save(e.getKey(), e.getValue()))
                .then()
                .doOnSuccess(v -> log.info("Wrote {} entries to Redis.", redisKeyToValue.size()))
                .doOnError(e -> log.error("Failed writing entries to Redis.", e));
    }

    /**
     * Converts a raw object to the specified type using ObjectMapper.
     */
    private <T> Mono<T> toTyped(Object raw, Class<T> type) {
        if (raw == null) return Mono.empty();
        if (type.isInstance(raw)) return Mono.just(type.cast(raw));
        try {
            return Mono.just(objectMapper.convertValue(raw, type));
        } catch (IllegalArgumentException ex) {
            log.error("Type conversion failed for value '{}' to {}", raw, type.getSimpleName(), ex);
            return Mono.error(ex);
        }
    }

    /**
     * Deletes all configuration keys from Redis matching the pattern "config::*".
     */
    public Mono<Void> deleteAllConfigKeys() {
        return redisStore.deleteKeysByPattern("config::*")
                .doOnSuccess(v -> log.info("Deleted all keys with pattern config::*"))
                .doOnError(e -> log.error("Failed to delete config::* keys", e)).then();
    }

    /**
     * Refreshes all configuration values and initializes enrichment config.
     * Called on startup or bus-refresh.
     */
    public void refreshAll() {
        deleteAllConfigKeys().then(refreshAllInternal(DEFAULT_APPLICATION, DEFAULT_PROFILE))
                .then(refreshEnrichmentConfig())
                .subscribe(
                        v -> log.info("ConfigValues initialized with fresh config for all applications."),
                        e -> log.error("Failed to initialize ConfigValues on startup", e)
                );
    }

    /**
     * Retrieves all enrichment properties for a given application.
     * If no mapping is found, returns an error.
     */
    public Mono<Map<String, Object>> getAllPropertiesForApplication(String application) throws InternalServerException {

        Map<String, EnrichmentToolConfig.AppMapping> appMappings = toolConfig.getApplications();
        EnrichmentToolConfig.AppMapping mapping = appMappings.get(application);

        if (mapping == null || mapping.getMappings() == null || mapping.getMappings().isEmpty()) {
            String errorMsg = String.format("No enrichment mappings found for application %s", application);
            log.error(errorMsg);
            return Mono.error(new ResourceNotFoundException(errorMsg));
        }

        return getPropertiesForApplication(application, mapping);
    }

    /**
     * Fetches configuration from the config service and resolves mapped values.
     * Also saves the resolved values to Redis.
     */
    private Mono<Map<String, Object>> fetchFromConfigService(String application, EnrichmentToolConfig.AppMapping mapping) {
        return configurationClient.loadConfig(application, DEFAULT_PROFILE)
                .map(config -> {
                    List<ConfigPropertySource> propertySources = config.getPropertySources();
                    if (propertySources == null || propertySources.isEmpty()) {
                        log.warn("No propertySources found for application '{}'", application);
                        return Collections.emptyMap();
                    }
                    Map<String, String> propMap = flatMapAppMapping(mapping);
                    Map<String, Object> resolvedValues = resolveConfigValues(config, propMap);
                    redisStore.save(String.format("config::%s", application), resolveConfigValues(config, propMap)).subscribe();
                    return resolvedValues;
                });
    }

    /**
     * Resolves config values from property sources based on provided mappings.
     */
    private Map<String, Object> resolveConfigValues(AppConfiguration config, Map<String, String> propMap) {

        Map<String, Object> resolvedValues = new HashMap<>();
        List<ConfigPropertySource> propertySources = config.getPropertySources();
        if (propMap.containsValue("name")) {
            resolvedValues.put("name", config.getName());
        }

        for (Map.Entry<String, String> mapEntry : propMap.entrySet()) {
            String property = mapEntry.getKey();
            String configPath = mapEntry.getValue();
            for (ConfigPropertySource source : propertySources) {
                Map<String, Object> sourceMap = source.getSource();
                if (sourceMap != null && sourceMap.containsKey(configPath)) {
                    Object value = sourceMap.get(configPath);
                    value = handleArrayValue(property, value);
                    resolvedValues.put(property, value);
                    break;
                }
            }
            if (!resolvedValues.containsKey(property)) {
                log.info("Property Value is not available : {}", configPath);
                resolvedValues.put(property, "test");
            }
        }
        return resolvedValues;
    }

    private Object handleArrayValue(String property, Object value) {
        if (!ARRAY_FIELDS.contains(property)) return value;
        return Objects.nonNull(value) ? value.toString().split(",") : null;
    }

    /**
     * Refreshes enrichment configuration for all mapped applications.
     * Loads from Redis if available, otherwise fetches from config service.
     */
    public Mono<Map<String, Map<String, Object>>> refreshEnrichmentConfig() throws InternalServerException {

        Map<String, EnrichmentToolConfig.AppMapping> appMappings = toolConfig.getApplications();
        if (appMappings == null || appMappings.isEmpty()) {
            log.warn("No enrichment mappings found.");
            return Mono.just(Collections.emptyMap());
        }

        return Flux.fromIterable(appMappings.entrySet())
                .flatMap(entry -> {
                    String application = entry.getKey();
                    EnrichmentToolConfig.AppMapping mapping = entry.getValue();
                    return getPropertiesForApplication(application, mapping)
                            .map(props -> Map.entry(application, props));
                })
                .collectMap(Map.Entry::getKey, Map.Entry::getValue);
    }

    /**
     * Gets enrichment properties for a specific application.
     * Tries Redis first, falls back to config service if not found.
     */
    private Mono<Map<String, Object>> getPropertiesForApplication(String application, EnrichmentToolConfig.AppMapping mapping) {
        return redisStore.fetchApplicationConfig(application)
                .flatMap(cachedValues -> {
                    if (!cachedValues.isEmpty()) {
                        return Mono.just(cachedValues);
                    }
                    return fetchFromConfigService(application, mapping);
                });
    }

    /**
     * Flattens nested enrichment mappings into a single map of property name to config path.
     */
    public static Map<String, String> flatMapAppMapping(EnrichmentToolConfig.AppMapping appMapping) {
        return appMapping.getMappings().values().stream()
                .filter(Objects::nonNull)
                .flatMap(categoryMap -> categoryMap.entrySet().stream())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (existing, replacement) -> replacement,
                        LinkedHashMap::new
                ));
    }

    public Mono<String> get(String redisKey) {
        return get(redisKey, String.class, DEFAULT_APPLICATION, DEFAULT_PROFILE);
    }

    public <T> Mono<T> get(String redisKey, Class<T> type) {
        return get(redisKey, type, DEFAULT_APPLICATION, DEFAULT_PROFILE);
    }

    public Mono<String> get(String redisKey, String application, String profile) {
        return get(redisKey, String.class, application, profile);
    }

    public Mono<String> get(String redisKey, String application) {
        return get(redisKey, String.class, application, DEFAULT_PROFILE);
    }

    public <T> Mono<T> get(String redisKey, Class<T> type, String application, String profile) {
        return getInternal(redisKey, type, application, profile);
    }

    /**
     * Initializes configuration on application startup or bus-refresh.
     */
    @PostConstruct
    public void initOnStartup() {
        refreshAll();
    }

}
