package com.eh.digiatalpathalogy.admin.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception ex) {
        log.error("Unhandled exception: {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), "An unexpected error occurred."));
    }

    @ExceptionHandler(RemoteServiceException.class)
    public ResponseEntity<Map<String, Object>> handleRemoteServiceException(RemoteServiceException ex) {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(buildErrorResponse(ex.getErrorCode(), ex.getMessage()));
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleResourceNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(buildErrorResponse(ex.getErrorCode(), ex.getMessage()));
    }

    @ExceptionHandler(InternalServerException.class)
    public ResponseEntity<Map<String, Object>> handleInternalServerException(InternalServerException ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildErrorResponse(ex.getErrorCode(), ex.getMessage()));
    }

    @ExceptionHandler(HttpRequestException.class)
    public ResponseEntity<Map<String, Object>> handleHttpRequestException(HttpRequestException ex) {
        HttpStatus status = HttpStatus.resolve(ex.getStatus().value());
        if (status == null) {
            status = HttpStatus.INTERNAL_SERVER_ERROR;
        }
        return ResponseEntity.status(status)
                .body(buildErrorResponse(status.getReasonPhrase(), ex.getResponseBody()));
    }


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationExceptions(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                fieldErrors.put(error.getField(), error.getDefaultMessage())
        );

        String errorMessage = "Validation failed for one or more fields.";

        Map<String, Object> errorBody = buildErrorResponse("Validation Error", errorMessage);
        errorBody.put("details", fieldErrors);

        return ResponseEntity.badRequest().body(errorBody);
    }


    private Map<String, Object> buildErrorResponse(String errorCode, String errorMessage) {
        Map<String, Object> errorBody = new LinkedHashMap<>();
        errorBody.put("errorCode", errorCode != null ? errorCode : "Unknown Error");
        errorBody.put("errorDescription", errorMessage != null ? errorMessage : "An unexpected error occurred.");
        return errorBody;
    }

}
