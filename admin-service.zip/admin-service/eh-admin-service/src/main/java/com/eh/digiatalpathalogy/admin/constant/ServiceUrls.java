package com.eh.digiatalpathalogy.admin.constant;

public class ServiceUrls {
    private ServiceUrls(){}

    public static final String PATH_QA_ANALYSIS = "/api/slide";


}
