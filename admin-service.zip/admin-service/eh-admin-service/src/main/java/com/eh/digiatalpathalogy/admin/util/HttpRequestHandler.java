package com.eh.digiatalpathalogy.admin.util;

import com.eh.digiatalpathalogy.admin.exception.HttpRequestException;
import io.netty.handler.timeout.TimeoutException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.net.SocketTimeoutException;
import java.net.URI;
import java.time.Duration;
import java.util.Map;

@Component
public class HttpRequestHandler {

    private static final Logger log = LoggerFactory.getLogger(HttpRequestHandler.class);
    private final WebClient webClient;

    private static final int MAX_RETRIES = 3;
    private static final Duration INITIAL_BACKOFF = Duration.ofSeconds(1);
    private static final Duration MAX_BACKOFF = Duration.ofSeconds(5);

    public HttpRequestHandler(WebClient webClient) {
        this.webClient = webClient;
    }

    public <T> Mono<T> request(String url, HttpMethod method,
                               Map<String, String> queryParams,
                               Object requestBody,
                               Map<String, String> httpHeaders,
                               ParameterizedTypeReference<T> responseType) {


        URI finalUri = buildUri(url, queryParams);
        log.info("Initiating HTTP {} request to URL: {}", method, finalUri);

        return webClient.method(method)
                .uri(finalUri)
                .headers(headers -> applyHeaders(headers, httpHeaders))
                .body(isBodyAllowed(method) && requestBody != null
                        ? BodyInserters.fromValue(requestBody)
                        : BodyInserters.empty())
                .retrieve()
                .onStatus(this::isErrorStatus, this::handleError)
                .bodyToMono(responseType)
                .doOnSuccess(response -> log.info("Successful response from {}", url))
                .doOnError(error -> log.error("Error during HTTP request to {}: {}", url, error.getMessage()))
                .retryWhen(Retry.backoff(MAX_RETRIES, INITIAL_BACKOFF)
                        .maxBackoff(MAX_BACKOFF)
                        .filter(this::isRetryableException)
                        .onRetryExhaustedThrow((spec, signal) -> signal.failure()))
                .onErrorResume(this::handleClientException);
    }

    private URI buildUri(String baseUrl, Map<String, String> queryParams) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(baseUrl);
        if (queryParams != null) {
            queryParams.forEach(builder::queryParam);
        }
        return builder.build().toUri();
    }

    private boolean isErrorStatus(HttpStatusCode httpStatusCode) {
        return httpStatusCode.is4xxClientError() || httpStatusCode.is5xxServerError();
    }

    private void applyHeaders(HttpHeaders headers, Map<String, String> customHeaders) {
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (customHeaders != null) {
            customHeaders.forEach(headers::add);
        }
    }

    private boolean isBodyAllowed(HttpMethod method) {
        return method == HttpMethod.POST || method == HttpMethod.PUT || method == HttpMethod.PATCH;
    }

    private Mono<? extends Throwable> handleError(ClientResponse response) {
        return response.bodyToMono(String.class).flatMap(errorBody -> {
            HttpStatusCode statusCode = response.statusCode();
            log.error("Downstream service error: {} - {}", statusCode, errorBody);
            return Mono.error(new HttpRequestException(HttpStatus.BAD_GATEWAY, "Downstream service error: " + errorBody));
        });
    }

    private <T> Mono<T> handleClientException(Throwable throwable) {
        if (throwable instanceof HttpRequestException httpEx) {
            return Mono.error(httpEx); // Already wrapped
        } else if (throwable instanceof WebClientRequestException) {
            log.error("Network error: {}", throwable.getMessage());
            return Mono.error(new HttpRequestException(HttpStatus.SERVICE_UNAVAILABLE, "Network error occurred"));
        } else if (throwable instanceof WebClientResponseException responseEx) {
            log.error("Unexpected HTTP response error: {} - {}", responseEx.getStatusCode(), responseEx.getResponseBodyAsString());
            return Mono.error(new HttpRequestException(HttpStatus.BAD_GATEWAY, "Downstream service error: " + responseEx.getResponseBodyAsString()));
        } else if (throwable instanceof TimeoutException || throwable instanceof SocketTimeoutException) {
            log.error("Request timed out: {}", throwable.getMessage());
            return Mono.error(new HttpRequestException(HttpStatus.GATEWAY_TIMEOUT, "Request timed out"));
        } else if (throwable instanceof IllegalArgumentException || throwable instanceof NullPointerException) {
            log.error("Invalid request parameters: {}", throwable.getMessage());
            return Mono.error(new HttpRequestException(HttpStatus.BAD_REQUEST, "Invalid request parameters"));
        } else {
            log.error("Unexpected error: {}", throwable.getMessage(), throwable);
            return Mono.error(new HttpRequestException(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error occurred"));
        }
    }

    private boolean isRetryableException(Throwable throwable) {
        return throwable instanceof WebClientRequestException ||
                throwable instanceof TimeoutException ||
                throwable instanceof SocketTimeoutException;
    }
}

