package com.eh.digiatalpathalogy.admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class AdminConsoleApplicationTests {

	@Test
	void contextLoads() {
	}

}
