package com.eh.digitalpathology.ibex.service;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class BarcodeStudyInfo {

    private final Map<String, String> barcodeToStudyMap = new ConcurrentHashMap<>();

    public void put(String barcode, String studyUid) {
        barcodeToStudyMap.put(barcode, studyUid);
    }

    public String get(String barcode) {
        return barcodeToStudyMap.get(barcode);
    }

    public String remove(String barcode) {
        return barcodeToStudyMap.remove(barcode);
    }

}

