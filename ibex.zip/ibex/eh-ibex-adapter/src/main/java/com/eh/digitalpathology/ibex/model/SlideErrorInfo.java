package com.eh.digitalpathology.ibex.model;

public record SlideErrorInfo(String barcode, int errorCode, String errorMsg ) {
}
