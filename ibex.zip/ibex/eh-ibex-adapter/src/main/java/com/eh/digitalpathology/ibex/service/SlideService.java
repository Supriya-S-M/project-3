/**
 * SlideService is used to fetch all the required data for slide creation and create the slide.
 * Author: Preeti Ankam
 * Date: October 30, 2024
 */

package com.eh.digitalpathology.ibex.service;

import com.eh.digitalpathology.ibex.client.IbexApiClient;
import com.eh.digitalpathology.ibex.config.OrganMappingConfig;
import com.eh.digitalpathology.ibex.constants.AppConstants;
import com.eh.digitalpathology.ibex.enums.StainNames;
import com.eh.digitalpathology.ibex.exceptions.IbexApiException;
import com.eh.digitalpathology.ibex.exceptions.SignedUrlGenerationException;
import com.eh.digitalpathology.ibex.model.Slide;
import com.eh.digitalpathology.ibex.util.AppUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

@Service
public class SlideService {
    private static final Logger logger = LoggerFactory.getLogger(SlideService.class);
    private final SignedUrlCreationService signedUrlCreationService;
    private final IbexApiClient ibexApiClient;
    private final OrganMappingConfig organMappingConfig;

    public SlideService(SignedUrlCreationService signedUrlCreationService, IbexApiClient ibexApiClient, OrganMappingConfig organMappingConfig) {
        this.signedUrlCreationService = signedUrlCreationService;
        this.ibexApiClient = ibexApiClient;
        this.organMappingConfig = organMappingConfig;
    }

    public void createSlide(Map<String, Object> metadataMap, String studyUid, String seriesUid, String sourceUrl, String barcode) throws IbexApiException {
        String caseId = AppUtil.getTagValue(metadataMap, AppConstants.ACCESSION_NO_TAG_KEY);
        Map<String, String> organCodeMap = AppUtil.extractOrganType(metadataMap, AppConstants.SPECIMEN_DESCRIPTION_SEQUENCE, AppConstants.PRIMARY_ANATOMIC_STRUCTURE_SEQ, AppConstants.CODE_VALUE, AppConstants.CODE_MEANING);

        if (organCodeMap.isEmpty()) {
            logger.warn("createSlide :: No organ code found in metadata. Skipping case and slide creation.");
            return;
        }
        organCodeMap.forEach((key, value) -> logger.info("buildSlide :: Code key : {} Code value: {}", key, value));

        String organCode = organCodeMap.values().iterator().next().toLowerCase();
        String organ = resolveOrgan(organCode);

        if (isAllowedOrgan(organ)) {
            logger.info("createSlide :: Proceeding with organ: {}", organ);
        } else {
            logger.info("createSlide :: Unsupported organ detected: '{}'. Skipping case and slide creation.",
                    organ);
            return;
        }

        if (AppUtil.validate(barcode) && AppUtil.validate(caseId)) {
            Slide newSlide = buildSlide(metadataMap, sourceUrl, caseId, barcode, organ);
            String jsonRequestBody = AppUtil.convertObjectToString(newSlide);
            if (jsonRequestBody != null) {
                try {
                    ibexApiClient.createSlide(jsonRequestBody, barcode);
                    logger.info("createSlide :: Case and slide creation completed for study uid: {} , series uid:{}.", studyUid, seriesUid);
                } catch (IbexApiException ex) {
                    throw new IbexApiException(ex);
                }
            }
        } else {
            String errorMessage = String.format("400 BAD REQUEST: CHECK REQUEST DATA: Invalid Barcode value: %s or Invalid Case Id: %s for study uid: %s , series uid:%s", barcode, caseId, studyUid, seriesUid);
            throw new IbexApiException(errorMessage);
        }
    }

    private boolean isAllowedOrgan(String organ) {
        logger.info("Allowed organs from config: {}", organMappingConfig.getAllowed());
        return organMappingConfig.getAllowed().contains(organ.toLowerCase());
    }


    private Slide buildSlide(Map<String, Object> metadataMap, String sourceUrl, String caseId, String barcodeValue, String organ) {
        Optional<String> stain = AppUtil.getStainValue(metadataMap);
        Slide newSlide = new Slide();
        newSlide.setId(barcodeValue);
        newSlide.setCaseId(caseId);
        newSlide.getDetails().setOrganType(organ);

        if (stain.isPresent()) {
            logger.info("buildSlide :: Stain is present.");
            StainNames stainEnum = StainNames.fromStain(stain.get());
            newSlide.getDetails().setStain(stainEnum.getStain());

            if ("Other".equalsIgnoreCase(stainEnum.getStain())) {
                newSlide.getDetails().setStainName(stain.get());
            }
        } else {
            logger.info("buildSlide :: No stain present for case id: {} and slide id: {}", caseId, barcodeValue);
        }


        newSlide.setSource(getSignedUrl(sourceUrl));
        // Optional fields
        newSlide.setScannedDate(LocalDate.now().toString());
        newSlide.setFileExt("zip");
        return newSlide;
    }

    private String getSignedUrl(String sourceUrl) {
        try {
            return signedUrlCreationService.generateSignedUrl(sourceUrl);
        } catch (IOException ex) {
            throw new SignedUrlGenerationException("Failed to create signed URL: ", ex);
        }
    }

    public String resolveOrgan(String rawValue) {
        String valueFromYaml = organMappingConfig.getMapping().getOrDefault(rawValue.trim().toLowerCase(), rawValue);
        logger.info("resolveOrgan :: Fetched organ value from YAML is: {}", valueFromYaml);
        return valueFromYaml;
    }

}
