/**
 * SignedUrlCreationService is used to generate the signed url for downloading the study.
 * It fetches the encrypted key from runtime config and decrypt it using AES algorithm.
 * Author: Preeti Ankam
 * Date: November 15, 2024
 */

package com.eh.digitalpathology.ibex.service;

import com.eh.digitalpathology.ibex.exceptions.DecryptionException;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.resourcemanager.v3.Project;
import com.google.cloud.resourcemanager.v3.ProjectsClient;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.joda.time.Minutes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RefreshScope
@Service
public class SignedUrlCreationService {
    private static final Logger logger = LoggerFactory.getLogger( SignedUrlCreationService.class );
    private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH = 16;

    @Value( "${service.account.name}" )
    private String clientEmail;

    @Value( "${project.secret}" )
    private String secretKey;

    @Value( "${signed.url.key}" )
    private String encryptedKey;

    @Value( "${project.name}" )
    private String projectId;

    @Value("${signed.url.validity:30}")
    private long urlValidity;

    public String generateSignedUrl ( String urlString ) throws MalformedURLException {
        try {
            String secretKeyBytes = encodeSecretKey( secretKey );
            SecretKeySpec secretKeySpec = new SecretKeySpec( secretKeyBytes.getBytes( StandardCharsets.UTF_8 ), "AES" );
            String privateKeyPkcs8 = decrypt( encryptedKey, secretKeySpec );

            byte[] decodedKey = Base64.getDecoder( ).decode( privateKeyPkcs8 );
            PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec( decodedKey );
            KeyFactory keyFactory = KeyFactory.getInstance( "RSA" );
            PrivateKey privateKey = keyFactory.generatePrivate( keySpec );

            // Convert the private key to a format that ServiceAccountCredentials can use
            ServiceAccountCredentials credentials = ServiceAccountCredentials.newBuilder( ).setClientEmail( clientEmail ).setPrivateKey( privateKey ).build( );

            URI uri = new URI( urlString );
            URL url = uri.toURL( );
            Pattern urlPattern = Pattern.compile( "/b/([^/]+)/o/([^?]+)" );
            Matcher urlMatcher = urlPattern.matcher( url.getPath( ) );

            if ( urlMatcher.find( ) ) {
                String bucketName = urlMatcher.group( 1 );
                String objectName = urlMatcher.group( 2 );
                Storage storage = StorageOptions.newBuilder( ).setProjectId( projectId ).setCredentials( credentials ).build( ).getService( );
                BlobInfo blobInfo = BlobInfo.newBuilder( bucketName, objectName ).build( );
                URL signedUrl = storage.signUrl( blobInfo, urlValidity , TimeUnit.MINUTES, Storage.SignUrlOption.withV4Signature( ) );
                return signedUrl.toString( );
            }
        } catch ( IOException e ) {
            logger.error( "generateSignedUrl :: Error generating signed URL: {}", e.getMessage( ) );
        } catch ( Exception e ) {
            logger.error( "generateSignedUrl :: Unexpected error: ", e );
        }
        return urlString;
    }

    private static String decrypt ( String encryptedData, SecretKey secretKey ) throws DecryptionException {
        try {
            Cipher cipher = Cipher.getInstance( AES_GCM_NO_PADDING );
            String projectNumber = getProjectNumber( );
            String ivSpec = encodeIVSpec( projectNumber );
            byte[] iv1 = Base64.getDecoder( ).decode( ivSpec );
            GCMParameterSpec spec = new GCMParameterSpec( GCM_TAG_LENGTH * 8, iv1 );
            cipher.init( Cipher.DECRYPT_MODE, secretKey, spec );
            byte[] decryptedBytes = cipher.doFinal( Base64.getDecoder( ).decode( encryptedData ) );
            return new String( decryptedBytes );
        } catch ( Exception ex ) {
            throw new DecryptionException( "Failed to decrypt data", ex );
        }
    }


    private static String encodeIVSpec ( String projectNumber ) {
        //convert to hex
        BigInteger projectNumberInt = new BigInteger( projectNumber );
        return String.format( "%016x", projectNumberInt );
    }

    private static String getProjectNumber ( ) {
        String projectNumber = null;
        try ( ProjectsClient pc = ProjectsClient.create( ) ) {
            String projectName = "projects/prj-d-path-integration-cs1h";
            Project pr = pc.getProject( projectName );
            String[] a = pr.getName( ).split( "/" );
            projectNumber = a[ 1 ];
        } catch ( Exception e ) {
            logger.error( "getProjectNumber :: Exception while fetching project number {}", e.getMessage( ) );
        }
        return projectNumber;
    }

    private static String encodeSecretKey ( String secretKey ) throws NoSuchAlgorithmException {

        MessageDigest digest = MessageDigest.getInstance( "SHA-256" );
        byte[] encodedHash = digest.digest( secretKey.getBytes( ) );

        // Convert the hash to a hexadecimal string
        StringBuilder hexString = new StringBuilder( );
        for ( byte b : encodedHash ) {
            String hex = Integer.toHexString( 0xff & b );
            if ( hex.length( ) == 1 ) hexString.append( '0' );
            hexString.append( hex );
        }

        return hexString.substring( 0, 32 );
    }

}

