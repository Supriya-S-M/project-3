package com.eh.digitalpathology.dicompurge.service;

import com.eh.digitalpathology.dicompurge.config.RetentionConfig;
import com.mongodb.client.result.DeleteResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

@Service
public class Hl7MessageCleanupService {

    private static final Logger logger = LoggerFactory.getLogger( Hl7MessageCleanupService.class );
    private final MongoTemplate mongoTemplate;

    private final RetentionConfig cleanupConfig;

    public Hl7MessageCleanupService (MongoTemplate mongoTemplate, RetentionConfig cleanupConfig ) {
        this.mongoTemplate = mongoTemplate;
        this.cleanupConfig = cleanupConfig;
    }

    public void cleanUpHL7Collections() {
        Map<String, Duration > retentionMap = cleanupConfig.getHl7Message();
        logger.info( "cleanUpHL7Collections :: retentionDays :: {}", retentionMap );
        retentionMap.forEach((messageType, days) -> {
            String collectionName = "hl7_" + messageType.toLowerCase();
            logger.info( "cleanUpHL7Collections :: collection Name :: {}", collectionName );
            Date thresholdDate = getDateDaysAgo(days);
            logger.info( "cleanUpHL7Collections :: threshold date :: {}", thresholdDate );
            Query query = new Query();
            query.addCriteria( Criteria.where("lastModifiedTime").lt(thresholdDate));

            DeleteResult result = mongoTemplate.remove(query, collectionName);
            logger.info("cleanUpHL7Collections :: Deleted  {} documents from {}", result.getDeletedCount(), collectionName);
        });
    }

    private Date getDateDaysAgo( Duration duration) {
        Instant instant = Instant.now().minus(duration);
        return Date.from(instant);

    }
}
