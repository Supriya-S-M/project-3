package com.eh.digitalpathology.dicompurge.config;

import com.eh.digitalpathology.dicompurge.service.Hl7MessageCleanupService;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

@Configuration
public class Hl7SchedulerConfig implements SchedulingConfigurer {

    private final Hl7CronConfig cleanupCronConfig;

    private final Hl7MessageCleanupService cleanupService;

    public Hl7SchedulerConfig ( Hl7CronConfig cleanupCronConfig, Hl7MessageCleanupService cleanupService ) {
        this.cleanupCronConfig = cleanupCronConfig;
        this.cleanupService = cleanupService;
    }

    @Override
    public void configureTasks( ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.addTriggerTask(
                cleanupService::cleanUpHL7Collections,
                triggerContext -> new CronTrigger( cleanupCronConfig.getCron()).nextExecution(triggerContext)
        );
    }
}
