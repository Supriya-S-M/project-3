package com.eh.digitalpathology.dicompurge.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "dicom_instances")
public record DicomInstance(@Id String id, String sopInstanceUid, String barcode,  String intermediateStoragePath, String processingStatus, @Indexed Date dicomInstanceReceivedTimestamp) {}
