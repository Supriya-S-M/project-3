package com.eh.digitalpathology.dicompurge.service;

import com.eh.digitalpathology.dicompurge.config.GcpConfig;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;

@Service
public class GcsFileService {

    private static final Logger logger = LoggerFactory.getLogger(GcsFileService.class);
    private final GcpConfig gcpConfig;

    public GcsFileService ( GcpConfig gcpConfig ) {
        this.gcpConfig = gcpConfig;
    }

    public boolean deleteFile(String gcsUri) {
        URI uri = URI.create(gcsUri);
        String bucketName = uri.getHost(); // "your-bucket-name"
        String objectName = uri.getPath().substring(1); // "path/to/your/file.dcm"
        logger.info( "deleteFile :: bucketName:: {}", bucketName );
        logger.info( "deleteFile :: objectName:: {}", objectName );
        Storage storage;
        try {
            storage = StorageOptions.newBuilder().setCredentials( ServiceAccountCredentials.fromStream(new ByteArrayInputStream(gcpConfig.getCreds().getBytes( StandardCharsets.UTF_8 )))).build().getService();
            return storage.delete( BlobId.of( bucketName, objectName ) );
        } catch ( IOException e ) {
            logger.error( "enrichDicomInstance :: unable to get access to storage :: {}", e.getMessage() );
            return false;
        }

    }

}
