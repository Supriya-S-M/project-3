package com.eh.digitalpathology.dicompurge.config;


import com.eh.digitalpathology.dicompurge.service.DocumentCleanupService;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;

@Configuration
public class DocumentSchedulerConfig implements SchedulingConfigurer {

    private final DocumentCronConfig cleanupCronConfig;

    private final DocumentCleanupService cleanupService;

    public DocumentSchedulerConfig ( DocumentCronConfig cleanupCronConfig, DocumentCleanupService cleanupService ) {
        this.cleanupCronConfig = cleanupCronConfig;
        this.cleanupService = cleanupService;
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        taskRegistrar.addTriggerTask(
                cleanupService::cleanUpDocuments,
                triggerContext -> new CronTrigger( cleanupCronConfig.getCron()).nextExecution(triggerContext)
        );
    }
}

