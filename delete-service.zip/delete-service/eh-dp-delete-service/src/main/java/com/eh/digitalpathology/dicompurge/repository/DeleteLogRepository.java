package com.eh.digitalpathology.dicompurge.repository;

import com.eh.digitalpathology.dicompurge.entity.DeletedDocumentLog;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeleteLogRepository extends MongoRepository< DeletedDocumentLog, String> {


}