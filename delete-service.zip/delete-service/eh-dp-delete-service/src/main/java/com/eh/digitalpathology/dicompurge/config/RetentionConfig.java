package com.eh.digitalpathology.dicompurge.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "retention")
@RefreshScope
public class RetentionConfig {
    private Map<String, Duration > status;
    private Map<String, Duration> hl7Message;

    public Map<String, Duration> getHl7Message() {
        return hl7Message;
    }

    public void setHl7Message(Map<String, Duration> hl7Message) {
        this.hl7Message = hl7Message;
    }


    public Map<String, Duration> getStatus() {
        return status;
    }

    public void setStatus(Map<String, Duration> status) {
        this.status = status;
    }
}

