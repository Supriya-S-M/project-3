package com.eh.digitalpathology.dicompurge.service;


import com.eh.digitalpathology.dicompurge.config.RetentionConfig;
import com.eh.digitalpathology.dicompurge.entity.DeletedDocumentLog;
import com.eh.digitalpathology.dicompurge.entity.DicomInstance;
import com.eh.digitalpathology.dicompurge.repository.DeleteLogRepository;
import com.eh.digitalpathology.dicompurge.repository.DicomInstanceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class DocumentCleanupService {
    private static final Logger log = LoggerFactory.getLogger( DocumentCleanupService.class.getName( ) );
    private final DicomInstanceRepository repository;

    private final RetentionConfig retentionConfig;
    private final DeleteLogRepository logRepository;
    private final GcsFileService gcsFileService;
    private final KafkaNotifier kafkaNotifier;

    @Value("${kafka.topic.email}")
    private String emailSvcTopic;

    public DocumentCleanupService (DicomInstanceRepository repository, RetentionConfig retentionConfig, DeleteLogRepository logRepository, GcsFileService gcsFileService, KafkaNotifier kafkaNotifier) {
        this.repository = repository;
        this.retentionConfig = retentionConfig;
        this.logRepository = logRepository;
        this.gcsFileService = gcsFileService;
        this.kafkaNotifier = kafkaNotifier;
    }

    public void cleanUpDocuments ( ) {
        Map< String, Duration > retentionDays = retentionConfig.getStatus( );
        log.info( "cleanUpDocuments :: retentionDays :: {}", retentionDays );
        retentionDays.forEach( ( status, days ) -> {
            Date thresholdDate = getDateDaysAgo( days );
            log.info( "cleanUpDocuments :: thresholdData :: {}", thresholdDate );
            log.info( "cleanUpDocuments :: status :: {}", status );
            List< DicomInstance > oldDocs = repository.findByProcessingStatusAndDicomInstanceReceivedTimestampBefore( status, thresholdDate );
            log.info( "cleanUpDocuments :: oldDocs :: {}", oldDocs );
            for ( DicomInstance doc : oldDocs ) {
                //
                kafkaNotifier.notify(emailSvcTopic, "DELETION_FROM_INTERMEDIATE_STORAGE", doc.barcode());
                log.info( "cleanUpDocuments :: dicom instances :: {}", doc );
                boolean deleted = gcsFileService.deleteFile( doc.intermediateStoragePath( ) );
                log.info("cleanUpDocuments :: files deleted:: {}", deleted);
                DeletedDocumentLog deletedDocumentLog = new DeletedDocumentLog( null, doc.sopInstanceUid( ), "Status " + doc.processingStatus( ) + " deleted after " + formatReadableDuration( days ), new Date( ), doc.dicomInstanceReceivedTimestamp( ) );
                logRepository.save( deletedDocumentLog );
            }

        } );
    }

    private Date getDateDaysAgo ( Duration duration ) {
        Instant instant = Instant.now( ).minus( duration );
        return Date.from( instant );

    }

    private String formatReadableDuration(Duration duration){
        long days = duration.toDays();
        long hours = duration.toHours() % 24;
        long minutes = duration.toMinutes() % 60;
        long seconds = duration.getSeconds() % 60;

        if (days > 0) return days + " day" + (days > 1 ? "s" : "");
        if (hours > 0) return hours + " hour" + (hours > 1 ? "s" : "");
        if (minutes > 0) return minutes + " minute" + (minutes > 1 ? "s" : "");
        if (seconds > 0) return seconds + " second" + (seconds > 1 ? "s" : "");

        return "0 seconds";

    }

}

