package com.eh.digitalpathology.dicompurge.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "document_logs")
public record DeletedDocumentLog(@Id String id, String sopInstanceUid, String reason, Date deletedTimestamp, Date dicomInstanceReceivedTime) {}
