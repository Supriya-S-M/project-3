package com.eh.digitalpathology.dicompurge.repository;

import com.eh.digitalpathology.dicompurge.entity.DicomInstance;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface DicomInstanceRepository extends MongoRepository< DicomInstance, String> {

    List<DicomInstance> findByProcessingStatusAndDicomInstanceReceivedTimestampBefore( String processingStatus, Date date);
}
