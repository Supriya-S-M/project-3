package com.eh.digitalpathalogy.techcyte.service;

import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.MessageReceiver;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PubSubPullServiceTest {

    private NotificationService notificationService;
    private PubSubPullService pubSubPullService;

    @BeforeEach
    void setUp ( ) {
        notificationService = mock( NotificationService.class );
        pubSubPullService = new PubSubPullService( notificationService );
    }


    @Test
    void testStartPulling_processesMessageAndStartsSubscriber ( ) {
        // Arrange
        PubsubMessage message = mock( PubsubMessage.class );
        when( message.getData( ) ).thenReturn( ByteString.copyFromUtf8( "test-payload" ) );

        AckReplyConsumer consumer = mock( AckReplyConsumer.class );

        ProjectSubscriptionName subscriptionName = mock( ProjectSubscriptionName.class );

        try ( MockedStatic< ProjectSubscriptionName > mockedSubscriptionName = mockStatic( ProjectSubscriptionName.class ); MockedStatic< Subscriber > mockedSubscriberStatic = mockStatic( Subscriber.class ) ) {
            mockedSubscriptionName.when( ( ) -> ProjectSubscriptionName.of( "prj-d-path-integration-cs1h", "techcyte-sub" ) ).thenReturn( subscriptionName );

            // Create a mock Subscriber and simulate message receiver
            Subscriber mockSubscriber = mock( Subscriber.class );
            when( mockSubscriber.startAsync( ) ).thenReturn( mockSubscriber );
            doNothing( ).when( mockSubscriber ).awaitRunning( );

            // Create a mock Builder
            Subscriber.Builder mockBuilder = mock( Subscriber.Builder.class );
            when( mockBuilder.build( ) ).thenReturn( mockSubscriber );

            // Simulate the message receiver callback
            mockedSubscriberStatic.when( ( ) -> Subscriber.newBuilder( eq( subscriptionName ), any( MessageReceiver.class ) ) ).thenAnswer( invocation -> {
                MessageReceiver receiver = invocation.getArgument( 1 );
                receiver.receiveMessage( message, consumer );
                return mockBuilder;
            } );

            // Act
            pubSubPullService.startPulling( );

            // Assert
            verify( notificationService ).processNotifications( "test-payload" );
            verify( consumer ).ack( );
            verify( mockSubscriber ).startAsync( );
            verify( mockSubscriber ).awaitRunning( );
        }
    }

}

