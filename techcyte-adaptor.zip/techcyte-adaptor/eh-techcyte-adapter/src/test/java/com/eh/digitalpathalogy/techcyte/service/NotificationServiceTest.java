package com.eh.digitalpathalogy.techcyte.service;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.ExecutorService;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith( MockitoExtension.class )
class NotificationServiceTest {

    @Mock
    private ZipIngestService zipIngestService;

    @Mock
    private ExecutorService executorService;

    @InjectMocks
    private NotificationService notificationService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void testNullPayload() {
        ResponseEntity<String> response = notificationService.processNotifications(null);
        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Message payload is null or empty", response.getBody());
    }

    @Test
    void testEmptyPayload() {
        ResponseEntity<String> response = notificationService.processNotifications("");
        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Message payload is null or empty", response.getBody());
    }

    @Test
    void testNonZipFile() {
        String payload = "{\"name\": \"file.txt\", \"bucket\": \"test-bucket\"}";
        ResponseEntity<String> response = notificationService.processNotifications(payload);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Non-ZIP file skipped", response.getBody());
        verifyNoInteractions(zipIngestService);
    }

    @Test
    void testValidZipFile() {
        String payload = "{\"name\": \"file.zip\", \"bucket\": \"test-bucket\"}";
        ResponseEntity<String> response = notificationService.processNotifications(payload);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("ZIP file processing started", response.getBody());
        verify(executorService).submit(any(Runnable.class));
    }

    @Test
    void testMalformedJson() {
        String payload = "{invalid json}";
        ResponseEntity<String> response = notificationService.processNotifications(payload);
        assertEquals(400, response.getStatusCodeValue());
        assertEquals("Failed to parse JSON", response.getBody());
    }

    @Test
    void testUnexpectedException() {
        ExecutorService brokenExecutor = mock(ExecutorService.class);
        doThrow(new RuntimeException("Executor failure")).when(brokenExecutor).submit(any(Runnable.class));

        NotificationService serviceWithBrokenExecutor = new NotificationService(zipIngestService, brokenExecutor);

        String payload = "{\"name\": \"file.zip\", \"bucket\": \"test-bucket\"}";
        ResponseEntity<String> response = serviceWithBrokenExecutor.processNotifications(payload);

        assertEquals(500, response.getStatusCodeValue());
        assertEquals("Unexpected error occurred", response.getBody());
    }
}