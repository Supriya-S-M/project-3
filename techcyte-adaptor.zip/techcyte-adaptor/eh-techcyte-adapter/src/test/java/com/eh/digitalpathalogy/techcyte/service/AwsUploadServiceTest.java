package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.AppProperties;
import com.eh.digitalpathalogy.techcyte.service.AWSTokenService;
import com.eh.digitalpathalogy.techcyte.service.AwsUploadService;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith( MockitoExtension.class )
class AwsUploadServiceTest {

    @Mock
    private AWSTokenService awsTokenService;

    @Mock
    private AppProperties appProperties;

    @Mock
    private AppProperties.Upload upload;

    @Mock
    private CloseableHttpClient httpClient;

    @Mock
    private CloseableHttpResponse httpResponse;

    @InjectMocks
    private AwsUploadService awsUploadService;

    private File tempFile;

    @BeforeEach
    void setup ( ) throws IOException {
        tempFile = File.createTempFile( "test", ".dcm" );
        Files.write( tempFile.toPath( ), "dummy content".getBytes( ) );

        when( appProperties.getUpload( ) ).thenReturn( upload );
        when( upload.getEndpoint( ) ).thenReturn( "https://dummy-endpoint.com" );
        when( awsTokenService.getValidToken( ) ).thenReturn( "dummy-token" );
    }

    @Test
    void testUploadAsyncSuccess() throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();

        HttpEntity entity = new StringEntity("OK");
        StatusLine statusLine = mock(StatusLine.class);
        when(statusLine.getStatusCode()).thenReturn(200);
        lenient().when(httpResponse.getStatusLine()).thenReturn(statusLine);
        lenient().when(httpResponse.getEntity()).thenReturn(entity);
        when(httpClient.execute(any(HttpPost.class))).thenReturn(httpResponse);

        CompletableFuture<Void> future = awsUploadService.uploadAsync("testFile.dcm", tempFile, executor);
        future.get(); // Wait for completion

        verify(httpClient, times(1)).execute(any(HttpPost.class));
    }


    @Test
    void testUploadToAws401ThenSuccess ( ) throws Exception {
        StatusLine unauthorized = mock( StatusLine.class );
        when( unauthorized.getStatusCode( ) ).thenReturn( 401 );
        lenient().when( unauthorized.getReasonPhrase( ) ).thenReturn( "Unauthorized" );

        StatusLine success = mock( StatusLine.class );
        when( success.getStatusCode( ) ).thenReturn( 200 );

        HttpEntity entity = new StringEntity( "Unauthorized" );

        when( httpResponse.getStatusLine( ) ).thenReturn( unauthorized, success );
        lenient().when( httpResponse.getEntity( ) ).thenReturn( entity );
        when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( httpResponse );

        awsUploadService.uploadToAws( "testFile.dcm", tempFile );

        verify( awsTokenService, times( 1 ) ).forceRefreshToken( );
        verify( httpClient, times( 2 ) ).execute( any( HttpPost.class ) );
    }

    @Test
    void testUploadToAwsFailureAfterRetries ( ) throws Exception {
        StatusLine errorStatus = mock( StatusLine.class );
        when( errorStatus.getStatusCode( ) ).thenReturn( 500 );
        when( errorStatus.getReasonPhrase( ) ).thenReturn( "Internal Server Error" );

        HttpEntity entity = new StringEntity( "Error" );

        when( httpResponse.getStatusLine( ) ).thenReturn( errorStatus );
        when( httpResponse.getEntity( ) ).thenReturn( entity );
        when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( httpResponse );

        IOException thrown = assertThrows( IOException.class, ( ) -> awsUploadService.uploadToAws( "testFile.dcm", tempFile ) );

        assertTrue( thrown.getMessage( ).contains( "AWS upload failed after retries" ) );
        verify( httpClient, times( 3 ) ).execute( any( HttpPost.class ) );
    }

    @AfterEach
    void cleanup ( ) {
        tempFile.delete( );
    }
}
