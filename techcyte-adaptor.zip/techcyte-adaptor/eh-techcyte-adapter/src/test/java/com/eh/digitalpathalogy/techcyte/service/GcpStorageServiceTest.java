package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.eh.digitalpathalogy.techcyte.utils.GCPUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.MockedStatic;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;

// --- Your project types (adjust packages if needed) ---
import com.eh.digitalpathalogy.techcyte.config.GcpConfig;


@ExtendWith( MockitoExtension.class )
class GcpStorageServiceTest {

    @Mock
    private GcpConfig gcpConfig;

    @Mock
    private CloseableHttpClient httpClient;

    @Mock
    private CloseableHttpResponse response;

    @Mock
    private StatusLine statusLine;

    private ExecutorService internalPipeExecutor;   // used by service to stream the file
    private ExecutorService asyncExecutor;          // passed to uploadAsync

    private GcpStorageService service;

    @Mock
    private DatabaseService dbService;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp ( ) {
        internalPipeExecutor = Executors.newSingleThreadExecutor( r -> new Thread( r, "pipe-exec" ) );
        asyncExecutor = Executors.newSingleThreadExecutor( r -> new Thread( r, "async-exec" ) );

        service = new GcpStorageService( gcpConfig, internalPipeExecutor, httpClient );

        // Stub URL construction used by the service
        when( gcpConfig.getDicomWebUrl( ) ).thenReturn( "https://example.com" );
        lenient().when(dbService.getDicomStroreUrl( anyString() ) ).thenReturn( "stores/my-store" );
        lenient( ).when( dbService.isBarcodeExists( anyString( ) ) ).thenReturn( false );
    }

    @AfterEach
    void tearDown ( ) {
        asyncExecutor.shutdownNow( );
        internalPipeExecutor.shutdownNow( );
    }

    @Test
    void uploadAsync_success_201_setsHeaders_andCompletes ( ) throws Exception {
        // Arrange: real temp DICOM file
        Path dicomPath = tempDir.resolve( "dicom-ok-201.dcm" );
        Files.writeString( dicomPath, "DICOM-DATA" );
        File file = dicomPath.toFile( );

        try ( MockedStatic< GCPUtils > mockStatic = Mockito.mockStatic( GCPUtils.class ) ) {
            // Match any GcpConfig instance to avoid instance-identity mismatches
            mockStatic.when( ( ) -> GCPUtils.getAccessToken( gcpConfig ) ).thenReturn( "token123" );

            // Probe: prove static mock is active (call with the same mock type)
            assertEquals( "token123", GCPUtils.getAccessToken( gcpConfig ), "Static mock did not apply" );

            when( statusLine.getStatusCode( ) ).thenReturn( 201 );
            lenient().when( statusLine.getReasonPhrase( ) ).thenReturn( "Created" );
            when( response.getStatusLine( ) ).thenReturn( statusLine );
            when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( response );

            // Act
            CompletableFuture< Void > future = service.uploadAsync( "file1.dcm", file, "stores/my-store"  , asyncExecutor );
            future.join( ); // should complete normally

            // Assert
            ArgumentCaptor< HttpPost > captor = ArgumentCaptor.forClass( HttpPost.class );
            verify( httpClient, times( 1 ) ).execute( captor.capture( ) );

            HttpPost post = captor.getValue( );

            String expectedUri = "https://example.com/stores/my-store/dicomWeb/studies";
            assertEquals( expectedUri, post.getURI( ).toString( ), "Upload URI should be formatted correctly" );

            // Entity is an InputStreamEntity
            assertNotNull( post.getEntity( ), "Request entity must be set" );
            assertTrue( post.getEntity( ) instanceof InputStreamEntity, "Entity must be InputStreamEntity" );

            // Optional: verify static invocation regardless of instance identity
            mockStatic.verify( ( ) -> GCPUtils.getAccessToken( any( GcpConfig.class ) ), times( 1 ) );
        }
    }


    @Test
    void uploadAsync_success_200_withoutAuthHeader_whenTokenEmpty ( ) throws Exception {
        // Arrange: real temp DICOM file
        Path dicomPath = tempDir.resolve( "dicom-ok-200.dcm" );
        Files.writeString( dicomPath, "DICOM-DATA" );
        File file = dicomPath.toFile( );

        try ( MockedStatic< GCPUtils > mockStatic = Mockito.mockStatic( GCPUtils.class ) ) {
            mockStatic.when( ( ) -> GCPUtils.getAccessToken( gcpConfig ) ).thenReturn( "" );

            // Probe
            assertEquals( "", GCPUtils.getAccessToken( gcpConfig ), "Static mock did not apply" );

            when( statusLine.getStatusCode( ) ).thenReturn( 200 );
            lenient( ).when( statusLine.getReasonPhrase( ) ).thenReturn( "OK" );
            when( response.getStatusLine( ) ).thenReturn( statusLine );
            when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( response );

            // Act
            CompletableFuture< Void > future = service.uploadAsync( "file2.dcm", file,"stores/my-store", asyncExecutor );
            future.join( );

            // Assert
            ArgumentCaptor< HttpPost > captor = ArgumentCaptor.forClass( HttpPost.class );
            verify( httpClient, times( 1 ) ).execute( captor.capture( ) );

            HttpPost post = captor.getValue( );
            assertEquals( "application/dicom", post.getFirstHeader( HttpHeaders.CONTENT_TYPE ).getValue( ), "Content-Type should be application/dicom" );

            // Authorization header should be absent when token is empty
            assertNull( post.getFirstHeader( HttpHeaders.AUTHORIZATION ), "Authorization header should not be set when token is empty" );
        }
    }

    @Test
    void uploadAsync_failure_non2xx_completesExceptionallyWithTechcyteException ( ) throws Exception {
        // Arrange
        Path dicomPath = tempDir.resolve( "dicom-bad-400.dcm" );
        Files.writeString( dicomPath, "DICOM-DATA" );
        File file = dicomPath.toFile( );

        try ( MockedStatic< GCPUtils > mockStatic = Mockito.mockStatic( GCPUtils.class ) ) {
            mockStatic.when( ( ) -> GCPUtils.getAccessToken( gcpConfig ) ).thenReturn( "token123" );
            assertEquals( "token123", GCPUtils.getAccessToken( gcpConfig ) );

            when( statusLine.getStatusCode( ) ).thenReturn( 400 );
            when( statusLine.getReasonPhrase( ) ).thenReturn( "Bad Request" );
            when( response.getStatusLine( ) ).thenReturn( statusLine );
            when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( response );

            // Act
            CompletableFuture< Void > future = service.uploadAsync( "bad-file.dcm", file,"stores/my-store", asyncExecutor );

            // Assert
            CompletionException ex = assertThrows( CompletionException.class, future::join );
            assertNotNull( ex.getCause( ) );
            assertTrue( ex.getCause( ) instanceof TechcyteException, "Cause should be TechcyteException when upload fails" );
            assertTrue( ex.getCause( ).getMessage( ).contains( "DICOM Store upload failed for" ), "Message should indicate DICOM Store upload failed" );
        }
    }

    @Test
    void uploadAsync_failure_httpClientThrowsIOException_wrapsTechcyteException ( ) throws Exception {
        // Arrange
        Path dicomPath = tempDir.resolve( "dicom-http-ioex.dcm" );
        Files.writeString( dicomPath, "DICOM-DATA" );
        File file = dicomPath.toFile( );

        try ( MockedStatic< GCPUtils > mockStatic = Mockito.mockStatic( GCPUtils.class ) ) {
            mockStatic.when( ( ) -> GCPUtils.getAccessToken( gcpConfig ) ).thenReturn( "token123" );
            assertEquals( "token123", GCPUtils.getAccessToken( gcpConfig ) );

            when( httpClient.execute( any( HttpPost.class ) ) ).thenThrow( new IOException( "boom" ) );

            // Act
            CompletableFuture< Void > future = service.uploadAsync( "ioex.dcm", file,"stores/my-store" , asyncExecutor );

            // Assert
            CompletionException ex = assertThrows( CompletionException.class, future::join );
            assertNotNull( ex.getCause( ) );
            assertTrue( ex.getCause( ) instanceof TechcyteException, "IOException from HttpClient should be wrapped in TechcyteException" );
        }
    }

    @Test
    void uploadAsync_success_evenIfWriteTaskThrows_ExecutionExceptionIsCaught ( ) throws Exception {
        // Arrange: intentionally use a missing file to make the writer throw UncheckedIOException
        File missing = tempDir.resolve( "does-not-exist.dcm" ).toFile( );
        assertFalse( missing.exists( ), "Test precondition failed: file should not exist" );

        try ( MockedStatic< GCPUtils > mockStatic = Mockito.mockStatic( GCPUtils.class ) ) {
            mockStatic.when( ( ) -> GCPUtils.getAccessToken( gcpConfig ) ).thenReturn( "token123" );
            assertEquals( "token123", GCPUtils.getAccessToken( gcpConfig ) );

            when( statusLine.getStatusCode( ) ).thenReturn( 200 );
            lenient( ).when( statusLine.getReasonPhrase( ) ).thenReturn( "OK" );
            when( response.getStatusLine( ) ).thenReturn( statusLine );
            when( httpClient.execute( any( HttpPost.class ) ) ).thenReturn( response );

            // Act: service should log the writer error but still complete for 2xx response
            CompletableFuture< Void > future = service.uploadAsync( "missing.dcm", missing,"stores/my-store",  asyncExecutor );

            // Assert: no exception thrown when joining
            assertDoesNotThrow( future::join, "Service should complete even if the write task throws" );
        }
    }
}
