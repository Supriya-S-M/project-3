package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.AppProperties;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import org.apache.http.HttpEntity;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith( MockitoExtension.class)
class AWSTokenServiceTest {

    @Mock
    private AppProperties appProperties;

    @Mock
    private CloseableHttpClient httpClient;

    @Mock
    private CloseableHttpResponse httpResponse;

    @Mock
    private StatusLine statusLine;

    @Mock
    private HttpEntity httpEntity;

    @Mock
    private AppProperties.Client client;

    @Mock
    private AppProperties.Token token;

    private AWSTokenService awsTokenService;

    @BeforeEach
    void setUp() {
        awsTokenService = new AWSTokenService(appProperties, httpClient);

    }

    @Test
    void shouldReturnCachedTokenIfNotExpired() {
        // Simulate cached token and expiry
        String cachedToken = "cached-token";
        Instant expiry = Instant.now().plusSeconds(3600);

        // Use reflection to set private fields
        ReflectionTestUtils.setField(awsTokenService, "cachedToken", cachedToken);
        ReflectionTestUtils.setField(awsTokenService, "expiryTime", expiry);

        String token = awsTokenService.getValidToken();
        assertEquals(cachedToken, token);
    }

    @Test
    void shouldRefreshTokenWhenExpired() throws Exception {
        // Setup mocks
        when(appProperties.getToken()).thenReturn(token);
        when(appProperties.getClient()).thenReturn(client);
        when(token.getEndpoint()).thenReturn("https://example.com/token");
        when(client.getClientId()).thenReturn("client-id");
        when(client.getClientSecret()).thenReturn("client-secret");

        when(httpClient.execute(any( HttpPost.class))).thenReturn(httpResponse);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(200);
        when(httpResponse.getEntity()).thenReturn(httpEntity);

        String json = "{\"access_token\":\"new-token\",\"expires_in\":3600}";

        InputStream inputStream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        when(httpEntity.getContent()).thenReturn(inputStream);


        String tokenResult = awsTokenService.getValidToken();
        assertEquals("new-token", tokenResult);
    }

    @Test
    void shouldThrowExceptionOnNon200Response() throws Exception {
        // Ensure no cached token or expiry
        ReflectionTestUtils.setField(awsTokenService, "cachedToken", null);
        ReflectionTestUtils.setField(awsTokenService, "expiryTime", null);

        // Mock AppProperties
        when(appProperties.getToken()).thenReturn(token);
        when(appProperties.getClient()).thenReturn(client);
        when(token.getEndpoint()).thenReturn("https://example.com/token");
        when(client.getClientId()).thenReturn("client-id");
        when(client.getClientSecret()).thenReturn("client-secret");

        // Mock HTTP response with 401
        when(httpClient.execute(any(HttpPost.class))).thenReturn(httpResponse);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(401);

        // Trigger and verify exception
        TechcyteException ex = assertThrows(TechcyteException.class, () -> awsTokenService.getValidToken());
        System.out.println(ex.getMessage() );
        assertTrue(ex.getMessage().contains("Failed to fetch token"));
    }


    @Test
    void shouldForceRefreshToken() throws Exception {
        // Setup mocks
        when(appProperties.getToken()).thenReturn(token);
        when(appProperties.getClient()).thenReturn(client);
        when(token.getEndpoint()).thenReturn("https://example.com/token");
        when(client.getClientId()).thenReturn("client-id");
        when(client.getClientSecret()).thenReturn("client-secret");

        when(httpClient.execute(any(HttpPost.class))).thenReturn(httpResponse);
        when(httpResponse.getStatusLine()).thenReturn(statusLine);
        when(statusLine.getStatusCode()).thenReturn(200);
        when(httpResponse.getEntity()).thenReturn(httpEntity);

        String json = "{\"access_token\":\"forced-token\",\"expires_in\":3600}";

        InputStream inputStream = new ByteArrayInputStream(json.getBytes( StandardCharsets.UTF_8));
        when(httpEntity.getContent()).thenReturn(inputStream);


        awsTokenService.forceRefreshToken();

        String token = ReflectionTestUtils.getField(awsTokenService, "cachedToken").toString();
        assertEquals("forced-token", token);
    }
}