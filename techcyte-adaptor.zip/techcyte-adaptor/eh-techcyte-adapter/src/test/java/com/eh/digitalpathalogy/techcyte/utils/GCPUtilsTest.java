package com.eh.digitalpathalogy.techcyte.utils;

import com.eh.digitalpathalogy.techcyte.config.GcpConfig;
import com.eh.digitalpathalogy.techcyte.exceptions.HealthcareApiException;
import com.google.api.services.healthcare.v1.CloudHealthcareScopes;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith( MockitoExtension.class )
class GCPUtilsTest {

    @Test
    void testGetAccessToken_withValidCredentials_returnsToken ( ) throws Exception {
        // Arrange
        String fakeToken = "fake-access-token";
        String fakeCredsJson = "{\"type\": \"service_account\", \"project_id\": \"test-project\"}";
        GcpConfig mockConfig = mock( GcpConfig.class );
        when( mockConfig.getCreds( ) ).thenReturn( fakeCredsJson );

        AccessToken mockAccessToken = new AccessToken( fakeToken, new Date( System.currentTimeMillis( ) + 3600 * 1000 ) );
        GoogleCredentials mockCredentials = mock( GoogleCredentials.class );
        when( mockCredentials.createScoped( Collections.singleton( CloudHealthcareScopes.CLOUD_PLATFORM ) ) ).thenReturn( mockCredentials );
        when( mockCredentials.refreshAccessToken( ) ).thenReturn( mockAccessToken );

        try ( MockedStatic< GoogleCredentials > mockedStatic = mockStatic( GoogleCredentials.class ) ) {
            mockedStatic.when( ( ) -> GoogleCredentials.fromStream( any( ) ) ).thenReturn( mockCredentials );

            // Act
            String token = GCPUtils.getAccessToken( mockConfig );

            // Assert
            assertEquals( fakeToken, token );
            verify( mockCredentials ).refreshIfExpired( );
        }
    }

    @Test
    void testGetAccessToken_withNullCredentials_returnsEmptyString ( ) throws Exception {
        // Arrange
        GcpConfig mockConfig = mock( GcpConfig.class );
        when( mockConfig.getCreds( ) ).thenReturn( null );

        // Act
        String token = GCPUtils.getAccessToken( mockConfig );

        // Assert
        assertEquals( "", token );
    }

    @Test
    void testGetAccessToken_withBlankCredentials_returnsEmptyString ( ) throws Exception {
        // Arrange
        GcpConfig mockConfig = mock( GcpConfig.class );
        when( mockConfig.getCreds( ) ).thenReturn( "   " );

        // Act
        String token = GCPUtils.getAccessToken( mockConfig );

        // Assert
        assertEquals( "", token );
    }

    @Test
    void testGetAccessToken_withInvalidCredentials_throwsException ( ) {
        // Arrange
        String invalidCreds = "invalid-json";
        GcpConfig mockConfig = mock( GcpConfig.class );
        when( mockConfig.getCreds( ) ).thenReturn( invalidCreds );

        // Act & Assert
        HealthcareApiException exception = assertThrows( HealthcareApiException.class, ( ) -> {
            GCPUtils.getAccessToken( mockConfig );
        } );

        assertTrue( exception.getMessage( ).contains( "Failed to get access token" ) );
    }
}