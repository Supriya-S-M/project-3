package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.GcpConfig;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.eh.digitalpathalogy.techcyte.model.DicomMetadata;
import com.eh.digitalpathalogy.techcyte.utils.DicomMetadataExtractor;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ZipIngestServiceTest {

    @Mock private AwsUploadService awsUploadService;
    @Mock private GcpStorageService dicomStoreUploadService;
    @Mock private ExecutorService ioExecutor;
    @Mock private GcpConfig gcpConfig;
    @Mock private DatabaseService dbService;

    @InjectMocks private ZipIngestService zipIngestService;

    private MockedStatic<ServiceAccountCredentials> credentialsMock;
    private MockedStatic<StorageOptions> storageOptionsMock;

    private Storage mockStorage;
    private Blob mockBlob;
    private ReadChannel mockReadChannel;

    @BeforeEach
    void setupStaticMocks() throws IOException {
        ServiceAccountCredentials mockCreds = mock(ServiceAccountCredentials.class);
        credentialsMock = mockStatic(ServiceAccountCredentials.class);
        credentialsMock.when(() -> ServiceAccountCredentials.fromStream(any())).thenReturn(mockCreds);

        storageOptionsMock = mockStatic(StorageOptions.class);
        StorageOptions.Builder builder = mock(StorageOptions.Builder.class);
        StorageOptions storageOptions = mock(StorageOptions.class);
        mockStorage = mock(Storage.class);

        storageOptionsMock.when(StorageOptions::newBuilder).thenReturn(builder);
        when(builder.setCredentials(mockCreds)).thenReturn(builder);
        when(builder.build()).thenReturn(storageOptions);
        when(storageOptions.getService()).thenReturn(mockStorage);
    }

    @AfterEach
    void tearDownStaticMocks() {
        credentialsMock.close();
        storageOptionsMock.close();
    }

    private void setupBlobMocks(byte[] zipBytes, String bucketId, String objectId) throws IOException {
        BlobId blobId = BlobId.of(bucketId, objectId);
        mockBlob = mock(Blob.class);
        mockReadChannel = mock(ReadChannel.class);

        when(mockBlob.reader()).thenReturn(mockReadChannel);
        when(mockStorage.get(blobId)).thenReturn(mockBlob);

        ByteArrayInputStream zipInputStream = new ByteArrayInputStream(zipBytes);
        ReadableByteChannel readableByteChannel = Channels.newChannel(zipInputStream);
        when(mockReadChannel.read(any(ByteBuffer.class))).thenAnswer(invocation -> readableByteChannel.read(invocation.getArgument(0)));
    }

    @Test
    void testProcessZipFileFromGcs_successfulUploadAndDelete() throws Exception {
        String bucketId = "bucket";
        String objectId = "dicom.zip";
        String dicomFileName = "image1.dcm";

        when(gcpConfig.getCreds()).thenReturn("mock-creds");

        ByteArrayOutputStream zipBytes = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(zipBytes)) {
            zos.putNextEntry(new ZipEntry(dicomFileName));
            zos.write("dummy-dicom".getBytes());
            zos.closeEntry();
        }

        setupBlobMocks(zipBytes.toByteArray(), bucketId, objectId);

        CompletableFuture<Void> successFuture = CompletableFuture.completedFuture(null);
        when(awsUploadService.uploadAsync(anyString(), any(File.class), eq(ioExecutor))).thenReturn(successFuture);

        DicomMetadata mockMetadata = mock(DicomMetadata.class);
        when(mockMetadata.barcode()).thenReturn("mock-barcode");
        when(mockMetadata.deviceSerialNumber()).thenReturn("mock-device");
        when(dbService.isBarcodeExists("mock-barcode")).thenReturn(false);
        when(dbService.getDicomStroreUrl("mock-device")).thenReturn("mock-dicom-store-url");
        when(dicomStoreUploadService.uploadAsync(anyString(), any(File.class), eq("mock-dicom-store-url"), eq(ioExecutor))).thenReturn(successFuture);
        try (MockedStatic<DicomMetadataExtractor> mockedStatic = mockStatic(DicomMetadataExtractor.class)) {
            mockedStatic.when(() -> DicomMetadataExtractor.extractMetadata(any(File.class))).thenReturn(mockMetadata);

            zipIngestService.processZipFileFromGcs(bucketId, objectId);
        }


        verify(mockStorage).delete(BlobId.of(bucketId, objectId));
    }

    @Test
    void testProcessZipFileFromGcs_nonDicomFiles_skipped() throws Exception {
        String bucketId = "bucket";
        String objectId = "non-dicom.zip";

        when(gcpConfig.getCreds()).thenReturn("mock-creds");

        ByteArrayOutputStream zipBytes = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(zipBytes)) {
            zos.putNextEntry(new ZipEntry("readme.txt"));
            zos.write("not a dicom".getBytes());
            zos.closeEntry();
        }

        setupBlobMocks(zipBytes.toByteArray(), bucketId, objectId);

        zipIngestService.processZipFileFromGcs(bucketId, objectId);

        verify(awsUploadService, never()).uploadAsync(anyString(), any(File.class), eq(ioExecutor));
        verify(dicomStoreUploadService, never()).uploadAsync(anyString(), any(File.class), anyString(), eq(ioExecutor));
//        verify(mockStorage, never()).delete( (BlobId) any() );
    }

    @Test
    void testProcessZipFileFromGcs_uploadFailure_blobNotDeleted() throws Exception {
        String bucketId = "bucket";
        String objectId = "upload-fail.zip";
        String dicomFileName = "fail.dcm";

        when(gcpConfig.getCreds()).thenReturn("mock-creds");

        ByteArrayOutputStream zipBytes = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(zipBytes)) {
            zos.putNextEntry(new ZipEntry(dicomFileName));
            zos.write("dummy".getBytes());
            zos.closeEntry();
        }

        setupBlobMocks(zipBytes.toByteArray(), bucketId, objectId);

        CompletableFuture<Void> failedFuture = CompletableFuture.failedFuture(new RuntimeException("Upload failed"));
        when(awsUploadService.uploadAsync(anyString(), any(File.class), eq(ioExecutor))).thenReturn(failedFuture);
        DicomMetadata mockMetadata = mock(DicomMetadata.class);
        when(mockMetadata.barcode()).thenReturn("mock-barcode");
        when(mockMetadata.deviceSerialNumber()).thenReturn("mock-device");
        when(dbService.isBarcodeExists("mock-barcode")).thenReturn(false);
        when(dbService.getDicomStroreUrl("mock-device")).thenReturn("mock-dicom-store-url");
        when(dicomStoreUploadService.uploadAsync(anyString(), any(File.class), eq("mock-dicom-store-url"), eq(ioExecutor))).thenReturn(CompletableFuture.completedFuture( null ));
        try (MockedStatic<DicomMetadataExtractor> mockedStatic = mockStatic(DicomMetadataExtractor.class)) {
            mockedStatic.when(() -> DicomMetadataExtractor.extractMetadata(any(File.class))).thenReturn(mockMetadata);

            zipIngestService.processZipFileFromGcs(bucketId, objectId);
        }

    //    verify(mockStorage, never()).delete( (BlobId) any() );
    }

    @Test
    void testProcessZipFileFromGcs_invalidGcpCreds_throwsException() {
        String bucketId = "bucket";
        String objectId = "missing-object.zip";

        when(gcpConfig.getCreds()).thenReturn("mock-creds");

        BlobId blobId = BlobId.of(bucketId, objectId);
        when(mockStorage.get(blobId)).thenReturn(null); // Simulate missing blob

        assertThrows(IllegalArgumentException.class, () -> zipIngestService.processZipFileFromGcs(bucketId, objectId));
    }


    @Test
    void testProcessZipFileFromGcs_corruptZip_throwsException() throws Exception {
        String bucketId = "bucket";
        String objectId = "corrupt.zip";

        when(gcpConfig.getCreds()).thenReturn("mock-creds");

        BlobId blobId = BlobId.of(bucketId, objectId);
        mockBlob = mock(Blob.class);
        mockReadChannel = mock(ReadChannel.class);

        when(mockStorage.get(blobId)).thenReturn(mockBlob);
        when(mockBlob.reader()).thenReturn(mockReadChannel);

        // Simulate corrupt ZIP by throwing IOException during channel read
        when(mockReadChannel.read(any(ByteBuffer.class))).thenThrow(new TechcyteException("Simulated read error"));

        assertThrows(TechcyteException.class, () -> zipIngestService.processZipFileFromGcs(bucketId, objectId));
    }

}
