package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.GcpConfig;
import com.eh.digitalpathalogy.techcyte.config.KafkaTopicConfig;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.eh.digitalpathalogy.techcyte.model.DicomMetadata;
import com.eh.digitalpathalogy.techcyte.model.PathQa;
import com.eh.digitalpathalogy.techcyte.utils.DicomMetadataExtractor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.ReadChannel;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.channels.Channels;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

@Service
public class ZipIngestService {

    private final Logger logger = LoggerFactory.getLogger( ZipIngestService.class.getName( ) );

    private final AwsUploadService awsUploadService;
    private final GcpStorageService dicomStoreUploadService;
    private final ExecutorService ioExecutor;
    private final GcpConfig gcpConfig;
    private final DatabaseService dbService;
    private final KafkaNotifier kafkaNotifier;
    private final KafkaTopicConfig kafkaTopicConfig;
    private final ObjectMapper objectMapper = new ObjectMapper( );

    public ZipIngestService ( AwsUploadService awsUploadService, GcpStorageService dicomStoreUploadService, @Qualifier( "zipIngestExecutor" ) ExecutorService ioExecutor, GcpConfig gcpConfig, DatabaseService dbService, KafkaNotifier kafkaNotifier, KafkaTopicConfig kafkaTopicConfig ) {
        this.awsUploadService = awsUploadService;
        this.dicomStoreUploadService = dicomStoreUploadService;
        this.ioExecutor = ioExecutor;
        this.gcpConfig = gcpConfig;
        this.dbService = dbService;
        this.kafkaNotifier = kafkaNotifier;
        this.kafkaTopicConfig = kafkaTopicConfig;
    }

    public void processZipFileFromGcs ( String bucketId, String objectId ) {
        if ( objectId == null || objectId.isBlank( ) ) {
            throw new IllegalArgumentException( "Object Id is required" );
        }

        Storage storage;
        try {
            storage = StorageOptions.newBuilder( ).setCredentials( ServiceAccountCredentials.fromStream( new ByteArrayInputStream( gcpConfig.getCreds( ).getBytes( StandardCharsets.UTF_8 ) ) ) ).build( ).getService( );
        } catch ( IOException e ) {
            throw new TechcyteException( "Failed to initialize GCP storage", e );
        }

        BlobId blobId = BlobId.of( bucketId, objectId );
        Blob blob = storage.get( blobId );
        if ( blob == null ) {
            throw new IllegalArgumentException( "No such object in GCS" );
        }

        int totalEntries = 0;
        int dicomFileCount = 0;
        List< CompletableFuture< Boolean > > uploadFutures = new ArrayList<>( );
        List< CompletableFuture< Boolean > > altUploadFutures = new ArrayList<>( );
        DicomMetadata metadataForNotification = null;

        logger.info( "processZipFileFromGcs :: Starting ZIP file processing for object: {}", objectId );
        try ( ReadChannel reader = blob.reader( ); InputStream inputStream = Channels.newInputStream( reader ); ZipInputStream zipInputStream = new ZipInputStream( inputStream ) ) {

            ZipEntry entry;
            while ( ( entry = zipInputStream.getNextEntry( ) ) != null ) {
                totalEntries++;
                String entryName = entry.getName( );
                logger.info( "processZipFileFromGcs :: Found entry: {}", entryName );

                if ( entry.isDirectory( ) || !isDicomFile( entryName ) ) {
                    logger.error( "processZipFileFromGcs :: Skipping non-DICOM or directory entry: {}", entryName );
                    zipInputStream.closeEntry( );
                    continue;
                }
                dicomFileCount++;

                String sanitizedFileName = Paths.get( entryName ).getFileName( ).toString( ); // Removes any path info
                File tempFile = new File( System.getProperty( "java.io.tmpdir" ), sanitizedFileName );
                try ( FileOutputStream fos = new FileOutputStream( tempFile ) ) {
                    byte[] buffer = new byte[ 8 * 1024 * 1024 ];
                    int bytesRead;
                    while ( ( bytesRead = zipInputStream.read( buffer ) ) != -1 ) {
                        fos.write( buffer, 0, bytesRead );
                    }
                }

                DicomMetadata metadata = DicomMetadataExtractor.extractMetadata( tempFile );
                String barcode = metadata.barcode( );
                if ( Boolean.TRUE.equals( dbService.isBarcodeExists( barcode ) ) ) {
                    metadataForNotification = metadata;
                    CompletableFuture< Boolean > altFuture = dicomStoreUploadService.uploadAsync( entryName, tempFile, gcpConfig.getPathqaStoreUrl( ), ioExecutor ).orTimeout( 5, TimeUnit.MINUTES ).thenApply( v -> true ).exceptionally( ex -> {
                        logger.error( "Alternate upload failed for file {}: {}", entryName, ex.getMessage( ) );
                        return false;
                    } );

                    altUploadFutures.add( altFuture );
                    uploadFutures.add( altFuture );
                    CompletableFuture< Void > cleanupFuture = CompletableFuture.allOf(altFuture ).whenComplete( ( v, ex ) -> {
                        boolean deleted = tempFile.delete( );
                        if ( deleted ) {
                            logger.info( "processZipFileFromGcs :: If Temp file deleted: {}", tempFile.getAbsolutePath( ) );
                        } else {
                            logger.error( "processZipFileFromGcs :: if Failed to delete temp file: {}", tempFile.getAbsolutePath( ) );
                        }
                    } );


                    uploadFutures.add( cleanupFuture.thenApply( v -> true ) );
                } else {

                    CompletableFuture< Boolean > awsFuture = awsUploadService.uploadAsync( entryName, tempFile, ioExecutor ).orTimeout( 5, TimeUnit.MINUTES ).thenApply( v -> true ).exceptionally( ex -> {
                        logger.error( "processZipFileFromGcs :: AWS upload failed for file {}: {}", entryName, ex.getMessage( ) );
                        return false;
                    } );
                    logger.info( "processZipFileFromGcs :: device Serial Number: {}", metadata.deviceSerialNumber( ) );
                    String dicomStoreUrl = dbService.getDicomStroreUrl( metadata.deviceSerialNumber( ) );
                    CompletableFuture< Boolean > gcpFuture = dicomStoreUploadService.uploadAsync( entryName, tempFile, dicomStoreUrl, ioExecutor ).orTimeout( 5, TimeUnit.MINUTES ).thenApply( v -> true ).exceptionally( ex -> {
                        logger.error( "processZipFileFromGcs :: GCP upload failed for file {}: {}", entryName, ex.getMessage( ) );
                        return false;
                    } );
                    uploadFutures.add( awsFuture );
                    uploadFutures.add( gcpFuture );
                    CompletableFuture< Void > cleanupFuture = CompletableFuture.allOf(awsFuture, gcpFuture ).whenComplete( ( v, ex ) -> {
                        boolean deleted = tempFile.delete( );
                        if ( deleted ) {
                            logger.info( "processZipFileFromGcs :: Else Temp file deleted: {}", tempFile.getAbsolutePath( ) );
                        } else {
                            logger.error( "processZipFileFromGcs :: Else Failed to delete temp file: {}", tempFile.getAbsolutePath( ) );
                        }
                    } );

                    uploadFutures.add( cleanupFuture.thenApply( v -> true ) );
                }

                zipInputStream.closeEntry( );
            }

            List< Boolean > results = CompletableFuture.allOf( uploadFutures.toArray( new CompletableFuture[ 0 ] ) ).thenApply( v -> uploadFutures.stream( ).map( CompletableFuture::join ).collect( Collectors.toList( ) ) ).join( );
            logger.info( "processZipFileFromGcs :: Total entries in ZIP: {}", totalEntries );
            logger.info( "processZipFileFromGcs :: Valid DICOM files: {}", dicomFileCount );
            boolean allSucceeded = results.stream( ).allMatch( Boolean::booleanValue );

            if ( allSucceeded ) {
                storage.delete( blobId );
                logger.info( "processZipFileFromGcs :: All uploads succeeded. GCS file deleted." );
            } else {
                logger.error( "processZipFileFromGcs :: Some uploads failed. GCS file retained." );
            }

            if ( !altUploadFutures.isEmpty( ) ) {
                boolean allAltSucceeded = altUploadFutures.stream( ).allMatch( CompletableFuture::join );

                if ( allAltSucceeded ) {
                    sendNotification( metadataForNotification );
                    logger.info( "Kafka notification sent for matched metadata." );
                } else {
                    logger.warn( "Some alternate uploads failed. Kafka notification skipped." );
                }
            }

        } catch ( IOException e ) {
            throw new TechcyteException( "Error processing zip file", e );
        }
    }

    private void sendNotification ( DicomMetadata metadataNotification ) {
        try {
            PathQa pathQa = new PathQa( metadataNotification.barcode( ), metadataNotification.studyInstanceUid( ), metadataNotification.seriesInstanceUid( ), metadataNotification.deviceSerialNumber( ) );
            String payload = objectMapper.writeValueAsString( pathQa );
            kafkaNotifier.notify( kafkaTopicConfig.getPathqa( ), metadataNotification.barcode( ), payload );
            logger.info( "sendKafkaNotification :: Kafka notification sent for barcode: {}", metadataNotification.barcode( ) );
        } catch ( Exception e ) {
            logger.error( "Failed to send Kafka notification for barcode {}: {}", metadataNotification.barcode( ), e.getMessage( ) );
        }
    }

    private boolean isDicomFile ( String fileName ) {
        String lower = fileName.toLowerCase( Locale.ROOT );
        return ( lower.endsWith( ".dcm" ) || lower.endsWith( ".dicom" ) ) && lower.contains( "." );
    }
}
