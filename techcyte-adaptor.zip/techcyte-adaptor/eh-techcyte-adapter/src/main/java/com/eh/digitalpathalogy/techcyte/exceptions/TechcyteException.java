package com.eh.digitalpathalogy.techcyte.exceptions;

public class TechcyteException extends RuntimeException{

    public TechcyteException(String message) {
        super(message);
    }

    public TechcyteException(String message, Throwable cause) {
        super(message, cause);
    }
}
