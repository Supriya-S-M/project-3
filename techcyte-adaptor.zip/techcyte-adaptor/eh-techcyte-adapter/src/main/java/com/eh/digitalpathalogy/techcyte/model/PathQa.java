package com.eh.digitalpathalogy.techcyte.model;

public record PathQa(String barcodeValue, String studyInstanceUid, String seriesInstanceUid, String deviceSerialNumber) {
}
