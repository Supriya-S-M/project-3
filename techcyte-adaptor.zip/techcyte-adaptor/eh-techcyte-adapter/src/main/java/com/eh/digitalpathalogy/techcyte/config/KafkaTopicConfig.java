package com.eh.digitalpathalogy.techcyte.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka.topic")
@RefreshScope
public class KafkaTopicConfig {

    private String pathqa;

    public String getPathqa ( ) {
        return pathqa;
    }

    public void setPathqa ( String pathqa ) {
        this.pathqa = pathqa;
    }
}
