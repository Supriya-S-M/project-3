package com.eh.digitalpathalogy.techcyte.utils;

import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.eh.digitalpathalogy.techcyte.model.DicomMetadata;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.io.DicomInputStream;

import java.io.File;
import java.io.IOException;

public class DicomMetadataExtractor {


    public static DicomMetadata extractMetadata( File dicomFile) {
        try ( DicomInputStream dis = new DicomInputStream(dicomFile)) {
            Attributes attrs = dis.readDataset();

            String barcode = attrs.getString( Tag.BarcodeValue);
            String deviceSerialNumber = attrs.getString(Tag.DeviceSerialNumber);
            String studyInstanceUID = attrs.getString(Tag.StudyInstanceUID);
            String seriesInstanceUID = attrs.getString(Tag.SeriesInstanceUID);

            return new DicomMetadata(barcode, seriesInstanceUID, studyInstanceUID, deviceSerialNumber);
        } catch ( IOException e) {
            throw new TechcyteException("Failed to read DICOM file: " + dicomFile.getName(), e);
        }
    }
}
