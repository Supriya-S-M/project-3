package com.eh.digitalpathalogy.techcyte.service;

import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

@Service
public class PubSubPullService {
    private static final String PROJECT_ID = "prj-d-path-integration-cs1h";
    private static final String SUBSCRIPTION_ID = "techcyte-sub";
    private static final Logger logger = LoggerFactory.getLogger( PubSubPullService.class.getName( ) );
    private final NotificationService notificationService;

    public PubSubPullService ( NotificationService notificationService ) {
        this.notificationService = notificationService;
    }

    @EventListener( ApplicationReadyEvent.class )
    public void startPulling ( ) {
        ProjectSubscriptionName subscriptionName = ProjectSubscriptionName.of( PROJECT_ID, SUBSCRIPTION_ID );

        Subscriber subscriber = Subscriber.newBuilder( subscriptionName, ( PubsubMessage message, AckReplyConsumer consumer ) -> {
            String payload = message.getData( ).toStringUtf8( );
            logger.info( "Received pull message: {}", payload );
            consumer.ack( );
            notificationService.processNotifications( payload );
        } ).build( );

        subscriber.startAsync( ).awaitRunning( );
        logger.info( "Started pulling messages..." );
    }
}

