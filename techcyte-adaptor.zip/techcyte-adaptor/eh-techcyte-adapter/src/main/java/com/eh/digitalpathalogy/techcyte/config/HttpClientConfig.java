package com.eh.digitalpathalogy.techcyte.config;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HttpClientConfig {


    @Bean
    public CloseableHttpClient closeableHttpClient ( ) {
        RequestConfig config = RequestConfig.custom( ).setSocketTimeout( 300000 ).setConnectTimeout( 300000 ).setConnectionRequestTimeout( 300000 ).build( );

        return HttpClients.custom( ).setDefaultRequestConfig( config ).setConnectionReuseStrategy( DefaultConnectionReuseStrategy.INSTANCE ).build( );
    }

}
