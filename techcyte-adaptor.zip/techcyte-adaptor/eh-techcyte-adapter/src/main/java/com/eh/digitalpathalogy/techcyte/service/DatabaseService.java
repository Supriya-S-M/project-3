package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.DBRestClient;
import com.eh.digitalpathalogy.techcyte.exceptions.DbConnectorExeption;
import com.eh.digitalpathalogy.techcyte.model.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class DatabaseService {
    private static final Logger log = LoggerFactory.getLogger( DatabaseService.class.getName( ) );

    private final DBRestClient dbRestClient;


    public DatabaseService ( DBRestClient dbRestClient ) {
        this.dbRestClient = dbRestClient;
    }


    public Boolean isBarcodeExists ( String barcode ) {
        try {
            return dbRestClient.exchange( HttpMethod.GET, "qaslide/barcode/" + barcode, null, new ParameterizedTypeReference< ApiResponse< Boolean >>( ) {
            }, null ).map( ApiResponse::content ).block( );
        } catch ( Exception ex ) {
            throw new DbConnectorExeption(  "DB error", ex.getMessage( ) );
        }
    }

    public String getDicomStroreUrl ( String deviceSerialNumber ) {
        String url = "scanner/" + deviceSerialNumber;

        try {
            return dbRestClient.exchange(HttpMethod.GET, url, null, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, null)
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new DbConnectorExeption("Invalid error", ex.getMessage());
        }
    }

}