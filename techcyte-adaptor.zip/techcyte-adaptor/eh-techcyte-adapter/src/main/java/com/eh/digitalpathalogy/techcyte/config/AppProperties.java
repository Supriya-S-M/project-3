package com.eh.digitalpathalogy.techcyte.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
@ConfigurationProperties(prefix = "aws")
public class AppProperties {

    private Client client;
    private Token token;
    private Upload upload;

    public Client getClient ( ) {
        return client;
    }

    public void setClient ( Client client ) {
        this.client = client;
    }

    public Token getToken ( ) {
        return token;
    }

    public void setToken ( Token token ) {
        this.token = token;
    }

    public Upload getUpload ( ) {
        return upload;
    }

    public void setUpload ( Upload upload ) {
        this.upload = upload;
    }

    public static class Client{
        private String clientId;
        private String clientSecret;

        public String getClientId ( ) {
            return clientId;
        }

        public void setClientId ( String clientId ) {
            this.clientId = clientId;
        }

        public String getClientSecret ( ) {
            return clientSecret;
        }

        public void setClientSecret ( String clientSecret ) {
            this.clientSecret = clientSecret;
        }
    }

    public static class Token{
        private String endpoint;

        public String getEndpoint ( ) {
            return endpoint;
        }

        public void setEndpoint ( String endpoint ) {
            this.endpoint = endpoint;
        }
    }

    public static class Upload{
        private String endpoint;

        public String getEndpoint ( ) {
            return endpoint;
        }

        public void setEndpoint ( String endpoint ) {
            this.endpoint = endpoint;
        }
    }
}
