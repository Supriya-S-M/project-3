package com.eh.digitalpathalogy.techcyte.config;

import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Configuration
public class ExecutorConfig {

    private static final Logger log = LoggerFactory.getLogger( ExecutorConfig.class );

    private ExecutorService zipIngestExecutor;
    private ExecutorService notificationServiceExecutor;
    private ExecutorService gcpStorageExecutor;

    @Bean( name = "zipIngestExecutor" )
    public ExecutorService zipIngestExecutor ( ) {
        this.zipIngestExecutor = Executors.newCachedThreadPool( );
        return this.zipIngestExecutor;
    }
    @Bean( name = "notificationServiceExecutor" )
    public ExecutorService notificationServiceExecutor ( ) {
        this.notificationServiceExecutor = Executors.newScheduledThreadPool( Runtime.getRuntime( ).availableProcessors( ) );
        return this.notificationServiceExecutor;
    }
    @Bean( name = "gcpStorageExecutor" )
    public ExecutorService gcpStorageExecutor ( ) {
        this.gcpStorageExecutor = Executors.newScheduledThreadPool( Runtime.getRuntime( ).availableProcessors( ) );
        return this.gcpStorageExecutor;
    }

    @PreDestroy
    public void shutdownExecutors ( ) {
        shutdownExecutor( zipIngestExecutor, "Zip Ingest ExecutorService" );
        shutdownExecutor( notificationServiceExecutor, "Notification Service ExecutorService" );
        shutdownExecutor( gcpStorageExecutor, "Gcp Storage ExecutorService" );
    }

    private void shutdownExecutor ( ExecutorService executor, String name ) {
        if ( executor != null ) {
            executor.shutdown( );
            try {
                if ( !executor.awaitTermination( 60, TimeUnit.SECONDS ) ) {
                    executor.shutdownNow( );
                    if ( !executor.awaitTermination( 60, TimeUnit.SECONDS ) ) {
                        log.error( "{} did not terminate", name );
                    }
                }
            } catch ( InterruptedException ex ) {
                executor.shutdownNow( );
                Thread.currentThread( ).interrupt( );
            }
        }
    }
}
