package com.eh.digitalpathalogy.techcyte.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutorService;

@Service
public class NotificationService {
    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class.getName());
    private final ZipIngestService zipIngestService;
    private final ExecutorService executorService;

    public NotificationService(ZipIngestService zipIngestService, @Qualifier("notificationServiceExecutor") ExecutorService executorService) {
        this.zipIngestService = zipIngestService;
        this.executorService = executorService;
    }

    public ResponseEntity<String> processNotifications(String messagePayload) {
        try {
            if (messagePayload == null || messagePayload.isEmpty()) {
                logger.error("processNotifications :: Message payload is null or empty");
                return ResponseEntity.badRequest().body("Message payload is null or empty");
            }

            ObjectMapper mapper = new ObjectMapper();
            JsonNode root = mapper.readTree(messagePayload);
            String name = root.path("name").asText();
            String bucket = root.path("bucket").asText();

            if (!name.endsWith(".zip")) {
                logger.info("processNotifications :: Skipping non-ZIP file: {}", name);
                return ResponseEntity.ok("Non-ZIP file skipped");
            }
            executorService.submit(() -> zipIngestService.processZipFileFromGcs(bucket, name));
            return ResponseEntity.ok("ZIP file processing started");

        } catch ( JsonMappingException | JsonParseException e) {
            logger.error("processNotifications :: Failed to parse JSON: {}", e.getMessage());
            return ResponseEntity.badRequest().body("Failed to parse JSON");
        } catch (Exception e) {
            logger.error("processNotifications :: Unexpected error occurred while processing the notifications :: {}", e.getMessage());
            return ResponseEntity.status( HttpStatus.INTERNAL_SERVER_ERROR).body("Unexpected error occurred");
        }
    }
}
