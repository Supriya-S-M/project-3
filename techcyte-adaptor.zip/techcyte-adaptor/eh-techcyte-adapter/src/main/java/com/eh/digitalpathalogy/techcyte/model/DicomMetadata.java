package com.eh.digitalpathalogy.techcyte.model;

public record DicomMetadata(String barcode, String seriesInstanceUid, String studyInstanceUid, String deviceSerialNumber) {
}
