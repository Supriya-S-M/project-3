package com.eh.digitalpathalogy.techcyte.service;


import com.eh.digitalpathalogy.techcyte.config.AppProperties;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

@Service
public class AWSTokenService {

    private final AppProperties appProperties;
    private final CloseableHttpClient httpClient;

    private final ReentrantLock lock = new ReentrantLock( );
    private volatile String cachedToken;
    private volatile Instant expiryTime;

    public AWSTokenService ( AppProperties appProperties, CloseableHttpClient httpClient ) {
        this.appProperties = appProperties;
        this.httpClient = httpClient;
    }

    public String getValidToken ( ) {
        if ( cachedToken != null && expiryTime != null && Instant.now( ).isBefore( expiryTime.minusSeconds( 60 ) ) ) {
            return cachedToken;
        }
        lock.lock( );
        try {
            if ( cachedToken != null && expiryTime != null && Instant.now( ).isBefore( expiryTime.minusSeconds( 60 ) ) ) {
                return cachedToken;
            }
            return refreshToken( );
        } finally {
            lock.unlock( );
        }
    }

    private String refreshToken ( ) {
        try {
            HttpPost post = new HttpPost( appProperties.getToken( ).getEndpoint( ) );
            post.setHeader( "Content-Type", "application/x-www-form-urlencoded" );
            List< NameValuePair > params = new ArrayList<>( );
            params.add( new BasicNameValuePair( "grant_type", "client_credentials" ) );
            params.add( new BasicNameValuePair( "client_id", appProperties.getClient( ).getClientId( ) ) ); // Replace with actual client ID
            params.add( new BasicNameValuePair( "client_secret", appProperties.getClient( ).getClientSecret( ) ) ); // Replace with actual client secret
            post.setEntity( new UrlEncodedFormEntity( params ) );

            try ( CloseableHttpResponse response = httpClient.execute( post ) ) {
                int statusCode = response.getStatusLine( ).getStatusCode( );
                if ( statusCode == 200 ) {
                    String responseBody = EntityUtils.toString( response.getEntity( ) );
                    // Parse the response to extract token and expiry
                    JsonNode jsonNode = new ObjectMapper( ).readTree( responseBody );
                    cachedToken = jsonNode.path( "access_token" ).asText( );
                    int expiresIn = jsonNode.path( "expires_in" ).asText( ).isEmpty( ) ? 3600 : Integer.parseInt( jsonNode.path( "expires_in" ).asText( ) );
                    expiryTime = Instant.now( ).plusSeconds( expiresIn );
                    return cachedToken;
                } else {
                    throw new TechcyteException( "Failed to fetch token, status code: " + statusCode );
                }
            }
        } catch ( Exception e ) {
            throw new TechcyteException( "Error fetching token " + e.getMessage() );
        }

    }

    public void forceRefreshToken ( ) {
        lock.lock( );
        try {
            cachedToken = null;
            expiryTime = null;
            refreshToken( );
        } finally {
            lock.unlock( );
        }
    }
}
