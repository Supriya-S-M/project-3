package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.GcpConfig;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import com.eh.digitalpathalogy.techcyte.utils.GCPUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.concurrent.*;

@Service
public class GcpStorageService {

    private final Logger log = LoggerFactory.getLogger( GcpStorageService.class.getName( ) );
    private final GcpConfig gcpConfig;
    private final ExecutorService executorService;
    private final CloseableHttpClient httpClient;

    public GcpStorageService ( GcpConfig gcpConfig, @Qualifier( "gcpStorageExecutor" ) ExecutorService executorService, CloseableHttpClient httpClient ) {
        this.gcpConfig = gcpConfig;
        this.executorService = executorService;
        this.httpClient = httpClient;
    }

    public CompletableFuture< Void > uploadAsync ( String fileName, File file, String dicomUrl, ExecutorService executor ) {
        return CompletableFuture.runAsync( ( ) -> {
            try {
                uploadToDicomStore( fileName, file, dicomUrl );
            } catch ( IOException e ) {
                throw new TechcyteException( "DICOM Store upload failed for " + fileName, e );
            }
        }, executor );
    }

    private void uploadToDicomStore ( String fileName, File file, String dicomUrl ) throws IOException {
        log.info( "uploadToDicomStore :: Starting upload of file: {}", fileName );
        String uri = String.format( "%s/%s/dicomWeb/studies", gcpConfig.getDicomWebUrl( ), dicomUrl );
        log.info( "uploadToDicomStore :: Upload URI: {}", uri );

        String accessToken = GCPUtils.getAccessToken( gcpConfig );

        try ( PipedInputStream pipedInputStream = new PipedInputStream( 1048576 ); PipedOutputStream pipedOutputStream = new PipedOutputStream( pipedInputStream ) ) {
            // Write file contents to pipedOutputStream in a separate thread
            Future< ? > writeTask = executorService.submit( ( ) -> {
                try ( FileInputStream fis = new FileInputStream( file ) ) {
                    byte[] buffer = new byte[ 1048576 ];
                    int bytesRead;
                    while ( ( bytesRead = fis.read( buffer ) ) != -1 ) {
                        pipedOutputStream.write( buffer, 0, bytesRead );
                    }
                } catch ( IOException e ) {
                    throw new UncheckedIOException( "Failed to stream DICOM file", e );
                } finally {
                    try {
                        pipedOutputStream.close( );
                    } catch ( IOException ignored ) {
                        //Exception ignored
                    }
                }
            } );

            HttpPost httpPost = new HttpPost( uri );
            httpPost.setHeader( HttpHeaders.CONTENT_TYPE, "application/dicom" );
            if ( accessToken != null && !accessToken.isEmpty( ) ) {
                httpPost.setHeader( HttpHeaders.AUTHORIZATION, "Bearer " + accessToken );
            }

            HttpEntity entity = new InputStreamEntity( pipedInputStream );
            httpPost.setEntity( entity );

            try ( CloseableHttpResponse response = httpClient.execute( httpPost ) ) {
                int statusCode = response.getStatusLine( ).getStatusCode( );
                if ( statusCode == 200 || statusCode == 201 ) {
                    log.info( "uploadToDicomStore :: Upload successful for file: {}", fileName );

                    try {
                        writeTask.get( 5, TimeUnit.MINUTES );
                    } catch ( InterruptedException | ExecutionException e ) {
                        Thread.currentThread( ).interrupt( );
                        log.error( "uploadToDicomStore :: Write task was interrupted", e );
                    } catch ( TimeoutException e ) {
                        writeTask.cancel( true );
                        log.error( "uploadToDicomStore :: Write task timed out", e );
                    }

                } else {
                    writeTask.cancel( true );
                    log.error( "uploadToDicomStore :: Upload failed. Status: {}, Response: {}", statusCode, response.getStatusLine().getReasonPhrase() );
                    throw new IOException( "DICOM upload failed, status = " + statusCode );
                }
            }
        }
    }

}
