package com.eh.digitalpathalogy.techcyte.service;

import com.eh.digitalpathalogy.techcyte.config.AppProperties;
import com.eh.digitalpathalogy.techcyte.exceptions.TechcyteException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;

@Service
public class AwsUploadService {

    private final Logger log = LoggerFactory.getLogger( AwsUploadService.class.getName( ) );
    private final AWSTokenService awsTokenService;
    private final AppProperties appProperties;
    private final CloseableHttpClient httpClient;

    public AwsUploadService ( AWSTokenService awsTokenService, AppProperties appProperties, CloseableHttpClient httpClient ) {
        this.awsTokenService = awsTokenService;
        this.appProperties = appProperties;
        this.httpClient = httpClient;
    }


    public CompletableFuture< Void > uploadAsync ( String fileName, File file, ExecutorService executor ) {
        return CompletableFuture.runAsync( ( ) -> {
            try {
                uploadToAws( fileName, file );
            } catch ( IOException e ) {
                throw new TechcyteException( "AWS upload failed for " + fileName, e );
            }
        }, executor );
    }

    public void uploadToAws ( String fileName, File file ) throws IOException {

        log.info( "uploadToAws :: Starting upload of file: {} of file size :: {}", fileName, file.length() );
        log.info( "uploadToAws :: Endpoint: {}", appProperties.getUpload( ).getEndpoint( ) );

        int maxRetries = 3;
        boolean retry = false;

        for ( int attempt = 1; attempt <= maxRetries; attempt++ ) {
            try ( FileInputStream fis = new FileInputStream( file ) ) {
                HttpPost post = getHttpPost( file, fis );

                try ( CloseableHttpResponse response = httpClient.execute( post ) ) {
                    int statusCode = response.getStatusLine( ).getStatusCode( );
                    if ( statusCode == 200 || statusCode == 201 ) {
                        log.info( "uploadToAws :: Upload successful for file: {}", fileName );
                        return;
                    } else if ( statusCode == 401 && !retry ) {
                        log.warn( "uploadToAws :: Unauthorized, refreshing token..." );
                        awsTokenService.forceRefreshToken( );
                        retry = true;
                    } else {
                        String responseBody = EntityUtils.toString( response.getEntity( ) );
                        log.error( "uploadToAws :: Attempt {} failed for file {}. Status: {}, Reason: {}, Response: {} ", attempt, fileName, statusCode, response.getStatusLine().getReasonPhrase(), responseBody );
                        if ( attempt == maxRetries ) {
                            throw new IOException( "AWS upload failed after retries, status = " + statusCode );
                        }
                    }
                }
            } catch ( IOException e ) {
                log.error( "uploadToAws :: IOException :: Attempt {} failed for file {}: {}", attempt, fileName, e.getMessage( ));
                if ( attempt == maxRetries ) throw new IOException( "AWS upload failed after retries" + attempt);
                try {
                    Thread.sleep( 1000L * attempt ); // Exponential backoff
                } catch ( InterruptedException ie ) {
                    Thread.currentThread( ).interrupt( );
                    log.error( "uploadToAws :: Thread was interrupted :: ie :: {}", ie.getMessage() );
                }
            }
        }
    }

    private HttpPost getHttpPost ( File file, FileInputStream fis ) {
        String token = awsTokenService.getValidToken( );

        HttpPost post = new HttpPost( appProperties.getUpload( ).getEndpoint( ) );
        post.setHeader( "Authorization", "Bearer " + token );
        post.setHeader( "Content-Type", "application/dicom" );

        InputStreamEntity entity = new InputStreamEntity( fis, file.length() );
        post.setEntity( entity );
        return post;
    }


}
