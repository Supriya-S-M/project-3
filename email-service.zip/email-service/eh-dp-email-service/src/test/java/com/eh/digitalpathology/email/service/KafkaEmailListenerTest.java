package com.eh.digitalpathology.email.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import static org.mockito.Mockito.*;

class KafkaEmailListenerTest {

    @Mock
    private EmailService emailService;

    @InjectMocks
    private KafkaEmailListener kafkaEmailListener;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testListen_shouldInvokeEmailService() {
        // Arrange
        String key = "DEFAULT";
        String value = "ABC123";
        ConsumerRecord<String, String> records = new ConsumerRecord<>("test-topic", 0, 0L, key, value);

        // Act
        kafkaEmailListener.listen(records);

        // Assert
        verify(emailService).sendEmail(key, value);
    }

    @Test
    void testListen_shouldHandleExceptionGracefully() {
        // Arrange
        String key = "DEFAULT";
        String value = "ABC123";
        ConsumerRecord<String, String> records = new ConsumerRecord<>("test-topic", 0, 0L, key, value);

        doThrow(new RuntimeException("Simulated failure")).when(emailService).sendEmail(key, value);

        // Act
        kafkaEmailListener.listen(records);

        // Assert
        verify(emailService).sendEmail(key, value);
        // No exception should propagate
    }
}