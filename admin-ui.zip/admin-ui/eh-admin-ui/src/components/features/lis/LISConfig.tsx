import React, { useEffect, useState } from "react";
import { Database, Edit, Save, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../../ui/card";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Label } from "../../ui/label";
import { useSelector } from "react-redux";
import { fetchEhTool, patchEhTool } from "../../../store/slices/ehToolsSlice";
import { toast } from "sonner";
import { useAppDispatch } from "../../../hooks";

export function LisConfig() {
  const dispatch = useAppDispatch();
  const { lisConnector, loading } = useSelector((s: any) => s.ehTools || {});

  const [editMode, setEditMode] = useState(false);
  const [initialized, setInitialized] = useState(false);

  const [form, setForm] = useState({
    applicationName: "",
    ipAddress: "",
    receivingPort: "",
    incomingPort: "",
    receivingFacility: "",
    receivingAppName: "",
    sendingFacility: "",
  });

  const [originalForm, setOriginalForm] = useState(form);

  // Fetch initial data
  useEffect(() => {
    dispatch(fetchEhTool({ toolKey: "eh-lis-connector" }));
  }, [dispatch]);

  // Sync data from Redux to form
  useEffect(() => {
    if (!lisConnector || Object.keys(lisConnector).length === 0 || initialized) return;

    const newData = {
      applicationName: lisConnector.appName || lisConnector.name || "",
      ipAddress: lisConnector.ipAddress || "",
      receivingPort: lisConnector.port?.toString() || "",
      incomingPort: lisConnector["incoming-port"]?.toString() || "",
      receivingFacility: lisConnector.receivingFacility || "",
      receivingAppName: lisConnector.receivingAppName || "",
      sendingFacility: lisConnector.sendingFacility || "",
    };

    setForm(newData);
    setOriginalForm(newData);
    setInitialized(true);
  }, [lisConnector, initialized]);

  const handleEdit = (enable: boolean) => {
    setEditMode(enable);
    if (!enable) setForm(originalForm);
  };

  const handleChange = (field: string, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const getChangedFields = (current: any, original: any) => {
    const diff: any = {};
    Object.keys(current).forEach((k) => {
      if ((current[k] || "").toString().trim() !== (original[k] || "").toString().trim()) {
        diff[k] = current[k];
      }
    });
    return diff;
  };

  const handleSave = async () => {
    const changes = getChangedFields(form, originalForm);
    
    if (Object.keys(changes).length === 0) {
      toast.info("No changes detected");
      setEditMode(false);
      return;
    }

    const body: any = {};
    if (changes.applicationName) body.appName = changes.applicationName;
    if (changes.ipAddress) body.ipAddress = changes.ipAddress;
    if (changes.receivingPort) body.port = parseInt(changes.receivingPort);
    if (changes.incomingPort) body["incoming-port"] = parseInt(changes.incomingPort);
    if (changes.receivingFacility !== undefined) body.receivingFacility = changes.receivingFacility;
    if (changes.receivingAppName !== undefined) body.receivingAppName = changes.receivingAppName;
    if (changes.sendingFacility !== undefined) body.sendingFacility = changes.sendingFacility;

    try {
      await dispatch(patchEhTool({ toolKey: "eh-lis-connector", body })).unwrap();
      toast.success("LIS configuration updated successfully");
      setOriginalForm(form);
      setEditMode(false);
    } catch (error) {
      console.error("Update error:", error);
      toast.error("Update failed. Please try again.");
    }
  };

  const renderInput = (field: string, label: string, disabled: boolean) => (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-gray-700">{label}</Label>
      <Input
        value={(form as any)[field] ?? ""}
        onChange={(e) => handleChange(field, e.target.value)}
        disabled={disabled}
        className={disabled ? "bg-gray-50 text-gray-600" : ""}
      />
      
    </div>
  );

  return (
    <div className="space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">LIS Application Details</h1>
        
        <Card className="border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Database className="h-5 w-5 text-blue-600" />
              LIS Connector
            </CardTitle>
          </CardHeader>
          <CardContent className="relative">
            <div className="grid md:grid-cols-2 gap-6 pb-16">
              {renderInput("applicationName", "Name of LIS", !editMode)}
              {renderInput("ipAddress", "IP Address", !editMode)}
              {renderInput("receivingPort", "Receiving Port", !editMode)}
              {renderInput("incomingPort", "Incoming Port", !editMode)}
              {/* {renderInput("receivingFacility", "Receiving Facility", !editMode)}
              {renderInput("receivingAppName", "Receiving App Name", !editMode)}
              {renderInput("sendingFacility", "Sending Facility", !editMode)} */}
            </div>

            <div className="mt-4 bottom-4 right-4 flex gap-2">
              {editMode ? (
                <>
                  <Button size="sm" onClick={handleSave} disabled={loading}>
                    <Save className="h-4 w-4 mr-1" /> Save
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleEdit(false)}>
                    <X className="h-4 w-4 mr-1" /> Cancel
                  </Button>
                </>
              ) : (
                <Button size="sm" onClick={() => handleEdit(true)}>
                  <Edit className="h-4 w-4 mr-1" /> Edit
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}