package com.eh.digitalpathology.dbconnector.controllers;

import com.eh.digitalpathology.dbconnector.dtos.CaseStudyDto;
import com.eh.digitalpathology.dbconnector.dtos.DicomDirDto;
import com.eh.digitalpathology.dbconnector.dtos.QidoResponseDto;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.mappers.CaseStudiesMapper;
import com.eh.digitalpathology.dbconnector.mappers.DicomDirMapper;
import com.eh.digitalpathology.dbconnector.mappers.QidoRsMapper;
import com.eh.digitalpathology.dbconnector.model.*;
import com.eh.digitalpathology.dbconnector.services.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping( "api" )
public class DatabaseRestController {
    private final Hl7Service hl7Service;
    private final DicomService dicomService;
    private final EnrichedService enrichedService;
    private final DicomDirService dicomDirService;
    private final DicomDirMapper dicomDirMapper;
    private final QidoRsMapper qidoRsMapper;
    private final CaseStudiesMapper caseStudiesMapper;
    private final ScannerService scannerService;
    private static final Logger log = LoggerFactory.getLogger( DatabaseRestController.class.getName( ) );

    @Autowired
    public DatabaseRestController ( Hl7Service hl7Service, DicomService dicomService, EnrichedService enrichedService, DicomDirService dicomDirService, DicomDirMapper dicomDirMapper, QidoRsMapper qidoRsMapper, CaseStudiesMapper caseStudiesMapper, ScannerService scannerService ) {
        log.info( "database rest controller initialized" );
        this.scannerService = scannerService;
        this.qidoRsMapper = qidoRsMapper;
        this.caseStudiesMapper = caseStudiesMapper;
        this.dicomDirMapper = dicomDirMapper;
        this.dicomDirService = dicomDirService;
        this.hl7Service = hl7Service;
        this.dicomService = dicomService;
        this.enrichedService = enrichedService;
    }

    @PostMapping( "hl7/persists" )
    public ResponseEntity< ApiResponse< Map< String, String > > > persistsMessage ( @RequestHeader( value = "X-Service-Name" ) String serviceName, @RequestBody Hl7MessageRequest hl7MessageRequest ) throws DatabaseException {
        log.info( "persistsMessage :: hl7MessageRequest:: {}", hl7MessageRequest );
        Map< String, String > response = hl7Service.savedHl7Message( serviceName, hl7MessageRequest );
        log.info( "persistsMessage:: response:: {}", response );
        return ResponseEntity.ok( ApiResponse.success( response ) );
    }

    @GetMapping( "hl7/search/barcode/{barcode}" )
    public ResponseEntity< ApiResponse< Map< String, Set< String > > > > fetchHl7MessageTypesForBarcode ( @PathVariable String barcode, HttpServletRequest request ) throws DatabaseException {
        log.info( "fetchHl7MessageTypesForBarcode :: barcode:: {}", barcode );

        String ipAddress = request.getHeader("X-Forwarded-For");
        if (ipAddress == null || ipAddress.isEmpty()) {
            ipAddress = request.getRemoteAddr(); // fallback if no proxy
        }
        log.info("Request received from IP: {}", ipAddress);

        Map< String, Set< String > > response = hl7Service.searchMessageTypeByBarcode( barcode );
        log.info( "fetchHl7MessageTypesForBarcode :: response from db:: {}", response );
        return ResponseEntity.ok( ApiResponse.success( response ) );
    }

    @PutMapping( "dicom/status/instances" )
    public ResponseEntity< ApiResponse< String > > updateStatusForInstanceId ( @RequestHeader( value = "X-Service-Name" ) String serviceName, @RequestBody BarcodeInstanceRequest barcodeInstanceRequest ) throws DatabaseException {
        log.info( "updateStatusForInstanceId :: barcode:: {}", barcodeInstanceRequest.barcode( ) );
        String status = dicomService.updateStatus( serviceName, barcodeInstanceRequest.barcode( ), barcodeInstanceRequest.sopInstanceUid( ) );
        log.info( "updateStatusForInstanceId :: status after updating to db:: {}", status );
        return ResponseEntity.ok( ApiResponse.success( status ) );
    }

    @PostMapping( "dicom/instances" )
    public ResponseEntity< ApiResponse< String > > persistsDicomInstances ( @RequestHeader( value = "X-Service-Name" ) String serviceName, @Valid @RequestBody CaseStudyDto dicomInstance ) throws DatabaseException {
        CaseStudy caseStudy = caseStudiesMapper.toEntity( dicomInstance );
        log.info( "persistsDicomInstances :: caseStudy:: {}", caseStudy );
        String status = dicomService.persists( serviceName, caseStudy );
        log.info( "persistsDicomInstances :: status after inserting to db:: {}", status );
        return ResponseEntity.ok( ApiResponse.success( status ) );
    }

    @GetMapping( "enriched/instances" )
    public ResponseEntity< ApiResponse< EnrichedResponse > > fetchInstancePathAndMessages ( @RequestHeader( value = "X-Service-Name" ) String serviceName, @Valid @RequestBody EnrichedRequest enrichRequest ) throws DatabaseException {
        log.info( "fetchInstancePathAndMessages :: enriched request :: {}", enrichRequest );
        EnrichedResponse response = enrichedService.fetchDicomEnrichedData( serviceName, enrichRequest );
        log.info( "fetchInstancePathAndMessages:: response:: {}", response );
        return ResponseEntity.ok( ApiResponse.success( response ) );
    }

    @PutMapping( "enriched/status" )
    public ResponseEntity< ApiResponse< String > > updatedEnrichmentStatus ( @RequestHeader( value = "X-Service-Name" ) String serviceName, @Valid @RequestBody EnrichInstance enrichInstance ) throws DatabaseException {
        log.info( "updatedEnrichmentStatus :: enriched instances ::  {}", enrichInstance );
        String messages = enrichedService.updateEnrichedStatus( serviceName, enrichInstance );
        log.info( "updatedEnrichmentStatus :: messages :: {} ", messages );
        return ResponseEntity.ok( ApiResponse.success( messages ) );
    }

    @PostMapping( "dicom/dicomdir" )
    public ResponseEntity< ApiResponse< String > > saveMetaDataInfo ( @Valid @RequestBody DicomDirDto dicomDirDto ) throws DatabaseException {
        DicomDirDocument dicomDirDocument = dicomDirMapper.toEntity( dicomDirDto );
        log.info( "saveMetaDataInfo :: dicom dir document ::  {}", dicomDirDocument.studyId() );
        String messages = dicomDirService.saveMetaDataInfo( dicomDirDocument );
        log.info( "saveMetaDataInfo :: messages :: {} ", messages );
        return ResponseEntity.ok( ApiResponse.success( messages ) );
    }

    @GetMapping( "dicom/dicomdir/{series}" )
    public ResponseEntity< ApiResponse< DicomDirDocument > > getMetaDataInfo ( @PathVariable String series ) throws DatabaseException {
        log.info( "getMetaDataInfo :: series :: {}", series );
        DicomDirDocument dicomDirDocument = dicomDirService.getMetaDataInfo( series );
        log.info( "getMetaDataInfo :: dicom dir document :: {} ", dicomDirDocument.studyId() );
        return ResponseEntity.ok( ApiResponse.success( dicomDirDocument ) );
    }

    @PostMapping( "hl7/message" )
    public ResponseEntity< ApiResponse< String > > getHl7Message ( @Valid @RequestBody Hl7MessageServiceRequest hl7MessageServiceRequest ) throws DatabaseException {
        log.info( "getHl7Message :: hl7 message service request :: {}", hl7MessageServiceRequest );
        String responseMessage = hl7Service.fetchHl7Message( hl7MessageServiceRequest );
        log.info( "getHl7Message :: hl7 message service response :: {}", responseMessage );
        return ResponseEntity.ok( ApiResponse.success( responseMessage ) );
    }

    @GetMapping( "instances/{seriesUid}" )
    public ResponseEntity< ApiResponse< List< InstancesMeta > > > getInstancesOfSeries ( @PathVariable String seriesUid ) throws DatabaseException {
        log.info( "getInstancesOfSeries :: series :: {}", seriesUid );
        List< InstancesMeta > instances = dicomService.getInstancesOfSeries( seriesUid );
        log.info( "getInstancesOfSeries :: instances :: {}", instances );
        return ResponseEntity.ok( ApiResponse.success( instances ) );
    }

    @GetMapping( "instances/status/{seriesId}/{instanceId}" )
    public ResponseEntity< ApiResponse< String > > getStatusOfInstance ( @PathVariable String seriesId, @PathVariable String instanceId ) throws DatabaseException {
        log.info( "getStatusOfInstance :: series :: {}, instances :: {} ", seriesId, instanceId );
        String status = dicomService.fetchStatusOfInstance( seriesId, instanceId );
        log.info( "getStatusOfInstance :: status  :: {}", status );
        return ResponseEntity.ok( ApiResponse.success( status ) );
    }

    @PutMapping( "dicom/dicomdir" )
    public ResponseEntity< ApiResponse< String > > updateDicomDir ( @Valid @RequestBody DicomDirDto dicomDirDto ) throws DatabaseException {
        log.info( "updateDicomDir :: series :: {}", dicomDirDto.seriesId( ) );
        DicomDirDocument dicomDirDocument = dicomDirMapper.toEntity( dicomDirDto );
        String response = dicomDirService.updateDicomDir( dicomDirDocument );
        log.info( "updateDicomDir :: response  :: {}", response );
        return ResponseEntity.ok( ApiResponse.success( response ) );
    }

    @GetMapping( "dicom/instance/{sopInstanceUid}" )
    public ResponseEntity< ApiResponse< CaseStudyDto > > getDicomInstanceBySopInstanceUid ( @PathVariable String sopInstanceUid ) {
        log.info( "getDicomInstanceBySopInstanceUid :: sopInstanceUid :: {}", sopInstanceUid );
        CaseStudy instance = dicomService.getDicomInstanceBySopInstanceUid( sopInstanceUid );
        log.info( "getDicomInstanceBySopInstanceUid :: response :: {}", instance );
        return ResponseEntity.ok( ApiResponse.success( caseStudiesMapper.toDto(instance) ) );
    }


    @PostMapping( "dicom/storage-commitment" )
    public ResponseEntity< ApiResponse< String > > saveStorageCommitment ( @Valid @RequestBody StorageCommitmentRequest request ) {
        log.info( "saveStorageCommitment :: StorageCommitmentRequest :: {}", request );
        dicomService.saveStorageCommitmentTrackers(request.trackers());
        return ResponseEntity.ok( ApiResponse.success( "Saved" ) );
    }

    @PostMapping( "dicom/qidors" )
    public ResponseEntity< ApiResponse< String > > saveQidoRs ( @Valid @RequestBody QidoResponseDto response ) {
        log.info( "saveQidoRs:: QidoResponse  :: {}", response );
        QidoResponse qidoResponse = qidoRsMapper.toEntity( response );
        dicomService.saveQidoRs( qidoResponse );
        return ResponseEntity.ok( ApiResponse.success( "Saved" ) );
    }

    @GetMapping( "instances/request/{requestId}" )
    public ResponseEntity< ApiResponse< List< String > > > getInstancesByRequestId ( @PathVariable String requestId ) throws DatabaseException { //list of string
        log.info( "getInstancesByRequestId :: series :: {}", requestId );
        List< String > instances = dicomService.getInstancesByRequestId( requestId );
        log.info( "getInstancesByRequestId :: instances :: {}", instances );
        return ResponseEntity.ok( ApiResponse.success( instances ) );
    }

    @PostMapping( "series/instance" )
    public ResponseEntity< ApiResponse< List<String> > > getSeriesIdByInstanceId ( @RequestBody List<String> instanceIds ) throws DatabaseException { //fetch series id of all instances, treurn and then compare
        log.info( "getSeriesIdByInstanceId :: instancesIds :: {}", instanceIds );
        List<String> seriesIds = dicomService.getSeriesIdByInstanceId( instanceIds );
        log.info( "getSeriesIdByInstanceId :: seriesId :: {}", seriesIds );
        return ResponseEntity.ok( ApiResponse.success( seriesIds ) );
    }

    @GetMapping("qaslide/barcode/{barcode}" )
    public ResponseEntity< ApiResponse< Boolean > > isBarcodeExists ( @PathVariable String barcode ) throws DatabaseException {
        log.info( "getQaSlideByBarcode :: barcode :: {}", barcode );
        boolean isBarcodeAvailable = scannerService.isBarcodeExistsForQaSlide( barcode );
        log.info( "getQaSlideByBarcode :: qaSlide :: {}", isBarcodeAvailable);
        return ResponseEntity.ok( ApiResponse.success( isBarcodeAvailable ) );
    }

    @GetMapping("scanner/{deviceSerialNumber}" )
    public ResponseEntity< ApiResponse<String >> getScannerDicomStoreByDeviceSerialNumber ( @PathVariable String deviceSerialNumber ) throws DatabaseException {
        log.info( "getScannersByDeviceSerialNumber :: deviceSerialNumber :: {}", deviceSerialNumber );
        String dicomStoreUrl = scannerService.getScannerDicomStoreByDeviceSerialNumber( deviceSerialNumber );
        log.info( "getScannersByDeviceSerialNumber :: scanners :: {}", dicomStoreUrl );
        return ResponseEntity.ok( ApiResponse.success( dicomStoreUrl ) );
    }
}
