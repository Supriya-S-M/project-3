package com.eh.digitalpathology.dbconnector.model;

public record InstancesMeta (String barcode,String seriesInstanceUid, String sopInstanceUid, String status, String intermediatePath, String deviceSerialNumber){}

