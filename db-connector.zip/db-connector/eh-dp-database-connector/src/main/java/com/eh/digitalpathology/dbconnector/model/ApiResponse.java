package com.eh.digitalpathology.dbconnector.model;


public record ApiResponse< T >(
        String status,
        T content,
        String errorCode,
        String errorMessage
) {
    public static < T > ApiResponse< T > success ( T content ) {
        return new ApiResponse<>( "success", content, null, null );
    }

    public static < T > ApiResponse< T > error ( String errorCode, String errorMessage ) {
        return new ApiResponse<>( "failure", null, errorCode, errorMessage );
    }
}
