package com.eh.digitalpathology.dbconnector.model;

import com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum;

public class WorkflowStatus extends  BaseEntity {
    private WorkflowStatusEnum status;

    public WorkflowStatusEnum getStatus() {
        return status;
    }

    public void setStatus(WorkflowStatusEnum status) {
        this.status = status;
    }
}
