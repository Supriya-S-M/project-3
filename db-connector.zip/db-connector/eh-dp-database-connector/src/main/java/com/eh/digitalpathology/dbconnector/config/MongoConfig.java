package com.eh.digitalpathology.dbconnector.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

import java.util.concurrent.TimeUnit;


@Configuration
public class MongoConfig {

    @Value("${spring.data.mongodb.uri}")
    private String uri;

    @Value("${spring.data.mongodb.username:#{''}}")
    private String username;

    @Value("${spring.data.mongodb.password:#{''}}")
    private String password;

    @Value("${spring.data.mongodb.database}")
    private String databaseName;

    private MongoClient mongoClientInstance;

    private static final Logger log = LoggerFactory.getLogger(MongoConfig.class);

    @Bean
    @RefreshScope
    public MongoClient mongoClient() {
        MongoClientSettings.Builder settingBuilder = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(uri))
                .applyToConnectionPoolSettings(poolBuilder -> poolBuilder
                        .maxSize(100) // Adjust based on expected concurrency
                        .minSize(10)
                        .maxWaitTime(1000, TimeUnit.MILLISECONDS)
                );

        if (!username.isEmpty() && !password.isEmpty()) {
            settingBuilder.credential(MongoCredential.createCredential(username, "admin", password.toCharArray()));
            log.info("MongoDB username configured: {}", username);
        }

        mongoClientInstance =  MongoClients.create(settingBuilder.build());
        return mongoClientInstance;
    }

    @Bean(name = "customMongoDatabaseFactory")
    @Primary
    public MongoDatabaseFactory customMongoDatabaseFactory(MongoClient mongoClient) {
        return new SimpleMongoClientDatabaseFactory(mongoClient, databaseName);
    }

    @Bean(name = "customMappingMongoConverter")
    @Primary
    public MappingMongoConverter customMappingMongoConverter(@Qualifier("customMongoDatabaseFactory") MongoDatabaseFactory factory) {
        DefaultDbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
        MappingMongoConverter converter = new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        converter.setMapKeyDotReplacement("_"); // Replace dots with underscores
        return converter;
    }

    @Bean
    @Primary
    public MongoTemplate mongoTemplate(MongoClient mongoClient, @Qualifier("customMappingMongoConverter") MappingMongoConverter converter) {
        return new MongoTemplate(customMongoDatabaseFactory(mongoClient), converter);
    }

    @PreDestroy
    public void cleanUp() {
        if (mongoClientInstance != null) {
            log.info("cleanUp :: Closing MongoClient");
            mongoClientInstance.close();
        }
    }
}

