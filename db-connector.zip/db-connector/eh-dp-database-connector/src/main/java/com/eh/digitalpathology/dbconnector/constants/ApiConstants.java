package com.eh.digitalpathology.dbconnector.constants;

public final class ApiConstants {
    private ApiConstants(){
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static final String MESSAGE_TYPE = "messageType";
    public static final String BARCODE = "barcode";
    public static final String STATUS = "processingStatus";
    public static final String SOP_INSTANCE_ID = "sopInstanceUid";
    public static final String MSH = "MSH";
    public static final String ACTUAL_STUDY_ID = "actualStudyInstanceUid";
    public static final String ENRICHMENT_TIMESTAMP = "enrichmentTimestamp";

    public static final String STORAGE_PATH = "intermediateStoragePath";
    public static final String ORIGINAL_STUDY_ID = "originalStudyInstanceUid";
    public static final String SERIES_ID = "seriesInstanceUid";

    public static final String DICOMDIR_STUDY_ID = "studyId";
    public static final String DICOMDIR_SERIES_ID = "seriesId";
    public static final String DEVICE_SERIAL_NUMBER = "deviceSerialNumber";
    public static final String CASE_NUMBER = "caseNumber";

}
