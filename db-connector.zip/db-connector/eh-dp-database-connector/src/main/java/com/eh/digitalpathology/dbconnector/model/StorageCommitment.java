package com.eh.digitalpathology.dbconnector.model;

public record StorageCommitment(String seriesInstanceUid,int instanceCount ) {}
