package com.eh.digitalpathology.dbconnector.mappers;


import com.eh.digitalpathology.dbconnector.dtos.CaseStudyDto;
import com.eh.digitalpathology.dbconnector.model.CaseStudy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface CaseStudiesMapper {

    CaseStudiesMapper INSTANCE = Mappers.getMapper( CaseStudiesMapper.class);

    @Mapping( target = "id", ignore = true)
    @Mapping( target = "processingStatus", ignore = true )
    CaseStudy toEntity( CaseStudyDto dto );

    @Mapping(target = "dicomInstanceReceivedTimestamp", source = "dicomInstanceReceivedTimestamp")
    CaseStudyDto toDto(CaseStudy entity);
}
