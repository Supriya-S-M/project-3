package com.eh.digitalpathology.dbconnector.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


@JsonInclude(JsonInclude.Include.NON_NULL)
public abstract class BaseEntity {

    @NotNull(message = "Barcode cannot be null")
    @NotBlank(message = "Barcode cannot be blank")
    private String barcode;

    @NotNull(message = "Sop InstanceUid cannot be null")
    @NotBlank(message = "Sop InstanceUid cannot be blank")
    private String sopInstanceUid;

    @NotNull(message = "Series InstanceUid cannot be null")
    @NotBlank(message = "Series InstanceUid cannot be blank")
    private String seriesInstanceUid;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public  String getSopInstanceUid() {
        return sopInstanceUid;
    }

    public void setSopInstanceUid(String sopInstanceUid) {
        this.sopInstanceUid = sopInstanceUid;
    }

    public String getSeriesInstanceUid() {
        return seriesInstanceUid;
    }

    public void setSeriesInstanceUid(String seriesInstanceUid) {
        this.seriesInstanceUid = seriesInstanceUid;
    }


}
