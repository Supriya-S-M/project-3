package com.eh.digitalpathology.dbconnector.model;

import java.util.List;

public record StorageCommitmentRequest(String seriesInstanceUid, boolean storageCmtStatus, List<StorageCommitmentTracker> trackers ) {}
