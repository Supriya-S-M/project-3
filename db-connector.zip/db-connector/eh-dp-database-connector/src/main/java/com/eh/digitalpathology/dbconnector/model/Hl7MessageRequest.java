package com.eh.digitalpathology.dbconnector.model;


public record Hl7MessageRequest(String hl7Message){}

