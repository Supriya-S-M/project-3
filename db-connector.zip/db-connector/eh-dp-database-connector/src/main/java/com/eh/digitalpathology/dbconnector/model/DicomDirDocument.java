package com.eh.digitalpathology.dbconnector.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Arrays;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Document
public record DicomDirDocument(
        @Id
        String id,
        @NotNull(message = "Study id cannot be null")
        @NotBlank(message = "Study id cannot be blank")
        String studyId,
        @NotNull(message = "Series id cannot be null")
        @NotBlank(message = "Series id cannot be blank")
        String seriesId,
        int imageCount,
        byte[] dicomDirFile
) {
    @Override
    public boolean equals ( Object o ) {
        if ( !( o instanceof DicomDirDocument that ) ) return false;
        return imageCount == that.imageCount && Objects.equals( id, that.id ) && Objects.equals( studyId, that.studyId ) && Objects.equals( seriesId, that.seriesId ) && Objects.deepEquals( dicomDirFile, that.dicomDirFile );
    }

    @Override
    public int hashCode ( ) {
        return Objects.hash( id, studyId, seriesId, imageCount, Arrays.hashCode( dicomDirFile ) );
    }

    @Override
    public String toString ( ) {
        return "DicomDirDocument{" +
                "id='" + id + '\'' +
                ", studyId='" + studyId + '\'' +
                ", seriesId='" + seriesId + '\'' +
                ", imageCount=" + imageCount +
                ", dicomDirFile=" + Arrays.toString( dicomDirFile ) +
                '}';
    }
}

