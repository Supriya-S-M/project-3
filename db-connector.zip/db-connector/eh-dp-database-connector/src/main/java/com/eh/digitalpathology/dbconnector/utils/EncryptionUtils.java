package com.eh.digitalpathology.dbconnector.utils;

import com.google.cloud.ServiceOptions;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

@Component
public class EncryptionUtils {

    private static final String ALGORITHM = "AES/GCM/NoPadding";
    private static final int IV_LENGTH = 12; // Recommended for GCM
    private static final int TAG_LENGTH_BIT = 128;

    private EncryptionUtils ( ) {

    }

    public static String encrypt ( String data ) throws GeneralSecurityException {
        byte[] iv = SecureRandom.getInstanceStrong( ).generateSeed( IV_LENGTH );
        Cipher cipher = Cipher.getInstance( ALGORITHM );
        String secretKeyBytes = encodeSecretKey( ServiceOptions.getDefaultProjectId( ) );
        SecretKeySpec key = new SecretKeySpec( secretKeyBytes.getBytes( StandardCharsets.UTF_8 ), "AES" );
        GCMParameterSpec gcmSpec = new GCMParameterSpec( TAG_LENGTH_BIT, iv );

        cipher.init( Cipher.ENCRYPT_MODE, key, gcmSpec );
        byte[] encrypted = cipher.doFinal( data.getBytes( StandardCharsets.UTF_8 ) );

        byte[] encryptedWithIv = ByteBuffer.allocate( iv.length + encrypted.length )
                .put( iv ).put( encrypted ).array( );

        return Base64.getEncoder( ).encodeToString( encryptedWithIv );
    }

    public static String decrypt ( String encryptedData ) throws GeneralSecurityException {
        byte[] decoded = Base64.getDecoder( ).decode( encryptedData );
        ByteBuffer buffer = ByteBuffer.wrap( decoded );

        byte[] iv = new byte[ IV_LENGTH ];
        buffer.get( iv );
        byte[] encrypted = new byte[ buffer.remaining( ) ];
        buffer.get( encrypted );

        Cipher cipher = Cipher.getInstance( ALGORITHM );
        String secretKeyBytes = encodeSecretKey( ServiceOptions.getDefaultProjectId( ) );
        SecretKeySpec key = new SecretKeySpec( secretKeyBytes.getBytes( StandardCharsets.UTF_8 ), "AES" );
        GCMParameterSpec gcmSpec = new GCMParameterSpec( TAG_LENGTH_BIT, iv );

        cipher.init( Cipher.DECRYPT_MODE, key, gcmSpec );
        byte[] decrypted = cipher.doFinal( encrypted );

        return new String( decrypted, StandardCharsets.UTF_8 );
    }
    private static String encodeSecretKey ( String secretKey ) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance( "SHA-256" );
        byte[] encodedHash = digest.digest( secretKey.getBytes( ) );

        StringBuilder hexString = new StringBuilder( );
        for ( byte b : encodedHash ) {
            String hex = Integer.toHexString( 0xff & b );
            if ( hex.length( ) == 1 ) hexString.append( '0' );
            hexString.append( hex );
        }

        return hexString.substring( 0, 32 ); // 16 bytes in hex
    }


}
