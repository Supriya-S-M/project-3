package com.eh.digitalpathology.dbconnector.mappers;


import com.eh.digitalpathology.dbconnector.dtos.DicomDirDto;
import com.eh.digitalpathology.dbconnector.model.DicomDirDocument;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper( componentModel = "spring" )
public interface DicomDirMapper {

    DicomDirMapper INSTANCE = Mappers.getMapper( DicomDirMapper.class );

    @Mapping( target = "id", ignore = true )
    DicomDirDocument toEntity ( DicomDirDto dto );

    DicomDirDto toDto ( DicomDirDocument entity );
}
