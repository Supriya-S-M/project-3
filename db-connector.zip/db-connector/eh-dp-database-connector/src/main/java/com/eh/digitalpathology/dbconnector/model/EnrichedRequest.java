package com.eh.digitalpathology.dbconnector.model;

public class EnrichedRequest extends BaseEntity{
    private String messageType;

    public String getMessageType() {
        return messageType;
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    @Override
    public String toString() {
        return "EnrichedRequest{" +
                "barcode='" + getBarcode() + '\'' +
                ", sopInstanceUid='" + getSopInstanceUid() + '\'' +
                ", seriesInstanceUid='" + getSeriesInstanceUid() + '\'' +
                ", messageType='" + messageType + '\'' +
                '}';
    }
}
