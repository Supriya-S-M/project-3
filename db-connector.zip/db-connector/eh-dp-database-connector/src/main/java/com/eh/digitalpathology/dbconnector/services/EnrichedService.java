package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.concurrent.ExecutionException;


@Service
public class EnrichedService {

    private final MongoRetryService mongoRetryService;
    private final DicomService dicomService;
    private final GlobalValidatorConfig validatorConfig;
    private final Hl7Service hl7Service;
    private static final Logger log = LoggerFactory.getLogger( EnrichedService.class.getName( ) );

    @Autowired
    public EnrichedService ( MongoRetryService mongoRetryService, DicomService dicomService, GlobalValidatorConfig validatorConfig, Hl7Service hl7Service ) {
        this.mongoRetryService = mongoRetryService;
        this.dicomService = dicomService;
        this.validatorConfig = validatorConfig;
        this.hl7Service = hl7Service;
    }

    public EnrichedResponse fetchDicomEnrichedData ( String serviceName, EnrichedRequest enrichRequest ) {
        log.info( "fetchDicomEnrichedData:: enrichRequest :: {}", enrichRequest );
        validatorConfig.validate( enrichRequest );
        Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( enrichRequest.getBarcode( ) ).and( ApiConstants.SOP_INSTANCE_ID ).is( enrichRequest.getSopInstanceUid( ) ) );

        try {
            var hl7Segment = hl7Service.fetchHl7Segment( enrichRequest.getBarcode( ), enrichRequest.getMessageType( ) );
            var caseStudy = mongoRetryService.findOne( query, CaseStudy.class, "dicom_instances" ).get( );
            if ( hl7Segment == null ) {
                throw new DatabaseException( "hl7 segment is null as there is no entry in the database" );
            }
            EnrichedResponse enrichedResponse = getEnrichedResponse( enrichRequest, hl7Segment, caseStudy );
            String updateStatusResult = dicomService.updateStatus( serviceName, enrichRequest.getBarcode( ), enrichRequest.getSopInstanceUid( ) );
            log.info( "fetchDicomEnrichedData :: status :: {}  and barcode :: {}", updateStatusResult, enrichRequest.getBarcode( ) );
            return enrichedResponse;
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching enriched data" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    private static EnrichedResponse getEnrichedResponse ( EnrichedRequest enrichRequest, Hl7Segment hl7Segment, CaseStudy caseStudy ) {
        EnrichedResponse enrichedResponse = new EnrichedResponse( );
        enrichedResponse.setParsedData( hl7Segment.parsedData( ) );
        enrichedResponse.setBarcode( enrichRequest.getBarcode( ) );
        enrichedResponse.setSopInstanceUid( enrichRequest.getSopInstanceUid( ) );
        enrichedResponse.setIntermediateStoragePath( caseStudy.getIntermediateStoragePath( ) );
        enrichedResponse.setSeriesInstanceUid( enrichRequest.getSeriesInstanceUid( ) );
        enrichedResponse.setOriginalStudyInstanceUid( caseStudy.getOriginalStudyInstanceUid( ) );
        return enrichedResponse;
    }

    public String updateEnrichedStatus ( String serviceName, EnrichInstance enrichInstance ) {

        var collection = "dicom_instances";
        log.info( "updateEnrichedStatus :: barcode :: {} ============== sop instance id :: {} ", enrichInstance.getBarcode( ), enrichInstance.getSopInstanceUid( ) );
        validatorConfig.validate( enrichInstance );

        String newServiceName = serviceName + '-' + enrichInstance.getStatus( );
        log.info( "updateEnrichedStatus :: newServiceName :: {}", newServiceName );
        WorkflowStatusEnum statusEnum = WorkflowStatusEnum.fromValue( newServiceName );
        log.info( "updateEnrichedStatus :: status enum ::  =================== {}", statusEnum );

        Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( enrichInstance.getBarcode( ) ).and( ApiConstants.SOP_INSTANCE_ID ).is( enrichInstance.getSopInstanceUid( ) ) );
        Update update = new Update( ).set( ApiConstants.STATUS, statusEnum ).set( ApiConstants.ACTUAL_STUDY_ID, enrichInstance.getActualStudyInstanceUid( ) ).set(ApiConstants.CASE_NUMBER, enrichInstance.getCaseNumber()).set( ApiConstants.ENRICHMENT_TIMESTAMP, Calendar.getInstance( ).getTime( ) );
        try {
            var caseStudy = mongoRetryService.findAndModify( query, update, collection, CaseStudy.class ).get( );
            log.info( "updateEnrichedStatus :: caseStudy :: {}", caseStudy );
            return "Study updated successfully:: " + ( caseStudy != null ? caseStudy.getSopInstanceUid( ) : "no data" );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while updating enriched status" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }
}
