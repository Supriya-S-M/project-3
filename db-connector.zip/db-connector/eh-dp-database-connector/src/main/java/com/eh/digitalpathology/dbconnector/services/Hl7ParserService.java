package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.config.BarcodeConfig;
import com.eh.digitalpathology.dbconnector.model.Delimiters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Service
public class Hl7ParserService {

    private static final Logger log = LoggerFactory.getLogger(Hl7ParserService.class.getName());
    private final BarcodeConfig barcodeConfig;

    public Hl7ParserService(BarcodeConfig barcodeConfig) {
        this.barcodeConfig = barcodeConfig;
    }

    public Map<String, String> parsedHl7Message(String hl7Message) {

        String[] segments = hl7Message.split("[\\r\\n]");
        if (segments.length == 0) return Map.of();

        String mshSegment = segments[0];
        Delimiters delimiters = extractDelimiters(mshSegment);
        Map<String, String> parsedData = new LinkedHashMap<>();
        for (String segment : segments) {
            parseSegment(segment, delimiters, parsedData);
        }
        extractBarcodeAndMessageType(parsedData, segments, delimiters);
        return parsedData;
    }


    private void extractBarcodeAndMessageType(Map<String, String> parsedData, String[] segments, Delimiters delimiters) {
        String[] mshSegment = segments[0].split(Pattern.quote(String.valueOf(delimiters.fieldSeparator())));
        String messageTypeField = mshSegment.length > 8 ? mshSegment[8] : "";
        log.info("extractBarcodeAndMessageType :: messageTypeField::: {}", messageTypeField);
        if (!messageTypeField.isEmpty()) {
            String messageType = messageTypeField.split(Pattern.quote(String.valueOf(delimiters.componentSeparator())))[0];
            parsedData.put(ApiConstants.MESSAGE_TYPE, messageType);
        }
        String barcode = extractBarcodeFromMessage(segments, parsedData.get(ApiConstants.MESSAGE_TYPE), delimiters);
        log.info("extractBarcodeAndMessageType :: barcode::: {}", barcode);
        if (barcode != null && !barcode.isEmpty()) {
            parsedData.put(ApiConstants.BARCODE, barcode);
        }
    }

    public String extractBarcodeFromMessage(String[] segments, String messageType, Delimiters delimiters) {
        String barcode = "";
        BarcodeConfig.BarcodeDefinition mapping = barcodeConfig.getMessages().get( messageType );
        log.info("extractBarcodeFromMessage ::mapping::  {}", barcodeConfig.getMessages().get( messageType ));

        if (mapping != null && mapping.getBarcode() != null) {
            barcode = extractBarcodeFromSegment(segments, mapping.getBarcode(), delimiters);
        }
        return barcode;
    }

    private String extractBarcodeFromSegment(String[] segments, String segmentField, Delimiters delimiters) {
        String[] segmentParts = segmentField.split("-");
        String segmentName = segmentParts[0];
        log.info("extractBarcodeFromSegment ::segmentName::: {}", segmentName);

        int[] indices = parseFieldPart(segmentParts[1]);
        int fieldIndex = indices[0];
        int componentIndex = indices.length > 1 ? indices[1] : 1; // Ensure componentIndex is 1 if not specified
        int subComponentIndex = indices.length > 2 ? indices[2] : 0;
        for (String segment : segments) {
            if (segment.startsWith(segmentName)) {
                String fieldValue = getFieldValue(segment, fieldIndex, delimiters);
                if (fieldValue != null) {
                    String componentValue = getComponentValue(fieldValue, componentIndex, delimiters);
                    if (componentValue != null){
                        return getSubComponentValue(componentValue, subComponentIndex, delimiters);
                    }
                }
            }
        }
        return "";
    }

    private int[] parseFieldPart(String fieldPart) {
        String[] parts = fieldPart.split("\\.");
        int[] indices = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            indices[i] = Integer.parseInt(parts[i]);
        }
        return indices;
    }

    private String getFieldValue(String segment, int fieldIndex, Delimiters delimiters) {
        String[] fields = segment.split(Pattern.quote(String.valueOf(delimiters.fieldSeparator())));
        return fields.length > fieldIndex ? fields[fieldIndex] : null;
    }

    private String getComponentValue(String fieldValue, int componentIndex, Delimiters delimiters) {
        String[] components = fieldValue.split(Pattern.quote(String.valueOf(delimiters.componentSeparator())));
        return components.length >= componentIndex ? components[componentIndex - 1] : null;
    }

    private String getSubComponentValue(String componentValue, int subComponentIndex, Delimiters delimiters) {

        String[] subComponents = componentValue.split(Pattern.quote(String.valueOf(delimiters.subcomponentSeparator())));
        if (subComponentIndex == 0) {
            return subComponents[0];
        } else {
            if (subComponents.length >= subComponentIndex) return subComponents[subComponentIndex - 1];
            return null;
        }
    }

    private void parseSegment(String segment, Delimiters delimiters, Map<String, String> parsedData) {
        String[] fields = segment.split(Pattern.quote(String.valueOf(delimiters.fieldSeparator())));
        String segmentName = fields[0];

        for (int fieldIndex = 1; fieldIndex < fields.length; fieldIndex++) {
            String fieldKey;
            if (segmentName.equals(ApiConstants.MSH)) {
                if (fieldIndex == 1) {
                    parsedData.put(segmentName + "-1", String.valueOf(delimiters.fieldSeparator()));
                    parsedData.put(segmentName + "-2", delimiters.componentSeparator() +
                            String.valueOf(delimiters.repetitionSeparator()) + delimiters.escapeCharacter() + delimiters.subcomponentSeparator());
                    continue;
                }
                fieldKey = String.format("%s-%d", segmentName, fieldIndex + 1);
            }else{
                fieldKey = String.format("%s-%d", segmentName, fieldIndex);
            }
            log.debug("parseSegment :: fieldKey::: {}", fieldKey);
            parseField(fieldKey, fields[fieldIndex], delimiters, parsedData);
        }
    }

    private void parseField(String fieldKey, String field, Delimiters delimiters, Map<String, String> parsedData) {
        if (field.isEmpty()) return;
        String[] repetitions = field.split(Pattern.quote(String.valueOf(delimiters.repetitionSeparator())));
        if (repetitions.length == 1) {
            parseComponents(fieldKey, repetitions[0], delimiters, parsedData);
        } else {
            int repetitionIndex = 0;
            while (repetitionIndex < repetitions.length) {
                String repetitionKey = String.format("%s[%d]", fieldKey, repetitionIndex + 1);
                log.debug("parseField :: repetitionKey::: {}", repetitionKey);
                parseComponents(repetitionKey, repetitions[repetitionIndex], delimiters, parsedData);
                repetitionIndex++;
            }
        }
    }

    private void parseComponents(String baseKey, String data, Delimiters delimiters, Map<String, String> parsedData) {
        if (data.isEmpty()) return;
        String[] components = data.split(Pattern.quote(String.valueOf(delimiters.componentSeparator())));

        for (int componentIndex = 0; componentIndex < components.length; componentIndex++) {
            String componentKey = (componentIndex == 0) ? baseKey : String.format("%s.%d", baseKey, componentIndex + 1);
            log.debug("parseComponents :: componentKey::: {}", componentKey);
            parseSubComponents(componentKey, components[componentIndex], delimiters.subcomponentSeparator(), parsedData, componentIndex == 0);
        }
        // Ensure the first component is always represented
        if (components.length == 0) {
            parseSubComponents(baseKey, data, delimiters.subcomponentSeparator(), parsedData, true);
        }
    }

    private void parseSubComponents(String baseKey, String data, char subComponentSeparator, Map<String, String> parsedData, boolean isFirstComponent) {
        if (data.isEmpty()) return;
        String key = baseKey;
        String[] subComponents = data.split(Pattern.quote(String.valueOf(subComponentSeparator)));
        if (isFirstComponent && subComponents.length >1){
           baseKey += ".1";
        }

        for (int subComponentIndex = 0; subComponentIndex < subComponents.length; subComponentIndex++) {
            String subComponentKey;
            if ((subComponentIndex == 0 && isFirstComponent)) {
                subComponentKey = key;
            } else {
                if (subComponentIndex == 0) subComponentKey = baseKey;
                else subComponentKey = String.format("%s.%d", baseKey, subComponentIndex + 1);
            }
            log.debug("parseSubComponents :: subComponentKey::: {}", subComponentKey);
            if (!subComponents[subComponentIndex].isEmpty()) {
                parsedData.put(subComponentKey, subComponents[subComponentIndex].replace( "\\S\\", "^" ).replace( "\\T\\", "&" ).replace( "\\R\\", "~" ));
            }
        }
        // Ensure the first subcomponent is always represented
        if (subComponents.length == 0) {
            parsedData.put(baseKey, data.replace( "\\S\\", "^" ).replace( "\\T\\", "&" ).replace( "\\R\\", "~" ));
        }
    }

    public Delimiters extractDelimiters(String mshSegment) {
        String delimiterField = mshSegment.substring(3, 8);
        log.info("extractDelimiters :: delimiterField::: {}", delimiterField);
        return new Delimiters(delimiterField.charAt(0), delimiterField.charAt(1), delimiterField.charAt(2), delimiterField.charAt(3), delimiterField.charAt(4));
    }
}


