package com.eh.digitalpathology.dbconnector.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public record QidoResponse(@Id String id, String seriesUid, String response, int statusCode) {}
