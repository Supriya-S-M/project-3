package com.eh.digitalpathology.dbconnector.dtos;

public record DocumentDto(String messageType) {}