package com.eh.digitalpathology.dbconnector.dtos;

public record QidoResponseDto(String seriesUid, String response, int statusCode) {
}
