package com.eh.digitalpathology.dbconnector.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.CollectionOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexInfo;
import org.springframework.data.mongodb.core.index.IndexOperations;

import java.util.List;
import java.util.Map;

@Configuration
public class IndexCreationConfig {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public IndexCreationConfig(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void ensureCollectionExists(String collectionName) {
        if (!mongoTemplate.collectionExists(collectionName)) {
            mongoTemplate.createCollection(collectionName, CollectionOptions.empty());
        }
    }

    public void createIndexForCollections(String collectionName, Map<String, Sort.Direction> indexFields, boolean unique) {
        IndexOperations indexOps = mongoTemplate.indexOps(collectionName);
        List<IndexInfo> existingIndexes = indexOps.getIndexInfo();
        String indexName = String.join("_", indexFields.keySet()) + "_idx";
        boolean indexExist = existingIndexes.stream().anyMatch(idx -> idx.getName().equals(indexName) && (unique == idx.isUnique()));

        if (!indexExist) {
            Index index = new Index();
            for (Map.Entry<String, Sort.Direction> entry : indexFields.entrySet()) {
                index.on(entry.getKey(), entry.getValue());
            }

            index.named(indexName);
            if (unique) {
                index.unique();
            }
            indexOps.ensureIndex(index);
        }
    }
}
