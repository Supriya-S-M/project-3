package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.Delimiters;
import com.eh.digitalpathology.dbconnector.model.Hl7MessageRequest;
import com.eh.digitalpathology.dbconnector.model.Hl7MessageServiceRequest;
import com.eh.digitalpathology.dbconnector.model.Hl7Segment;
import com.eh.digitalpathology.dbconnector.utils.EncryptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
@RefreshScope
public class Hl7Service {

    private static final Logger log = LoggerFactory.getLogger( Hl7Service.class.getName( ) );

    @Value( "${app.message.lis-response}" )
    private String lisMessageRequest;

    @Value( "${hl7.encrypted}" )
    private boolean isEncrypted;

    private static final String CACHE_PREFIX = "barcode:";

    private final MongoRetryService mongoRetryService;
    private final Hl7ParserService hl7ParserService;
    private final IndexCreationConfig indexCreationConfig;
    private final Hl7AsyncService hl7AsyncService;
    private final GlobalValidatorConfig validatorConfig;
    private final RedisTemplate< String, Object > redisTemplate;

    @Autowired
    public Hl7Service ( MongoRetryService mongoRetryService, Hl7ParserService hl7ParserService, IndexCreationConfig indexCreationConfig, Hl7AsyncService hl7AsyncService, GlobalValidatorConfig validatorConfig, RedisTemplate< String, Object > redisTemplate ) {
        this.mongoRetryService = mongoRetryService;
        this.hl7ParserService = hl7ParserService;
        this.indexCreationConfig = indexCreationConfig;
        this.hl7AsyncService = hl7AsyncService;
        this.validatorConfig = validatorConfig;
        this.redisTemplate = redisTemplate;
    }

    public Map< String, String > savedHl7Message ( String serviceName, Hl7MessageRequest hl7MessageRequest ) {

        Map< String, String > parsedData = hl7ParserService.parsedHl7Message( hl7MessageRequest.hl7Message( ) );

        log.info( "savedHl7Message :: service name :: {}", serviceName );
        var barcode = parsedData.get( ApiConstants.BARCODE );
        log.info( "savedHl7Message :: barcode :: {}", barcode );

        var messageType = parsedData.get( ApiConstants.MESSAGE_TYPE );
        log.info( "savedHl7Message :: message type :: {}", messageType );

        parsedData.remove( ApiConstants.BARCODE );
        parsedData.remove( ApiConstants.MESSAGE_TYPE );

        String encryptedRawMessage;
        try {
            encryptedRawMessage = EncryptionUtils.encrypt( hl7MessageRequest.hl7Message( ) );
        } catch ( Exception e ) {
            throw new DatabaseException( "Unable to encrypt messages:: " + e.getMessage( ) );
        }
        Map< String, String > encryptedParsedData = parsedData.entrySet( ).stream( )
                .collect( Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> {
                            try {
                                return EncryptionUtils.encrypt( entry.getValue( ) );
                            } catch ( Exception ex ) {
                                throw new DatabaseException( "Unable to encrypt messages :: " + ex.getMessage( ) );
                            }
                        } ) );
        Hl7Segment hl7SegmentObject;
        if ( !isEncrypted ) {
            hl7SegmentObject = Hl7Segment.create( barcode, messageType, hl7MessageRequest.hl7Message( ), parsedData, Calendar.getInstance( ).getTime( ) );
        } else {
            hl7SegmentObject = Hl7Segment.create( barcode, messageType, encryptedRawMessage, encryptedParsedData, Calendar.getInstance( ).getTime( ) );
        }
        var collection = "hl7_" + messageType.toLowerCase( );

        validatorConfig.validate( hl7SegmentObject );

        indexCreationConfig.ensureCollectionExists( collection );
        indexCreationConfig.createIndexForCollections( collection, Map.of( ApiConstants.BARCODE, Sort.Direction.ASC ), true );

        try {
            var hl7Segment = mongoRetryService.save( hl7SegmentObject, collection ).get( );
            Map< String, String > barcodeMap = new HashMap<>( );
            barcodeMap.put( "barcode", hl7Segment.barcode( ) );

            String cacheKey = CACHE_PREFIX + barcode;
            String hl7CacheKey = "hl7:" + barcode + ":" + messageType;
            redisTemplate.delete( cacheKey );
            redisTemplate.delete( hl7CacheKey );

            return barcodeMap;
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while saving hl7 message" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public String fetchHl7Message ( Hl7MessageServiceRequest hl7MessageServiceRequest ) {
        validatorConfig.validate( hl7MessageServiceRequest );
        String[] segments = hl7MessageServiceRequest.hl7Message( ).split( "[\\r\\n]" );
        if ( segments.length == 0 ) return "";

        String mshSegment = segments[ 0 ];
        Delimiters delimiters = hl7ParserService.extractDelimiters( mshSegment );
        String barcode = hl7ParserService.extractBarcodeFromMessage( segments, hl7MessageServiceRequest.messageType( ), delimiters );
        log.info( "fetchHl7Message :: message type from request is :: {}", hl7MessageServiceRequest.messageType( ) );
        log.info( "fetchHl7Message :: barcode from request is :: {}", barcode );
        Map< String, Set< String > > messageTypes = searchMessageTypeByBarcode( barcode );
        Set< String > messages = messageTypes.get( ApiConstants.MESSAGE_TYPE );
        if ( !messages.contains( lisMessageRequest ) ) {
            return "";
        }
        try {
            var hl7Message = fetchHl7Segment( barcode, lisMessageRequest );
            return hl7Message.rawHl7Message( );
        } catch ( DatabaseException ex ) {
            throw new DatabaseException( "Unable to fetch hl7 message:: " + ex.getMessage( ) );
        }

    }

    public Map< String, Set< String > > searchMessageTypeByBarcode ( String barcode ) {
        String cacheKey = CACHE_PREFIX + barcode;

        // 1. Try to get from cache
        Map< String, Set< String > > cachedResult = (Map< String, Set< String > >) redisTemplate.opsForValue( ).get( cacheKey );
        if ( cachedResult != null ) {
            log.info( "Cache hit for barcode: {}", barcode );
            return cachedResult;
        }
        try {
            return hl7AsyncService.searchMessageTypeByBarcodeAsync( barcode ).get( ); // blocking call
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching message type by barcode" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request: " + cause.getMessage( ), cause );
        }
    }


    public Hl7Segment fetchHl7Segment ( String barcode, String messageType ) {
        String hl7CacheKey = "hl7:" + barcode + ":" + messageType;

        try {
            return hl7AsyncService.fetchHl7SegmentAsync( barcode, messageType, hl7CacheKey, isEncrypted ).get( ); // blocking call
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching HL7 segment" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request: " + cause.getMessage( ), cause );
        }
    }


}
