package com.eh.digitalpathology.dbconnector.config;


import jakarta.validation.*;
import org.springframework.context.annotation.Configuration;

import java.util.Set;

@Configuration
public class  GlobalValidatorConfig {

    private final Validator validator;

    public GlobalValidatorConfig() {
        try (ValidatorFactory factory = Validation.buildDefaultValidatorFactory()) {
            this.validator = factory.getValidator();
        }
    }

    public <T> void validate(T object){
        Set<ConstraintViolation<T>> violations = validator.validate(object);
        if (!violations.isEmpty()){
            StringBuilder sb = new StringBuilder("Validation failed: ");
            for (ConstraintViolation<T> violation : violations){
                sb.append(violation.getPropertyPath()).append(" - ").append(violation.getMessage()).append("; ");
            }
            throw new ValidationException(sb.toString());
        }
    }

}
