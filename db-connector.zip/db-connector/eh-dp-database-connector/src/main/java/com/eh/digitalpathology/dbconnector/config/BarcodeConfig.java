package com.eh.digitalpathology.dbconnector.config;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;


@Configuration
@ConfigurationProperties(prefix = "barcode-messages")
@RefreshScope
public class BarcodeConfig {
    private static final Logger log = LoggerFactory.getLogger(BarcodeConfig.class.getName());

    private Map<String, BarcodeDefinition> messages = new HashMap<>();

    public Map<String, BarcodeDefinition> getMessages() {
        return messages;
    }

    public void setMessages(Map<String, BarcodeDefinition> messages) {
        this.messages = messages;
    }

    public static class BarcodeDefinition{
        private String barcode;

        public String getBarcode() {
            return barcode;
        }

        public void setBarcode(String barcode) {
            this.barcode = barcode;
        }
    }

    @PostConstruct
    public void init(){
        log.error("Barcode config loaded:: {}" , messages);
    }
}


