package com.eh.digitalpathology.dbconnector.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
@EnableAsync
public class AsyncConfig{

    private static final Logger log = LoggerFactory.getLogger( AsyncConfig.class.getName( ) );

    @Bean
    public AsyncConfigurer asyncConfigurer(@Qualifier("mongoAsyncExecutor") ThreadPoolTaskExecutor executor) {
        return new AsyncConfigurer() {
            @Override
            public Executor getAsyncExecutor() {
                return executor;
            }

            @Override
            public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
                return (ex, method, params) ->
                    // Log or handle uncaught exceptions from async methods
                    log.error("Async error in method: {} :: cause :: {}",  method.getName(), ex);

            }
        };
    }
}
