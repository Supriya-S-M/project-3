package com.eh.digitalpathology.dbconnector.mappers;

import com.eh.digitalpathology.dbconnector.dtos.QidoResponseDto;
import com.eh.digitalpathology.dbconnector.model.QidoResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper( componentModel = "spring" )
public interface QidoRsMapper {

    QidoRsMapper INSTANCE = Mappers.getMapper( QidoRsMapper.class);
    @Mapping( target = "id", ignore = true )
    QidoResponse toEntity( QidoResponseDto qidoRs );
}
