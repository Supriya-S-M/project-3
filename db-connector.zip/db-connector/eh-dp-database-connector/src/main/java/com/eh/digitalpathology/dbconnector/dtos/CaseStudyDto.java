package com.eh.digitalpathology.dbconnector.dtos;

import com.eh.digitalpathology.dbconnector.model.BaseEntity;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class CaseStudyDto extends BaseEntity {

    private String originalStudyInstanceUid;
    private String actualStudyInstanceUid;
    private String intermediateStoragePath;
    private String deviceSerialNumber;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date dicomInstanceReceivedTimestamp;
    private Date enrichmentTimestamp;
    private String caseNumber;

    public String getOriginalStudyInstanceUid() {
        return originalStudyInstanceUid;
    }

    public void setOriginalStudyInstanceUid(String originalStudyInstanceUid) {
        this.originalStudyInstanceUid = originalStudyInstanceUid;
    }

    public String getActualStudyInstanceUid() {
        return actualStudyInstanceUid;
    }

    public void setActualStudyInstanceUid(String actualStudyInstanceUid) {
        this.actualStudyInstanceUid = actualStudyInstanceUid;
    }

    public String getIntermediateStoragePath() {
        return intermediateStoragePath;
    }

    public void setIntermediateStoragePath(String intermediateStoragePath) {
        this.intermediateStoragePath = intermediateStoragePath;
    }

    public Date getDicomInstanceReceivedTimestamp() {
        return dicomInstanceReceivedTimestamp;
    }

    public void setDicomInstanceReceivedTimestamp(Date dicomInstanceReceivedTimestamp) {
        this.dicomInstanceReceivedTimestamp = dicomInstanceReceivedTimestamp;
    }

    public Date getEnrichmentTimestamp() {
        return enrichmentTimestamp;
    }

    public void setEnrichmentTimestamp(Date enrichmentTimestamp) {
        this.enrichmentTimestamp = enrichmentTimestamp;
    }

    public String getDeviceSerialNumber ( ) {
        return deviceSerialNumber;
    }

    public void setDeviceSerialNumber ( String deviceSerialNumber ) {
        this.deviceSerialNumber = deviceSerialNumber;
    }

    public String getCaseNumber ( ) {
        return caseNumber;
    }

    public void setCaseNumber ( String caseNumber ) {
        this.caseNumber = caseNumber;
    }
}
