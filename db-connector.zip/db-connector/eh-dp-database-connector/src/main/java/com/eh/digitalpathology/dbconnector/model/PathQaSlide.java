package com.eh.digitalpathology.dbconnector.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record PathQaSlide(String id, String barcode, String activationCode) {
}
