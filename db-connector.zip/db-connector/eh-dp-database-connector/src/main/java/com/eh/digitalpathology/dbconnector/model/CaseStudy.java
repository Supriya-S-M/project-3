package com.eh.digitalpathology.dbconnector.model;

import com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Document
public class CaseStudy extends BaseEntity {

    @Id
    private String id;

    private String originalStudyInstanceUid;
    private String actualStudyInstanceUid;
    private String intermediateStoragePath;
    private WorkflowStatusEnum processingStatus;
    private Date dicomInstanceReceivedTimestamp;
    private Date enrichmentTimestamp;
    private String deviceSerialNumber;
    private String caseNumber;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getEnrichmentTimestamp() {
        return enrichmentTimestamp;
    }

    public void setEnrichmentTimestamp(Date enrichmentTimestamp) {
        this.enrichmentTimestamp = enrichmentTimestamp;
    }

    public Date getDicomInstanceReceivedTimestamp() {
        return dicomInstanceReceivedTimestamp;
    }

    public void setDicomInstanceReceivedTimestamp(Date dicomInstanceReceivedTimestamp) {
        this.dicomInstanceReceivedTimestamp = dicomInstanceReceivedTimestamp;
    }

    public WorkflowStatusEnum getProcessingStatus() {
        return processingStatus;
    }

    public void setProcessingStatus(WorkflowStatusEnum processingStatus) {
        this.processingStatus = processingStatus;
    }

    public String getIntermediateStoragePath() {
        return intermediateStoragePath;
    }

    public void setIntermediateStoragePath(String intermediateStoragePath) {
        this.intermediateStoragePath = intermediateStoragePath;
    }

    public String getActualStudyInstanceUid() {
        return actualStudyInstanceUid;
    }

    public void setActualStudyInstanceUid(String actualStudyInstanceUid) {
        this.actualStudyInstanceUid = actualStudyInstanceUid;
    }

    public String getOriginalStudyInstanceUid() {
        return originalStudyInstanceUid;
    }

    public void setOriginalStudyInstanceUid(String originalStudyInstanceUid) {
        this.originalStudyInstanceUid = originalStudyInstanceUid;
    }

    public String getDeviceSerialNumber ( ) {
        return deviceSerialNumber;
    }

    public void setDeviceSerialNumber ( String deviceSerialNumber ) {
        this.deviceSerialNumber = deviceSerialNumber;
    }

    public String getCaseNumber ( ) {
        return caseNumber;
    }

    public void setCaseNumber ( String caseNumber ) {
        this.caseNumber = caseNumber;
    }

    @Override
    public String toString() {
        return "CaseStudy{" +
                "id='" + id + '\'' +
                ", originalStudyInstanceUid='" + originalStudyInstanceUid + '\'' +
                ", actualStudyInstanceUid='" + actualStudyInstanceUid + '\'' +
                ", intermediateStoragePath='" + intermediateStoragePath + '\'' +
                ", processingStatus=" + processingStatus +
                ", dicomInstanceReceivedTimestamp=" + dicomInstanceReceivedTimestamp +
                ", enrichmentTimestamp=" + enrichmentTimestamp +
                '}';
    }
}


