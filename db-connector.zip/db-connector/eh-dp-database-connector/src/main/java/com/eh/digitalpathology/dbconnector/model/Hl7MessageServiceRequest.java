package com.eh.digitalpathology.dbconnector.model;

import jakarta.validation.constraints.NotNull;

public record Hl7MessageServiceRequest(String hl7Message,
        @NotNull(message = "Message Type cannot be null") String messageType) {}
