package com.eh.digitalpathology.dbconnector.model;


public record BarcodeInstanceRequest(String barcode, String sopInstanceUid){}

