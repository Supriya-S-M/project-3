package com.eh.digitalpathology.dbconnector.config;

import jakarta.annotation.PreDestroy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Configuration
public class TaskExecutorConfig {

    private final ThreadPoolTaskExecutor threadPoolTaskExecutor;

    public TaskExecutorConfig() {
        this.threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
        int processors = Runtime.getRuntime().availableProcessors();
        this.threadPoolTaskExecutor.setCorePoolSize(processors);
        this.threadPoolTaskExecutor.setMaxPoolSize(processors * 2);
        this.threadPoolTaskExecutor.setQueueCapacity(1000);
        this.threadPoolTaskExecutor.setKeepAliveSeconds( 60 );
        this.threadPoolTaskExecutor.setThreadNamePrefix("MongoExecutor-");
        this.threadPoolTaskExecutor.setRejectedExecutionHandler( new ThreadPoolExecutor.CallerRunsPolicy() );
        this.threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown( true );
        this.threadPoolTaskExecutor.setAwaitTerminationSeconds( 30 );
        this.threadPoolTaskExecutor.initialize();
    }


    @Bean(name = "mongoAsyncExecutor")
    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
        return this.threadPoolTaskExecutor;
    }

    @PreDestroy
    public void shutdownExecutor() {
        var executor = threadPoolTaskExecutor.getThreadPoolExecutor();
        executor.shutdown();

        try {
            if (!executor.awaitTermination(60, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException ex) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

    }
}