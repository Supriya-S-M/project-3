package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.dtos.DocumentDto;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.Hl7Segment;
import com.eh.digitalpathology.dbconnector.utils.EncryptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Service
public class Hl7AsyncService {

    private static final Logger log = LoggerFactory.getLogger( Hl7AsyncService.class.getName( ) );
    private final MongoRetryService mongoRetryService;
    private final RedisTemplate< String, Object > redisTemplate;

    private static final String CACHE_PREFIX = "barcode:";

    public Hl7AsyncService ( MongoRetryService mongoRetryService, RedisTemplate< String, Object > redisTemplate ) {
        this.mongoRetryService = mongoRetryService;
        this.redisTemplate = redisTemplate;
    }

    @Async
    public CompletableFuture< Hl7Segment > fetchHl7SegmentAsync ( String barcode, String messageType, String hl7CacheKey, boolean isEncrypted ) {
        Hl7Segment cachedHl7 = (Hl7Segment) redisTemplate.opsForValue( ).get( hl7CacheKey );
        if ( cachedHl7 != null ) {
            log.info( "fetchHl7Segment :: Cache hit for HL7Dto: {}", hl7CacheKey );
            return CompletableFuture.completedFuture( cachedHl7 );
        }
        String collectionName = "hl7_" + messageType.toLowerCase( );
        Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( barcode ) );
        return mongoRetryService.findOne( query, Hl7Segment.class, collectionName ).thenApply( hl7Segment -> {
            if ( hl7Segment == null ) {
                return null;
            }
            if ( !isEncrypted ) {
                redisTemplate.opsForValue( ).set( hl7CacheKey, hl7Segment, Duration.ofHours( 1 ) );
                return hl7Segment;
            }
            String decryptRawMessage;
            try {
                decryptRawMessage = EncryptionUtils.decrypt( hl7Segment.rawHl7Message( ) );
            } catch ( Exception e ) {
                throw new DatabaseException( "Unable to decrypt values :: " + e.getMessage( ), e );
            }
            Map< String, String > decryptParsedData = hl7Segment.parsedData( ).entrySet( ).stream( ).collect( Collectors.toMap( Map.Entry::getKey, entry -> {
                try {
                    return EncryptionUtils.decrypt( entry.getValue( ) );
                } catch ( Exception e ) {
                    throw new DatabaseException( "Unable to decrypt values :: " + e.getMessage( ), e );
                }
            } ) );

            Hl7Segment updatedHl7Segment = Hl7Segment.create( hl7Segment.barcode( ), hl7Segment.messageType( ), decryptRawMessage, decryptParsedData, hl7Segment.lastModifiedTime( ) );

            redisTemplate.opsForValue( ).set( hl7CacheKey, updatedHl7Segment, Duration.ofHours( 1 ) );
            return updatedHl7Segment;
        } );
    }

    @Async
    public CompletableFuture< Map< String, Set< String > > > searchMessageTypeByBarcodeAsync ( String barcode ) {
        Map< String, Set< String > > result = new HashMap<>( );
        Set< String > messageTypeResults = Collections.synchronizedSet( new HashSet<>( ) );
        return mongoRetryService.getCollectionNames( ).thenCompose( collectionNames -> {
            List< CompletableFuture< Void > > futures = new ArrayList<>( );

            for ( String collectionName : collectionNames ) {
                Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( barcode ) );
                query.fields( ).include( ApiConstants.MESSAGE_TYPE );

                CompletableFuture< Void > future = mongoRetryService.find( query, DocumentDto.class, collectionName ).thenAccept( documents -> {
                    for ( DocumentDto document : documents ) {
                        String messageType = document.messageType( );
                        if ( messageType != null ) {
                            messageTypeResults.add( messageType );
                        }
                    }
                } );

                futures.add( future );
            }
            // Combine all futures and return result when all are done
            return CompletableFuture.allOf( futures.toArray( new CompletableFuture[ 0 ] ) ).thenApply( v -> {
                result.put( ApiConstants.MESSAGE_TYPE, messageTypeResults );
                log.info( "searchMessageTypeByBarcodeAsync :: result :: {}", result );
                redisTemplate.opsForValue( ).set( CACHE_PREFIX + barcode, result, Duration.ofHours( 1 ) );
                return result;
            } );
        } );
    }
}
