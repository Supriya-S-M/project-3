package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.DicomDirDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class DicomDirService {

    private static final Logger log = LoggerFactory.getLogger( DicomDirService.class.getName( ) );

    private final MongoRetryService mongoRetryService;
    private final IndexCreationConfig indexCreationConfig;
    private final GlobalValidatorConfig validatorConfig;

    private static final String DICOM_META_DATA = "dicom_meta_data";

    @Autowired
    public DicomDirService ( MongoRetryService mongoRetryService, IndexCreationConfig indexCreationConfig, GlobalValidatorConfig validatorConfig ) {
        this.mongoRetryService = mongoRetryService;
        this.indexCreationConfig = indexCreationConfig;
        this.validatorConfig = validatorConfig;
    }

    public String saveMetaDataInfo ( DicomDirDocument dicomDirDocument ) {
        String collection = DICOM_META_DATA;
        validatorConfig.validate( dicomDirDocument );

        indexCreationConfig.ensureCollectionExists( collection );
        indexCreationConfig.createIndexForCollections( collection, Map.of( ApiConstants.DICOMDIR_SERIES_ID, Sort.Direction.ASC ), true );
        try {
            CompletableFuture<DicomDirDocument> f = mongoRetryService.save( dicomDirDocument, collection );
            var dicomDir = f.get(2, TimeUnit.MINUTES );
            log.info( "saveMetaDataInfo :: dicomdir id :: {}", dicomDir.id( ) );
            return "DICOMDIR saved successfully " + dicomDir.id( );
        } catch ( InterruptedException ex ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching instances." );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request :: " + cause.getMessage( ), cause );
        } catch ( TimeoutException e ) {
            return "Saving DICOMDIR timed out. Please try again." + dicomDirDocument.id();
        }

    }


    public DicomDirDocument getMetaDataInfo ( String series ) {
        Query query = new Query( Criteria.where( ApiConstants.DICOMDIR_SERIES_ID ).is( series ) );
        try {
            CompletableFuture<DicomDirDocument> f = mongoRetryService.findOne( query, DicomDirDocument.class, DICOM_META_DATA );
            var dicomDirDocument = f.get(2, TimeUnit.MINUTES );
            if ( null == dicomDirDocument ) {
                throw new DatabaseException( " No DICOMDIR document is found for series :: " + series );
            }
            log.info( "getMetaDataInfo :: dicom dir document study id :: {}", dicomDirDocument.studyId( ) );
            return dicomDirDocument;
        } catch ( InterruptedException ex ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread is interrupted while fetching metadata" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        } catch ( TimeoutException e ) {
            throw new DatabaseException( "Fetching DICOMDIR timed out for series :: " + series );
        }

    }

    public String updateDicomDir ( DicomDirDocument dicomDirDocument ) {
        validatorConfig.validate( dicomDirDocument );
        Query query = new Query( Criteria.where( ApiConstants.DICOMDIR_SERIES_ID ).is( dicomDirDocument.seriesId( ) ) );
        Update dicomDirUpdate = new Update( ).set( ApiConstants.DICOMDIR_STUDY_ID, dicomDirDocument.studyId( ) ).set( "dicomDirFile", dicomDirDocument.dicomDirFile( ) );
        try {
            CompletableFuture<DicomDirDocument> f  = mongoRetryService.findAndModify( query, dicomDirUpdate, DICOM_META_DATA, DicomDirDocument.class );
            var dicomDir = f.get(2, TimeUnit.MINUTES );
            if ( dicomDir == null ) {
                throw new DatabaseException( "No document was updated for series ID: " + dicomDirDocument.seriesId( ) );
            }
            log.info( "updateDicomDir :: dicom dir document has been updated :: {}", dicomDir.studyId( ) );
            return "DICOMDIR updated successfully " + dicomDir.id( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread is interrupted while updating dicom dir" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error Updating dicom dir document :: " + cause.getMessage( ), cause );
        } catch ( TimeoutException e ) {
            throw new DatabaseException( "Updating DICOMDIR timed out for series :: " + dicomDirDocument.seriesId( ) );
        }
    }
}
