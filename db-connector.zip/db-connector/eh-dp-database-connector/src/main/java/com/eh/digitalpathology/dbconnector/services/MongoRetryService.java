package com.eh.digitalpathology.dbconnector.services;

import com.mongodb.*;
import com.mongodb.client.result.UpdateResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@Service
@RefreshScope
public class MongoRetryService {

    private final MongoTemplate mongoTemplate;

    @Autowired
    public MongoRetryService ( MongoTemplate mongoTemplate ) {
        this.mongoTemplate = mongoTemplate;
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< T > save ( T entity, String collectionName ) {
        return CompletableFuture.completedFuture( mongoTemplate.insert( entity, collectionName ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< List< T > > find ( Query query, Class< T > clazz, String collectionName ) {
        return CompletableFuture.completedFuture( mongoTemplate.find( query, clazz, collectionName ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public CompletableFuture< Set< String > > getCollectionNames ( ) {
        return CompletableFuture.completedFuture( mongoTemplate.getCollectionNames( ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< T > findAndModify ( Query query, Update update, String collectionName, Class< T > clazz ) {
        return CompletableFuture.completedFuture( mongoTemplate.findAndModify( query, update, new FindAndModifyOptions( ).returnNew( true ).upsert( false ), clazz, collectionName ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< T > findOne ( Query query, Class< T > clazz, String collectionName ) {
        return CompletableFuture.completedFuture( mongoTemplate.findOne( query, clazz, collectionName ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< Boolean > upsert ( Query query, Update update, Class< T > entityClass, String collectionName ) {
        UpdateResult result = mongoTemplate.upsert( query, update, entityClass, collectionName );
        return CompletableFuture.completedFuture( result.wasAcknowledged( ) );
    }

    @Async
    @Retryable( retryFor = { MongoSocketReadException.class, MongoSocketWriteException.class, MongoTimeoutException.class, MongoException.class }, maxAttemptsExpression = "${mongo.retry.max-attempts}",
            backoff = @Backoff( delay = 1000, multiplier = 2 ) )
    public < T > CompletableFuture< Boolean > upsertBulk ( List< T > documents, String collectionName, Class< T > clazz, Function< T, Query > queryFunction, Function< T, Update > updateFunction, BulkOperations.BulkMode mode ) {
        BulkOperations bulkOps = mongoTemplate.bulkOps( mode, clazz, collectionName );
        for ( T doc : documents ) {
            Query query = queryFunction.apply( doc );
            Update update = updateFunction.apply( doc );
            bulkOps.upsert( query, update );
        }
        return CompletableFuture.completedFuture( bulkOps.execute( ).wasAcknowledged( ) );
    }

}
