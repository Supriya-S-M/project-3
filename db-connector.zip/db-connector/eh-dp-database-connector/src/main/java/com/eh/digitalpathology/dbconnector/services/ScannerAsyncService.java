package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.model.PathQaSlide;
import com.eh.digitalpathology.dbconnector.model.SlideScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;

@Service
public class ScannerAsyncService {
    private static final Logger logger = LoggerFactory.getLogger( ScannerAsyncService.class.getName( ) );
    private final MongoRetryService mongoRetryService;
    private final RedisTemplate< String, Object > redisTemplate;

    public ScannerAsyncService ( MongoRetryService mongoRetryService, RedisTemplate< String, Object > redisTemplate ) {
        this.mongoRetryService = mongoRetryService;
        this.redisTemplate = redisTemplate;
    }

    @Async
    public CompletableFuture< PathQaSlide > fetchQaSlide( String barcode, String slideCacheKey) {
        Object cachedSlide = redisTemplate.opsForValue( ).get( slideCacheKey );
        if ( cachedSlide != null ) {

            if (cachedSlide instanceof String && "NULL".equals(cachedSlide)) {
                logger.info("fetchQaSlide :: Cache hit for NULL PathQaSlide: {}", slideCacheKey);
                return CompletableFuture.completedFuture(null);
            }
            logger.info( "fetchHl7Segment :: Cache hit for PathQaSlide: {}", slideCacheKey );
            return CompletableFuture.completedFuture((PathQaSlide) cachedSlide );
        }
        String collectionName = "qa_slide";
        Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( barcode ) );
        return mongoRetryService.findOne( query, PathQaSlide.class, collectionName ).thenApply(pathQaSlide -> {
            logger.info( "fetchQaSlide :: pathQaSlide ::  {}", pathQaSlide );
            if ( pathQaSlide == null){
                redisTemplate.opsForValue().set(slideCacheKey, "NULL", Duration.ofHours(1));
                return null;
            }
            redisTemplate.opsForValue( ).set( slideCacheKey, pathQaSlide, Duration.ofHours( 1 ) );
            return pathQaSlide;
        }  );
    }

    @Async
    public CompletableFuture<SlideScanner> fetchDicomWebUrlByDeviceSerialNumber(String deviceSerialNumber, String scannerCacheKey) {
        Object cachedSlideScanner  = redisTemplate.opsForValue().get(scannerCacheKey);
        if (cachedSlideScanner != null) {
            if (cachedSlideScanner instanceof String && "NULL".equals(cachedSlideScanner)) {
                logger.info("fetchScannerByDeviceSerialNumber :: Cache hit for NULL PathQaSlide: {}", cachedSlideScanner);
                return CompletableFuture.completedFuture(null);
            }
            logger.info("fetchScannerByDeviceSerialNumber :: Cache hit for Scanners: {}", scannerCacheKey);
            return CompletableFuture.completedFuture((SlideScanner) cachedSlideScanner);
        }
        String collectionName = "slide_scanner";
        Query query = new Query(Criteria.where(ApiConstants.DEVICE_SERIAL_NUMBER).is(deviceSerialNumber));
        return mongoRetryService.findOne(query, SlideScanner.class, collectionName).thenApply(scanner -> {
            if (scanner == null) {
                redisTemplate.opsForValue().set(scannerCacheKey, "NULL", Duration.ofHours(1));
                return null;
            }
            redisTemplate.opsForValue().set(scannerCacheKey, scanner, Duration.ofHours(1));
            return scanner;
        });
    }
}
