package com.eh.digitalpathology.dbconnector.model;

public record Delimiters( char fieldSeparator, char componentSeparator, char repetitionSeparator, char escapeCharacter, char subcomponentSeparator) {}
