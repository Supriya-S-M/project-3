package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.CaseStudy;
import com.eh.digitalpathology.dbconnector.model.InstancesMeta;
import com.eh.digitalpathology.dbconnector.model.QidoResponse;
import com.eh.digitalpathology.dbconnector.model.StorageCommitmentTracker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;


@Service
public class DicomService {

    private static final Logger log = LoggerFactory.getLogger( DicomService.class.getName( ) );

    private final MongoRetryService mongoRetryService;
    private final IndexCreationConfig indexCreationConfig;
    private final GlobalValidatorConfig validatorConfig;

    private static final String TRACKER_COLLECTION = "stgcmt_tracker";
    private static final String DICOM_INSTANCES_COLLECTION = "dicom_instances";

    public DicomService ( MongoRetryService mongoRetryService, IndexCreationConfig indexCreationConfig, GlobalValidatorConfig validatorConfig ) {
        this.mongoRetryService = mongoRetryService;
        this.indexCreationConfig = indexCreationConfig;
        this.validatorConfig = validatorConfig;
    }

    public String persists ( String serviceName, CaseStudy dicomAttributes ) {
        var collection = DICOM_INSTANCES_COLLECTION;

        WorkflowStatusEnum statusEnum = WorkflowStatusEnum.fromValue( serviceName );
        dicomAttributes.setProcessingStatus( statusEnum );
        log.info( "persists:: dicom attributes :: {} ", dicomAttributes );

        validatorConfig.validate( dicomAttributes );

        indexCreationConfig.ensureCollectionExists( collection );
        indexCreationConfig.createIndexForCollections( collection, Map.of( ApiConstants.BARCODE, Sort.Direction.ASC, ApiConstants.SOP_INSTANCE_ID, Sort.Direction.DESC ), true );
        indexCreationConfig.createIndexForCollections( collection, Map.of( ApiConstants.SERIES_ID, Sort.Direction.ASC ), false );
        indexCreationConfig.createIndexForCollections( collection, Map.of(ApiConstants.SOP_INSTANCE_ID, Sort.Direction.ASC), false );

        try {
            var caseStudy = mongoRetryService.save( dicomAttributes, collection ).get( );
            saveOrUpdateStorageCmtTracker( dicomAttributes );
            log.info( "persists :: case study :: {}", ( caseStudy != null ? caseStudy.getId( ) : "no data updated" ) );
            return "Study saved successfully:: " + ( caseStudy != null ? caseStudy.getSopInstanceUid( ) : "no data updated" );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while saving instances" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public String updateStatus ( String serviceName, String barcode, String sopInstanceUid ) {
        log.info( "updateStatus:: service name :: {}, barcode :: {}, sopInstanceUid :: {} ", serviceName, barcode, sopInstanceUid );
        WorkflowStatusEnum statusEnum = WorkflowStatusEnum.fromValue( serviceName );
        log.info( "updateStatus :: status enum :: {}", statusEnum );
        Query query = new Query( Criteria.where( ApiConstants.BARCODE ).is( barcode ).and( ApiConstants.SOP_INSTANCE_ID ).is( sopInstanceUid ) );
        Update update = new Update( ).set( ApiConstants.STATUS, statusEnum );
        try {
            var study = mongoRetryService.findAndModify( query, update, DICOM_INSTANCES_COLLECTION, CaseStudy.class ).get( );
            log.info( "updateStatus :: study :: {} ", study );
            return "Sop instance id :: " + ( study != null ? study.getSopInstanceUid( ) : "no data" ) + "is updated";
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while updating status of the  instances" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public List< InstancesMeta > getInstancesOfSeries ( String seriesUid ) {
        Query query = new Query( Criteria.where( ApiConstants.SERIES_ID ).is( seriesUid ) );

        try {
            var caseStudies = mongoRetryService.find( query, CaseStudy.class, DICOM_INSTANCES_COLLECTION ).get( );
            return caseStudies.stream( ).filter( Objects::nonNull ).map( caseStudy -> new InstancesMeta( caseStudy.getBarcode( ), caseStudy.getSeriesInstanceUid( ), caseStudy.getSopInstanceUid( ), caseStudy.getProcessingStatus( ).name( ), caseStudy.getIntermediateStoragePath( ), caseStudy.getDeviceSerialNumber( ) ) ).toList( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while getting instances of series" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public String fetchStatusOfInstance ( String seriesInstanceUid, String sopInstanceUid ) {
        Query query = new Query( Criteria.where( ApiConstants.SERIES_ID ).is( seriesInstanceUid ).and( ApiConstants.SOP_INSTANCE_ID ).is( sopInstanceUid ) );
        query.fields( ).include( "processingStatus" );

        try {
            var instances = mongoRetryService.findOne( query, CaseStudy.class, DICOM_INSTANCES_COLLECTION ).get( );
            return instances != null ? instances.getProcessingStatus( ).name( ) : null;

        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while getting status of the  instances" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public CaseStudy getDicomInstanceBySopInstanceUid ( String sopInstanceUid ) {
        Query query = new Query( Criteria.where( ApiConstants.SOP_INSTANCE_ID ).is( sopInstanceUid ) );
        try {
            return mongoRetryService.findOne( query, CaseStudy.class, DICOM_INSTANCES_COLLECTION ).get( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching instances by sop instance uid" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public void saveStorageCommitmentTrackers ( List< StorageCommitmentTracker > trackerList ) {
        validatorConfig.validate( trackerList );
        indexCreationConfig.ensureCollectionExists( TRACKER_COLLECTION );
        indexCreationConfig.createIndexForCollections( TRACKER_COLLECTION, Map.of( ApiConstants.SOP_INSTANCE_ID, Sort.Direction.ASC ), true );


        try {
             CompletableFuture<Boolean> f = mongoRetryService.upsertBulk( trackerList, TRACKER_COLLECTION, StorageCommitmentTracker.class, tracker -> {
                tracker.setTimestamp( new Date( ) );
                return new Query( Criteria.where( "sopInstanceUid" ).is( tracker.getSopInstanceUid( ) ) );
            }, tracker -> new Update( ).set( "seriesInstanceUid", tracker.getSeriesInstanceUid( ) ).set( "cmtRequestStatus", tracker.getCmtRequestStatus( ) ).set( "cmtResponseStatus", tracker.getCmtResponseStatus( ) ).set( "cmtRequestId", tracker.getRequestId( ) ).set( "timestamp",
                     tracker.getTimestamp( ) ), BulkOperations.BulkMode.UNORDERED );
            Boolean isStorageCommitmentSaved = f.completeOnTimeout(false, 2, TimeUnit.MINUTES  ).get();
            if ( Boolean.FALSE.equals( isStorageCommitmentSaved ) ) {
                throw new DatabaseException( "Bulk upsert failed for storage commitment trackers" );
            }
            log.info( "saveStorageCommitmentTrackers :: the storage commitment saved status is :: {}", isStorageCommitmentSaved );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while saving storage commitment trackers" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request: " + cause.getMessage( ), cause );
        }
    }


    private void saveOrUpdateStorageCmtTracker ( CaseStudy caseStudy ) {
        indexCreationConfig.ensureCollectionExists( TRACKER_COLLECTION );
        indexCreationConfig.createIndexForCollections( TRACKER_COLLECTION, Map.of( ApiConstants.SOP_INSTANCE_ID, Sort.Direction.ASC ), true );
        indexCreationConfig.createIndexForCollections( TRACKER_COLLECTION, Map.of( "cmtRequestId", Sort.Direction.ASC ), false );
        Query query = new Query( Criteria.where( ApiConstants.SOP_INSTANCE_ID ).is( caseStudy.getSopInstanceUid( ) ) );
        Update update = new Update( ).set( ApiConstants.SERIES_ID, caseStudy.getSeriesInstanceUid( ) ).set( "timestamp", new Date( ) );
        try {
            Boolean isCommitmentTrackerSaved = mongoRetryService.upsert( query, update, StorageCommitmentTracker.class, TRACKER_COLLECTION ).get( );

            log.info( "saveOrUpdateStorageCmtTracker :: Task saveOrUpdateStorageCmtTracker completed successfully! :: {}", isCommitmentTrackerSaved );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while saving or updating storage commitments tracker" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public void saveQidoRs ( QidoResponse response ) {
        String collectionName = "qido_rs_store";
        validatorConfig.validate( response );
        indexCreationConfig.ensureCollectionExists( collectionName );
        indexCreationConfig.createIndexForCollections( collectionName, Map.of( ApiConstants.SERIES_ID, Sort.Direction.ASC ), true );
        Query query = new Query( Criteria.where( ApiConstants.SERIES_ID ).is( response.seriesUid( ) ) );
        Update update = new Update( ).set( "response", response.response( ) );

        try {
            Boolean isQidoRsSaved = mongoRetryService.upsert( query, update, QidoResponse.class, collectionName ).get( );
            log.info( "saveQidoRs :: response :: {}", isQidoRsSaved );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while saving qido rs" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public List< String > getInstancesByRequestId ( String requestId ) {
        Query query = new Query( Criteria.where( "cmtRequestId" ).is( requestId ) );

        try {
            var caseStudies = mongoRetryService.find( query, StorageCommitmentTracker.class, TRACKER_COLLECTION ).get( );
            return caseStudies.stream( ).filter( Objects::nonNull ).map( StorageCommitmentTracker::getSopInstanceUid ).toList( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching instances by request id" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

    public List< String > getSeriesIdByInstanceId ( List< String > instanceIds ) {
        Query query = new Query( Criteria.where( ApiConstants.SOP_INSTANCE_ID ).in( instanceIds ) );

        try {
            var future = mongoRetryService.find( query, CaseStudy.class, DICOM_INSTANCES_COLLECTION );
            var matchedInstance = future.get( );
            return matchedInstance.stream( ).map( CaseStudy::getSeriesInstanceUid ).filter( Objects::nonNull ).toList( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching series by instance id" );
        } catch ( ExecutionException ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

}
