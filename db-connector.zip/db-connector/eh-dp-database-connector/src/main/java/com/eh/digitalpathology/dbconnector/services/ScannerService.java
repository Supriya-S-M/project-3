package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.PathQaSlide;
import com.eh.digitalpathology.dbconnector.model.SlideScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Service
public class ScannerService {

    private static final Logger logger = LoggerFactory.getLogger( ScannerService.class.getName( ) );

    private final ScannerAsyncService scannerAsyncService;

    public ScannerService ( ScannerAsyncService scannerAsyncService ) {
        this.scannerAsyncService = scannerAsyncService;
    }


    public boolean isBarcodeExistsForQaSlide ( String barcode ) {
        logger.info( "getQaSlideByBarcode :: barcode :: {}", barcode );
        String slideCacheKey = "slide::barcode::" + barcode;

        try {
            CompletableFuture< PathQaSlide > future = scannerAsyncService.fetchQaSlide( barcode, slideCacheKey );
            // Wait up to 2 minutes, then bail out
            PathQaSlide pathQaSlide = future.get( 2, TimeUnit.MINUTES );

            logger.info( "isBarcodeExistsForQaSlide :: pathQaSlide :: {}", pathQaSlide );
            return pathQaSlide != null;

        } catch ( TimeoutException te ) {
            logger.warn( "Timed out after 2 minutes waiting for QA slide for barcode {}", barcode );
            return false;

        } catch ( InterruptedException ie ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching QA Slide data", ie );

        } catch ( ExecutionException ee ) {
            Throwable cause = ee.getCause( );
            String msg = ( cause != null ? cause.getMessage( ) : ee.getMessage( ) );
            throw new DatabaseException( "Error processing MongoDB Request: " + msg, ( cause != null ? cause : ee ) );
        }
    }


    public String getScannerDicomStoreByDeviceSerialNumber ( String deviceSerialNumber ) {
        logger.info( "getScannerDicomStoreByDeviceSerialNumber :: deviceSerialNumber :: {}", deviceSerialNumber );
        String scannerCacheKey = "scanner::deviceId::" + deviceSerialNumber;
        try {
            SlideScanner scanner = scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber( deviceSerialNumber, scannerCacheKey ).get( );
            if ( scanner == null ) {
                return "";
            }
            return scanner.dicomStore( );
        } catch ( InterruptedException e ) {
            Thread.currentThread( ).interrupt( );
            throw new DatabaseException( "Thread was interrupted while fetching Scanner Dicom Store data" );
        } catch ( Exception ex ) {
            Throwable cause = ex.getCause( );
            throw new DatabaseException( "Error processing MongoDB Request" + cause.getMessage( ), cause );
        }
    }

}
