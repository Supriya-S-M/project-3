package com.eh.digitalpathology.dbconnector.enums;

public enum WorkflowStatusEnum {
    DICOM_INSTANCE_RECEIVED("dicom-receiver"),
    LIS_REQUEST_GENERATED("message-generator"),
    LIS_RESPONSE_RECEIVED("lis-connector"),
    NEGATIVE_QUERY_RECEIVED("negative-query"),
    ENRICHMENT_STARTED("dicom-enriched"),
    ENRICHMENT_COMPLETED("dicom-enriched-completed"),
    ENRICHMENT_FAILED("dicom-enriched-failed"),
    COMMITTED("committed"),
    EXPORTED("exported");

    private String value;

    WorkflowStatusEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static WorkflowStatusEnum fromValue(String value) {
        for (WorkflowStatusEnum status : WorkflowStatusEnum.values()) {
            if (status.getValue().equalsIgnoreCase(value)) {
                return status;
            }
        }
        throw new IllegalArgumentException("Unknown value: " + value);
    }
}
