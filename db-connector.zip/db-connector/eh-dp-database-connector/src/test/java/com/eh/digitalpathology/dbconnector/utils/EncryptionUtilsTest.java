package com.eh.digitalpathology.dbconnector.utils;

import com.google.cloud.ServiceOptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

import javax.crypto.Cipher;

import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mockStatic;

class EncryptionUtilsTest {
    private static final String PROJECT_ID = "test-project";
    private static final String SAMPLE_TEXT = "Sample Text Message";

    @BeforeEach
    void setup() throws NoSuchAlgorithmException {
        Cipher.getMaxAllowedKeyLength("AES");
    }

    @Test
    void testEncryptAndDecrypt_Success() throws Exception {
        try (MockedStatic<ServiceOptions> mocked = mockStatic(ServiceOptions.class)) {
            mocked.when(ServiceOptions::getDefaultProjectId).thenReturn(PROJECT_ID);

            String encrypted = EncryptionUtils.encrypt(SAMPLE_TEXT);
            assertNotNull(encrypted);
            assertNotEquals(SAMPLE_TEXT, encrypted, "Encrypted text should not match original data");

            String decrypted = EncryptionUtils.decrypt(encrypted);
            assertEquals(SAMPLE_TEXT, decrypted, "Decrypted text should match original input");
        }
    }

    @Test
    void testEncrypt_NullInput_ThrowsException() {
        try (MockedStatic<ServiceOptions> mocked = mockStatic(ServiceOptions.class)) {
            mocked.when(ServiceOptions::getDefaultProjectId).thenReturn(PROJECT_ID);

            assertThrows(NullPointerException.class, () -> EncryptionUtils.encrypt(null));
        }
    }

    @Test
    void testDecrypt_InvalidBase64_ThrowsException() {
        try (MockedStatic<ServiceOptions> mocked = mockStatic(ServiceOptions.class)) {
            mocked.when(ServiceOptions::getDefaultProjectId).thenReturn(PROJECT_ID);

            assertThrows(IllegalArgumentException.class, () -> EncryptionUtils.decrypt("Invalid@@@Base64"));
        }
    }

    @Test
    void testDecrypt_WithWrongKey_Fails() throws Exception {
        try (MockedStatic<ServiceOptions> mocked = mockStatic(ServiceOptions.class)) {
            mocked.when(ServiceOptions::getDefaultProjectId).thenReturn(PROJECT_ID);

            String encrypted = EncryptionUtils.encrypt(SAMPLE_TEXT);

            mocked.when(ServiceOptions::getDefaultProjectId).thenReturn("different-project");
            assertThrows(GeneralSecurityException.class, () -> EncryptionUtils.decrypt(encrypted),
                    "Decrypting with different key should fail");
        }
    }
}


