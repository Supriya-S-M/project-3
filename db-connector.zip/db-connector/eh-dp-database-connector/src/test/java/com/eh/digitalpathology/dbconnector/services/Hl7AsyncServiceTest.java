package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.dtos.DocumentDto;
import com.eh.digitalpathology.dbconnector.model.Hl7Segment;
import com.eh.digitalpathology.dbconnector.utils.EncryptionUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class Hl7AsyncServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;
    @Mock
    private RedisTemplate<String, Object> redisTemplate;
    @Mock
    private ValueOperations<String, Object> valueOperations;
    @InjectMocks
    private Hl7AsyncService hl7AsyncService;

    @BeforeEach
    void setUp() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
    }

    @Test
    void testFetchHl7SegmentAsync_CacheHit() {
        String hl7Message = """
                MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
                OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
                """;
        String barcode = "VSA-100";
        String messageType = "ORU";
        String hl7CacheKey = "hl7_oru_12345";
        boolean isEncrypted = false;

        Hl7Segment cachedSegment = Hl7Segment.create(barcode, messageType, hl7Message, Map.of(),new Date());
        when(valueOperations.get(hl7CacheKey)).thenReturn(cachedSegment);

        CompletableFuture<Hl7Segment> future = hl7AsyncService.fetchHl7SegmentAsync(barcode, messageType, hl7CacheKey, isEncrypted);
        Hl7Segment result = future.join();

        Assertions.assertNotNull(result);
        Assertions.assertEquals(cachedSegment, result);
        verify(mongoRetryService, never()).findOne(any(), any(), anyString());
    }

    @Test
    void testFetchHl7SegmentAsync_UnencryptedMsg() {
        String barcode = "VSA-100";
        String messageType = "ORU";
        String hl7CacheKey = "hl7_oru_12345";
        boolean isEncrypted = false;

        String rawMessage = "MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4";
        Hl7Segment hl7Segment = Hl7Segment.create(barcode, messageType, rawMessage, Map.of(), new Date());

        when(valueOperations.get(hl7CacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(Hl7Segment.class), eq("hl7_oru")))
                .thenReturn(CompletableFuture.completedFuture(hl7Segment));

        CompletableFuture<Hl7Segment> future = hl7AsyncService.fetchHl7SegmentAsync(barcode, messageType, hl7CacheKey, isEncrypted);
        Hl7Segment result = future.join();

        Assertions.assertNotNull(result);
        Assertions.assertEquals(barcode, result.barcode());
        verify(valueOperations).set("hl7_oru_12345", hl7Segment, Duration.ofHours(1));
    }

    @Test
    void testFetchHl7SegmentAsync_EncryptedMsg_Success() {
        String barcode = "VSA-200";
        String messageType = "ORU";
        String hl7CacheKey = "hl7_oru_67890";
        boolean isEncrypted = true;

        String encryptedRaw = "encryptedRawMessage";
        String decryptedRaw = "decryptedRawMessage";

        Map<String, String> encryptedData = Map.of("key1", "encVal1");
        Map<String, String> decryptedData = Map.of("key1", "decVal1");

        Hl7Segment hl7Segment = Hl7Segment.create(barcode, messageType, encryptedRaw, encryptedData, new Date());

        when(valueOperations.get(hl7CacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(Hl7Segment.class), eq("hl7_oru")))
                .thenReturn(CompletableFuture.completedFuture(hl7Segment));

        try (MockedStatic<EncryptionUtils> utilities = mockStatic(EncryptionUtils.class)) {
            utilities.when(() -> EncryptionUtils.decrypt(encryptedRaw)).thenReturn(decryptedRaw);
            utilities.when(() -> EncryptionUtils.decrypt("encVal1")).thenReturn("decVal1");

            CompletableFuture<Hl7Segment> future = hl7AsyncService.fetchHl7SegmentAsync(barcode, messageType, hl7CacheKey, isEncrypted);
            Hl7Segment result = future.join();

            Assertions.assertNotNull(result);
            Assertions.assertEquals(decryptedRaw, result.rawHl7Message());
            Assertions.assertEquals(decryptedData, result.parsedData());
            verify(valueOperations).set(eq(hl7CacheKey), any(Hl7Segment.class), eq(Duration.ofHours(1)));

        }
    }


    @Test
    void testSearchMessageTypeByBarcodeAsync() {
        String barcode = "VSA-100";
        Set<String> collections = Set.of("hl7_oul", "hl7_oru");

        DocumentDto doc1 = new DocumentDto("OUL");
        DocumentDto doc2 = new DocumentDto("ORU");

        when(mongoRetryService.getCollectionNames())
                .thenReturn(CompletableFuture.completedFuture(collections));

        when(mongoRetryService.find(any(), eq(DocumentDto.class), eq("hl7_oul")))
                .thenReturn(CompletableFuture.completedFuture(List.of(doc1)));

        when(mongoRetryService.find(any(), eq(DocumentDto.class), eq("hl7_oru")))
                .thenReturn(CompletableFuture.completedFuture(List.of(doc2)));

        CompletableFuture<Map<String, Set<String>>> future =
                hl7AsyncService.searchMessageTypeByBarcodeAsync(barcode);
        Map<String, Set<String>> result = future.join();

        Assertions.assertNotNull(result);
        Assertions.assertTrue(result.containsKey(ApiConstants.MESSAGE_TYPE));
        Assertions.assertEquals(Set.of("OUL", "ORU"), result.get(ApiConstants.MESSAGE_TYPE));
    }

}
