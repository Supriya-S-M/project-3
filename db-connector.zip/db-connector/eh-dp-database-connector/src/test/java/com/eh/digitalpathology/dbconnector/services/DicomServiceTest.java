package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.CaseStudy;
import com.eh.digitalpathology.dbconnector.model.InstancesMeta;
import com.eh.digitalpathology.dbconnector.model.QidoResponse;
import com.eh.digitalpathology.dbconnector.model.StorageCommitmentTracker;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.springframework.data.mongodb.core.BulkOperations;

import static com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum.DICOM_INSTANCE_RECEIVED;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DicomServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;
    @Mock
    private IndexCreationConfig indexCreationConfig;
    @Mock
    private GlobalValidatorConfig validatorConfig;
    @InjectMocks
    private DicomService dicomService;
    private CaseStudy caseStudy;

    @BeforeEach
    void setUp() {
        caseStudy = new CaseStudy();
        caseStudy.setSopInstanceUid("sop123");
        caseStudy.setSeriesInstanceUid("series123");
        caseStudy.setBarcode("VSA-100");
        caseStudy.setProcessingStatus(DICOM_INSTANCE_RECEIVED);
    }

    @Test
    void testPersists_success()  {
        when(mongoRetryService.save(any(), anyString())).thenReturn(CompletableFuture.completedFuture(caseStudy));

        when(mongoRetryService.upsert(any(), any(), eq(StorageCommitmentTracker.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(true));

        String result = dicomService.persists("dicom-receiver", caseStudy);

        assertTrue(result.contains("Study saved successfully"));
        verify(validatorConfig).validate(caseStudy);
        verify(indexCreationConfig).createIndexForCollections(eq("stgcmt_tracker"), any(), eq(true));
    }

    @Test
    void testPersists_interruptedException() throws Exception {
        CompletableFuture<CaseStudy> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));
        when(mongoRetryService.save(any(CaseStudy.class), anyString())).thenReturn(mockFuture);
        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.persists("dicom-receiver", caseStudy));
        Assertions.assertEquals( "Thread was interrupted while saving instances", exception.getMessage());

    }


    @Test
    void testPersists_executionException() {
        when(mongoRetryService.save(any(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.persists("dicom-receiver", caseStudy));

        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));
        verify(indexCreationConfig).ensureCollectionExists(anyString());
        verify(indexCreationConfig).createIndexForCollections(anyString(), any(), eq(true));
    }


    @Test
    void testUpdateStatus_success() {
        when(mongoRetryService.findAndModify(any(), any(), anyString(), eq(CaseStudy.class)))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));

        String result = dicomService.updateStatus("dicom-receiver", "VSA-100", "sop123");

        assertTrue(result.contains("is updated"));
    }

    @Test
    void testUpdateStatus_interruptedException() throws Exception {

        CompletableFuture<CaseStudy> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.findAndModify(any(), any(), anyString(), eq(CaseStudy.class)))
                .thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.updateStatus("dicom-receiver", "barcode123", "sop123"));

        Assertions.assertEquals( "Thread was interrupted while updating status of the  instances", exception.getMessage());
        verify(mongoRetryService).findAndModify(any(), any(), anyString(), eq(CaseStudy.class));
    }

    @Test
    void testUpdateStatus_executionException() {
        when(mongoRetryService.findAndModify(any(), any(), anyString(), eq(CaseStudy.class)))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomService.updateStatus("dicom-receiver", "barcode123", "sop123");
        });
        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));

        verify(mongoRetryService).findAndModify(any(), any(), anyString(), eq(CaseStudy.class));
    }


    @Test
    void testGetInstancesOfSeries_success() {
        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(List.of(caseStudy)));

        List<InstancesMeta> result = dicomService.getInstancesOfSeries("series123");

        Assertions.assertEquals(1, result.size());
        Assertions.assertEquals("sop123", result.get(0).sopInstanceUid());
    }

    @Test
    void testGetInstancesOfSeries_interruptedException() throws Exception {
        CompletableFuture<List<CaseStudy>> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.getInstancesOfSeries("series123")
        );
        Assertions.assertEquals("Thread was interrupted while getting instances of series", exception.getMessage());

        verify(mongoRetryService).find(any(), eq(CaseStudy.class), anyString());
    }

    @Test
    void testGetInstancesOfSeries_executionException() {
        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomService.getInstancesOfSeries("series123");
        });
        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));

        verify(mongoRetryService).find(any(), eq(CaseStudy.class), anyString());
    }

    @Test
    void testFetchStatusOfInstance_success() {
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));

        String status = dicomService.fetchStatusOfInstance("series123", "sop123");

        Assertions.assertEquals(DICOM_INSTANCE_RECEIVED.toString(), status);
    }

    @Test
    void testFetchStatusOfInstance_interruptedException() throws Exception {
        CompletableFuture<CaseStudy> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString())).thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.fetchStatusOfInstance("series123", "sop123")
        );
        Assertions.assertEquals("Thread was interrupted while getting status of the  instances", exception.getMessage());
        verify(mongoRetryService).findOne(any(), eq(CaseStudy.class), anyString());
    }

    @Test
    void testFetchStatusOfInstance_executionException() {
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomService.fetchStatusOfInstance("series123", "sop123");
        });
        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));

        verify(mongoRetryService).findOne(any(), eq(CaseStudy.class), anyString());
    }


    @Test
    void testGetDicomInstanceBySopInstanceUid_success() {
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));

        CaseStudy result = dicomService.getDicomInstanceBySopInstanceUid("sop123");

        Assertions.assertNotNull(result);
        Assertions.assertEquals("sop123", result.getSopInstanceUid());
    }

    @Test
    void testGetDicomInstanceBySopInstanceUid_executionException() {
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.getDicomInstanceBySopInstanceUid("sop123"));
        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));

        verify(mongoRetryService).findOne(any(), eq(CaseStudy.class), anyString());
    }

    @Test
    void testGetDicomInstanceBySopInstanceUid_interruptedException() throws Exception {
        CompletableFuture<CaseStudy> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString())).thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.getDicomInstanceBySopInstanceUid("sop123"));
        Assertions.assertEquals("Thread was interrupted while fetching instances by sop instance uid", exception.getMessage());

        verify(mongoRetryService).findOne(any(), eq(CaseStudy.class), anyString());
    }


    @Test
    void testSaveStorageCommitmentTrackers_success() {
        StorageCommitmentTracker tracker = new StorageCommitmentTracker();
        tracker.setSopInstanceUid("sop123");
        tracker.setSeriesInstanceUid("series123");
        tracker.setRequestId("req123");
        tracker.setTimestamp(new Date());
        tracker.setCmtRequestStatus(true);
        tracker.setCmtResponseStatus(true);

        when(mongoRetryService.upsertBulk(anyList(), anyString(), eq(StorageCommitmentTracker.class), any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(true));

        dicomService.saveStorageCommitmentTrackers(List.of(tracker));

        verify(validatorConfig).validate(anyList());
        verify(indexCreationConfig).ensureCollectionExists(anyString());
        verify(indexCreationConfig).createIndexForCollections(anyString(), any(), eq(true));

        Assertions.assertEquals("series123", tracker.getSeriesInstanceUid());
        Assertions.assertEquals("sop123", tracker.getSopInstanceUid());
        Assertions.assertEquals("req123", tracker.getRequestId());
        Assertions.assertTrue(tracker.getCmtRequestStatus());
        Assertions.assertTrue(tracker.getCmtResponseStatus());

    }

    @Test
    void testSaveStorageCommitmentTrackers_interruptedException() throws Exception {
        StorageCommitmentTracker tracker = new StorageCommitmentTracker();
        tracker.setSopInstanceUid("sop123");

        CompletableFuture<Boolean> mockFuture = mock(CompletableFuture.class);
        CompletableFuture<Boolean> timedFuture = mock(CompletableFuture.class);
        when(mockFuture.completeOnTimeout(anyBoolean(), eq( 2L ), eq( TimeUnit.MINUTES ))).thenReturn( timedFuture );
        when( timedFuture.get() ).thenThrow( new InterruptedException( "Interrupted" ) );

        when(mongoRetryService.upsertBulk(anyList(), anyString(), eq(StorageCommitmentTracker.class), any(), any(),
                eq(BulkOperations.BulkMode.UNORDERED))).thenReturn(mockFuture);

        List<StorageCommitmentTracker> trackers = List.of(new StorageCommitmentTracker());

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.saveStorageCommitmentTrackers(trackers));
        Assertions.assertEquals("Thread was interrupted while saving storage commitment trackers", exception.getMessage());

        verify(validatorConfig).validate(anyList());
    }

    @Test
    void testSaveStorageCommitmentTrackers_executionException() throws Exception {
        StorageCommitmentTracker tracker = new StorageCommitmentTracker();
        tracker.setSopInstanceUid("sop123");

        ExecutionException mockExecutionException = new ExecutionException(new RuntimeException("MongoDB failure"));

        // Mock the original future returned by upsertBulk
        CompletableFuture<Boolean> mockFuture = mock(CompletableFuture.class);

        // Mock the "timed" future returned by completeOnTimeout(...)
        CompletableFuture<Boolean> timedFuture = mock(CompletableFuture.class);

        when(mockFuture.completeOnTimeout(anyBoolean(), eq( 2L ), eq( TimeUnit.MINUTES ))).thenReturn( timedFuture );
        when( timedFuture.get() ).thenThrow( mockExecutionException );
        when(mongoRetryService.upsertBulk(anyList(),anyString(), eq(StorageCommitmentTracker.class), any(), any(), any())).thenReturn(mockFuture);
        List<StorageCommitmentTracker> trackers = List.of(new StorageCommitmentTracker());

        DatabaseException ex = assertThrows(DatabaseException.class, () -> dicomService.saveStorageCommitmentTrackers(trackers));
        assertTrue(ex.getMessage().contains("Error processing MongoDB Request: "));
        verify(validatorConfig).validate(anyList());
    }


    @Test
    void testPersists_saveOrUpdateStorageCmtTracker_executionException() {
        when(mongoRetryService.save(any(), anyString()))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));

        when(mongoRetryService.upsert(any(), any(), eq(StorageCommitmentTracker.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomService.persists("dicom-receiver", caseStudy);});

        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));
        verify(mongoRetryService).upsert(any(), any(), eq(StorageCommitmentTracker.class), anyString());
    }

    @Test
    void testSaveQidoRs_success() {
        QidoResponse response = new QidoResponse("01", "seriesId1.0","response",1);

        when(mongoRetryService.upsert(any(), any(), eq(QidoResponse.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(true));

        dicomService.saveQidoRs(response);

        verify(validatorConfig).validate(response);
    }

    @Test
    void testSaveQidoRs_executionException() {
        QidoResponse response = new QidoResponse("01", "seriesId1.0","response",1);

        doNothing().when(validatorConfig).validate(any());
        when(mongoRetryService.upsert(any(), any(), eq(QidoResponse.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", new RuntimeException("Mongo error"))));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {dicomService.saveQidoRs(response);});

        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));
        verify(mongoRetryService).upsert(any(), any(), eq(QidoResponse.class), anyString());
    }


    @Test
    void testSaveQidoRs_interruptedException() throws Exception {
        QidoResponse response = new QidoResponse("01", "seriesId1.0","response",1);

        CompletableFuture<Boolean> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.upsert(any(), any(), eq(QidoResponse.class), anyString()))
                .thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.saveQidoRs(response));

        Assertions.assertEquals("Thread was interrupted while saving qido rs", exception.getMessage());
        verify(validatorConfig).validate(response);
        verify(indexCreationConfig).ensureCollectionExists("qido_rs_store");
    }

    @Test
    void testGetInstancesByRequestId_success() {
        StorageCommitmentTracker tracker = new StorageCommitmentTracker();
        tracker.setSopInstanceUid("sop123");

        when(mongoRetryService.find(any(), eq(StorageCommitmentTracker.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(List.of(tracker)));

        List<String> result = dicomService.getInstancesByRequestId("req123");

        Assertions.assertEquals(List.of("sop123"), result);
    }

    @Test
    void testGetInstancesByRequestId_interruptedException() throws Exception {
        CompletableFuture<List<StorageCommitmentTracker>> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.find(any(), eq(StorageCommitmentTracker.class), anyString()))
                .thenReturn(mockFuture);

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.getInstancesByRequestId("req123")
        );

        Assertions.assertEquals("Thread was interrupted while fetching instances by request id", exception.getMessage());
        verify(mongoRetryService).find(any(), eq(StorageCommitmentTracker.class), anyString());
    }

    @Test
    void testGetInstancesByRequestId_executionException() {
        when(mongoRetryService.find(any(), eq(StorageCommitmentTracker.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(
                        new ExecutionException("Execution failed", new RuntimeException("Mongo error"))
                ));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomService.getInstancesByRequestId("req123"));

        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));
        verify(mongoRetryService).find(any(), eq(StorageCommitmentTracker.class), anyString());
    }


    @Test
    void testGetSeriesIdByInstanceId_success() {
        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(List.of(caseStudy)));

        List<String> result = dicomService.getSeriesIdByInstanceId(List.of("sop123"));

        Assertions.assertEquals(List.of("series123"), result);
    }

    @Test
    void testGetSeriesIdByInstanceId_interruptedException() throws Exception {
        CompletableFuture<List<CaseStudy>> mockFuture = mock(CompletableFuture.class);
        when(mockFuture.get()).thenThrow(new InterruptedException("Interrupted"));

        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(mockFuture);
        List<String> instanceIds = List.of("series1", "series2");
        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomService.getSeriesIdByInstanceId(instanceIds));

        Assertions.assertEquals("Thread was interrupted while fetching series by instance id", exception.getMessage());
        verify(mongoRetryService).find(any(), eq(CaseStudy.class), anyString());
    }


    @Test
    void testGetSeriesIdByInstanceId_executionException() {
        when(mongoRetryService.find(any(), eq(CaseStudy.class), anyString()))
                .thenReturn(CompletableFuture.failedFuture(
                        new ExecutionException("Execution failed", new RuntimeException("Mongo error"))
                ));
        List<String> instanceIds = List.of("series1", "series2");

        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomService.getSeriesIdByInstanceId(instanceIds);});

        Assertions.assertTrue( exception.getMessage().contains("Error processing MongoDB Request"));
        verify(mongoRetryService).find(any(), eq(CaseStudy.class), anyString());
    }

}
