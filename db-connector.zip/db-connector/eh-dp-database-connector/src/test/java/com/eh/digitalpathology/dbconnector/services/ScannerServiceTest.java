package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.PathQaSlide;
import com.eh.digitalpathology.dbconnector.model.SlideScanner;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith( MockitoExtension.class )
class ScannerServiceTest {
    @Mock
    private ScannerAsyncService scannerAsyncService;

    private ScannerService scannerService;

    @BeforeEach
    void setup ( ) {
        scannerService = new ScannerService( scannerAsyncService );
    }

    @Test
    void testIsBarcodeExistsForQaSlide_whenSlideExists_returnsTrue ( ) {
        String barcode = "VSA-150";
        PathQaSlide mockSlide = new PathQaSlide( "Id1", "VSA-150", "code123" );

        when( scannerAsyncService.fetchQaSlide( eq( barcode ), anyString( ) ) ).thenReturn( CompletableFuture.completedFuture( mockSlide ) );

        boolean result = scannerService.isBarcodeExistsForQaSlide( barcode );
        assertTrue( result );
    }

    @Test
    void testIsBarcodeExistsForQaSlide_whenSlideDoesNotExist_returnsFalse ( ) {
        String barcode = "VSA-150";

        when( scannerAsyncService.fetchQaSlide( eq( barcode ), anyString( ) ) ).thenReturn( CompletableFuture.completedFuture( null ) );

        boolean result = scannerService.isBarcodeExistsForQaSlide( barcode );
        assertFalse( result );
    }

    @Test
    void testIsBarcodeExistsForQaSlide_InterruptedException ( ) throws Exception {
        String barcode = "VSA-150";

        CompletableFuture< PathQaSlide > future = mock( CompletableFuture.class );
        when( scannerAsyncService.fetchQaSlide( eq( barcode ), anyString( ) ) ).thenReturn( future );
        when(future.get(eq(2L), eq( TimeUnit.MINUTES))).thenThrow(new InterruptedException());
        try {
            DatabaseException ex = Assertions.assertThrows( DatabaseException.class, ( ) -> scannerService.isBarcodeExistsForQaSlide( barcode ) );
            Assertions.assertEquals( "Thread was interrupted while fetching QA Slide data", ex.getMessage( ) );
            // The service sets the interrupt flag; assert it's set
            Assertions.assertTrue( Thread.currentThread( ).isInterrupted( ), "Interrupt flag should be set on the current thread" );
        } finally {
            // Clear the interrupt flag to avoid affecting other tests
            Thread.interrupted( ); // returns current flag and clears it
        }
    }

    @Test
    void testIsBarcodeExistsForQaSlide_throwsException ( ) {
        String barcode = "VSA-150";
        when( scannerAsyncService.fetchQaSlide( eq( barcode ), anyString( ) ) ).thenReturn( CompletableFuture.failedFuture( new Exception( ) ) );
        DatabaseException thrown = assertThrows( DatabaseException.class, ( ) -> scannerService.isBarcodeExistsForQaSlide( barcode ) );
        Assertions.assertTrue( thrown.getMessage( ).contains( "Error processing MongoDB Request" ) );
    }

    @Test
    void testGetScannerDicomStoreByDeviceSerialNumber_whenScannerExists_returnsDicomStore ( ) {
        String deviceSerialNumber = "device001";
        SlideScanner mockScanner = mock( SlideScanner.class );
        when( mockScanner.dicomStore( ) ).thenReturn( "dicom-store-url" );

        when( scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber( eq( deviceSerialNumber ), anyString( ) ) ).thenReturn( CompletableFuture.completedFuture( mockScanner ) );

        String result = scannerService.getScannerDicomStoreByDeviceSerialNumber( deviceSerialNumber );
        Assertions.assertEquals( "dicom-store-url", result );
    }

    @Test
    void testGetScannerDicomStoreByDeviceSerialNumber_whenScannerIsNull_returnsEmptyString ( ) {
        String deviceSerialNumber = "device001";

        when( scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber( eq( deviceSerialNumber ), anyString( ) ) ).thenReturn( CompletableFuture.completedFuture( null ) );

        String result = scannerService.getScannerDicomStoreByDeviceSerialNumber( deviceSerialNumber );
        Assertions.assertEquals( "", result );
    }

    @Test
    void testGetScannerDicomStoreByDeviceSerialNumber_DatabaseException ( ) throws Exception {
        String deviceSerialNumber = "device001";

        CompletableFuture< SlideScanner > future = mock( CompletableFuture.class );
        when( scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber( eq( deviceSerialNumber ), anyString( ) ) ).thenReturn( future );
        when( future.get( ) ).thenThrow( new InterruptedException( ) );

        DatabaseException exception = assertThrows( DatabaseException.class, ( ) -> scannerService.getScannerDicomStoreByDeviceSerialNumber( deviceSerialNumber ) );

        Assertions.assertEquals( "Thread was interrupted while fetching Scanner Dicom Store data", exception.getMessage( ) );

    }

    @Test
    void testGetScannerDicomStoreByDeviceSerialNumber_ExecutionException ( ) {
        String deviceSerialNumber = "device001";
        when( scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber( eq( deviceSerialNumber ), anyString( ) ) ).thenReturn( CompletableFuture.failedFuture( new RuntimeException( ) ) );

        DatabaseException exception = assertThrows( DatabaseException.class, ( ) -> scannerService.getScannerDicomStoreByDeviceSerialNumber( deviceSerialNumber ) );

        Assertions.assertTrue( exception.getMessage( ).contains( "Error processing MongoDB Request" ) );

    }


}