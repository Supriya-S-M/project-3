package com.eh.digitalpathology.dbconnector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(properties = "spring.cloud.config.enabled=false")
class DBConnectorApplicationTests {

	@Test
	void contextLoads() {
		// no implementation
	}

}
