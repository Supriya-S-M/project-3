package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EnrichedServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;
    @Mock
    private DicomService dicomService;
    @Mock
    private Hl7Service hl7Service;
    @InjectMocks
    private EnrichedService enrichedService;
    @Mock
    private GlobalValidatorConfig validatorConfig;

    @Test
    void testFetchDicomEnrichedData_success()  {

        EnrichedRequest request = new EnrichedRequest();
        request.setBarcode("123");
        request.setSopInstanceUid("sop123");
        request.setSeriesInstanceUid("series123");
        request.setMessageType("ORU");

        Hl7Segment hl7Segment = mock(Hl7Segment.class);

        CaseStudy caseStudy = new CaseStudy();
        caseStudy.setIntermediateStoragePath("/path");
        caseStudy.setOriginalStudyInstanceUid("originalUid");

        when(hl7Service.fetchHl7Segment("123", "ORU")).thenReturn(hl7Segment);
        when(mongoRetryService.findOne(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));
        when(dicomService.updateStatus(any(), any(), any())).thenReturn("UPDATED");

        EnrichedResponse response = enrichedService.fetchDicomEnrichedData("serviceName", request);

        Assertions.assertEquals("123", response.getBarcode());
        Assertions.assertEquals("sop123", response.getSopInstanceUid());
        Assertions.assertEquals("series123", response.getSeriesInstanceUid());
        Assertions.assertEquals("/path", response.getIntermediateStoragePath());
        Assertions.assertEquals("originalUid", response.getOriginalStudyInstanceUid());
    }

    @Test
    void testFetchDicomEnrichedData_hl7SegmentNull_throwsException()  {
        EnrichedRequest request = new EnrichedRequest();
        request.setBarcode("123");
        request.setSopInstanceUid("sop123");
        request.setMessageType("ORU");

        when(mongoRetryService.findOne(any(), any(), any()))
                .thenReturn(CompletableFuture.completedFuture(new CaseStudy()));

        when(hl7Service.fetchHl7Segment(any(), any())).thenReturn(null);

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () ->
                enrichedService.fetchDicomEnrichedData("serviceName", request)
        );
        Assertions.assertEquals("hl7 segment is null as there is no entry in the database", exception.getMessage());

    }

    @Test
    void testFetchDicomEnrichedData_interruptedException() throws Exception {
        EnrichedRequest request = new EnrichedRequest();
        request.setBarcode("123");
        request.setSopInstanceUid("sop123");
        request.setMessageType("ORU");

        Hl7Segment hl7Segment = mock(Hl7Segment.class);
        when(hl7Service.fetchHl7Segment(any(), any())).thenReturn(hl7Segment);

        CompletableFuture<CaseStudy> future = mock(CompletableFuture.class);
        when(future.get()).thenThrow(new InterruptedException("Interrupted"));
        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString())).thenReturn(future);

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class,
                () -> enrichedService.fetchDicomEnrichedData("serviceName", request));
        Assertions.assertEquals("Thread was interrupted while fetching enriched data", exception.getMessage());

    }

    @Test
    void testFetchDicomEnrichedData_executionException() {
        EnrichedRequest request = new EnrichedRequest();
        request.setBarcode("123");
        request.setSopInstanceUid("sop123");
        request.setMessageType("ORU");

        Hl7Segment hl7Segment = mock(Hl7Segment.class);
        when(hl7Service.fetchHl7Segment(any(), any())).thenReturn(hl7Segment);

        when(mongoRetryService.findOne(any(), eq(CaseStudy.class), anyString())).
                thenReturn(CompletableFuture.failedFuture(new ExecutionException("failed",new Throwable())));

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class,
                () -> enrichedService.fetchDicomEnrichedData("serviceName", request));
        Assertions.assertTrue(exception.getMessage().contains("Error processing MongoDB Request"));

    }

    @Test
    void testUpdateEnrichedStatus_success()  {
        EnrichInstance instance = new EnrichInstance();
        instance.setBarcode("123");
        instance.setSopInstanceUid("sop123");
        instance.setStatus("COMPLETED");
        instance.setActualStudyInstanceUid("actualUid");

        CaseStudy caseStudy = new CaseStudy();
        caseStudy.setSopInstanceUid("sop123");

        when(mongoRetryService.findAndModify(any(), any(), eq("dicom_instances"), eq(CaseStudy.class)))
                .thenReturn(CompletableFuture.completedFuture(caseStudy));

        String result = enrichedService.updateEnrichedStatus("dicom-enriched", instance);

        Assertions.assertEquals("Study updated successfully:: sop123", result);
    }

    @Test
    void testUpdateEnrichedStatus_interruptedException() throws InterruptedException, ExecutionException {
        EnrichInstance instance = new EnrichInstance();
        instance.setBarcode("123");
        instance.setSopInstanceUid("sop123");
        instance.setStatus("COMPLETED");

        CompletableFuture<CaseStudy> future = mock(CompletableFuture.class);
        when(future.get()).thenThrow(new InterruptedException("Interrupted"));
        when(mongoRetryService.findAndModify(any(), any(), any(),eq(CaseStudy.class))).thenReturn(future);

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () ->
                enrichedService.updateEnrichedStatus("dicom-enriched", instance)
        );
        Assertions.assertEquals("Thread was interrupted while updating enriched status", exception.getMessage());

    }

    @Test
    void testUpdateEnrichedStatus_executionException() {
        EnrichInstance instance = new EnrichInstance();
        instance.setBarcode("123");
        instance.setSopInstanceUid("sop123");
        instance.setStatus("COMPLETED");
        when(mongoRetryService.findAndModify(any(), any(), any(),eq(CaseStudy.class))).
                thenReturn(CompletableFuture.failedFuture(new ExecutionException("failed",new Throwable())));

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () ->
                enrichedService.updateEnrichedStatus("dicom-enriched", instance)
        );
        Assertions.assertTrue(exception.getMessage().contains("Error processing MongoDB Request"));

    }
}
