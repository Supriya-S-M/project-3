package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.DicomDirDocument;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DicomDirServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;
    @Mock
    private IndexCreationConfig indexCreationConfig;
    @Mock
    private GlobalValidatorConfig validatorConfig;
    @InjectMocks
    private DicomDirService dicomDirService;
    private DicomDirDocument sampleDocument;


    @BeforeEach
    void setUp() {
        sampleDocument = new DicomDirDocument
                ("series123","study456","seriesId1",5,new byte[3]);
    }

    @Test
    void testSaveMetaDataInfo_success() {
        when(mongoRetryService.save(any(), eq("dicom_meta_data")))
                .thenReturn(CompletableFuture.completedFuture(sampleDocument));

        String result = dicomDirService.saveMetaDataInfo(sampleDocument);

        Assertions.assertTrue(result.contains("DICOMDIR saved successfully"));
        verify(validatorConfig).validate(sampleDocument);
        verify(indexCreationConfig).ensureCollectionExists("dicom_meta_data");
        verify(indexCreationConfig).createIndexForCollections(eq("dicom_meta_data"), anyMap(), eq(true));
    }


    @Test
    void testSaveMetaDataInfo_InterruptedException() throws Exception {
        DicomDirDocument dicomDirDocument = mock(DicomDirDocument.class);

        CompletableFuture<DicomDirDocument> future = mock(CompletableFuture.class);
        when(mongoRetryService.save(eq(dicomDirDocument),anyString())).thenReturn(future);
        when(future.get(eq(2L), eq( TimeUnit.MINUTES))).thenThrow(new InterruptedException());

        DatabaseException exception = assertThrows(DatabaseException.class, () -> dicomDirService.saveMetaDataInfo(dicomDirDocument));
        Assertions.assertEquals("Thread was interrupted while fetching instances.", exception.getMessage());

        verify(validatorConfig).validate(dicomDirDocument);
    }

    @Test
    void testSaveMetaDataInfo_ExecutionException()  {
        DicomDirDocument dicomDirDocument = mock(DicomDirDocument.class);
        Throwable cause = new RuntimeException("Mongo error");
        when(mongoRetryService.save(any(), any())).thenReturn(CompletableFuture.failedFuture(cause));
        DatabaseException exception = assertThrows(DatabaseException.class, () -> {
            dicomDirService.saveMetaDataInfo(dicomDirDocument);
        });

        Assertions.assertTrue(exception.getMessage().contains("Error processing MongoDB Request"));
    }



    @Test
    void testGetMetaDataInfo_success() {
        when(mongoRetryService.findOne(any(), eq(DicomDirDocument.class), eq("dicom_meta_data")))
                .thenReturn(CompletableFuture.completedFuture(sampleDocument));

        DicomDirDocument result = dicomDirService.getMetaDataInfo("series123");
        Assertions.assertEquals("study456", result.studyId());
        Assertions.assertEquals("seriesId1", result.seriesId());
        Assertions.assertEquals(5, result.imageCount());
    }

    @Test
    void testGetMetaDataInfo_InterruptedException() throws Exception {
        String seriesId = "SERIES123";
        CompletableFuture<DicomDirDocument> future = mock(CompletableFuture.class);
        when(future.get(eq(2L), eq( TimeUnit.MINUTES))).thenThrow(new InterruptedException("Interruption"));

        when(mongoRetryService.findOne(any(), eq(DicomDirDocument.class), eq("dicom_meta_data")))
                .thenReturn(future);
        DatabaseException exception = Assertions.assertThrows(DatabaseException.class,() -> dicomDirService.getMetaDataInfo(seriesId));
        Assertions.assertEquals("Thread is interrupted while fetching metadata", exception.getMessage());

    }

    @Test
    void testGetMetaDataInfo_ExecutionException() {
        String series = "SERIES123";
        Throwable cause = new RuntimeException("Mongo error");

        when(mongoRetryService.findOne(any(), eq(DicomDirDocument.class), eq("dicom_meta_data")))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", cause)));

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () -> {dicomDirService.getMetaDataInfo(series);});
        Assertions.assertTrue(exception.getMessage().contains("Error processing MongoDB Request"));
    }

    @Test
    void testGetMetaDataInfo_notFound() {
        when(mongoRetryService.findOne(any(), eq(DicomDirDocument.class), eq("dicom_meta_data")))
                .thenReturn(CompletableFuture.completedFuture(null));

        DatabaseException exception = assertThrows(DatabaseException.class,
                () -> dicomDirService.getMetaDataInfo("series123"));
        Assertions.assertTrue(exception.getMessage().contains("No DICOMDIR document is found"));
    }

    @Test
    void testUpdateDicomDir_success() {
        when(mongoRetryService.findAndModify(any(), any(), eq("dicom_meta_data"), eq(DicomDirDocument.class)))
                .thenReturn(CompletableFuture.completedFuture(sampleDocument));

        String result = dicomDirService.updateDicomDir(sampleDocument);

        Assertions.assertTrue(result.contains("DICOMDIR updated successfully"));
        verify(validatorConfig).validate(sampleDocument);
    }


    @Test
    void testUpdateDicomDir_notFound() {
        when(mongoRetryService.findAndModify(any(), any(), eq("dicom_meta_data"), eq(DicomDirDocument.class)))
                .thenReturn(CompletableFuture.completedFuture(null));

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                dicomDirService.updateDicomDir(sampleDocument)
        );

        Assertions.assertTrue(exception.getMessage().contains("No document was updated"));
    }

    @Test
    void testUpdateDicomDir_InterruptedException() throws Exception {
        DicomDirDocument dicomDirDocument = mock(DicomDirDocument.class);
        when(dicomDirDocument.seriesId()).thenReturn("SERIES-123");

        CompletableFuture<DicomDirDocument> future = mock(CompletableFuture.class);
        when(future.get(eq(2L), eq( TimeUnit.MINUTES))).thenThrow(new InterruptedException("Interruption"));

        when(mongoRetryService.findAndModify(any(), any(), any(), eq(DicomDirDocument.class))).thenReturn(future);

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class,() -> dicomDirService.updateDicomDir(dicomDirDocument));

        Assertions.assertEquals("Thread is interrupted while updating dicom dir", exception.getMessage());
        verify(validatorConfig).validate(dicomDirDocument);
    }

    @Test
    void testUpdateDicomDir_ExecutionException() {
        DicomDirDocument dicomDirDocument = mock(DicomDirDocument.class);
        when(dicomDirDocument.seriesId()).thenReturn("SERIES123");
        when(dicomDirDocument.studyId()).thenReturn("STUDY123");

        Throwable cause = new RuntimeException("Mongo error");
        when(mongoRetryService.findAndModify(any(), any(), eq("dicom_meta_data"), eq(DicomDirDocument.class)))
                .thenReturn(CompletableFuture.failedFuture(new ExecutionException("Execution failed", cause)));

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () -> {
            dicomDirService.updateDicomDir(dicomDirDocument);
        });

        Assertions.assertTrue(exception.getMessage().contains("Error Updating dicom dir document"));
    }

}
