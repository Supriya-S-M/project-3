package com.eh.digitalpathology.dbconnector.services;

import com.mongodb.Function;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.result.UpdateResult;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.mockito.Mockito.*;
import org.junit.jupiter.api.Test;

@ExtendWith(MockitoExtension.class)
class MongoRetryServiceTest {

    @Mock
    private MongoTemplate mongoTemplate;

    private MongoRetryService mongoRetryService;

    @BeforeEach
    void setUp() {
        mongoRetryService = new MongoRetryService(mongoTemplate);
    }

    @Test
    void testSave() {
        String collectionName = "testCollection";
        String entity = "testEntity";

        when(mongoTemplate.insert(entity, collectionName)).thenReturn(entity);

        CompletableFuture<String> result = mongoRetryService.save(entity, collectionName);
        Assertions.assertEquals(entity, result.join());
    }

    @Test
    void testFind() {
        String collectionName = "testCollection";
        Query query = new Query();
        List<String> expected = List.of("doc1", "doc2");

        when(mongoTemplate.find(query, String.class, collectionName)).thenReturn(expected);

        CompletableFuture<List<String>> result = mongoRetryService.find(query, String.class, collectionName);
        Assertions.assertEquals(expected, result.join());
    }

    @Test
    void testGetCollectionNames() {
        Set<String> expected = Set.of("collection1", "collection2");

        when(mongoTemplate.getCollectionNames()).thenReturn(expected);

        CompletableFuture<Set<String>> result = mongoRetryService.getCollectionNames();
        Assertions.assertEquals(expected, result.join());
    }

    @Test
    void testFindAndModify() {
        Query query = new Query();
        Update update = new Update();
        String collectionName = "testCollection";
        String expected = "modifiedDoc";

        when(mongoTemplate.findAndModify(eq(query), eq(update), any(FindAndModifyOptions.class), eq(String.class), eq(collectionName)))
                .thenReturn(expected);

        CompletableFuture<String> result = mongoRetryService.findAndModify(query, update, collectionName, String.class);
        Assertions.assertEquals(expected, result.join());
    }

    @Test
    void testFindOne() {
        Query query = new Query();
        String expected = "foundDoc";

        when(mongoTemplate.findOne(query, String.class, "testCollection")).thenReturn(expected);

        CompletableFuture<String> result = mongoRetryService.findOne(query, String.class, "testCollection");
        Assertions.assertEquals(expected, result.join());
    }

    @Test
    void testUpsert() {
        Query query = new Query();
        Update update = new Update();
        UpdateResult updateResult = mock(UpdateResult.class);

        when(updateResult.wasAcknowledged()).thenReturn(true);
        when(mongoTemplate.upsert(query, update, String.class, "testCollection")).thenReturn(updateResult);

        CompletableFuture<Boolean> result = mongoRetryService.upsert(query, update, String.class, "testCollection");
        Assertions.assertTrue(result.join());
    }

    @Test
    void testUpsertBulk() {
        List<String> documents = List.of("doc1", "doc2");
        String collectionName = "testCollection";

        BulkOperations bulkOps = mock(BulkOperations.class);
        BulkWriteResult bulkWriteResult = mock(BulkWriteResult.class);

        when(mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, String.class, collectionName)).thenReturn(bulkOps);
        when(bulkOps.execute()).thenReturn(bulkWriteResult);
        when(bulkWriteResult.wasAcknowledged()).thenReturn(true);

        Function<String, Query> queryFunction = doc -> new Query();
        Function<String, Update> updateFunction = doc -> new Update();

        CompletableFuture<Boolean> result = mongoRetryService.upsertBulk(documents,collectionName, String.class, queryFunction, updateFunction, BulkOperations.BulkMode.UNORDERED);

        Assertions.assertTrue(result.join());
    }

}
