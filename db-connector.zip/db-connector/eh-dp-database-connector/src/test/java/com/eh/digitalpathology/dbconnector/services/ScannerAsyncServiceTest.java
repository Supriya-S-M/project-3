package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.model.PathQaSlide;
import com.eh.digitalpathology.dbconnector.model.SlideScanner;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ScannerAsyncServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;

    @Mock
    private RedisTemplate<String, Object> redisTemplate;

    @Mock
    private ValueOperations<String, Object> valueOperations;

    @InjectMocks
    private ScannerAsyncService scannerAsyncService;

    private final String barcode = "VSA-150";
    private final String slideCacheKey = "slide-001";
    private final String scannerCacheKey = "scanner-001";
    private final String deviceSerialNumber = "SN123";

    @Test
    void testFetchQaSlide_ReturnsCachedScanner() throws Exception {
        PathQaSlide cachedSlide = new PathQaSlide("Id1","VSA-150","code123");
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(slideCacheKey)).thenReturn(cachedSlide);

        CompletableFuture<PathQaSlide> result = scannerAsyncService.fetchQaSlide(barcode, slideCacheKey);

        assertEquals(cachedSlide, result.get());
        verify(mongoRetryService, never()).findOne(any(), eq(PathQaSlide.class), anyString());
    }

    @Test
    void testFetchQaSlide_FetchesFromDatabaseAndCaches() throws Exception {
        PathQaSlide dbSlide = new PathQaSlide("Id1","VSA-150","code123");
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(slideCacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(PathQaSlide.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(dbSlide));

        CompletableFuture<PathQaSlide> result = scannerAsyncService.fetchQaSlide(barcode, slideCacheKey);

        assertEquals(dbSlide, result.get());
        verify(valueOperations).set(slideCacheKey, dbSlide, Duration.ofHours(1));
    }

    @Test
    void testFetchQaSlide_ReturnsNullWhenNotFoundInDB() throws Exception {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(slideCacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(PathQaSlide.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(null));

        CompletableFuture<PathQaSlide> result = scannerAsyncService.fetchQaSlide(barcode, slideCacheKey);
        assertNull(result.get());
    }

    @Test
    void testFetchDicomWebUrlByDeviceSerialNumber_ReturnsCachedScanner() throws Exception {

        SlideScanner cachedScanner = new SlideScanner("scanner-id-001", "Scanner-001", "model-001", "Lab 3, Floor 2", "Pathology", "projects/abc/dicomStores/xyz", "AETITLE123", "device-001", "SN-123456");

        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(scannerCacheKey)).thenReturn(cachedScanner);

        CompletableFuture<SlideScanner> result = scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber(deviceSerialNumber, scannerCacheKey);

        assertEquals(cachedScanner, result.get());
        verify(mongoRetryService, never()).findOne(any(), eq(SlideScanner.class), anyString());
    }

    @Test
    void testFetchDicomWebUrlByDeviceSerialNumber_FetchesFromDatabaseAndCaches() throws Exception {
        SlideScanner dbScanner = new SlideScanner("scanner-id-001", "Scanner-001", "model-001", "Lab 3, Floor 2", "Pathology", "projects/abc/dicomStores/xyz", "AETITLE123", "device-001", "SN-123456");

        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(scannerCacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(SlideScanner.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(dbScanner));

        CompletableFuture<SlideScanner> result = scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber(deviceSerialNumber, scannerCacheKey);

        assertEquals(dbScanner, result.get());
        verify(valueOperations).set(scannerCacheKey, dbScanner, Duration.ofHours(1));
    }

    @Test
    void testFetchDicomWebUrlByDeviceSerialNumber_ReturnsNullWhenNotFoundInDB() throws Exception {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(scannerCacheKey)).thenReturn(null);
        when(mongoRetryService.findOne(any(), eq(SlideScanner.class), anyString()))
                .thenReturn(CompletableFuture.completedFuture(null));

        CompletableFuture<SlideScanner> result = scannerAsyncService.fetchDicomWebUrlByDeviceSerialNumber(deviceSerialNumber, scannerCacheKey);
        assertNull(result.get());
    }
}