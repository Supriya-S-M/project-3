package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.GlobalValidatorConfig;
import com.eh.digitalpathology.dbconnector.config.IndexCreationConfig;
import com.eh.digitalpathology.dbconnector.constants.ApiConstants;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.model.*;
import com.eh.digitalpathology.dbconnector.utils.EncryptionUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class Hl7ServiceTest {

    @Mock
    private MongoRetryService mongoRetryService;
    @Mock
    private Hl7ParserService hl7ParserService;
    @Mock
    private IndexCreationConfig indexCreationConfig;
    @Mock
    private Hl7AsyncService hl7AsyncService;
    @Mock
    private GlobalValidatorConfig validatorConfig;
    @Mock
    private RedisTemplate<String, Object> redisTemplate;
    @Mock
    private ValueOperations<String,Object> valueOperations;
    @InjectMocks
    private Hl7Service hl7Service;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(hl7Service, "lisMessageRequest", "OUL");
        ReflectionTestUtils.setField(hl7Service, "isEncrypted", false);
    }

    @Test
    void testSavedHl7Message_shouldSaveAndReturnBarcode() {
        String hl7Message = """
            MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
            OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
            """;

        Map<String, String> parsedData = new HashMap<>();
        parsedData.put(ApiConstants.BARCODE, "FIX-0098");
        parsedData.put(ApiConstants.MESSAGE_TYPE, "OUL");

        Hl7MessageRequest request = new Hl7MessageRequest(hl7Message);
        when(hl7ParserService.parsedHl7Message(hl7Message)).thenReturn(parsedData);
        Map<String, String> parsedDataForHl7Segment = new HashMap<>(parsedData);
        Hl7Segment segment = Hl7Segment.create("FIX-0098", "ORU", hl7Message, parsedDataForHl7Segment, new Date());
        CompletableFuture<Hl7Segment> futureSegment = CompletableFuture.completedFuture(segment);
        when(mongoRetryService.save(any(Hl7Segment.class), any())).thenReturn(futureSegment);

        Map<String, String> result = hl7Service.savedHl7Message("testService", request);

        Assertions.assertEquals("FIX-0098", result.get("barcode"));
        verify(redisTemplate).delete("barcode:FIX-0098");
        verify(redisTemplate).delete("hl7:FIX-0098:OUL");
        verify(indexCreationConfig).ensureCollectionExists("hl7_oul");
        verify(validatorConfig).validate(ArgumentMatchers.any(Hl7Segment.class));
    }

    @Test
    void testSavedHl7Message_shouldThrowDatabaseException_onEncryptionFailure() {
        String hl7Message = """
        MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
        OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
        """;

        Hl7MessageRequest request = new Hl7MessageRequest(hl7Message);

        Map<String, String> parsedData = new HashMap<>();
        parsedData.put(ApiConstants.BARCODE, "FIX-0098");
        parsedData.put(ApiConstants.MESSAGE_TYPE, "OUL");
        parsedData.put("SOME_FIELD", "someValue");

        when(hl7ParserService.parsedHl7Message(hl7Message)).thenReturn(parsedData);

        try (MockedStatic<EncryptionUtils> utilities = mockStatic(EncryptionUtils.class)) {
            utilities.when(() -> EncryptionUtils.encrypt(hl7Message)).thenReturn("encryptedMessage");

            utilities.when(() -> EncryptionUtils.encrypt("someValue"))
                    .thenThrow(new RuntimeException());

            DatabaseException exception = assertThrows(DatabaseException.class, () ->
                    hl7Service.savedHl7Message("testService", request));

            Assertions.assertTrue(exception.getMessage().contains("Unable to encrypt messages"));
        }
    }


    @Test
    void testSavedHl7Message_InterruptedException() throws ExecutionException, InterruptedException {
        String hl7Message = """
            MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
            OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
            """;
        Hl7MessageRequest request = new Hl7MessageRequest(hl7Message);

        Map<String, String> parsedData = new HashMap<>();
        parsedData.put(ApiConstants.BARCODE, "FIX-0098");
        parsedData.put(ApiConstants.MESSAGE_TYPE, "ORU");

        when(hl7ParserService.parsedHl7Message(hl7Message)).thenReturn(parsedData);
        CompletableFuture<Hl7Segment> future = mock(CompletableFuture.class);
        when(mongoRetryService.save(any(Hl7Segment.class),anyString())).thenReturn(future);
        when(future.get()).thenThrow(new InterruptedException());

        DatabaseException exception = Assertions.assertThrows(DatabaseException.class, () -> hl7Service.savedHl7Message("serviceName", request));
        Assertions.assertEquals("Thread was interrupted while saving hl7 message", exception.getMessage());


    }


    @Test
    void testFetchHl7Message_shouldReturnRawMessage() {
        String hl7Message = """
            MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
            OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
            """;

        Hl7MessageServiceRequest request = new Hl7MessageServiceRequest(hl7Message,"OUL");


        when(hl7ParserService.extractDelimiters(anyString())).thenReturn(new Delimiters('|', '^', '~', '\\', '&'));
        when(hl7ParserService.extractBarcodeFromMessage(ArgumentMatchers.any(), eq("OUL"),  ArgumentMatchers.any(Delimiters.class))).
                thenReturn("FIX-0098");
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);

        when(hl7AsyncService.searchMessageTypeByBarcodeAsync(anyString())).thenReturn(
                CompletableFuture.completedFuture(Map.of("messageType", Set.of("OUL")))
        );
        when(hl7AsyncService.fetchHl7SegmentAsync(anyString(), anyString(), anyString(), anyBoolean())).thenReturn(
                CompletableFuture.completedFuture(Hl7Segment.create("FIX-0098", "OUL", hl7Message, Map.of(), new Date()))
        );

        String result = hl7Service.fetchHl7Message(request);
        Assertions.assertEquals(hl7Message, result);
    }

    @Test
    void testFetchHl7Segment_shouldReturnSegment() {
        Hl7Segment segment = Hl7Segment.create("FIX-0098", "OUL", "rawHL7", Map.of(), new Date());
        when(hl7AsyncService.fetchHl7SegmentAsync("FIX-0098", "OUL", "hl7:FIX-0098:OUL", false))
                .thenReturn(CompletableFuture.completedFuture(segment));

        Hl7Segment result = hl7Service.fetchHl7Segment("FIX-0098", "OUL");
        Assertions.assertEquals("FIX-0098", result.barcode());
    }

    @Test
    void testFetchHl7Message_shouldThrowDatabaseException() {
        String hl7Message = """
            MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
            OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
            """;
        Hl7MessageServiceRequest request = new Hl7MessageServiceRequest(hl7Message,"OUL");

        when(hl7ParserService.extractDelimiters(anyString())).thenReturn(new Delimiters('|','^','~','\\','&'));
        when(hl7ParserService.extractBarcodeFromMessage(any(), eq("OUL"), any())).thenReturn("FIX-0098");
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(hl7AsyncService.searchMessageTypeByBarcodeAsync(anyString()))
                .thenReturn(CompletableFuture.completedFuture(Map.of("messageType", Set.of("OUL"))));

        when(hl7AsyncService.fetchHl7SegmentAsync(anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(CompletableFuture.failedFuture(new DatabaseException("Error")));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> hl7Service.fetchHl7Message(request));
        Assertions.assertTrue(exception.getMessage().contains("Unable to fetch hl7 message"));

    }

    @Test
    void testFetchHl7Segment_InterruptedException() throws ExecutionException, InterruptedException {
        String barcode = "FIX-0098";
        String messageType = "OUL";
        String hl7CacheKey = "hl7:" + barcode + ":" + messageType;

        CompletableFuture<Hl7Segment> future = mock(CompletableFuture.class);
        when(hl7AsyncService.fetchHl7SegmentAsync(barcode, messageType, hl7CacheKey, false))
                .thenReturn(future);
        when(future.get()).thenThrow(new InterruptedException());

        DatabaseException exception = assertThrows(DatabaseException.class, () ->
                hl7Service.fetchHl7Segment(barcode, messageType));

        Assertions.assertEquals("Thread was interrupted while fetching HL7 segment", exception.getMessage());
    }

    @Test
    void testSearchMessageTypeByBarcode_InterruptedException() throws Exception {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(anyString())).thenReturn(null);

        CompletableFuture<Map<String, Set<String>>> future = mock(CompletableFuture.class);
        when(future.get()).thenThrow(new InterruptedException());
        when(hl7AsyncService.searchMessageTypeByBarcodeAsync(anyString())).thenReturn(future);

        DatabaseException exception = assertThrows(DatabaseException.class, () -> hl7Service.searchMessageTypeByBarcode("FIX-0098"));
        Assertions.assertEquals("Thread was interrupted while fetching message type by barcode" , exception.getMessage());

    }

    @Test
    void testSearchMessageTypeByBarcode_ExecutionException() {
        when(redisTemplate.opsForValue()).thenReturn(valueOperations);
        when(valueOperations.get(anyString())).thenReturn(null);

        when(hl7AsyncService.searchMessageTypeByBarcodeAsync(anyString())).
                thenReturn(CompletableFuture.failedFuture(new ExecutionException("failed",new Throwable())));

        DatabaseException exception = assertThrows(DatabaseException.class, () -> hl7Service.searchMessageTypeByBarcode("FIX-0098"));
        Assertions.assertEquals("Error processing MongoDB Request: failed", exception.getMessage());

    }

}
