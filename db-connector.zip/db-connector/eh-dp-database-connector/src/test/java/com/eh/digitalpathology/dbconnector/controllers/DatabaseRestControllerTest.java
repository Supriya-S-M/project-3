package com.eh.digitalpathology.dbconnector.controllers;

import com.eh.digitalpathology.dbconnector.dtos.CaseStudyDto;
import com.eh.digitalpathology.dbconnector.dtos.DicomDirDto;
import com.eh.digitalpathology.dbconnector.dtos.QidoResponseDto;
import com.eh.digitalpathology.dbconnector.enums.WorkflowStatusEnum;
import com.eh.digitalpathology.dbconnector.exceptions.DatabaseException;
import com.eh.digitalpathology.dbconnector.mappers.CaseStudiesMapper;
import com.eh.digitalpathology.dbconnector.mappers.DicomDirMapper;
import com.eh.digitalpathology.dbconnector.mappers.QidoRsMapper;
import com.eh.digitalpathology.dbconnector.model.*;
import com.eh.digitalpathology.dbconnector.services.DicomDirService;
import com.eh.digitalpathology.dbconnector.services.DicomService;
import com.eh.digitalpathology.dbconnector.services.EnrichedService;
import com.eh.digitalpathology.dbconnector.services.Hl7Service;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DatabaseRestControllerTest {

    @InjectMocks
    private DatabaseRestController databaseRestController;
    @Mock
    private Hl7Service hl7Service;
    @Mock
    private DicomService dicomService;
    @Mock
    private EnrichedService enrichedService;
    @Mock
    private DicomDirService dicomDirService;
    @Mock
    private DicomDirMapper dicomDirMapper;
    @Mock
    private QidoRsMapper qidoRsMapper;
    @Mock
    private CaseStudiesMapper caseStudiesMapper;

    @Test
    void testPersistsMessage() throws DatabaseException {
        String hl7Message = """
                MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
                OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
                """;
        Hl7MessageRequest request = new Hl7MessageRequest(hl7Message);
        Map<String, String> mockResponse = Map.of("key", "value");

        when(hl7Service.savedHl7Message(any(), any())).thenReturn(mockResponse);
        ResponseEntity<ApiResponse<Map<String, String>>> response = databaseRestController.persistsMessage("test-service", request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("value", response.getBody().content().get("key"));
    }


//    @Test
//    void testFetchHl7MessageTypesForBarcode() throws DatabaseException {
//        Map<String, Set<String>> responseMap = Map.of("type", Set.of("ORU"));
//        when(hl7Service.searchMessageTypeByBarcode(any())).thenReturn(responseMap);
//
//        ResponseEntity<ApiResponse<Map<String, Set< String>>>> response = databaseRestController.fetchHl7MessageTypesForBarcode("VSA-123");
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(Set.of("ORU"), response.getBody().content().get("type"));
//    }


    @Test
    void testUpdateStatusForInstanceId() throws DatabaseException {
        BarcodeInstanceRequest request = new BarcodeInstanceRequest("barcode", "uid");
        when(dicomService.updateStatus(any(),any(),any())).thenReturn("updated");

        ResponseEntity< ApiResponse< String > > response = databaseRestController.updateStatusForInstanceId("X-Service-Name", request);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("updated", response.getBody().content());
    }


    @Test
    void testPersistsDicomInstances() throws DatabaseException {
        CaseStudyDto dto = new CaseStudyDto();
        dto.setDicomInstanceReceivedTimestamp(new Date());
        dto.setEnrichmentTimestamp(new Date());
        dto.setActualStudyInstanceUid("series1.3.6.111");
        dto.setOriginalStudyInstanceUid("series1.3.6.111");
        dto.setIntermediateStoragePath("/path");

        CaseStudy entity = new CaseStudy();
        entity.setDicomInstanceReceivedTimestamp(new Date());
        entity.setEnrichmentTimestamp(new Date());
        entity.setActualStudyInstanceUid("series1.3.6.111");
        entity.setOriginalStudyInstanceUid("series1.3.6.111");
        entity.setIntermediateStoragePath("/path");
        entity.setId("1.0");
        entity.setProcessingStatus(WorkflowStatusEnum.DICOM_INSTANCE_RECEIVED);
        when(caseStudiesMapper.toEntity(dto)).thenReturn(entity);
        when(dicomService.persists(WorkflowStatusEnum.DICOM_INSTANCE_RECEIVED.toString(),entity)).thenReturn("saved");

        ResponseEntity< ApiResponse< String > >  response = databaseRestController.persistsDicomInstances(WorkflowStatusEnum.DICOM_INSTANCE_RECEIVED.toString(), dto);
        assertEquals("saved", response.getBody().content());
        assertEquals(HttpStatus.OK, response.getStatusCode());
    }


    @Test
    void testFetchInstancePathAndMessages() throws DatabaseException {
        EnrichedRequest request = new EnrichedRequest();
        EnrichedResponse enrichedResponse = new EnrichedResponse();
        when(enrichedService.fetchDicomEnrichedData(any(),any())).thenReturn(enrichedResponse);

        var response = databaseRestController.fetchInstancePathAndMessages("X-Service-Name", request);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(enrichedResponse, response.getBody().content());
    }

    @Test
    void testUpdatedEnrichmentStatus() throws DatabaseException {
        EnrichInstance instance = new EnrichInstance();
        when(enrichedService.updateEnrichedStatus(any(),any())).thenReturn("updated enrichment status");

        var response = databaseRestController.updatedEnrichmentStatus("X-Service-Name", instance);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("updated enrichment status", response.getBody().content());
    }


    @Test
    void testSaveMetaDataInfo() throws DatabaseException {
        DicomDirDto dto = new DicomDirDto("studyId","1.2.4.1.1111123333",3,new byte[3]);
        DicomDirDocument doc = new DicomDirDocument("1","studyId","1.2.4.1.1111123333",3,new byte[3]);

        when(dicomDirMapper.toEntity(dto)).thenReturn(doc);
        when(dicomDirService.saveMetaDataInfo(doc)).thenReturn("saved");

        var response = databaseRestController.saveMetaDataInfo(dto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("saved", response.getBody().content());
    }

    @Test
    void testGetMetaDataInfo() throws DatabaseException {
        DicomDirDocument doc = new DicomDirDocument("1","studyId","1.2.4.1.1111123333",3,new byte[3]);
        when(dicomDirService.getMetaDataInfo(any())).thenReturn(doc);

        var response = databaseRestController.getMetaDataInfo("series1.2");
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(doc, response.getBody().content());
    }


    @Test
    void testGetHl7Message() throws DatabaseException {
        String hl7Message = """
                MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
                OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
                """;
        Hl7MessageServiceRequest request = new Hl7MessageServiceRequest(hl7Message,"OUL");
        when(hl7Service.fetchHl7Message(request)).thenReturn(hl7Message);

        var response = databaseRestController.getHl7Message(request);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(hl7Message, response.getBody().content());
    }


    @Test
    void testGetInstancesOfSeries() throws DatabaseException {
        List<InstancesMeta> instances = List.of(new InstancesMeta("FIX-0098","series123","sop1.2.3","test-status", "/path","device1.2.3"));


        when(dicomService.getInstancesOfSeries(any())).thenReturn(instances);

        var response = databaseRestController.getInstancesOfSeries(any());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(instances, response.getBody().content());
    }

    @Test
    void testGetStatusOfInstance() throws DatabaseException {
        when(dicomService.fetchStatusOfInstance(any(),any())).thenReturn("status-completed");
        var response = databaseRestController.getStatusOfInstance(any(),any());
        assertEquals(HttpStatus.OK, response.getStatusCode());

    }

    @Test
    void testUpdateDicomDir() throws DatabaseException {
        DicomDirDto dto = new DicomDirDto("studyId","1.2.4.1.1111123333",3,new byte[3]);
        DicomDirDocument doc = new DicomDirDocument("1","studyId","1.2.4.1.1111123333",3,new byte[3]);
        when(dicomDirMapper.toEntity(dto)).thenReturn(doc);
        when(dicomDirService.updateDicomDir(doc)).thenReturn("updated");

        var response = databaseRestController.updateDicomDir(dto);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("updated", response.getBody().content());
    }

    @Test
    void testGetDicomInstanceBySopInstanceUid() {
        CaseStudyDto dto = new CaseStudyDto();
        dto.setDicomInstanceReceivedTimestamp(new Date());
        dto.setEnrichmentTimestamp(new Date());
        dto.setActualStudyInstanceUid("series1.3.6.111");
        dto.setOriginalStudyInstanceUid("series1.3.6.111");
        dto.setIntermediateStoragePath("/path");

        CaseStudy entity = new CaseStudy();
        entity.setDicomInstanceReceivedTimestamp(new Date());
        entity.setEnrichmentTimestamp(new Date());
        entity.setActualStudyInstanceUid("series1.3.6.111");
        entity.setOriginalStudyInstanceUid("series1.3.6.111");
        entity.setIntermediateStoragePath("/path");
        entity.setId("1.0");
        when(dicomService.getDicomInstanceBySopInstanceUid(any())).thenReturn(entity);
        when(caseStudiesMapper.toDto(entity)).thenReturn(dto);

        var response = databaseRestController.getDicomInstanceBySopInstanceUid(anyString());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(dto, response.getBody().content());
    }

    @Test
    void testSaveStorageCommitment() {
        StorageCommitmentRequest request = new StorageCommitmentRequest("seriesId",true,List.of(new StorageCommitmentTracker()));
        lenient().doNothing().when(dicomService).saveStorageCommitmentTrackers(request.trackers());

        var response = databaseRestController.saveStorageCommitment(request);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Saved", response.getBody().content());
    }

    @Test
    void testSaveQidoRs() {
        QidoResponseDto dto = new QidoResponseDto("1.2.1.11122","Qido-response",200);
        QidoResponse entity = new QidoResponse("1.0","1.2.1.11122","Qido-response",200);
        when(qidoRsMapper.toEntity(dto)).thenReturn(entity);
        doNothing().when(dicomService).saveQidoRs(entity);

        var response = databaseRestController.saveQidoRs(dto);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        assertEquals("Saved", response.getBody().content());
    }


    @Test
    void testGetInstancesByRequestId() throws DatabaseException {
        List<String> instances = List.of("instance1", "instance2");
        when(dicomService.getInstancesByRequestId(any())).thenReturn(instances);

        var response = databaseRestController.getInstancesByRequestId(any());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(instances, response.getBody().content());
    }

    @Test
    void testGetSeriesIdByInstanceId() throws DatabaseException {
        List<String> instanceIds = List.of("instance1", "instance2");
        List<String> seriesIds = List.of("series1", "series2");
        when(dicomService.getSeriesIdByInstanceId(instanceIds)).thenReturn(seriesIds);

        var response = databaseRestController.getSeriesIdByInstanceId(instanceIds);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(seriesIds, response.getBody().content());
    }

}






