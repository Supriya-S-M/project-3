package com.eh.digitalpathology.dbconnector.services;

import com.eh.digitalpathology.dbconnector.config.BarcodeConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.IOException;
import java.util.Map;
import java.util.stream.Stream;

class Hl7ParserServiceTest {

    private BarcodeConfig barcodeConfig;
    private Hl7ParserService hl7ParserService;

    @BeforeEach
    void setUp ( ) throws IOException {
        barcodeConfig = new BarcodeConfig( );
        barcodeConfig = YamlReader.readYaml( "barcode-config.yml", BarcodeConfig.class );
        hl7ParserService = new Hl7ParserService( barcodeConfig );
    }

    @Test
    void testParsedHl7Message_whenHl7MessageOfTypeOULIsGiven_shouldReturnMapWithParsedData ( ) throws JsonProcessingException {
        // given
        String oulhl7Message = """
                MSH|^~\\&|DPIS||POWERPATH|LAB|20210730165500||ORU^R01|MSG0000000000003|P|2.4
                OBR|1|FIX-0098|1000^STC^1234~1200^ST^3455|FIX-0098|SLIDESCAN
                """;

        //when

        Map< String, String > parsedData = hl7ParserService.parsedHl7Message( oulhl7Message );
        ObjectMapper mapper = new ObjectMapper( );
        String json = mapper.writerWithDefaultPrettyPrinter( ).writeValueAsString( parsedData );
        System.out.println( json );
        //then
        Assertions.assertEquals( "FIX-0098", parsedData.get( "barcode" ) );


    }

    @ParameterizedTest
    @MethodSource("provideHl7MessageForBarcode")
    void testParsedHl7Message_whenHl7MessageOfTypeORUIsGiven_shouldReturnMapWithParsedData (String hl7MessageInput, String expected ) throws JsonProcessingException {
        //given
        //when
        Map< String, String > parsedData = hl7ParserService.parsedHl7Message( hl7MessageInput );
        ObjectMapper mapper = new ObjectMapper( );
        String json = mapper.writerWithDefaultPrettyPrinter( ).writeValueAsString( parsedData );
        System.out.println( json );
        System.out.println( parsedData.get( "barcode" ) );
        System.out.println( parsedData.get( "messageType" ) );
        //then
        Assertions.assertEquals(expected, parsedData.get("barcode"));

    }

    static String hl7Message = """
            MSH|^~\\&|LIS|LAB|DPL|EnrichmentTool|20250131200044||OML^O33^OML_O33|MSG000000157|P|2.5.1|||||||||LAB-80^IHE\r
            PID|1||0^^^Endeavour Health&10.1000/182&ISO^MR||25SP_Hamamatsu&&&&SFN^DPIA_Foxtrot^^^^||19830606|M||413773004^Caucasian race^SCT||||||||||||413773004^Caucasian race^SCT^HL70189|||||||||||||337915000^Homo sapiens^SCT\r
            SPM|1|PV22;PRA;Case-F&Endeavour Lab&10.1000/183&ISO|SPM-138|119376003^Tissue specimen^SCT||111095003^Formaldehyde^SCT~311731000^Paraffin wax^SCT~12710003^hematoxylin stain^SCT~36879007^Water soluble eosin stain^SCT|65801008^Excision^SCT|15425007^Peritoneum^SCT|^^||P|||Peritoneum FFPE HE|||202412031011||||||||||433466003^Microscope slide^SCT|||HAMACASEF^^^Endeavour Health&10.1000/182&ISO|1.23.4344.56789.01028\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017237||||||F\r
            SAC||HAMACASEF^Endeavour Lab^10.1000/183^ISO|PV22;PRA;Case-F;Slide-F-4^Endeavour Health^10.1000/182^ISO||||||||||||||||||||||||||||||||||||||||||||433466003^Microscope slide^SCT|GLASS^Glass\r
            ORC||PV22;PRA;Case-F;Slide-F-4^Endeavour Health^10.1000/182^10.1000/182|FILL-00100124^Endeavour Lab^10.1000/183^ISO\r
            OBR||PV22;PRA;Case-F;Slide-F-4^Endeavour Health^10.1000/182^ISO|FILL-00100124^Endeavour Lab^10.1000/183^ISO|11529-5^Surgical Pathology Study Report^LN\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017237||||||F
            """;

    static String hl7Message1 = """
            MSH|^~\\&|LIS|LAB|DPL|EnrichmentTool|20250131200044||OML^O33^OML_O33|MSG000000153|P|2.5.1|||||||||LAB-80^IHE\r
            PID|1||123123129^^^Endeavour Health&10.1000/182&ISO^MR||25SP_Hamamatsu&&&&SFN^DPIA_Bravo^^^^||19830202|M||413490006^American Indian or Alaska native^SCT||||||||||||413490006^American Indian or Alaska native^SCT|||||||||||||337915000^Homo sapiens^SCT\r
            SPM|1|PV22;PRA;Case-B&Endeavour Lab&10.1000/183&ISO|SPM-134|119376003^Tissue specimen^SCT||111095003^Formaldehyde^SCT~311731000^Paraffin wax^SCT~12710003^hematoxylin stain^SCT~36879007^Water soluble eosin stain^SCT|65801008^Excision^SCT|23451007^Adrenal gland^SCT|^^||P|||Adrenal gland FFPE HE|||202412031011||||||||||433466003^Microscope slide^SCT|||HAMACASEB^^^Endeavour Health&10.1000/182&ISO|1.23.4344.56789.01024\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017233||||||F\r
            SAC||HAMACASEB^Endeavour Lab^10.1000/183^ISO|PV22;PRA;Case-B;Slide-B-6^Endeavour Health^10.1000/182^ISO||||||||||||||||||||||||||||||||||||||||||||433466003^Microscope slide^SCT|GLASS^Glass\r
            ORC||PV22;PRA;Case-B;Slide-B-6^Endeavour Health^10.1000/182^ISO|FILL-00100120^Endeavour Lab^10.1000/183^ISO\r
            OBR||PV22;PRA;Case-B;Slide-B-6^Endeavour Health^10.1000/182^ISO|FILL-00100120^Endeavour Lab^10.1000/183^ISO|11529-5^Surgical Pathology Study Report^LN\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410017233||||||F
            """;
    static String hl7Message2 = """
            MSH|^~\\&|LIS|LAB|DPL|EnrichmentTool|20250131200044||OML^O33^OML_O33|MSG000000131|P|2.5.1|||||||||LAB-80^IHE\r
            PID|1||232799^^^Endeavour Health&10.1000/182&ISO^MR||Dennis&&&&SFN^Doe^John^Sir^V^MD||19862294669421|A||2028-9^Asian||||||||||||2028-9^Asian^HL70189|||||||||||||0^Homo sapiens^HL70446\r
            SPM|1|38YZGP&Endeavour Lab&10.1000/183&ISO|SPM-122|0^Tissue^HL70487||431510009^Formalin^SCT~311731000^Paraffin wax^SCT~4656000^alcian blue 8GX stain^SCT|0^Biopsy^HL70488|0^Liver^HL70070|0^Anterior^HL70542||P|||Prostate sample|||202501281425||||||||||0^Microscopic Slide^HL70785|||ACC000121^^^Endeavour Health&10.1000/182&ISO|1.23.4344.56789.01012\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410011110||||||F\r
            SAC|EXACC000121|ACC0010121^Endeavour Lab^10.1000/183^ISO|38YZGP^Endeavour Health^10.1000/182^ISO|SPMPC-011|||||||||||||||||||||||||||||||||||||||||||0^Microscopic Slide^HL70967|GLASS^Glass\r
            ORC||38YZGP^Endeavour Health^10.1000/182^10.1000/182|FILL-00100108^Endeavour Lab^10.1000/183^ISO\r
            OBR||38YZGP^Endeavour Health^10.1000/182^ISO|FILL-00100108^Endeavour Lab^10.1000/183^ISO|11529-5^Surgical Pathology Study Report^LN\r
            OBX|1|EI|110180^Study Instance UID^DCM||1.3.6.1.4.1.36533.1704668241992146589146178681714410011110||||||F
            """;

    private static Stream< Arguments > provideHl7MessageForBarcode ( ) {
        return Stream.of( Arguments.of( hl7Message, "PV22;PRA;Case-F;Slide-F-4" ), Arguments.of( hl7Message1, "PV22;PRA;Case-B;Slide-B-6" ), Arguments.of( hl7Message2, "38YZGP" ));
    }
}