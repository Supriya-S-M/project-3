package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.model.*;

import com.eh.digitalpathology.enricher.utils.DicomDirUtils;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.*;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class KafkaExportEventConsumerTest {

    @Mock
    private DatabaseService databaseService;
    @Mock
    private QidoRsService qidoRsService;
    @Mock
    private KafkaNotificationProducer kafkaProducer;
    @Mock
    private DicomTracker tracker;
    @Mock
    private GcpConfig gcpConfig;
    @Mock
    private ScheduledExecutorService executor;
    @Mock
    private ExecutorService executorService;
    @Mock
    private ExecutorService ioExecutor;

    private KafkaExportEventConsumer consumer;

    @BeforeEach
    void setup() throws Exception {

        consumer = new KafkaExportEventConsumer(tracker, databaseService, qidoRsService, gcpConfig, kafkaProducer, executor, executorService, ioExecutor);
        lenient().when(gcpConfig.getCreds()).thenReturn("{}");

        setField(consumer, "exportTopic", "EXPORT_TOPIC");
        setField(consumer, "emailSvcTopic", "EMAIL_TOPIC");
        setField(consumer, "enrichSvcTopic", "ENRICH_TOPIC");
        setField(consumer, "enrichmentStatusCheckIntervalMs", 5);
        setField(consumer, "retryDelayInMilliseconds", 5);
        setField(consumer, "sopCheckIntervalMinutes", 0L);
        setField(consumer, "waitTimeMinutes", 0L);
        setField(consumer, "maxRetryAttempts", 1);

        runImmediately(executorService);
        runImmediately(ioExecutor);
        mockScheduling(executor);
    }


    @Test
    void testListen_HandleDicomDirStatus() throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        StgmtStatus input = new StgmtStatus(
                "REQ-01", "1.2.840.1001.1.1",
                DicomEnrichmentConstants.DICOM_DIR
        );

        String json = mapper.writeValueAsString(input);
        ConsumerRecord<String, String> rec = new ConsumerRecord<>("topic", 0, 0L, "key", json);
        Acknowledgment ack = mock(Acknowledgment.class);

        when(tracker.getState("1.2.840.1001.1.1")).thenReturn(null);

        consumer.listen(rec, ack);

        verify(tracker).markCommitmentReceived("1.2.840.1001.1.1");
        verify(ack, timeout(200)).acknowledge();
    }

    @Test
    void testListen_StorageCommitmentFlow() throws Exception {
        StgmtStatus status = mock(StgmtStatus.class);
        when(status.status()).thenReturn(DicomEnrichmentConstants.STORAGE_COMMITMENT);
        when(status.seriesInstanceUid()).thenReturn("1.2.840.1001.1.1");
        when(status.cmtReqId()).thenReturn("REQ-01");

        ObjectMapper mapper = new ObjectMapper();
        ConsumerRecord<String, String> rec =
                new ConsumerRecord<>("topic", 0, 0L, "k", mapper.writeValueAsString(status));

        Acknowledgment ack = mock(Acknowledgment.class);

        when(databaseService.fetchInstancesByRequestId("REQ-01"))
                .thenReturn(List.of("1.2.840.1001.2"));

        when(databaseService.checkForSopPresence(List.of("1.2.840.1001.2")))
                .thenReturn("1.2.840.1001.1.1");

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        when(tracker.getState("1.2.840.1001.1.1")).thenReturn(state);

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(testInstance("1.2.840.1001.1.1", "1.2.840.1001.2")));

        consumer.listen(rec, ack);

        verify(tracker, timeout(200)).markCommitmentReceived("1.2.840.1001.1.1");
        verify(ack, timeout(200)).acknowledge();
    }

    @Test
    void testListen_DicomDir_StatePresent_ButDicomDirIsNull() throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        StgmtStatus input = new StgmtStatus(
                "REQ01",
                "1.2.840.1001.1.1",
                DicomEnrichmentConstants.DICOM_DIR
        );

        ConsumerRecord<String, String> consumerRecord =
                new ConsumerRecord<>("topic", 0, 0L, "key", mapper.writeValueAsString(input));

        Acknowledgment ack = mock(Acknowledgment.class);

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        when(tracker.getState("1.2.840.1001.1.1")).thenReturn(state);
        when(databaseService.fetchMetaData("1.2.840.1001.1.1")).thenReturn(null);

        consumer.listen(consumerRecord, ack);

        verify(tracker).markCommitmentReceived("1.2.840.1001.1.1");
        assertEquals(DicomEnrichmentConstants.DICOM_DIR, state.getCommitmentStatus());
        verify(kafkaProducer, never()).sendNotification(eq("export_topic"), any(), any());
        verify(ack, timeout(200)).acknowledge();
    }

    @Test
    void testValidatedAndTriggerExport_Success() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        InstancesMeta inst = testInstance("1.2.840.1001.1.1", "1.2.840.1001.2");

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1")).thenReturn(List.of(inst));
        when(qidoRsService.qidoRsCall(any(), any(), any())).thenReturn(testQidoResponse("1.2.840.1001.1.1.1", Set.of("1.2.840.1001.2")));
        when(databaseService.getDicomStroreUrl(any())).thenReturn("http://dicom-url");

        CompletableFuture<Void> future =
                invokePrivateCF(consumer, "validateAndTriggerExport",
                        new Class[]{String.class, int.class, DicomDirDocument.class, SeriesState.class, long.class},
                        "1.2.840.1001.1.1", 1, null, state, System.currentTimeMillis());

        future.join();
        ArgumentCaptor<String> topicCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> keyCaptor   = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> payloadCaptor = ArgumentCaptor.forClass(String.class);

        verify(kafkaProducer).sendNotification(topicCaptor.capture(), keyCaptor.capture(), payloadCaptor.capture());
        assertEquals("EXPORT_TOPIC", topicCaptor.getValue());
        assertEquals("1.2.840.1001.1.1", keyCaptor.getValue());
        assertNotNull(payloadCaptor.getValue());
    }


    @Test
    void testValidatedAndTriggerExport_TimeoutPath() throws Exception {

        String series = "1.2.840.1001.1.1";
        SeriesState state = new SeriesState(series);
        setField(consumer, "waitTimeMinutes", 1L);
        long oldTime = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(5);

        DicomDirDocument doc = new DicomDirDocument();
        doc.setImageCount(1);

        CompletableFuture<Void> cf = invokePrivateCF(consumer, "validateAndTriggerExport",
                new Class[]{String.class, int.class, DicomDirDocument.class, SeriesState.class, long.class},
                series, 1, doc, state, oldTime);

        cf.join();
        verify(kafkaProducer, never()).sendNotification(any(), any(), any());
        verify(tracker, never()).invalidate(any());
    }

    @Test
    void testExtractStudyAndInstanceCount() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readTree("""
        [
          {
            "0020000D": { "vr": "UI","Value": ["1.2.840.113619.2.55"]},
            "00080018": {"vr": "UI","Value": ["1.2.840.113619.2.55.1"]}
          },
          {
            "0020000D": {"vr": "UI","Value": ["1.2.840.113619.2.55"]},
            "00080018": { "vr": "UI","Value": ["1.2.840.113619.2.55.2"]}
          }
        ]""");
        Pair<String, Set<String>> result = invokePrivateMethod(consumer, "extractStudyIdAndInstanceCount",
                new Class[]{JsonNode.class}, node);

        assertEquals("1.2.840.113619.2.55", result.getLeft());
        assertEquals(Set.of("1.2.840.113619.2.55.1", "1.2.840.113619.2.55.2"), result.getRight());
    }

    @Test
    void testRetryOnFailure_DelegatesToRetryRecursive() throws Exception {
        SeriesState state = new SeriesState("1.2.840.1001.1.1");

        InstancesMeta failed = testInstanceWithStatus("1.2.840.1001.1.1", "1.2.840.1001.1.1.2",
                DicomEnrichmentConstants.ENRICHMENT_FAILED_STATUS);

        InstancesMeta completed = testInstanceWithStatus("1.2.840.1001.1.1", "1.2.840.1001.1.1.1",
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS);

        Map<String, List<InstancesMeta>> map = new HashMap<>();
        map.put(DicomEnrichmentConstants.ENRICHMENT_FAILED, List.of(failed));
        map.put(DicomEnrichmentConstants.ENRICHMENT_COMPLETED, List.of(completed));

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(failed));

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "retryOnFailure", new Class[]{Map.class, SeriesState.class},
                        map, state);

        cf.join();

        verify(kafkaProducer, atLeastOnce()).sendNotification(eq("ENRICH_TOPIC"), eq("RETRY"), anyString());
    }

    @Test
    void testRetryRecursive_MaxRetryTriggersNotification() throws Exception {
        SeriesState state = new SeriesState("1.2.840.1001.1.1");

        setField(consumer, "maxRetryAttempts", 3);
        setField(state, "retryCount", 3);

        InstancesMeta failed =
                testInstanceWithStatus("1.2.840.1001.1.1", "1.2.840.1001.1.1.2",
                        DicomEnrichmentConstants.ENRICHMENT_FAILED_STATUS);

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "retryRecursive",
                        new Class[]{List.class, Set.class, SeriesState.class}, List.of(failed), Set.of(),
                        state);

        cf.join();

        verify(kafkaProducer).sendNotification("EMAIL_TOPIC", "MAX_RETRIES_REACHED", failed.barcode());
        assertTrue(state.isExportTriggered());
    }

    @Test
    void testHandleRetryCompletion_CommitmentReceivedTriggersExport() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        state.commitmentReceived.set(true);
        state.setCommitmentStatus(DicomEnrichmentConstants.STORAGE_COMMITMENT);

        InstancesMeta inst =
                testInstanceWithStatus("1.2.840.1001.1.1", "1.2.840.1001.1.1.1.2",
                        DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS);

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(inst));

        when(databaseService.getDicomStroreUrl(any()))
                .thenReturn("http://dicom-url");

        when(qidoRsService.qidoRsCall(any(), any(), any()))
                .thenReturn(testQidoResponse("1.2.840.1001.2.1", Set.of("1.2.840.1001.2.1.2")));

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "handleRetryCompletion",
                        new Class[]{List.class, SeriesState.class}, List.of(inst), state);

        cf.join();

        verify(kafkaProducer, atLeastOnce()).sendNotification(eq("EXPORT_TOPIC"), eq("1.2.840.1001.1.1"), anyString());
        assertTrue(state.isExportTriggered());
    }

    @Test
    void testWaitForEnrichmentCompletionAsync_CompletesImmediately() throws Exception {

        InstancesMeta inst = testInstanceWithStatus(
                "1.2.840.1001.1.1",
                "1.2.840.1001.1.1.2",
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS
        );

        when(databaseService.getStatusOfInstance(
                "1.2.840.1001.1.1",
                "1.2.840.1001.1.1.2"
        )).thenReturn(DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS);

        CompletableFuture<Boolean> future =
                invokePrivateMethod(consumer, "waitForEnrichmentCompletionAsync",
                        new Class[]{InstancesMeta.class, long.class, long.class},
                        inst, 1L, 0L);

        assertTrue(future.join());
    }

    @Test
    void testWaitForEnrichmentCompletionAsync_FailsImmediately() throws Exception {

        InstancesMeta inst = testInstanceWithStatus(
                "1.2.840.1001.1.1",
                "1.2.840.1001.1.1.1.2",
                "ENRICHMENT_PENDING"
        );

        when(databaseService.getStatusOfInstance(any(), any()))
                .thenReturn(DicomEnrichmentConstants.ENRICHMENT_FAILED_STATUS);

        CompletableFuture<Boolean> future =
                invokePrivateMethod(consumer, "waitForEnrichmentCompletionAsync",
                        new Class[]{InstancesMeta.class, long.class, long.class},
                        inst, 1L, 0L);

        Boolean result = future.join();

        assertFalse(result);
    }


    @Test
    void testOnSeriesTimeOut_SuccessPath() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        InstancesMeta inst = testInstanceWithStatus(
                "1.2.840.1001.1.1", "1.2.840.1001.1.1.1.2",
                "ENRICHMENT_COMPLETED"
        );

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(inst));

        when(qidoRsService.qidoRsCall(any(), any(), any()))
                .thenReturn(testQidoResponse("1.2.840.1001.2.1", Set.of("1.2.840.1001.2.1.1")));

        when(databaseService.getDicomStroreUrl(any()))
                .thenReturn("http://dicom-url");

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "onSeriesTimeOut",
                        new Class[]{String.class, SeriesState.class},
                        "1.2.840.1001.1.1", state);

        cf.join();

        verify(kafkaProducer, atLeastOnce())
                .sendNotification(eq("EXPORT_TOPIC"), eq("1.2.840.1001.1.1"), anyString());

        verify(tracker).invalidate("1.2.840.1001.1.1");
    }

    @Test
    void testOnSeriesTimeOut_FailureRetryPath() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");
        InstancesMeta inst = testInstanceWithStatus("1.2.840.1001.1.1", "1.2.840.1001.1.1.1.2", "ENRICHMENT_FAILED");

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(inst), List.of(inst), List.of(inst));

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "onSeriesTimeOut", new Class[]{String.class, SeriesState.class},
                        "1.2.840.1001.1.1", state);

        cf.join();

        verify(kafkaProducer, atLeastOnce()).sendNotification("EMAIL_TOPIC","MAX_RETRIES_REACHED", "VSA-155");
    }

    @Test
    void testOnSeriesTimeOut_whenStateIsNull() {

        CompletableFuture<Void> future = consumer.onSeriesTimeOut("1.2.840.1001.1", null);

        assertNotNull(future);
        assertTrue(future.isDone());
        assertNull(future.join());

        verifyNoInteractions(databaseService, kafkaProducer);
        verify(tracker, never()).invalidate(any());
    }

    @Test
    void testTriggerQidoRsAndExport_RewritesDicomDirStudyId() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");

        InstancesMeta inst = testInstanceWithStatus(
                "1.2.840.1001.1.1", "1.2.840.1001.1.1.2",
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS
        );

        List<InstancesMeta> instances = List.of(inst);

        DicomDirDocument doc = new DicomDirDocument();
        doc.setStudyId("1.2.840.1001.1");
        doc.setDicomDirFile("OLD".getBytes());

        JsonNode qidoResponse =
                testQidoResponse("1.2.840.1001.2.1", Set.of("1.2.840.1001.2.1.1"));

        when(databaseService.getDicomStroreUrl(any()))
                .thenReturn("http://dicom-url");

        when(qidoRsService.qidoRsCall(any(), any(), any()))
                .thenReturn(qidoResponse);

        try (MockedStatic<DicomDirUtils> mocked = mockStatic(DicomDirUtils.class)) {
            mocked.when(() ->
                    DicomDirUtils.modifyStudyIdInDicomDir(doc, "1.2.840.1001.2.1")
            ).thenReturn("UPDATED-DIR".getBytes());

            CompletableFuture<Void> cf =
                    invokePrivateCF(
                            consumer,
                            "triggerQidoRsAndExport", new Class[]{SeriesState.class, String.class, int.class, List.class, DicomDirDocument.class},
                            state,
                            "1.2.840.1001.1.1", 1, instances, doc);

            cf.join();

            assertEquals("1.2.840.1001.2.1", doc.getStudyId());
            assertArrayEquals("UPDATED-DIR".getBytes(), doc.getDicomDirFile());
            verify(databaseService).updateDicomDir(doc);
        }
    }

    @Test
    void testTriggerQidoRsAndExport_FallsBackToRetry() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1.1");


        InstancesMeta inst1 = testInstanceWithStatus(
                "1.2.840.1001.1.1", "1.2.840.1001.1.1.1.2",
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS
        );

        InstancesMeta inst2 = testInstanceWithStatus(
                "1.2.840.1001.1.1", "1.2.840.1001.1.1.2",
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS
        );

        List<InstancesMeta> instances = List.of(inst1, inst2);

        JsonNode qidoResponse =
                testQidoResponse("1.2.840.1001.2.1", Set.of("1.2.840.1001.2.1.1"));

        when(databaseService.getDicomStroreUrl(any()))
                .thenReturn("http://dicom-url");

        when(qidoRsService.qidoRsCall(any(), any(), any()))
                .thenReturn(qidoResponse);

        when(databaseService.fetchInstancesOfSeries("1.2.840.1001.1.1"))
                .thenReturn(List.of(inst1));

        CompletableFuture<Void> cf =
                invokePrivateCF(consumer, "triggerQidoRsAndExport",
                        new Class[]{SeriesState.class, String.class, int.class, List.class, DicomDirDocument.class},
                        state, "1.2.840.1001.1.1", 2, instances, null);

        cf.join();

        verify(kafkaProducer, atLeastOnce())
                .sendNotification(eq("ENRICH_TOPIC"), eq("RETRY"), anyString());
    }

    private void setField(Object target, String field, Object value) throws Exception {
        Field f = target.getClass().getDeclaredField(field);
        f.setAccessible(true);
        f.set(target, value);
    }

    private <T> T invokePrivateMethod(Object target, String name, Class<?>[] types, Object... args) throws Exception {
        Method m = target.getClass().getDeclaredMethod(name, types);
        m.setAccessible(true);
        return (T) m.invoke(target, args);
    }

    private <T> CompletableFuture<T> invokePrivateCF(Object target, String name, Class<?>[] types, Object... args) throws Exception {
        Method m = target.getClass().getDeclaredMethod(name, types);
        m.setAccessible(true);
        return (CompletableFuture<T>) m.invoke(target, args);
    }


    private InstancesMeta testInstance(String series, String sop) {
        return new InstancesMeta(
                "VSA-155", series, sop,
                DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS,
                "gs://bucket/file.dcm",
                "test-device01"
        );
    }

    private InstancesMeta testInstanceWithStatus(String series, String sop, String status) {
        return new InstancesMeta(
                "VSA-155", series, sop,
                status,
                "gs://bucket/file.dcm",
                "test-device01"
        );
    }

    private JsonNode testQidoResponse(String studyId, Set<String> sopList) {
        ObjectMapper mapper = new ObjectMapper();
        ArrayNode arr = mapper.createArrayNode();

        for (String sop : sopList) {
            ObjectNode instance = mapper.createObjectNode();

            ObjectNode studyNode = mapper.createObjectNode();
            ArrayNode studyVal = mapper.createArrayNode();
            studyVal.add(studyId);
            studyNode.set("Value", studyVal);
            instance.set("0020000D", studyNode);

            ObjectNode sopNode = mapper.createObjectNode();
            ArrayNode sopVal = mapper.createArrayNode();
            sopVal.add(sop);
            sopNode.set("Value", sopVal);
            instance.set("00080018", sopNode);

            arr.add(instance);
        }
        return arr;
    }

    private void runImmediately(ExecutorService executor) {
        lenient().doAnswer(inv -> {((Runnable) inv.getArgument(0)).run();return null;}).
                when(executor).execute(any(Runnable.class));

        lenient().when(executor.submit(any(Callable.class)))
                .thenAnswer(inv -> CompletableFuture.completedFuture(((Callable<?>) inv.getArgument(0)).call()));
    }

    private void mockScheduling(ScheduledExecutorService scheduler) {

        lenient().doAnswer(inv -> {Runnable task = inv.getArgument(0);task.run();return null;})
                .when(scheduler).execute(any(Runnable.class));

        lenient().doAnswer(inv -> {Runnable task = inv.getArgument(0);task.run();return mock(ScheduledFuture.class);})
                .when(scheduler).schedule(any(Runnable.class), anyLong(), any(TimeUnit.class));
    }


    @Test
    void testHandleExportIfCommitmentReceived_DicomDirPath_Coverage() throws Exception {

        SeriesState state = new SeriesState("1.2.840.1001.1");
        state.setCommitmentStatus(DicomEnrichmentConstants.DICOM_DIR);
        state.commitmentReceived.set(true);

        String barcode = "1.2.840.1001.1";

        DicomDirDocument dicomDoc = new DicomDirDocument();
        dicomDoc.setImageCount(1);
        dicomDoc.setStudyId("1.2.840.1001.1.1");

        when(databaseService.fetchMetaData("1.2.840.1001.1"))
                .thenReturn(dicomDoc);

        setField(consumer, "waitTimeMinutes", 0L);

        CompletableFuture<Void> future =
                invokePrivateMethod(consumer, "handleExportIfCommitmentReceived", new Class[]{SeriesState.class, String.class}, state, barcode);

        future.join();

        verify(databaseService).fetchMetaData("1.2.840.1001.1");
        verify(tracker).invalidate("1.2.840.1001.1");
    }



}
