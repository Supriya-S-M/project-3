package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.ExternalConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import com.eh.digitalpathology.enricher.mapper.CaseInfoMapper;
import com.eh.digitalpathology.enricher.model.CaseInfo;
import com.eh.digitalpathology.enricher.model.EnrichInstance;
import com.eh.digitalpathology.enricher.model.LisResponse;
import com.eh.digitalpathology.enricher.utils.YamlReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mapstruct.factory.Mappers;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class KafkaEventConsumerTest {

    @Mock
    private ExternalConfig mockConfig;
    @Mock
    private DicomEnrichmentService mockDicomEnrichmentService;
    @Mock
    private DicomTracker mockDicomTracker;
    @Mock
    private KafkaNotificationProducer mockKafkaNotificationProducer;
    @Mock
    private CaseInfoMapper mockCaseInfoMapper;
    @Mock
    private Acknowledgment acknowledgment;
    @InjectMocks
    private KafkaEventConsumer kafkaEventConsumer;


    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(kafkaEventConsumer, "dicomMappingsBasePath", "/test/path/");
        ReflectionTestUtils.setField(kafkaEventConsumer, "emailSvcTopic", "email-topic");
        kafkaEventConsumer = new KafkaEventConsumer(mockConfig, mockDicomEnrichmentService, mockDicomTracker, mockKafkaNotificationProducer);
    }

    @Test
    void testExtractData_Success() throws Exception {

        LisResponse mockLisResponse = new LisResponse();
        mockLisResponse.setBarcode("VSA-155");

        String json = new ObjectMapper().writeValueAsString(mockLisResponse);
        ConsumerRecord<String, String> records = new ConsumerRecord<>("topic", 0, 0L, "key1", json);

        LisResponse result = kafkaEventConsumer.extractData(records);

        assertNotNull(result);
        assertEquals("VSA-155", result.getBarcode());
    }

    @Test
    void testExtractData_EmptyMessage_ThrowsException() {

        ConsumerRecord<String, String> records = new ConsumerRecord<>("topic", 0, 0L, "key1", "");
        DicomEnrichmentServiceException exception = assertThrows(
                DicomEnrichmentServiceException.class, () -> kafkaEventConsumer.extractData(records));
        assertEquals("Received empty message", exception.getMessage());
    }

    @Test
    void testExtractData_InvalidJson_ThrowsException() {
        ConsumerRecord<String, String> records = new ConsumerRecord<>("topic", 0, 0L, "key1", "invalid-json");
        DicomEnrichmentServiceException exception = assertThrows(
                DicomEnrichmentServiceException.class,
                () -> kafkaEventConsumer.extractData(records)
        );

        assertEquals("Unable to extract data from message", exception.getMessage());
    }


    @Test
    void testProcessEvent_Success() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSeriesInstanceUid("1.2.840.10008.1.2.1");

        EnrichInstance enrichInstance = new EnrichInstance();
        enrichInstance.setSeriesInstanceUid("1.2.840.10008.1.2.1");

        when(mockDicomEnrichmentService.fetchDataForEnrichment(any(CaseInfo.class), any(), any())).thenReturn(enrichInstance);

        kafkaEventConsumer.processEvent(caseInfo);

        verify(mockDicomEnrichmentService, times(1))
                .fetchDataForEnrichment(any(CaseInfo.class), any(), any());
        verify(mockDicomTracker, times(1))
                .handleInstances("1.2.840.10008.1.2.1", caseInfo);
    }

    @Test
    void testListen_SuccessfulProcessing() throws Exception {

        LisResponse lisResponse = new LisResponse();
        lisResponse.setBarcode("VSA-155");

        String json = new ObjectMapper().writeValueAsString(lisResponse);
        ConsumerRecord<String, String> records = new ConsumerRecord<>("topic", 0, 0L, "key", json);

        ReflectionTestUtils.setField(kafkaEventConsumer, "additivesMapping", new HashMap<>());
        ReflectionTestUtils.setField(kafkaEventConsumer, "dynamicYamlCache", new HashMap<>());

        try (MockedStatic<Mappers> mappersMock = mockStatic(Mappers.class)) {
            CaseInfoMapper mapper = mock(CaseInfoMapper.class);
            mappersMock.when(() -> Mappers.getMapper(CaseInfoMapper.class)).thenReturn(mapper);

            EnrichInstance enrichInstance = new EnrichInstance();
            enrichInstance.setSeriesInstanceUid("1.2.840.10008.1.2.1");

            when(mockConfig.getLisMessageResponse()).thenReturn("TEST_RESPONSE");
            when(mockDicomEnrichmentService.fetchDataForEnrichment(any(), anyMap(), anyMap()))
                    .thenReturn(enrichInstance);

            kafkaEventConsumer.listen(records, acknowledgment);

            verify(acknowledgment).acknowledge();
            verify(mockDicomEnrichmentService).fetchDataForEnrichment(any(), anyMap(), anyMap());

            ArgumentCaptor<CaseInfo> caseCaptor = ArgumentCaptor.forClass(CaseInfo.class);
            verify(mockDicomTracker).handleInstances(eq("1.2.840.10008.1.2.1"), caseCaptor.capture());

            CaseInfo actualCase = caseCaptor.getValue();
            assertNotNull(actualCase);
        }
    }

    @Test
    void testInit_withValidYaml_shouldPopulateMappings() {
        Map<String, String> mappings = Map.of("key1", "file1.yaml");
        Map<String, Object> yamlData = new HashMap<>();
        yamlData.put("mappings", mappings);

        Map<String, Object> fileYaml = Map.of("test-key", "test-value");

        try (MockedStatic<YamlReader> yamlReaderMock = mockStatic(YamlReader.class)) {
            yamlReaderMock.when(() -> YamlReader.readYaml(contains(DicomEnrichmentConstants.MAPPING_YAML)))
                    .thenReturn(yamlData);
            yamlReaderMock.when(() -> YamlReader.readYaml(contains("file1.yaml")))
                    .thenReturn(fileYaml);

            kafkaEventConsumer.init();

            Map<String, Map<String, Object>> dynamicYamlCache =
                    (Map<String, Map<String, Object>>) ReflectionTestUtils.getField(kafkaEventConsumer, "dynamicYamlCache");

            assertNotNull(dynamicYamlCache);
            assertEquals(fileYaml, dynamicYamlCache.get("key1"));
        }
    }

}
