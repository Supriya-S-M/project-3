package com.eh.digitalpathology.enricher.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class KafkaNotificationProducerTest {

    @Mock
    private KafkaTemplate<String, String> mockKafkaTemplate;
    @InjectMocks
    private KafkaNotificationProducer kafkaNotificationProducer;

    @Test
    void testSendNotification_Success() {

        String topic = "email-topic";
        String key = "test-key";
        String data = "test-value";

        kafkaNotificationProducer.sendNotification(topic, key, data);
        verify(mockKafkaTemplate, times(1)).send(topic, key, data);
    }

    @Test
    void testSendNotification_ExceptionHandled() {

        String topic = "email-topic";
        String key = "test-key";
        String data = "test-value";

        doThrow(new RuntimeException()).when(mockKafkaTemplate).send(topic, key, data);
        kafkaNotificationProducer.sendNotification(topic, key, data);
        verify(mockKafkaTemplate, times(1)).send(topic, key, data);
    }
}