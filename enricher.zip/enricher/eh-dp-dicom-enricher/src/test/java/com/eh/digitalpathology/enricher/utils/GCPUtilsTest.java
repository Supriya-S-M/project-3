package com.eh.digitalpathology.enricher.utils;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.exceptions.HealthcareApiException;
import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedConstruction;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.InputStream;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GCPUtilsTest {

    @Test
    void testGetAccessToken_BlankCreds_ReturnsEmpty() throws Exception {
        GcpConfig config = mock(GcpConfig.class);
        when(config.getCreds()).thenReturn("");

        String token = GCPUtils.getAccessToken(config);

        assertEquals("", token);
    }

    @Test
    void testGetAccessToken_Success_ReturnsToken() throws Exception {
        String credsJson = "{ \"type\": \"service_account\" }";

        GcpConfig config = mock(GcpConfig.class);
        when(config.getCreds()).thenReturn(credsJson);

        GoogleCredentials mockCreds = mock(GoogleCredentials.class);

        try (MockedStatic<GoogleCredentials> staticMock = mockStatic(GoogleCredentials.class)) {

            staticMock.when(() -> GoogleCredentials.fromStream(any(InputStream.class)))
                    .thenReturn(mockCreds);

            when(mockCreds.createScoped(anySet())).thenReturn(mockCreds);

            doNothing().when(mockCreds).refreshIfExpired();

            AccessToken token = new AccessToken("FAKE_TOKEN_123", null);
            when(mockCreds.refreshAccessToken()).thenReturn(token);

            String result = GCPUtils.getAccessToken(config);

            assertEquals("FAKE_TOKEN_123", result);
        }
    }


    @Test
    void testGetAccessToken_CredentialException_ThrowsHealthcareApiException() {
        String credsJson = "{ \"invalid\": true }";

        GcpConfig config = mock(GcpConfig.class);
        when(config.getCreds()).thenReturn(credsJson);

        try (MockedConstruction<GoogleCredentials> mocked = mockConstruction(GoogleCredentials.class,
                (mock, context) -> {
                    when(mock.createScoped((Collection<String>) any())).thenThrow(new RuntimeException("bad creds"));
                })) {

            HealthcareApiException ex =
                    assertThrows(HealthcareApiException.class, () -> GCPUtils.getAccessToken(config));

            assertTrue(ex.getMessage().contains("Failed to get access token"));
        }
    }
}