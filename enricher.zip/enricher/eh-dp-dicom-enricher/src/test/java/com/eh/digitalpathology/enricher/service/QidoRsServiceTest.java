package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.model.InstancesMeta;
import com.eh.digitalpathology.enricher.utils.GCPUtils;
import com.fasterxml.jackson.databind.JsonNode;
import java.net.http.HttpRequest;
import java.net.http.HttpClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import sun.misc.Unsafe;


import java.lang.reflect.Field;
import java.net.http.HttpResponse;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QidoRsServiceTest {

    @Mock
    private GcpConfig gcpConfig;
    @Mock
    private DatabaseService databaseService;
    @Mock
    private HttpClient httpClient;
    @InjectMocks
    private QidoRsService qidoRsService;

    @BeforeEach
    void setup() throws Exception  {
        when(gcpConfig.getDicomWebUrl()).thenReturn("https://test.com");

        Field field = QidoRsService.class.getDeclaredField("httpClient");
        field.setAccessible(true);

        Field field2 = Unsafe.class.getDeclaredField("theUnsafe");
        field2.setAccessible(true);
        Unsafe object = (Unsafe) field2.get(null);
        object.putObject(object.staticFieldBase(field), object.staticFieldOffset(field), httpClient);
    }

    @Test
    void qidoRsCall_Success_ReturnsJson() throws Exception {

        String seriesUid = "";
        List<InstancesMeta> instances = List.of(
                new InstancesMeta("VSA-155", "1.2.840.10008.3.1.1","1.2.840.10008.3.1.2","test","/test/path","test-device01"),
                new InstancesMeta("VSA-155", "1.2.840.10008.3.2.1","1.2.840.10008.3.2.2","test","/test/path","test-device02")
        );
        String dicomWebUrl = "project/dataset/store";

        HttpResponse<String> mockResponse = mock(HttpResponse.class);
        when(mockResponse.statusCode()).thenReturn(200);
        when(mockResponse.body()).thenReturn("{\"result\":\"ok\"}");

        try (MockedStatic<GCPUtils> gcpMock = mockStatic(GCPUtils.class)) {
            gcpMock.when(() -> GCPUtils.getAccessToken(gcpConfig)).thenReturn("token");

            when(httpClient.send(any(HttpRequest.class), any(HttpResponse.BodyHandler.class)))
                    .thenReturn(mockResponse);

            JsonNode result = qidoRsService.qidoRsCall(seriesUid, instances, dicomWebUrl);

            assertNotNull(result);
            assertEquals("ok", result.get("result").asText());

            verify(databaseService).saveQidoRsResponse(200, "{\"result\":\"ok\"}", seriesUid);
            verify(databaseService, times(2)).updateStatus(any());
        }
    }

    @Test
    void qidoRsCall_Non200Status_ReturnsNull() throws Exception {

        String seriesUid = "xyz";
        List<InstancesMeta> instances = List.of();
        String dicomWebUrl = "project/dataset/store";

        HttpResponse<String> mockResponse = mock(HttpResponse.class);
        when(mockResponse.statusCode()).thenReturn(404);
        when(mockResponse.body()).thenReturn("Not Found");

        try (MockedStatic<GCPUtils> gcpMock = mockStatic(GCPUtils.class)) {
            gcpMock.when(() -> GCPUtils.getAccessToken(gcpConfig)).thenReturn("token");

            when(httpClient.send(any(HttpRequest.class), any(HttpResponse.BodyHandler.class)))
                    .thenReturn(mockResponse);

            JsonNode result = qidoRsService.qidoRsCall(seriesUid, instances, dicomWebUrl);

            assertNull(result);

            verify(databaseService).saveQidoRsResponse(404, "Not Found", seriesUid);
            verify(databaseService, never()).updateStatus(any());
        }
    }
}
