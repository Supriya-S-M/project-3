package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.dbclient.DBRestClient;
import com.eh.digitalpathology.enricher.exceptions.Hl7MessageException;
import com.eh.digitalpathology.enricher.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DatabaseServiceTest {

    @Mock
    private DBRestClient dbRestClient;

    @InjectMocks
    private DatabaseService databaseService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(databaseService, "instanceInfoURL", "http://test-instance");
        ReflectionTestUtils.setField(databaseService, "instanceEnrichmentStatusURL", "http://test-enrichment-status");
    }

    @Test
    void testFetchDataForEnrichment_success() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.3.1111222");

        EnrichedResponse enrichedResponse = new EnrichedResponse();
        ApiResponse<EnrichedResponse> apiResponse =
                new ApiResponse<>("SUCCESS", enrichedResponse, null, null);

        ArgumentCaptor<Consumer<HttpHeaders>> consumerCaptor = ArgumentCaptor.forClass(Consumer.class);

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), eq(caseInfo), any(ParameterizedTypeReference.class), consumerCaptor.capture()))
                .thenReturn(Mono.just(apiResponse));

        EnrichedResponse result = databaseService.fetchDataForEnrichment(caseInfo);

        assertNotNull(result);
        assertEquals(enrichedResponse, result);

        HttpHeaders testHeaders = new HttpHeaders();
        consumerCaptor.getValue().accept(testHeaders);

        assertTrue(testHeaders.containsKey("X-Service-Name"));
        assertEquals(DicomEnrichmentConstants.DICOM_ENRICHMENT, testHeaders.getFirst("X-Service-Name"));
    }

    @Test
    void testFetchDataForEnrichment_exception() {
        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.3.6.1111222");

        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException("Error"));

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.fetchDataForEnrichment(caseInfo));


        assertEquals("Error", exception.getMessage());
        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testUpdateEnrichmentStatus_success() {
        EnrichInstance enrichInstance = new EnrichInstance();
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "response", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.PUT), anyString(), eq(enrichInstance),
                any(ParameterizedTypeReference.class), any()))
                .thenReturn(Mono.just(apiResponse));

        String result = databaseService.updateEnrichmentStatus(enrichInstance);
        assertEquals("SUCCESS", result);
    }

    @Test
    void testUpdateEnrichmentStatus_exception() {
        EnrichInstance enrichInstance = new EnrichInstance();

        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.updateEnrichmentStatus(enrichInstance));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testFetchMetaData_success() {
        DicomDirDocument document = new DicomDirDocument();
        ApiResponse<DicomDirDocument> apiResponse = new ApiResponse<>("SUCCESS",document,"","");

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), isNull(),
                any(ParameterizedTypeReference.class), isNull()))
                .thenReturn(Mono.just(apiResponse));

        DicomDirDocument result = databaseService.fetchMetaData("1.2.3.1111222");
        assertNotNull(result);
    }

    @Test
    void testFetchMetaData_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.fetchMetaData("1.2.3.1111222"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }
    @Test
    void testUpdateStatus_success() {
        BarcodeInstanceRequest request = new BarcodeInstanceRequest("vsa-070","1.2.3.7.11112226");
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "Updated", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.PUT), anyString(), eq(request),
                any(ParameterizedTypeReference.class), any())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.updateStatus(request);
        assertEquals("SUCCESS", result);
    }

    @Test
    void testUpdateStatus_exception() {
        BarcodeInstanceRequest request = new BarcodeInstanceRequest("vsa-070", "1.2.3.7.11112226");

        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.updateStatus(request));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testFetchInstancesOfSeries_success() {
        List<InstancesMeta> instances = List.of(new InstancesMeta("vsa-070","1.2.840.10008.3.1.1","1.2.840.10008.3.1.2","test-status","/test/file","test-device01"));
        ApiResponse<List<InstancesMeta>> apiResponse = new ApiResponse<>("SUCCESS", instances, null, null);

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), isNull(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        List<InstancesMeta> result = databaseService.fetchInstancesOfSeries("1.2.840.10008.3.1.1");
        assertEquals(1, result.size());
    }

    @Test
    void testFetchInstancesOfSeries_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.fetchInstancesOfSeries("1.2.840.10008.3.1.1"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testGetStatusOfInstance_success() {
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "test-status", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), isNull(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.getStatusOfInstance("1.2.840.10008.3.1.1", "1.2.840.10008.3.1.2");
        assertEquals("test-status", result);
    }

    @Test
    void testGetStatusOfInstance_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.getStatusOfInstance("1.2.840.10008.3.1.1", "1.2.840.10008.3.1.1"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testUpdateDicomDir_success() {
        DicomDirDocument document = new DicomDirDocument();
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "Updated", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.PUT), anyString(), eq(document),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        assertDoesNotThrow(() -> databaseService.updateDicomDir(document));

    }

    @Test
    void testUpdateDicomDir_exception() {
        DicomDirDocument document = new DicomDirDocument();

        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.updateDicomDir(document));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testSaveQidoRsResponse_success() {
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "Saved", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.POST), anyString(), any(QidoResponse.class),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        assertDoesNotThrow(() -> databaseService.saveQidoRsResponse(200, "body", "1.2.840.10008.3.1.1"));
    }

    @Test
    void testSaveQidoRsResponse_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.saveQidoRsResponse(200, "body", "1.2.840.10008.3.1.1"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testCheckForSopPresence_singleSeriesId() {
        List<String> seriesIds = List.of("1.2.840.10008.3.1.1");
        ApiResponse<List<String>> apiResponse = new ApiResponse<>("SUCCESS", seriesIds, null, null);

        when(dbRestClient.exchange(eq(HttpMethod.POST), anyString(), any(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.checkForSopPresence(List.of("1.2.840.10008.3.1.2", "1.2.840.10008.3.1.3"));
        assertEquals("1.2.840.10008.3.1.1", result);
    }

    @Test
    void testCheckForSopPresence_NullSeriesIds() {
        List<String> seriesIds = List.of();
        ApiResponse<List<String>> apiResponse = new ApiResponse<>("SUCCESS",seriesIds , null, null);

        when(dbRestClient.exchange(eq(HttpMethod.POST), anyString(), any(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.checkForSopPresence(List.of("1.2.840.10008.3.1.1", "1.2.840.10008.3.1.2"));
        assertNull(result);
    }
    @Test
    void testCheckForSopPresence_multipleSeriesIds() {
        List<String> seriesIds = List.of("1.2.840.10008.3.1.1", "1.2.840.10008.3.1.1.2");
        ApiResponse<List<String>> apiResponse = new ApiResponse<>("SUCCESS", seriesIds, null, null);

        when(dbRestClient.exchange(eq(HttpMethod.POST), anyString(), any(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.checkForSopPresence(List.of("1.2.840.10008.3.1.1.2", "1.2.840.10008.3.1.1.3"));
        assertNull(result);
    }

    @Test
    void testCheckForSopPresence_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        List<String> sopList = List.of("1.2.840.10008.3.1.1", "1.2.840.10008.3.1..2");

        Hl7MessageException exception = assertThrows(
                Hl7MessageException.class, () -> databaseService.checkForSopPresence(sopList));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }


    @Test
    void testFetchInstancesByRequestId_success() {
        List<String> instances = List.of("1.2.840.10008.3.1.1", "1.2.840.10008.3.1.2");
        ApiResponse<List<String>> apiResponse = new ApiResponse<>("SUCCESS", instances, null, null);

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), isNull(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        List<String> result = databaseService.fetchInstancesByRequestId("req1d1.2");
        assertEquals(2, result.size());
    }

    @Test
    void testFetchInstancesByRequestId_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.fetchInstancesByRequestId("req1d1.2"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

    @Test
    void testGetDicomStoreUrl_success() {
        ApiResponse<String> apiResponse = new ApiResponse<>("SUCCESS", "http://dicom-store-url", null, null);

        when(dbRestClient.exchange(eq(HttpMethod.GET), anyString(), isNull(),
                any(ParameterizedTypeReference.class), isNull())).thenReturn(Mono.just(apiResponse));

        String result = databaseService.getDicomStroreUrl("test-device01");
        assertEquals("http://dicom-store-url", result);
    }

    @Test
    void testGetDicomStoreUrl_exception() {
        when(dbRestClient.exchange(any(), any(), any(), any(), any()))
                .thenThrow(new RuntimeException());

        Hl7MessageException exception = assertThrows(Hl7MessageException.class,
                () -> databaseService.getDicomStroreUrl("test-device01"));

        assertEquals(DicomEnrichmentConstants.INVALID_ERROR, exception.getErrorCode());
    }

}
