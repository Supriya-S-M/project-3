package com.eh.digitalpathology.enricher.dbclient;

import static org.junit.jupiter.api.Assertions.*;

import com.eh.digitalpathology.enricher.exceptions.Hl7MessageException;
import com.eh.digitalpathology.enricher.model.ApiResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.client.*;
import reactor.core.publisher.Mono;

import java.util.function.Function;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DBRestClientTest {

    @Mock
    private WebClient webClient;
    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;
    @Mock
    private WebClient.RequestBodySpec requestBodySpec;
    @Mock
    private WebClient.RequestHeadersSpec<?> requestHeadersSpec;
    @Mock
    private WebClient.ResponseSpec responseSpec;
    @InjectMocks
    private DBRestClient dbRestClient;

    @Test
    void testExchange_SuccessfulResponse() {
        ApiResponse<String> apiResponse = new ApiResponse<>("success", "Data Received", "", "");

        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("test/uri")).thenReturn(requestBodySpec);
        when(requestBodySpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class))).thenReturn(Mono.just(apiResponse));

        ApiResponse<Object> result = dbRestClient
                .exchange(HttpMethod.GET, "test/uri", null, new ParameterizedTypeReference<>() {}, null)
                .block();

        assertNotNull(result);
        assertEquals("success", result.status());
        assertEquals("Data Received", result.content());
        verify(webClient).method(HttpMethod.GET);
        verify(requestBodyUriSpec).uri("test/uri");
    }


    @Test
    void testExchange_ErrorResponse_ThrowsHl7MessageException() {
        when(webClient.method(HttpMethod.POST)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("test/uri")).thenReturn(requestBodySpec);

        doReturn(requestHeadersSpec).when(requestBodySpec).body(any());

        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class)))
                .thenReturn(Mono.error(new Hl7MessageException("HL7_404", "Invalid HL7 message")));

        Mono<?> result = dbRestClient.exchange(
                HttpMethod.POST, "test/uri", "payload",
                new ParameterizedTypeReference<>() {}, HttpHeaders::clear);

        Hl7MessageException thrown = assertThrows(
                Hl7MessageException.class,
                result::block
        );

        assertEquals("HL7_404", thrown.getErrorCode());
        assertEquals("Invalid HL7 message", thrown.getMessage());

        verify(webClient).method(HttpMethod.POST);
        verify(requestBodySpec).body(any());
        verify(requestHeadersSpec).headers(any());
    }

    @Test
    void testExchange_OnStatusNonFailure_ReturnsEmptyAndContinues() {
        ApiResponse<String> successResponse =
                new ApiResponse<>("success", "OK", "", "");

        when(webClient.method(HttpMethod.GET)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("test/uri")).thenReturn(requestBodySpec);
        when(requestBodySpec.retrieve()).thenReturn(responseSpec);

        when(responseSpec.onStatus(any(), any())).thenAnswer(invocation -> {
            Function<ClientResponse, Mono<?>> fn = invocation.getArgument(1);

            ClientResponse mockResponse = mock(ClientResponse.class);
            ApiResponse<String> nonFailure = new ApiResponse<>("success", "", "", "");

            when(mockResponse.bodyToMono(any(ParameterizedTypeReference.class)))
                    .thenReturn(Mono.just(nonFailure));

            fn.apply(mockResponse);
            return responseSpec;
        });

        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class)))
                .thenReturn(Mono.just(successResponse));

        ApiResponse<?> result = dbRestClient.exchange(
                HttpMethod.GET, "test/uri", null,
                new ParameterizedTypeReference<>() {}, null
        ).block();

        assertNotNull(result);
        assertEquals("success", result.status());
    }


    @Test
    void testExchange_OnStatusFailure_ThrowsHl7MessageException() {

        when(webClient.method(HttpMethod.POST)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri("test/uri")).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(BodyInserter.class)))
                .thenReturn(requestHeadersSpec);

        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.onStatus(any(), any())).thenReturn(responseSpec);

        when(responseSpec.bodyToMono(any(ParameterizedTypeReference.class)))
                .thenReturn(Mono.error(new Hl7MessageException("HL7_501", "Processing failed")));

        Mono<?> result = dbRestClient.exchange(HttpMethod.POST,
                "test/uri",
                "payload",
                new ParameterizedTypeReference<>() {},
                HttpHeaders::clear
        );

        Hl7MessageException thrown =
                assertThrows(Hl7MessageException.class, result::block);

        assertEquals("HL7_501", thrown.getErrorCode());
        assertEquals("Processing failed", thrown.getMessage());
    }

}


