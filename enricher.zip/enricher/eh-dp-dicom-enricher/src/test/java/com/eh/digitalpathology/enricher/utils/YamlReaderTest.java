package com.eh.digitalpathology.enricher.utils;

import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class YamlReaderTest {

    @TempDir
    Path tempDir;

    @Test
    void testReadYaml_Success_ReturnsMap() throws Exception {

        Path yamlFile = tempDir.resolve("test.yaml");
        Files.writeString(yamlFile, "key: value");

        Map<String, Object> result = YamlReader.readYaml(yamlFile.toString());

        assertNotNull(result);
        assertEquals("value", result.get("key"));
    }

    @Test
    void testReadYaml_FileNotFound_ThrowsException() {

        String invalidPath = "file.yaml";
        DicomEnrichmentServiceException ex = assertThrows(
                DicomEnrichmentServiceException.class,
                () -> YamlReader.readYaml(invalidPath)
        );

        assertTrue(ex.getMessage().contains("Unable to read yaml file"));
    }
}
