package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.model.CaseInfo;
import com.eh.digitalpathology.enricher.model.SeriesState;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DicomTrackerTest {

    @Mock
    private ScheduledExecutorService mockScheduler;
    @Mock
    private ScheduledFuture<Void> mockScheduledFuture;
    @Mock
    private BiFunction<String, SeriesState, CompletableFuture<Void>> mockCallback;

    private DicomTracker dicomTracker;

    @BeforeEach
    void setup() {
        dicomTracker = new DicomTracker(mockScheduler);
        ReflectionTestUtils.setField(dicomTracker, "taskTimeoutMinutes", 1L);
        dicomTracker.setOnSeriesTimeOutCallback(mockCallback);
    }

    @Test
    void testHandleInstances_NewSeries_SchedulesTimer() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.1.2.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.1.2.1");
        when(mockScheduler.schedule(any(Runnable.class), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.1.2.1", caseInfo);

        SeriesState state = dicomTracker.getState("1.2.840.10008.1.2.1");
        assertNotNull(state);

        verify(mockScheduler, times(1)).schedule(any(Runnable.class), eq(1L), eq(TimeUnit.MINUTES));
    }


    @Test
    void testHandleInstances_ExistingSeries_ResetsTimer() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.3.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.3.1.1");

        when(mockScheduler.schedule(any(Runnable.class), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);
        SeriesState existingState = dicomTracker.getState("1.2.840.10008.3.1.1");
        existingState.setTimerTask(mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);
        verify(mockScheduledFuture, atLeastOnce()).cancel(false);
        verify(mockScheduler, atLeastOnce()).schedule(any(Runnable.class), anyLong(), any(TimeUnit.class));
    }

    @Test
    void testHandleInstances_AlreadyCommittedSeries_DoesNotScheduleTimerAgain() {
        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.3.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.3.1.1");

        when(mockScheduler.schedule(any(Runnable.class), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);

        dicomTracker.markCommitmentReceived("1.2.840.10008.3.1.1");

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);

        verify(mockScheduler, times(1))
                .schedule(any(Runnable.class), anyLong(), any(TimeUnit.class));
    }

    @Test
    void testHandleInstances_TimeoutCallbackTriggered_WhenCommitmentNotReceived()  {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.3.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.3.1.1");

        ArgumentCaptor<Runnable> runnableCaptor = ArgumentCaptor.forClass(Runnable.class);
        when(mockScheduler.schedule(runnableCaptor.capture(), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        CompletableFuture<Void> completedFuture = CompletableFuture.completedFuture(null);
        when(mockCallback.apply(anyString(), any())).thenReturn(completedFuture);


        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);

        Runnable scheduledTask = runnableCaptor.getValue();
        assertNotNull(scheduledTask);
        scheduledTask.run();

        verify(mockCallback, times(1)).apply(eq("1.2.840.10008.3.1.1"), any(SeriesState.class));
    }

    @Test
    void testMarkCommitmentReceived_CancelsTimer() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.3.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.3.1.1");

        when(mockScheduler.schedule(any(Runnable.class), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);
        SeriesState state = dicomTracker.getState("1.2.840.10008.3.1.1");
        state.setTimerTask(mockScheduledFuture);

        dicomTracker.markCommitmentReceived("1.2.840.10008.3.1.1");

        assertTrue(state.commitmentReceived.get(), "Commitment flag should be true after markCommitmentReceived");
        verify(mockScheduledFuture, times(1)).cancel(false);
    }

    @Test
    void testSetOnSeriesTimeOutCallback_SetsProperly() {

        BiFunction<String, SeriesState, CompletableFuture<Void>> anotherCallback = mock(BiFunction.class);
        dicomTracker.setOnSeriesTimeOutCallback(anotherCallback);
        assertNotNull(anotherCallback);
    }

    @Test
    void testInvalidate_RemovesEntryFromCache() {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setSopInstanceUid("1.2.840.10008.3.1.2");
        caseInfo.setSeriesInstanceUid("1.2.840.10008.3.1.1");
        when(mockScheduler.schedule(any(Runnable.class), anyLong(), any(TimeUnit.class)))
                .thenReturn((ScheduledFuture) mockScheduledFuture);

        dicomTracker.handleInstances("1.2.840.10008.3.1.1", caseInfo);
        assertNotNull(dicomTracker.getState("1.2.840.10008.3.1.1"));

        dicomTracker.invalidate("1.2.840.10008.3.1.1");

        assertNull(dicomTracker.getState("1.2.840.10008.3.1.1"));
    }


}