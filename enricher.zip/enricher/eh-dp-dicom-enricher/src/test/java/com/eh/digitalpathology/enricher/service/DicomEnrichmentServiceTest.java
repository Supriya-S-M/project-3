package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.api.EnrichedDicomStorageStrategy;
import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.dataloader.YamlLoader;
import com.eh.digitalpathology.enricher.model.*;
import com.eh.digitalpathology.enricher.utils.YamlReader;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import com.google.cloud.storage.Blob;
import com.google.cloud.ReadChannel;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomInputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.lang.reflect.Method;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DicomEnrichmentServiceTest {

    @Mock
    private DatabaseService databaseService;
    @Mock
    private EnrichedDicomStorageStrategy dicomStorageStrategy;
    @Mock
    private GcpConfig gcpConfig;
    @Mock
    private KafkaNotificationProducer kafkaNotificationProducer;
    @Mock
    private YamlLoader yamlLoader;

    DicomEnrichmentService service;

    @BeforeEach
    void init() {
        service = new DicomEnrichmentService(databaseService, dicomStorageStrategy, gcpConfig, kafkaNotificationProducer, yamlLoader);
    }


    @Test
    void fetchDataForEnrichment_success()  {

        CaseInfo caseInfo = new CaseInfo();
        caseInfo.setMessageType("OUL");

        EnrichedResponse response = new EnrichedResponse();
        response.setBarcode("VSA-155");
        response.setIntermediateStoragePath("gs://bucket/test.dcm");
        response.setParsedData(Map.of("test-key", "test-value"));
        response.setOriginalStudyInstanceUid("1.2.840.1001.1");
        response.setSeriesInstanceUid("1.2.840.1001.1.1");
        response.setSopInstanceUid("1.2.840.1001.1.1.1");

        when(databaseService.fetchDataForEnrichment(caseInfo)).thenReturn(response);

        when(gcpConfig.getCreds()).thenReturn("test-credentials");

        try (MockedStatic<YamlReader> mockYaml = mockStatic(YamlReader.class)) {

            mockYaml.when(() -> YamlReader.readYaml(anyString()))
                    .thenReturn(Map.of("tags", List.of()));

            try (MockedStatic<ServiceAccountCredentials> mockCreds =
                         mockStatic(ServiceAccountCredentials.class)) {

                ServiceAccountCredentials creds = mock(ServiceAccountCredentials.class);
                mockCreds.when(() -> ServiceAccountCredentials.fromStream(any()))
                        .thenReturn(creds);

                try (MockedStatic<StorageOptions> mockStorageOptions =
                             mockStatic(StorageOptions.class)) {

                    StorageOptions.Builder builder = mock(StorageOptions.Builder.class);
                    StorageOptions options = mock(StorageOptions.class);
                    Storage storage = mock(Storage.class);
                    Blob blob = mock(Blob.class);
                    ReadChannel readChannel = mock(ReadChannel.class);

                    mockStorageOptions.when(StorageOptions::newBuilder)
                            .thenReturn(builder);

                    when(builder.setCredentials(any())).thenReturn(builder);
                    when(builder.build()).thenReturn(options);
                    when(options.getService()).thenReturn(storage);

                    when(storage.get(anyString(), anyString())).thenReturn(blob);
                    when(blob.reader()).thenReturn(readChannel);

                    try (MockedConstruction<DicomInputStream> mockDis =
                                 mockConstruction(DicomInputStream.class, (mock, ctx) -> {
                                     when(mock.readDataset()).thenReturn(new Attributes());
                                     when(mock.readFileMetaInformation()).thenReturn(new Attributes());
                                 })) {

                        EnrichInstance enrichInstance = service.fetchDataForEnrichment(caseInfo, Map.of(), Map.of());

                        assertNotNull(enrichInstance);
                        assertEquals("VSA-155", enrichInstance.getBarcode());
                    }
                }
            }
        }
    }


    @Test
    void setAttributes_formatsPNCorrectly() throws Exception {
        Attributes attributes = new Attributes();

        TagItem pnTag = new TagItem();
        pnTag.setName("PatientName");
        pnTag.setVr("PN");
        pnTag.setValue("Test^^Name");

        Method method = DicomEnrichmentService.class
                .getDeclaredMethod("setAttributes", Attributes.class, List.class);
        method.setAccessible(true);

        method.invoke(service, attributes, List.of(pnTag));

        assertEquals("Test^Name", attributes.getString(Tag.PatientName));
    }

    @Test
    void populateValues_removesEmptyTags() throws Exception {
        TagItem tag = new TagItem();
        tag.setName("TestTag");
        tag.setDefaultValue("");
        tag.setValue("");

        List<TagItem> tags = new ArrayList<>(List.of(tag));

        Method m = DicomEnrichmentService.class
                .getDeclaredMethod("populateValues", List.class, Map.class, String.class);
        m.setAccessible(true);
        m.invoke(service, tags, Map.of(), "VSA-155");

        assertTrue(tags.isEmpty());
    }


    @Test
    void storeDicomInstance_success() throws Exception {
        Attributes fmi = new Attributes();
        Attributes dcm = new Attributes();

        dcm.setString(Tag.StudyInstanceUID, VR.UI, "1.2.840.1001.1");
        dcm.setString(Tag.SOPInstanceUID, VR.UI, "1.2.840.1001.1.1.1");
        dcm.setString(Tag.SeriesInstanceUID, VR.UI, "1.2.840.1001.1.1");
        dcm.setString(Tag.AccessionNumber, VR.SH, "ACC-001");

        Method m = DicomEnrichmentService.class.getDeclaredMethod(
                "storeDicomInstance",
                Attributes.class, Attributes.class, String.class, String.class
        );
        m.setAccessible(true);

        EnrichInstance out = (EnrichInstance) m.invoke(service, fmi, dcm, "VSA-155", "test-device01");

        verify(dicomStorageStrategy).storeEnrichedDicomInstance(fmi, dcm, "test-device01");
        verify(databaseService).updateEnrichmentStatus(any());
        assertEquals("completed", out.getStatus());
    }


    @Test
    void mergeDynamicContent_addsDynamicStructures() throws Exception {
        TagItem root = new TagItem();
        root.setDynamicInclude(true);

        Map<String, Map<String, Object>> dynamicYaml = Map.of(
                "TYPE1", Map.of("tags",
                        List.of(Map.of(
                                "name", "DynamicTag",
                                "vr", "LO",
                                "value", ""
                        ))
                )
        );

        Map<String, String> additivesMapping = Map.of("A", "TYPE1");
        Map<String, String> matchedTypes = Map.of("SPM-6[1]", "A");
        List<TagItem> tags = new ArrayList<>(List.of(root));

        invokePrivateMethod(service, "mergeDynamicContent", new Class[]{List.class, Map.class, Map.class, Map.class},
                tags, dynamicYaml, additivesMapping, matchedTypes
        );

        assertFalse(tags.stream().anyMatch(t -> "DynamicTag".equals(t.getName())));
    }


    @Test
    void applyDynamicInclusion_processesSpm6IndexedKey() throws Exception {

        Map<String, String> parsedHl7 = new HashMap<>();
        parsedHl7.put("SPM-6[1]", "TISSUE");

        when(yamlLoader.getYamlDataMaps()).thenReturn(
                Map.of("SPM-6", Map.of(
                        "TISSUE",
                        Map.of(DicomEnrichmentConstants.CODE_TYPE, "BIOPSY"))));

        Map<String, Map<String, Object>> dynamicYamlCache = new HashMap<>();
        Map<String, String> additivesMapping = new HashMap<>();

        DicomTags dicomTags = new DicomTags();
        dicomTags.setTags(new ArrayList<>());

        invokePrivateMethod(service, "applyDynamicInclusion",
                new Class[]{DicomTags.class, Map.class, Map.class, Map.class, String.class},
                dicomTags, parsedHl7, dynamicYamlCache, additivesMapping, "VSA-155");

        assertDoesNotThrow(() -> invokePrivateMethod(service, "applyDynamicInclusion",
                        new Class[]{DicomTags.class, Map.class, Map.class, Map.class, String.class},
                        dicomTags, parsedHl7, dynamicYamlCache, additivesMapping, "BC123"
                )
        );

    }

    private Object invokePrivateMethod(Object target, String methodName, Class<?>[] paramTypes, Object... args)
            throws Exception {
        Method m = target.getClass().getDeclaredMethod(methodName, paramTypes);
        m.setAccessible(true);
        return m.invoke(target, args);
    }

    @Test
    void getCodeSetMapping_missingMapping_triggersEmail1() throws Exception {

        when(yamlLoader.getYamlDataMaps())
                .thenReturn(Map.of("SPM-6", Map.of()));

        invokePrivateMethod(service, "getCodeSetMapping", new Class[]{String.class, String.class, String.class, Map.class, String.class},
                "SPM-6", "Coding Scheme Designator", "X", new HashMap<>(), "BC123");

        verify(kafkaNotificationProducer).sendNotification(isNull(), eq("CODE_SET_MAPPING_FIELD_MISSING"), anyString());
    }

    @Test
    void convertToTagItemList_createsBasicTag() throws Exception {
        List<Map<String, Object>> yaml = List.of(
                Map.of(
                        "name", "PatientName",
                        "vr", "PN",
                        "value", "Test^Name",
                        "defaultValue", ""
                )
        );

        Method m = DicomEnrichmentService.class.
                getDeclaredMethod("convertToTagItemList", List.class, Optional.class);
        m.setAccessible(true);

        List<TagItem> result = (List<TagItem>) m.invoke(service, yaml, Optional.empty());

        assertEquals(1, result.size());
        TagItem tag = result.get(0);
        assertEquals("PatientName", tag.getName());
        assertEquals("PN", tag.getVr());
        assertEquals("Test^Name", tag.getValue());
    }

    @Test
    void setTagValue_replacesHL7Key() throws Exception {

        Map<String, Object> yaml = Map.of("value", "SPM-6");
        TagItem tag = new TagItem();

        invokePrivateMethod(service, "setTagValue",
                new Class[]{TagItem.class, Map.class, Optional.class},
                tag, yaml, Optional.of("SPM-6[1]"));

        assertEquals("SPM-6[1]", tag.getValue());
    }

    @Test
    void setTagValue_assignsMultiValues() throws Exception {

        Map<String, Object> yaml = Map.of(
                "value", List.of("RIGHT", "LATERAL", "APEX"));
        TagItem tag = new TagItem();

        invokePrivateMethod(service, "setTagValue",
                new Class[]{TagItem.class, Map.class, Optional.class},
                tag, yaml, Optional.empty());

        assertEquals(List.of("RIGHT", "LATERAL", "APEX"), tag.getValues());
    }

    @Test
    void setDynamicTag_setsDefaults() throws Exception {

        TagItem tag = new TagItem();
        invokePrivateMethod(service, "setDynamicTag", new Class[]{TagItem.class}, tag);

        assertTrue(tag.isDynamicInclude());
        assertEquals("SQ", tag.getVr());
        assertEquals("", tag.getValue());
    }

    @Test
    void setTagItems_populatesNestedTags() throws Exception {

        Map<String, Object> child = Map.of(
                "name", "ChildTag",
                "vr", "LO",
                "value", "RIGHT_APEX"
        );

        Map<String, Object> parent = Map.of(
                "name", "Parent",
                "vr", "SQ",
                "items", List.of(child)
        );

        TagItem tag = new TagItem();

        invokePrivateMethod(service, "setTagItems",
                new Class[]{TagItem.class, Map.class, Optional.class},
                tag, parent, Optional.empty());

        assertNotNull(tag.getItems());
        assertEquals(1, tag.getItems().size());
        assertEquals("ChildTag", tag.getItems().get(0).getName());
    }

    @Test
    void convertToTagItemList_basicTag_parsedCorrectly() throws Exception {
        Map<String, Object> map = Map.of(
                "name", "PatientID",
                "vr", "LO",
                "value", "PID-3"
        );

        List<Map<String,Object>> input = List.of(map);

        List<TagItem> result = (List<TagItem>) invokePrivateMethod(
                service,
                "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                input, Optional.empty()
        );

        TagItem tag = result.get(0);
        assertEquals("PatientID", tag.getName());
        assertEquals("LO", tag.getVr());
        assertEquals("PID-3", tag.getValue());
    }

    @Test
    void convertToTagItemList_replacesSpm6Key() throws Exception {
        Map<String, Object> map = Map.of(
                "name", "TestTag",
                "vr", "LO",
                "value", "SPM-6"
        );

        List<TagItem> result = (List<TagItem>) invokePrivateMethod(
                service,
                "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                List.of(map),
                Optional.of("SPM-6[1]")
        );

        assertEquals("SPM-6[1]", result.get(0).getValue());
    }

    @Test
    void convertToTagItemList_handlesValueList() throws Exception {
        Map<String, Object> map = Map.of(
                "name", "TestTag",
                "vr", "CS",
                "value", List.of("LEFT","RIGHT","BILATERAL")
        );

        List<TagItem> out = (List<TagItem>) invokePrivateMethod(
                service,
                "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                List.of(map),
                Optional.empty()
        );

        assertEquals(List.of("LEFT","RIGHT","BILATERAL"), out.get(0).getValues());
    }

    @Test
    void convertToTagItemList_dynamicInclude_setsDefaults() throws Exception {
        Map<String, Object> map = Map.of(
                "name", "DynamicRoot",
                "include", "dynamic"
        );

        List<TagItem> out = (List<TagItem>) invokePrivateMethod(
                service,
                "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                List.of(map),
                Optional.empty()
        );

        TagItem tag = out.get(0);

        assertTrue(tag.isDynamicInclude());
        assertEquals("SQ", tag.getVr());
        assertEquals("", tag.getValue());
    }

    @Test
    void convertToTagItemList_nestedItemsProcessed() throws Exception {
        Map<String, Object> child = Map.of(
                "name", "ChildTag",
                "vr", "LO",
                "value", "X"
        );

        Map<String, Object> parent = Map.of(
                "name", "Parent",
                "vr", "SQ",
                "items", List.of(child)
        );

        List<TagItem> out = (List<TagItem>) invokePrivateMethod(
                service,
                "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                List.of(parent), Optional.empty()
        );

        TagItem root = out.get(0);
        assertEquals(1, root.getItems().size());
        assertEquals("ChildTag", root.getItems().get(0).getName());
    }

    @Test
    void populatePatientName_replacesHl7KeysCorrectly() throws Exception {
        TagItem tag = new TagItem();
        tag.setValue("FN^LN");

        Map<String,String> hl7 = Map.of(
                "FN", "Test",
                "LN", "Name"
        );

        invokePrivateMethod(service, "populatePatientName", new Class[]{TagItem.class, Map.class},
                tag, hl7);

        assertEquals("Test^Name", tag.getValue());
    }


    @Test
    void populateMultiValuesMapping_mapsFirstMatchingValue() throws Exception {
        TagItem tag = new TagItem();
        tag.setName("PID-10");
        tag.setVr("LO");
        tag.setValues(List.of("ASIAN", "Caucasian"));

        Map<String,String> hl7 = Map.of("Caucasian", "Mapped");

        invokePrivateMethod(
                service,
                "populateMultiValuesMapping",
                new Class[]{TagItem.class, Map.class, Map.class, String.class, List.class},
                tag, hl7, new HashMap<>(), "VSA-155", new ArrayList<>()
        );

        assertEquals("Mapped", tag.getValue());
    }

    @Test
    void populateHL7ParsedData_truncatesStudyDate() throws Exception {
        TagItem tag = new TagItem();
        tag.setName("StudyDate");
        tag.setVr("DA");

        String populatedData = (String) invokePrivateMethod(
                service,
                "populateHL7ParsedData",
                new Class[]{TagItem.class, String.class, String.class, List.class, Map.class, String.class},
                tag, "StudyDate", "20250101123000",
                new ArrayList<>(), new HashMap<>(), "VSA-155"
        );

        assertEquals("20250101", populatedData);
    }

    @Test
    void convertToTagItemList_setsValue_and_dynamicInclude() throws Exception {

        Map<String, Object> map = new HashMap<>();
        map.put("name", "Dyn");
        map.put("include", "dynamic");
        List<Map<String, Object>> input = List.of(map);

        List<TagItem> result = (List<TagItem>) invokePrivateMethod(service, "convertToTagItemList",
                new Class[]{List.class, Optional.class}, input, Optional.empty());

        assertEquals(1, result.size());
        TagItem t = result.get(0);
        assertTrue(t.isDynamicInclude());
        assertEquals("SQ", t.getVr());
        assertEquals("", t.getValue());
    }

    @Test
    void setTagValue_replacesSPM6_whenHl7KeyPresent() throws Exception {
        Map<String, Object> map = new HashMap<>();
        map.put("value", "Specimen from SPM-6 site");

        TagItem tagItem = new TagItem();

        Method m = DicomEnrichmentService.class.getDeclaredMethod(
                "setTagValue",
                TagItem.class, Map.class, Optional.class
        );
        m.setAccessible(true);

        m.invoke(service, tagItem, map, Optional.of("Right Forearm"));

        String val = tagItem.getValue();
        assertEquals("Specimen from Right Forearm site", val);
        assertFalse(val.contains("SPM-6"));
        assertTrue(val.contains("Right Forearm"));

    }

    @Test
    void setTagItems_buildsNestedItems() throws Exception {
        Map<String, Object> child = new HashMap<>();
        child.put(DicomEnrichmentConstants.NAME, "Child");
        child.put(DicomEnrichmentConstants.VR, "LO");
        List<Map<String, Object>> nested = List.of(child);

        Map<String, Object> parentMap = new HashMap<>();
        parentMap.put(DicomEnrichmentConstants.TAGS, nested);

        TagItem parent = new TagItem();
        invokePrivateMethod(service, "setTagItems",
                new Class[]{TagItem.class, Map.class, Optional.class},
                parent, parentMap, Optional.empty());

        assertNotNull(parent.getItems());
        assertEquals(1, parent.getItems().size());
        assertEquals("Child", parent.getItems().get(0).getName());
    }

    @Test
    void populatePatientName_replacesComponentsFromHl7Map() throws Exception {
        TagItem tag = new TagItem();
        tag.setValue("GIVEN^FAMILY^MIDDLE");

        Map<String, String> hl7 = new HashMap<>();
        hl7.put("GIVEN", "Test");
        hl7.put("FAMILY", "User");
        hl7.put("MIDDLE", "L");

        invokePrivateMethod(service, "populatePatientName",
                new Class[]{TagItem.class, Map.class},
                tag, hl7);

        assertEquals("Test^User^L", tag.getValue());
    }

    @Test
    void populateTagItems_marksSequenceEmpty_and_addsToRemove() throws Exception {

        TagItem inner = new TagItem();
        inner.setItems(new ArrayList<>());
        TagItem parent = new TagItem();
        parent.setVr("SQ");
        parent.setName("Sequence");
        parent.setItems(new ArrayList<>(List.of(inner)));

        List<TagItem> removeList = new ArrayList<>();
        Map<String, String> hl7 = new HashMap<>();

        invokePrivateMethod(service, "populateTagItems",
                new Class[]{TagItem.class, Map.class, List.class, String.class},
                parent, hl7, removeList, "VSA-155");

        assertTrue(removeList.contains(parent));
    }

    @Test
    void populateMultiValuesMapping_addsEmptyIfNoMatch() throws Exception {
        TagItem tagItem = new TagItem();
        tagItem.setName("TestTag");
        tagItem.setValues(List.of("value1", "value2"));
        tagItem.setDefaultValue("");

        Map<String, String> hl7 = new HashMap<>();
        Map<String, Map<?, ?>> codeSeqMap = new HashMap<>();
        List<TagItem> itemsToRemove = new ArrayList<>();

        invokePrivateMethod(service, "populateMultiValuesMapping",
                new Class[]{TagItem.class, Map.class, Map.class, String.class, List.class},
                tagItem, hl7, codeSeqMap, "VSA-155", itemsToRemove);

        assertTrue(itemsToRemove.contains(tagItem));
    }

    @Test
    void testHandleDateTime_substringsCorrectPositions() throws Exception {

        TagItem ti = new TagItem();
        ti.setName("StudyDate");

        String studyDateResult = (String) invokePrivateMethod(
                service,
                "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                ti, "20200101123456", new ArrayList<TagItem>()
        );
        assertEquals("20200101", studyDateResult);

        ti.setName("StudyTime");
        String studyTimeResult = (String) invokePrivateMethod(
                service,
                "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                ti, "2020010112345678", new ArrayList<TagItem>()
        );
        assertEquals("12345678", studyTimeResult);

        ti.setName("PatientBirthTime");
        List<TagItem> removeList = new ArrayList<>();

        String birthTimeResult = (String) invokePrivateMethod(
                service,
                "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                ti, "20200101", removeList
        );

        assertEquals("20200101", birthTimeResult);
        assertEquals(1, removeList.size());
    }

    @Test
    void checkEmptySequence_returnsTrueForEmptyInnerItems() throws Exception {
        TagItem inner = new TagItem();
        inner.setItems(new ArrayList<>());
        inner.setName(null);
        inner.setVr(null);
        inner.setValue(null);

        TagItem seq = new TagItem();
        seq.setItems(new ArrayList<>(List.of(inner)));

        Object res = invokePrivateMethod(service, "checkEmptySequence", new Class[]{TagItem.class}, seq);
        assertEquals(Boolean.TRUE, res);
    }


    @Test
    void mergeSpecimenDescSeqItems_mergesMultipleAttributes() throws Exception {
        Attributes attributes = new Attributes();

        Sequence seq = attributes.newSequence(Tag.SpecimenDescriptionSequence, 2);

        Attributes a1 = new Attributes();
        a1.setString(Tag.SpecimenIdentifier, VR.LO, "ID1");

        Attributes a2 = new Attributes();
        a2.setString(Tag.SpecimenShortDescription, VR.LO, "SOURCE-X");

        seq.add(a1);
        seq.add(a2);

        invokePrivateMethod(service, "mergeSpecimenDescSeqItems",
                new Class[]{Attributes.class}, attributes);

        Sequence resultSeq = attributes.getSequence(Tag.SpecimenDescriptionSequence);
        assertNotNull(resultSeq);
        assertEquals(1, resultSeq.size(), "Expected merged single sequence element");

        Attributes merged = resultSeq.get(0);

        assertEquals("ID1", merged.getString(Tag.SpecimenIdentifier));
        assertEquals("SOURCE-X", merged.getString(Tag.SpecimenShortDescription));
    }


    @Test
    void populateTagItems_removesEmptySqTag() throws Exception {

        TagItem child = new TagItem();
        child.setName("");
        child.setVr(null);
        child.setValue("");
        child.setItems(new ArrayList<>());

        TagItem parent = new TagItem();
        parent.setVr("SQ");
        parent.setItems(new ArrayList<>(List.of(child)));

        List<TagItem> removeList = new ArrayList<>();

        Map<String, String> hl7 = new HashMap<>();

        invokePrivateMethod(
                service,
                "populateTagItems",
                new Class[]{TagItem.class, Map.class, List.class, String.class},
                parent, hl7, removeList, "VSA-155"
        );

        assertTrue(removeList.contains(parent));
    }

    @Test
    void handleDateTime_truncatesForStudyDateAndTimeAndBirthTime() throws Exception {
        TagItem studyDate = new TagItem();
        studyDate.setName("StudyDate");
        studyDate.setVr("DA");
        String out1 = (String) invokePrivateMethod(service, "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                studyDate, "20220101EXTRA", new ArrayList<>());
        assertEquals("20220101", out1);

        TagItem studyTime = new TagItem();
        studyTime.setName("StudyTime");
        studyTime.setVr("TM");
        String out2 = (String) invokePrivateMethod(service, "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                studyTime, "20220101090000", new ArrayList<>());
        assertEquals("090000", out2);

        TagItem birthTime = new TagItem();
        birthTime.setName("PatientBirthTime");
        birthTime.setVr("TM");
        List<TagItem> list = new ArrayList<>();
        String out3 = (String) invokePrivateMethod(service, "handleDateTime",
                new Class[]{TagItem.class, String.class, List.class},
                birthTime, "20220101080000", list);
        assertEquals("080000", out3);
    }

    @Test
    void checkEmptySequence_returnsTrueWhenInnerItemsEmpty() throws Exception {
        TagItem inner = new TagItem();
        inner.setItems(new ArrayList<>());
        inner.setName(""); inner.setVr(""); inner.setValue("");

        TagItem seq = new TagItem();
        seq.setItems(new ArrayList<>(List.of(inner)));

        Boolean res = (Boolean) invokePrivateMethod(service, "checkEmptySequence", new Class[]{TagItem.class}, seq);
        assertTrue(res);
    }

    @Test
    void convertToTagItemList_buildsTagItems_withDynamicAndValues() throws Exception {

        Map<String,Object> tagMap1 = new HashMap<>();
        tagMap1.put(DicomEnrichmentConstants.NAME, "PatientName");
        tagMap1.put(DicomEnrichmentConstants.VR, "PN");
        tagMap1.put(DicomEnrichmentConstants.VALUE, "Test^^Name");

        Map<String,Object> tagMap2 = new HashMap<>();
        tagMap2.put(DicomEnrichmentConstants.NAME, "DynamicTag");
        tagMap2.put(DicomEnrichmentConstants.INCLUDE, DicomEnrichmentConstants.DYNAMIC_TAG);

        List<Map<String,Object>> yamlList = List.of(tagMap1, tagMap2);

        List<TagItem> items = (List<TagItem>) invokePrivateMethod(service, "convertToTagItemList",
                new Class[]{List.class, Optional.class},
                yamlList, Optional.empty());

        assertEquals(2, items.size());
        assertEquals("PatientName", items.get(0).getName());
        assertTrue(items.get(1).isDynamicInclude());
    }

    @Test
    void populatePatientName_substitutesUsingHl7Map() throws Exception {
        TagItem tagItem = new TagItem();
        tagItem.setValue("GIVEN^FAMILY");

        Map<String,String> hl7 = new HashMap<>();
        hl7.put("GIVEN", "Test");
        hl7.put("FAMILY", "User");

        invokePrivateMethod(service, "populatePatientName", new Class[]{TagItem.class, Map.class}, tagItem, hl7);

        assertEquals("Test^User", tagItem.getValue());
    }


    @Test
    void setAttributeSequence_createsEmptySequenceForSpecimenPreparation() throws Exception {

        Attributes attrs = new Attributes();

        TagItem nested = new TagItem();
        nested.setName("SpecimenIdentifier");
        nested.setVr("LO");
        nested.setValue("ID01");

        TagItem parent = new TagItem();
        parent.setName("SpecimenPreparationSequence");
        parent.setVr("SQ");
        parent.setItems(List.of(nested));

        invokePrivateMethod(service,
                "setAttributeSequence",
                new Class[]{Attributes.class, TagItem.class, int.class},
                attrs, parent, Tag.SpecimenPreparationSequence);

        Sequence seq = attrs.getSequence(Tag.SpecimenPreparationSequence);
        assertNotNull(seq, "Sequence must be created");

        assertTrue(seq.isEmpty());
    }


    @Test
    void setNestedAttributes_addsNestedAttributes() throws Exception {
        Attributes root = new Attributes();
        Sequence seq = root.newSequence(Tag.SpecimenPreparationSequence, 1);

        TagItem child = new TagItem();
        child.setName("SpecimenIdentifier");
        child.setVr("LO");
        child.setValue("PID-3");

        TagItem parent = new TagItem();
        parent.setName("SpecimenPreparationSequence");
        parent.setVr("SQ");

        invokePrivateMethod(
                service,
                "setNestedAttributes",
                new Class[]{Attributes.class, Sequence.class, TagItem.class, TagItem.class, int.class},
                root, seq, parent, child, Tag.SpecimenPreparationSequence
        );

        assertEquals(1, seq.size(), "Sequence must contain 1 nested attributes item");
        Attributes nested = seq.get(0);

        assertNotNull(nested);
    }

    @Test
    void overrideSequenceData_replacesSequenceContents() throws Exception {
        Attributes attrs = new Attributes();

        Sequence seq = attrs.newSequence(Tag.ContainerTypeCodeSequence, 2);
        seq.add(new Attributes());
        seq.add(new Attributes());

        TagItem tag = new TagItem();
        tag.setName("ContainerTypeCodeSequence");
        tag.setVr("SQ");

        Attributes nestedAttr = new Attributes();
        nestedAttr.setString(Tag.SpecimenIdentifier, VR.LO, "SAMPLE-001");

        invokePrivateMethod(
                service,
                "overrideSequenceData",
                new Class[]{Attributes.class, Attributes.class, TagItem.class},
                attrs, nestedAttr, tag
        );

        Sequence updatedSeq = attrs.getSequence(Tag.ContainerTypeCodeSequence);
        assertEquals(1, updatedSeq.size());
        assertEquals("SAMPLE-001", updatedSeq.get(0).getString(Tag.SpecimenIdentifier));
    }


    @Test
    void addDynamicContent_setsItemsOnTagItem_whenNameMatchesAndNoItems() throws Exception {

        Map<String, Object> dynamicItem = Map.of(
                "name", "DynamicRoot",
                "vr", "SQ",
                "tags", List.of(
                        Map.of("name", "ChildTag", "vr", "LO", "value", "XYZ")
                )
        );

        Map<String, Map<String, Object>> dynamicYamlCache =
                Map.of("TYPE1", Map.of("tags", List.of(dynamicItem)));

        Map.Entry<String, String> match = Map.entry("SPM-6[1]", "TYPE1");

        TagItem tagItem = new TagItem();
        tagItem.setName("DynamicRoot");
        tagItem.setVr("SQ");
        tagItem.setItems(null);

        List<TagItem> parallelItems = new ArrayList<>();

        invokePrivateMethod(
                service,
                "addDynamicContent",
                new Class[]{Map.class, Map.Entry.class, TagItem.class, List.class},
                dynamicYamlCache, match, tagItem, parallelItems
        );

        assertNotNull(tagItem.getItems(), "Items should be assigned via dynamic content");
        assertTrue(tagItem.getItems().size() > 0);
        assertTrue(parallelItems.isEmpty(), "parallelItems must remain empty in this branch");
    }

    @Test
    void addDynamicContent_addsToParallelItems_whenNameDoesNotMatch() throws Exception {

        Map<String, Object> dynamicItem = Map.of(
                "name", "DynamicRoot",
                "vr", "SQ",
                "tags", List.of(
                        Map.of("name", "OtherTag", "vr", "LO", "value", "ABC")
                )
        );

        Map<String, Map<String, Object>> dynamicYamlCache =
                Map.of("TYPE1", Map.of("tags", List.of(dynamicItem)));

        Map.Entry<String, String> match = Map.entry("SPM-6[1]", "TYPE1");

        TagItem tagItem = new TagItem();
        tagItem.setName("Tag1");
        tagItem.setVr(VR.LO.toString());
        tagItem.setItems(null);

        List<TagItem> parallelItems = new ArrayList<>();

        invokePrivateMethod(
                service,
                "addDynamicContent",
                new Class[]{Map.class, Map.Entry.class, TagItem.class, List.class},
                dynamicYamlCache, match, tagItem, parallelItems
        );

        assertTrue(parallelItems.size() > 0);
        assertNull(tagItem.getItems());
    }

    @Test
    void testPopulateValues() throws Exception {

        TagItem item1 = new TagItem();
        item1.setName("PatientName");
        item1.setVr("LO");
        item1.setValue("HL7_KEY");

        TagItem item2 = new TagItem();
        item2.setName("EthnicGroup");
        item2.setVr("LO");
        item2.setValues(List.of("Caucasian","Asian"));

        TagItem item3 = new TagItem();
        item3.setName("PatientName");
        item3.setVr("PN");
        item3.setValue("LAST^FIRST");

        TagItem item4 = new TagItem();
        item4.setName("Dummy");
        item4.setVr("LO");
        item4.setValue(null);
        item4.setDefaultValue("");

        List<TagItem> tags = new ArrayList<>(List.of(item1, item2, item3, item4));

        Map<String,String> hl7 = new HashMap<>();
        hl7.put("HL7_KEY", "HL7_VALUE");
        hl7.put("Asian", "MappedValue");
        hl7.put("LAST", "LNAME");
        hl7.put("FIRST", "FNAME");

        invokePrivateMethod(
                service,
                "populateValues",
                new Class[]{List.class, Map.class, String.class},
                tags, hl7, "VSA-155"
        );


        assertEquals("HL7_VALUE", item1.getValue());
        assertEquals("MappedValue", item2.getValue());
        assertEquals("LNAME^FNAME", item3.getValue());
        assertFalse(tags.contains(item4), "Empty tag should be removed from list");
    }

    @Test
    void getCodeSetMapping_usesCachedCodeSeqMap_whenPresent() throws Exception {
        Map<String, Object> dicomMap = Map.of("EthnicGroup", "ASIAN");

        Map<String, Map<?, ?>> cache = new HashMap<>();
        cache.put("SPM-6", dicomMap);

        String result = (String) invokePrivateMethod(
                service,
                "getCodeSetMapping",
                new Class[]{String.class, String.class, String.class, Map.class, String.class},
                "SPM-6",
                "EthnicGroup",
                "hl7_message",
                cache,
                "VSA-155"
        );

        assertEquals("ASIAN", result);
    }

    @Test
    void getCodeSetMapping_yamlStringMapping_returnsMappedValue() throws Exception {
        Map<String, Map<String, String>> yaml = Map.of(
                "SPM-6", Map.of("X", "MAPPED_STRING")
        );

        when(yamlLoader.getYamlDataMaps()).thenReturn((Map)yaml);

        String result = (String) invokePrivateMethod(
                service,
                "getCodeSetMapping",
                new Class[]{String.class, String.class, String.class, Map.class, String.class},
                "SPM-6",
                "EthnicGroup",
                "X",
                new HashMap<>(),
                "VSA-155"
        );

        assertEquals("MAPPED_STRING", result);
    }

    @Test
    void truncateCharacters_nullOrEmpty_returnsEmpty() throws Exception {

        String result = (String) invokePrivateMethod(
                service,
                "truncateCharacters",
                new Class[]{String.class},
                (String) null
        );
        assertEquals("", result);

        String result2 = (String) invokePrivateMethod(
                service,
                "truncateCharacters",
                new Class[]{String.class},
                ""
        );
        assertEquals("", result2);
    }

    @Test
    void truncateCharacters_withinLimit_returnsSameValue() throws Exception {
        String input = "Right Apex";

        String result = (String) invokePrivateMethod(
                service,
                "truncateCharacters",
                new Class[]{String.class},
                input
        );

        assertEquals(input, result);
    }

    @Test
    void truncateCharacters_exceedsLimit_truncatesByWords() throws Exception {
        String input = "ABNORMAL XRAY FINDINGS NEED REVIEW ";
        String out = (String) invokePrivateMethod(
                service,
                "truncateCharacters",
                new Class[]{String.class},
                input
        );
        assertEquals("ABNORMAL XRAY", out);
    }

}


