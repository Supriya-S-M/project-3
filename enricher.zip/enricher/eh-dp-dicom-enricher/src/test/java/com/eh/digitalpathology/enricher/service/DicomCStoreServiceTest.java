package com.eh.digitalpathology.enricher.service;


import com.eh.digitalpathology.enricher.config.PacsConfig;
import com.eh.digitalpathology.enricher.exceptions.DicomCStoreServiceException;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomOutputStream;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.*;

import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.stream.Stream;
import java.util.jar.JarOutputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class DicomCStoreServiceTest {

    private PacsConfig pacsConfig;
    private DicomCStoreService service;

    @TempDir
    Path tempDir;

    @BeforeEach
    void setUp() {
        pacsConfig = mock(PacsConfig.class);
        when(pacsConfig.getRemoteAETitle()).thenReturn("AE_TITLE");
        when(pacsConfig.getRemoteHost()).thenReturn("localhost");
        when(pacsConfig.getRemotePort()).thenReturn(104);

        service = new DicomCStoreService(pacsConfig);
    }

    @AfterEach
    void verifyTempDirCleanUp() throws IOException {
        try (Stream<Path> stream = Files.walk(tempDir)) {
            boolean cleanup = stream.anyMatch(p -> !p.equals(tempDir));
            assertFalse(cleanup, "cleanup of files not completed");
        }
    }

    @Test
    void storeEnrichedDicomInstance_successFlow() throws Exception {

        Attributes meta = new Attributes();
        meta.setString(Tag.MediaStorageSOPClassUID, VR.UI, "1.2.840.10008.5.1.4.1.1.2");
        meta.setString(Tag.MediaStorageSOPInstanceUID, VR.UI, "1.2.3.4.5.6");
        meta.setString(Tag.TransferSyntaxUID, VR.UI, "1.2.840.10008.1.2.1");
        meta.setString(Tag.ImplementationClassUID, VR.UI, "1.2.3.4.5");

        Attributes attrs = new Attributes();
        attrs.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4");

        Path tempJar = Files.createTempFile("test-classpath-", ".jar");
        try (JarOutputStream jos = new JarOutputStream(Files.newOutputStream(tempJar))) {
            //
        }

        String originalClasspath = System.getProperty("java.class.path");
        System.setProperty("java.class.path", tempJar.toString());
        Path fakeTmp = Files.createTempDirectory("mockTmp");

        try (MockedStatic<Paths> mockPaths = Mockito.mockStatic(Paths.class)) {

            mockPaths.when(() -> Paths.get("/tmp")).thenReturn(fakeTmp);

            try (MockedConstruction<DicomOutputStream> mockDicom = Mockito.mockConstruction(
                    DicomOutputStream.class,
                    (mock, ctx) -> {
                        OutputStream os = (OutputStream) ctx.arguments().get(0);
                        doAnswer(inv -> {
                            os.write("DATA".getBytes());
                            os.close();
                            return null;
                        }).when(mock).writeDataset(any(), any());
                    })) {

                Process mockProcess = mock(Process.class);
                when(mockProcess.getInputStream())
                        .thenReturn(new ByteArrayInputStream(new byte[0]));
                when(mockProcess.waitFor()).thenReturn(0);

                try (MockedConstruction<ProcessBuilder> mockPb =
                             Mockito.mockConstruction(ProcessBuilder.class, (pb, c) -> {
                                 when(pb.command(anyList())).thenReturn(pb);
                                 when(pb.redirectErrorStream(anyBoolean())).thenReturn(pb);
                                 when(pb.start()).thenReturn(mockProcess);
                             })) {

                    service.storeEnrichedDicomInstance(meta, attrs, "test-device01");

                    assertDirectoryClean(fakeTmp);
                }
            }
        } finally {
            if (originalClasspath != null)
                System.setProperty("java.class.path", originalClasspath);

            Files.deleteIfExists(tempJar);
        }
    }


    private void assertDirectoryClean(Path root) throws IOException {
        try (Stream<Path> s = Files.walk(root)) {
            long count = s.filter(p -> !p.equals(root)).count();
            assertEquals(0, count);
        }
    }

    @Test
    void writeDicomToPipe_nullInputs_throwsDicomCStoreServiceException() throws Exception {

        Method method = DicomCStoreService.class
                .getDeclaredMethod("writeDicomToPipe", Attributes.class, Attributes.class, PipedOutputStream.class);
        method.setAccessible(true);

        InvocationTargetException ex = assertThrows(InvocationTargetException.class,
                () -> method.invoke(service, null, null, new PipedOutputStream()));

        assertNotNull(ex.getCause());
        assertInstanceOf(DicomCStoreServiceException.class, ex.getCause());
    }


    @Test
    void createTemporaryFileFromPipe_readIOException() throws Exception {

        PipedInputStream pisThatThrows = new PipedInputStream() {
            @Override
            public synchronized int read(byte[] b, int off, int len) throws IOException {
                throw new IOException();
            }
        };

        Method createTemp = DicomCStoreService.class
                .getDeclaredMethod("createTemporaryFileFromPipe", PipedInputStream.class);
        createTemp.setAccessible(true);

        Path cleanup = null;

        try {
            createTemp.invoke(service, pisThatThrows);
        } catch (InvocationTargetException ex) {
            cleanup = Files.list(Paths.get(System.getProperty("java.io.tmpdir")))
                    .filter(p -> p.getFileName().toString().startsWith("eh-c-store-temp-dicom"))
                    .findFirst()
                    .orElse(null);

            assertInstanceOf(DicomCStoreServiceException.class, ex.getCause());
        }

        if (cleanup != null) {
            Files.deleteIfExists(cleanup);
        }
    }



    @Test
    void getClassPath_whenJavaClassPathIsDirectory_throwsIllegalArgument() throws Exception {
        String orig = System.getProperty("java.class.path");

        try {
            Path tempDirectory = Files.createTempDirectory("cp-test");
            System.setProperty("java.class.path", tempDirectory.toString());

            Method method = DicomCStoreService.class.getDeclaredMethod("getClassPath");
            method.setAccessible(true);

            Throwable ex = assertThrows(Throwable.class, () -> {
                try {
                    method.invoke(service);
                } catch (InvocationTargetException e) {
                    throw e.getCause();
                }
            });

            assertInstanceOf(IllegalArgumentException.class, ex);
        } finally {
            System.setProperty("java.class.path", orig);
        }
    }

    @Test
    void deleteTemporaryFile_deletesFile() throws Exception {

        Path tmp = Files.createTempFile(tempDir, "delete-test", ".tmp");
        assertTrue(Files.exists(tmp));

        Method method = DicomCStoreService.class.getDeclaredMethod("deleteTemporaryFile", Path.class);
        method.setAccessible(true);

        method.invoke(service, tmp);

        assertFalse(Files.exists(tmp), "Temp file expected to be removed.");
    }


    @Test
    void deleteDirectoryRecursively_deletesAll() throws Exception {

        Path parent = Files.createDirectory(tempDir.resolve("parent"));
        Path child = Files.createDirectory(parent.resolve("child"));
        Path f1 = Files.createFile(parent.resolve("file1.txt"));
        Path f2 = Files.createFile(child.resolve("file2.txt"));

        Method method = DicomCStoreService.class
                .getDeclaredMethod("deleteDirectoryRecursively", Path.class);
        method.setAccessible(true);

        method.invoke(service, parent);

        assertFalse(Files.exists(f1));
        assertFalse(Files.exists(f2));
        assertFalse(Files.exists(child));
        assertFalse(Files.exists(parent));
    }

    @Test
    void cleanUpTemporaryFiles_deleteFailure_logsError() throws Exception {

        Path failingFile = mock(Path.class);

        try (MockedStatic<Files> filesMock = mockStatic(Files.class)) {

            filesMock.when(() -> Files.walk(tempDir))
                    .thenReturn(Stream.of(tempDir, failingFile));

            filesMock.when(() -> Files.isDirectory(tempDir)).thenReturn(true);
            filesMock.when(() -> Files.isDirectory(failingFile)).thenReturn(false);
            filesMock.when(() -> Files.deleteIfExists(failingFile))
                    .thenThrow(new IOException());

            filesMock.when(() -> Files.exists(failingFile)).thenReturn(true);

            Method method = DicomCStoreService.class.getDeclaredMethod("cleanUpTemporaryFiles");
            method.setAccessible(true);

            assertDoesNotThrow(() -> method.invoke(service));
        }
    }

    @Test
    void cleanUpTemporaryFiles_removesFilesAndDirectories() throws Exception {

        Path temp = Files.createTempDirectory("mock-root");

        Path dir = Files.createDirectory(temp.resolve("storescu-dir"));
        Path nested = Files.createDirectory(dir.resolve("nested"));
        Path file = Files.createFile(dir.resolve("file.txt"));
        Path dcm = Files.createFile(temp.resolve("data.dcm"));

        assertTrue(Files.exists(dir));
        assertTrue(Files.exists(nested));
        assertTrue(Files.exists(file));
        assertTrue(Files.exists(dcm));

        try (MockedStatic<Paths> mock = mockStatic(Paths.class)) {
            mock.when(() -> Paths.get("/tmp")).thenReturn(temp);
            Method method = DicomCStoreService.class.getDeclaredMethod("cleanUpTemporaryFiles");
            method.setAccessible(true);
            assertDoesNotThrow(() -> method.invoke(service));
        }

        assertDirectoryClean(temp);
    }
}







