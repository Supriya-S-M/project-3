package com.eh.digitalpathology.enricher.utils;

import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import com.eh.digitalpathology.enricher.model.DicomDirDocument;
import org.dcm4che3.data.*;
import org.dcm4che3.io.DicomInputStream;
import org.dcm4che3.io.DicomOutputStream;
import org.dcm4che3.util.UIDUtils;
import org.junit.jupiter.api.Test;
import org.mockito.MockedConstruction;
import org.mockito.Mockito;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class DicomDirUtilsTest {

    @Test
    void testModifyStudyIdInDicomDir_UpdatesStudyRecordSuccessfully() throws Exception {

        DicomDirDocument mockDoc = Mockito.mock(DicomDirDocument.class);

        Attributes fmi = new Attributes();
        fmi.setString(Tag.MediaStorageSOPClassUID, VR.UI, UID.MediaStorageDirectoryStorage);
        fmi.setString(Tag.MediaStorageSOPInstanceUID, VR.UI, UIDUtils.createUID());
        fmi.setString(Tag.TransferSyntaxUID, VR.UI, UID.ExplicitVRLittleEndian);

        Attributes dicomDirData = new Attributes();

        Sequence seq = dicomDirData.newSequence(Tag.DirectoryRecordSequence, 1);

        Attributes studyRecord = new Attributes();
        studyRecord.setString(Tag.DirectoryRecordType, VR.CS, "STUDY");
        studyRecord.setString(Tag.StudyInstanceUID, VR.UI, "1.3.5.111666");

        seq.add(studyRecord);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (DicomOutputStream dos = new DicomOutputStream(baos, UID.ExplicitVRLittleEndian)) {
            dos.writeDataset(fmi, dicomDirData);
        }

        when(mockDoc.getDicomDirFile()).thenReturn(baos.toByteArray());

        String newStudyId = "1.3.6.7.111222237";

        byte[] updatedBytes = DicomDirUtils.modifyStudyIdInDicomDir(mockDoc, newStudyId);

        Attributes updatedDataset;
        try (DicomInputStream dis = new DicomInputStream(new ByteArrayInputStream(updatedBytes))) {
            updatedDataset = dis.readDataset(-1);
        }

        Sequence updatedSeq = updatedDataset.getSequence(Tag.DirectoryRecordSequence);
        assertNotNull(updatedSeq);
        assertEquals(1, updatedSeq.size());

        Attributes updatedRecord = updatedSeq.get(0);

        assertEquals("STUDY", updatedRecord.getString(Tag.DirectoryRecordType));
        assertEquals(newStudyId, updatedRecord.getString(Tag.StudyInstanceUID));
    }

    @Test
    void testModifyStudyIdInDicomDir_ReadIOException_ThrowsCustomException() {
        DicomDirDocument mockDoc = Mockito.mock(DicomDirDocument.class);

        when(mockDoc.getDicomDirFile()).thenReturn(new byte[]{0x00, 0x01, 0x02});

        DicomEnrichmentServiceException ex = assertThrows(
                DicomEnrichmentServiceException.class,
                () -> DicomDirUtils.modifyStudyIdInDicomDir(mockDoc, "1.2.3")
        );

        assertTrue(ex.getMessage().startsWith("Error while reading dicomdir bytes ::"));
    }


    @Test
    void testModifyStudyIdInDicomDir_WriteIOException_ThrowsCustomException() throws Exception {

        DicomDirDocument mockDoc = Mockito.mock(DicomDirDocument.class);

        Attributes attrs = new Attributes();
        attrs.setString(Tag.DirectoryRecordType, VR.CS, "STUDY1.3.5.111666");

        Attributes fmi = new Attributes();
        fmi.setString(Tag.TransferSyntaxUID, VR.UI, UID.ExplicitVRLittleEndian);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (DicomOutputStream dos = new DicomOutputStream(baos, UID.ExplicitVRLittleEndian)) {
            dos.writeDataset(fmi, attrs);
        }

        when(mockDoc.getDicomDirFile()).thenReturn(baos.toByteArray());

        try (MockedConstruction<DicomOutputStream> mocked = Mockito.mockConstruction(
                DicomOutputStream.class,
                (mock, context) -> {
                    Mockito.doThrow(new IOException("forced write failure"))
                            .when(mock).writeDataset(Mockito.any(), Mockito.any());
                })) {

            DicomEnrichmentServiceException ex = assertThrows(
                    DicomEnrichmentServiceException.class,
                    () -> DicomDirUtils.modifyStudyIdInDicomDir(mockDoc, "1.3.6.7.111222237")
            );

            assertTrue(ex.getMessage().startsWith("Error while writing dicom dir ::"));
        }
    }


}
