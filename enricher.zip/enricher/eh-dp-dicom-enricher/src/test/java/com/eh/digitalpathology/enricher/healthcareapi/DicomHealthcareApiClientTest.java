package com.eh.digitalpathology.enricher.healthcareapi;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.exceptions.HealthcareApiException;
import com.eh.digitalpathology.enricher.service.DatabaseService;
import com.eh.digitalpathology.enricher.utils.GCPUtils;
import com.google.common.util.concurrent.MoreExecutors;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomOutputStream;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import java.io.*;
import java.util.concurrent.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DicomHealthcareApiClientTest {

    @Mock
    private GcpConfig mockGcpConfig;
    @Mock
    DatabaseService databaseService;
    @Mock
    private StatusLine mockStatusLine;
    @Mock
    private CloseableHttpClient mockHttpClient;
    @Mock
    private CloseableHttpResponse mockHttpResponse;

    private DicomHealthcareApiClient dicomHealthcareApiClient;

    @BeforeEach
    void setUp() {
        dicomHealthcareApiClient = new DicomHealthcareApiClient(mockGcpConfig,databaseService);
        dicomHealthcareApiClient.executorService = MoreExecutors.newDirectExecutorService();

    }

    @Test
    void testStoreDicomInstances_SuccessFlow() throws Exception {

        Attributes dicomMeta = new Attributes();
        dicomMeta.setString(Tag.SOPClassUID, VR.UI, "1.2.840.10008.5.1.4.1.1.2");
        dicomMeta.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4.5");

        Attributes dcmAttributes = new Attributes();
        dcmAttributes.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4.5");
        dcmAttributes.setString(Tag.PatientID, VR.LO, "P123");

        when(mockGcpConfig.getDicomWebUrl())
                .thenReturn("https://health.googleapis.com/v1/projects/demo");

        when(databaseService.getDicomStroreUrl("test-device01"))
                .thenReturn("/datasets/demo-dataset/dicomStores/demo-store");

        try (MockedStatic<HttpClients> mockedHttpClients = mockStatic(HttpClients.class);
             MockedStatic<GCPUtils> mockedGCPUtils = mockStatic(GCPUtils.class);
             MockedConstruction<DicomOutputStream> mockedDicomOutputStream =
                     mockConstruction(DicomOutputStream.class, (mock, context) -> {
                         doNothing().when(mock).writeDataset(any(), any());
                         doNothing().when(mock).writeFileMetaInformation(any());
                         doNothing().when(mock).close();
                     })
        ) {

            mockedGCPUtils.when(() -> GCPUtils.getAccessToken(mockGcpConfig)).thenReturn("test-token");

            HttpClientBuilder builder = mock(HttpClientBuilder.class);
            when(builder.setDefaultRequestConfig(any())).thenReturn(builder);
            when(builder.build()).thenReturn(mockHttpClient);
            mockedHttpClients.when(HttpClients::custom).thenReturn(builder);

            when(mockStatusLine.getStatusCode()).thenReturn(HttpStatus.SC_OK);
            when(mockHttpResponse.getStatusLine()).thenReturn(mockStatusLine);
            when(mockHttpClient.execute(any(HttpPost.class))).thenReturn(mockHttpResponse);

            assertDoesNotThrow(() ->
                    dicomHealthcareApiClient.storeEnrichedDicomInstance(
                            dicomMeta, dcmAttributes, "test-device01")
            );

            verify(mockHttpClient, times(1)).execute(any(HttpPost.class));
        }
    }


    @Test
    void testStoreDicomInstances_HttpFailure_ThrowsHealthcareApiException()  {

        Attributes meta = new Attributes();
        meta.setString(Tag.PatientID, VR.LO, "P123");

        Attributes attrs = new Attributes();
        attrs.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4");

        when(mockGcpConfig.getDicomWebUrl()).thenReturn("https://health.googleapis.com/v1/projects/demo");

        try (MockedStatic<GCPUtils> mocked = mockStatic(GCPUtils.class)) {
            mocked.when(() -> GCPUtils.getAccessToken(mockGcpConfig)).thenReturn("dummy-token");

            HealthcareApiException ex = assertThrows(
                    HealthcareApiException.class,
                    () -> dicomHealthcareApiClient.storeEnrichedDicomInstance(meta, attrs, "Dev123")
            );

            assertTrue(ex.getMessage().contains("An error occurred while uploading"));
        }
    }

    @Test
    void testStoreDicomInstances_IOExceptionDuringHttpExecution() throws Exception {

        Attributes dicomMeta = new Attributes();
        dicomMeta.setString(Tag.SOPClassUID, VR.UI, "1.2.840.10008.5.1.4.1.1.2");
        dicomMeta.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4.5");

        Attributes dcmAttributes = new Attributes();
        dcmAttributes.setString(Tag.SOPInstanceUID, VR.UI, "1.2.3.4.5");
        dcmAttributes.setString(Tag.PatientID, VR.LO, "P123");

        when(mockGcpConfig.getDicomWebUrl()).thenReturn("https://health.googleapis.com/v1/projects/demo");
        when(databaseService.getDicomStroreUrl("test-device01")).thenReturn("/datasets/demo-dataset/dicomStores/demo-store");

        try (
                MockedStatic<HttpClients> mockedHttpClients = mockStatic(HttpClients.class);
                MockedStatic<GCPUtils> mockedGCPUtils = mockStatic(GCPUtils.class);
                MockedConstruction<DicomOutputStream> mockedDicomOutputStream =
                        mockConstruction(DicomOutputStream.class, (mock, context) -> {
                            doNothing().when(mock).writeDataset(any(), any());
                            doNothing().when(mock).close();
                        })
        ) {
            mockedGCPUtils.when(() -> GCPUtils.getAccessToken(mockGcpConfig)).thenReturn("dummy-token");

            HttpClientBuilder mockBuilder = mock(HttpClientBuilder.class);
            when(mockBuilder.setDefaultRequestConfig(any())).thenReturn(mockBuilder);
            when(mockBuilder.build()).thenReturn(mockHttpClient);
            mockedHttpClients.when(HttpClients::custom).thenReturn(mockBuilder);

            when(mockHttpClient.execute(any(HttpPost.class))).thenThrow(new IOException());

            HealthcareApiException exception = assertThrows(HealthcareApiException.class, () ->
                    dicomHealthcareApiClient.storeEnrichedDicomInstance(dicomMeta, dcmAttributes, "Dev123")
            );

            assertTrue(exception.getMessage().contains("An error occurred while uploading the enriched DICOM "));
            assertNotNull(exception.getCause());

        }
    }

    @Test
    void testShutdownExecutor_WhenNotTerminated_ShouldInvokeShutdownNow() throws InterruptedException {

        ExecutorService mockExecutor = mock(ExecutorService.class);
        when(mockExecutor.awaitTermination(anyLong(), any())).thenReturn(false);
        dicomHealthcareApiClient.executorService = mockExecutor;

        dicomHealthcareApiClient.shutdownExecutor();
        verify(mockExecutor).shutdown();
        verify(mockExecutor).awaitTermination(30, TimeUnit.SECONDS);
        verify(mockExecutor).shutdownNow();
    }

    @Test
    void testShutdownExecutor_WhenInterrupted_ShouldInvokeShutdownNow() throws InterruptedException {

        ExecutorService mockExecutor = mock(ExecutorService.class);
        when(mockExecutor.awaitTermination(anyLong(), any())).thenThrow(new InterruptedException());
        dicomHealthcareApiClient.executorService = mockExecutor;
        boolean wasInterruptedBefore = Thread.currentThread().isInterrupted();

        dicomHealthcareApiClient.shutdownExecutor();

        verify(mockExecutor).shutdown();
        verify(mockExecutor).shutdownNow();
        assertTrue(Thread.interrupted());
        if (wasInterruptedBefore) Thread.currentThread().interrupt();
    }

}
