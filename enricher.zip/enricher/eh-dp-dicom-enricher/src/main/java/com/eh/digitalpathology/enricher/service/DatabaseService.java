package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.dbclient.DBRestClient;
import com.eh.digitalpathology.enricher.exceptions.Hl7MessageException;
import com.eh.digitalpathology.enricher.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RefreshScope
public class DatabaseService {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseService.class);
    private final DBRestClient dbRestClient;

    @Value("${db.connector.enrich.instance}")
    String instanceInfoURL;

    @Value("${db.connector.enrich.status}")
    String instanceEnrichmentStatusURL;

    public DatabaseService(DBRestClient dbRestClient) {
        this.dbRestClient = dbRestClient;
    }

    public EnrichedResponse fetchDataForEnrichment(CaseInfo caseInfo) {
        logger.info("fetchDataForEnrichment :: Fetching Intermediate DICOM file & HL7 parsed data for enrichment :: {}", caseInfo.getSopInstanceUid());
        HttpHeaders headers = setHttpHeaders(DicomEnrichmentConstants.DICOM_ENRICHMENT);
        try {
            return dbRestClient.exchange(HttpMethod.GET, instanceInfoURL, caseInfo, new ParameterizedTypeReference<ApiResponse<EnrichedResponse>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    private static HttpHeaders setHttpHeaders(String serviceName) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Service-Name", serviceName);
        return headers;
    }

    public String updateEnrichmentStatus(EnrichInstance enrichInstance) {

        HttpHeaders headers = setHttpHeaders(DicomEnrichmentConstants.DICOM_ENRICHMENT);
        try {
            return dbRestClient.exchange(HttpMethod.PUT, instanceEnrichmentStatusURL, enrichInstance, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::status).block();

        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    public String updateStatus(BarcodeInstanceRequest barcodeInstanceRequest) {

        HttpHeaders headers = setHttpHeaders(DicomEnrichmentConstants.COMMITTED);

        try {
            return dbRestClient.exchange(HttpMethod.PUT, "dicom/status/instances", barcodeInstanceRequest, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, httpHeaders -> httpHeaders.putAll(headers))
                    .map(ApiResponse::status).block();

        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    public DicomDirDocument fetchMetaData( String seriesId) {
        logger.info("fetchMetaData :: seriesId :: {}", seriesId);
        String instanceUrl = "dicom/dicomdir/" + seriesId;
        try {
            return dbRestClient.exchange(HttpMethod.GET, instanceUrl, null, new ParameterizedTypeReference<ApiResponse<DicomDirDocument>>() {
                    }, null)
                    .map(ApiResponse::content).block();

        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }

    }

    public List<InstancesMeta> fetchInstancesOfSeries( String seriesId)  {
        logger.info("fetchInstancesMetaDataBySeriesId :: seriesId :: {}", seriesId);
        String url = "instances/" + seriesId;
        try {
            return dbRestClient.exchange(HttpMethod.GET, url, null, new ParameterizedTypeReference<ApiResponse<List<InstancesMeta>>>() {
                    }, null)
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    public String getStatusOfInstance(String seriesId, String instanceId)  {
        logger.info("fetchStatusOfInstance :: series id :: {}, instance id :: {} ",  seriesId, instanceId);
        String url = "instances/status/" + seriesId + "/" + instanceId;
        try {
            return dbRestClient.exchange(HttpMethod.GET, url, null, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, null)
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }

    }

    public void updateDicomDir(DicomDirDocument dicomDirDocument){
        try{
            String response =  dbRestClient.exchange( HttpMethod.PUT, "dicom/dicomdir", dicomDirDocument, new ParameterizedTypeReference< ApiResponse< String > >( ) {
            }, null ).map( ApiResponse::status ).block();
            logger.info( "updateDicomDir :: response from database:: {} ", response );
        }catch ( Exception ex ) {
            throw new Hl7MessageException( DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage( ) );
        }
    }

    public void saveQidoRsResponse ( int status, String body, String seriesUid ) {
        try{
            String response =  dbRestClient.exchange( HttpMethod.POST, "dicom/qidors", new QidoResponse( seriesUid, body, status ), new ParameterizedTypeReference< ApiResponse< String > >( ) {
            }, null ).map( ApiResponse::status ).block();
            logger.info( " saveQidoRsResponse :: response from database:: {} ", response );
        }catch ( Exception ex ) {
            throw new Hl7MessageException( DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage( ) );
        }
    }

    public String checkForSopPresence(List<String> sopInstanceIds) {
        try {
            logger.info("checkForSopPresence :: instance ids :: {} ", sopInstanceIds);
            List<String> seriesIds = dbRestClient.exchange(HttpMethod.POST, "series/instance", sopInstanceIds, new ParameterizedTypeReference<ApiResponse<List<String>>>() {
            }, null).map(ApiResponse::content).block();

            logger.info("checkForSopPresence :: series ids received:: {} ", seriesIds);
            if (seriesIds == null || seriesIds.isEmpty()) {
                logger.warn("No series ids found for given SOP instance ids.");
                return null;
            }
            Set<String> uniqueSeriesIds = new HashSet<>(seriesIds);
            if (uniqueSeriesIds.size() == 1) {
                return uniqueSeriesIds.iterator().next();
            } else {
                logger.warn("Multiple different series ids found for given sop instance ids: {}", uniqueSeriesIds);
                return null;
            }
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    public List<String> fetchInstancesByRequestId(String requestId) {
        logger.info("fetchInstancesByRequestId :: requestId :: {}", requestId);
        String url = "instances/request/" + requestId;
        try {
            return dbRestClient.exchange(HttpMethod.GET, url, null, new ParameterizedTypeReference<ApiResponse<List<String>>>() {
                    }, null)
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }

    public String getDicomStroreUrl ( String deviceSerialNumber ) {
        String url = "scanner/" + deviceSerialNumber;
        try {
            return dbRestClient.exchange(HttpMethod.GET, url, null, new ParameterizedTypeReference<ApiResponse<String>>() {
                    }, null)
                    .map(ApiResponse::content).block();
        } catch (Exception ex) {
            throw new Hl7MessageException(DicomEnrichmentConstants.INVALID_ERROR, ex.getMessage());
        }
    }
}