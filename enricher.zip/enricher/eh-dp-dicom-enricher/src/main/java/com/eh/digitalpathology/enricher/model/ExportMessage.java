package com.eh.digitalpathology.enricher.model;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public record ExportMessage(String barcode,String seriesId, String studyId, int instanceCount, List<String> instances,
                            byte[] dicomDirBytes, String dicomWebUrl) {

    @Override
    public boolean equals ( Object o ) {
        if ( o == null || getClass( ) != o.getClass( ) ) return false;
        ExportMessage that = (ExportMessage) o;
        return instanceCount == that.instanceCount && Objects.equals( studyId, that.studyId ) && Objects.equals( seriesId, that.seriesId ) && Objects.deepEquals( dicomDirBytes, that.dicomDirBytes ) && Objects.equals( instances, that.instances );
    }

    @Override
    public int hashCode() {
        return Objects.hash(seriesId, studyId, instanceCount, instances, Arrays.hashCode(dicomDirBytes));
    }

    @Override
    public String toString() {
        return "ExportMessage{" +
                "seriesId='" + seriesId + '\'' +
                ", studyId='" + studyId + '\'' +
                ", instanceCount='" + instanceCount + '\'' +
                ", instances='" + instances +
                ", dicomDirBytes=" + Arrays.toString(dicomDirBytes) +
                ", dicomWebUrl='" + dicomWebUrl + '\'' +
                '}';
    }

}

