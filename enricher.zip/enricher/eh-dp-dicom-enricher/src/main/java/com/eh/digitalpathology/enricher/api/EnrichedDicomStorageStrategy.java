package com.eh.digitalpathology.enricher.api;

import org.dcm4che3.data.Attributes;
import com.eh.digitalpathology.enricher.exceptions.*;

public interface EnrichedDicomStorageStrategy {
    void storeEnrichedDicomInstance(Attributes dicomFileMetadata, Attributes dcmAttributes, String deviceSerialNumber) throws DicomStorageException;
}