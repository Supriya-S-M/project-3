package com.eh.digitalpathology.enricher.model;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public record StorageCommitment (String _id, String seriesInstanceUid, String studyInstanceUid, List<String> instances, byte[] dicomDirFile) {

    @Override
    public boolean equals ( Object o ) {
        if ( o == null || getClass( ) != o.getClass( ) ) return false;
        StorageCommitment that = (StorageCommitment) o;
        return Objects.equals( _id, that._id ) && Objects.deepEquals( dicomDirFile, that.dicomDirFile ) && Objects.equals( instances, that.instances ) && Objects.equals( studyInstanceUid, that.studyInstanceUid ) && Objects.equals( seriesInstanceUid, that.seriesInstanceUid );
    }

    @Override
    public int hashCode() {
        return Objects.hash(_id, seriesInstanceUid, studyInstanceUid, instances, Arrays.hashCode(dicomDirFile));
    }

    @Override
    public String toString() {
        return "StorageCommitment{" +
                "_id='" + _id + '\'' +
                ", seriesInstanceUid='" + seriesInstanceUid + '\'' +
                ", studyInstanceUid='" + studyInstanceUid + '\'' +
                ", instances='" + instances +
                ", dicomDirFile=" + Arrays.toString(dicomDirFile) +
                '}';
    }
}

