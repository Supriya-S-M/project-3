package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.api.EnrichedDicomStorageStrategy;
import com.eh.digitalpathology.enricher.config.PacsConfig;
import com.eh.digitalpathology.enricher.exceptions.DicomCStoreServiceException;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.io.DicomOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class DicomCStoreService implements EnrichedDicomStorageStrategy {
    private static final Logger LOGGER = LoggerFactory.getLogger(DicomCStoreService.class);
    private final PacsConfig pacsConfig;

    @Autowired
    public DicomCStoreService(PacsConfig pacsConfig) {
        this.pacsConfig = pacsConfig;
    }

    public void storeEnrichedDicomInstance(Attributes dicomFileMetadata, Attributes dcmAttributes, String deviceSerialNumber) throws DicomCStoreServiceException {
        LOGGER.debug("storeEnrichedDicomInstance:: the method is being called :: {}", deviceSerialNumber);
        try (PipedOutputStream pos = new PipedOutputStream();
             PipedInputStream pis = new PipedInputStream(pos, 1048576)) {
            Thread writerThread = new Thread(() -> {
                try {
                    writeDicomToPipe(dicomFileMetadata, dcmAttributes, pos);
                } catch (DicomCStoreServiceException e) {
                    LOGGER.error("storeEnrichedDicomInstance:: Failed to write DICOM data to pipe", e);
                }
            });
            writerThread.start();
            Path tempFilePath = createTemporaryFileFromPipe(pis);
            String dicomFilePath = tempFilePath.toAbsolutePath().toString();
            LOGGER.info("storeEnrichedDicomInstance:: temp file has been created :: {}", dicomFilePath);
            String sopInstanceUID = dcmAttributes.getString(Tag.SOPInstanceUID);
            performCStore(dicomFilePath, sopInstanceUID);
            deleteTemporaryFile(tempFilePath);
            writerThread.join();
        } catch (IOException e) {
            throw new DicomCStoreServiceException("Failed to create pipe streams for DICOM data", e);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new DicomCStoreServiceException("Failed to create pipe streams for DICOM data", ex);
        } finally {
            cleanUpTemporaryFiles();
        }
    }

    private void writeDicomToPipe(Attributes dicomFileMetadata, Attributes dcmAttributes, PipedOutputStream pos) throws DicomCStoreServiceException {
        if (dicomFileMetadata == null || dcmAttributes == null) {
            LOGGER.error("writeDicomToPipe :: dicomFileMetadata or dcmAttributes is null");
            throw new DicomCStoreServiceException("DICOM metadata or attributes are null");
        }
        try (DicomOutputStream dicomOutputStream = new DicomOutputStream(pos, "")) {
            dicomOutputStream.writeDataset(dicomFileMetadata, dcmAttributes);
            LOGGER.info("writeDicomToPipe :: DICOM dataset written to pipe");
        } catch (IOException e) {
            throw new DicomCStoreServiceException("Failed to write DICOM dataset to pipe", e);
        }
    }

    private Path createTemporaryFileFromPipe(PipedInputStream pis) throws DicomCStoreServiceException {
        Path tempFilePath;
        try {
            tempFilePath = Files.createTempFile("eh-c-store-temp-dicom", ".dcm");
            try (OutputStream fileOutputStream = Files.newOutputStream(tempFilePath)) {
                byte[] buffer = new byte[1048576];
                int bytesRead;
                while ((bytesRead = pis.read(buffer)) != -1) {
                    fileOutputStream.write(buffer, 0, bytesRead);
                }
            }
            LOGGER.info("createTemporaryFileFromPipe :: Temporary DICOM file created from pipe: {}", tempFilePath.toAbsolutePath());
        } catch (IOException e) {
            throw new DicomCStoreServiceException("Failed to create temporary file from pipe", e);
        }
        return tempFilePath;
    }

    private void performCStore(String dicomFilePath, String sopInstanceUID) throws DicomCStoreServiceException, IOException {
        String command = String.format("%s@%s:%d", pacsConfig.getRemoteAETitle(), pacsConfig.getRemoteHost(), pacsConfig.getRemotePort());
        String[] args = {"-c", command, dicomFilePath};

        LOGGER.info("performCStore :: Executing C-Store SCU command for SOPInstanceUID: {}", sopInstanceUID);
        LOGGER.info("performCStore :: C-Store SCU command: {}", command);
        LOGGER.info("performCStore :: Temporary DICOM file path for C-Store operation: {}", dicomFilePath);
        String classpath = getClassPath();
        List<String> commands = new ArrayList<>();
        commands.add("java");
        commands.add("-cp");
        commands.add(classpath);
        commands.add("org.dcm4che3.tool.storescu.StoreSCU");
        commands.addAll(Arrays.asList(args));

        // Build the command to run the StoreSCU.main method
        ProcessBuilder processBuilder = new ProcessBuilder(commands);
        processBuilder.redirectErrorStream(true);
        // Start the process
        Process process = processBuilder.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Do nothing (consume output without printing)
                if (line.isEmpty()) {
                    LOGGER.info("performCStore :: Line is empty while reading the file.");
                }
            }
            // Wait for the process to complete
            int exitCode = process.waitFor();
            LOGGER.error("performCStore :: Process exited with code: {}", exitCode);
            // Handle the exit code or any exceptions here
            if (exitCode == 2) {
                throw new DicomCStoreServiceException(String.format("C-Store operation for SOP Instance UID %s failed", sopInstanceUID));
            }
        } catch (IOException | InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new DicomCStoreServiceException("C-Store operation failed for sop instance uid " + sopInstanceUID, ex);
        }

    }

    private String getClassPath() throws IOException {
        String javaClassPath = System.getProperty("java.class.path");
        File jarFile = new File(javaClassPath);
        if (!jarFile.exists() || !jarFile.isFile()) {
            throw new IllegalArgumentException("Unable to determine classpath dynamically");
        }
        File tempDir = Files.createTempDirectory("storescu-deps").toFile();
        try (JarFile jar = new JarFile(jarFile)) {
            Enumeration<JarEntry> entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                if (entry.getName().startsWith("BOOT-INF/lib/") && entry.getName().endsWith(".jar")) {
                    File file = new File(tempDir, entry.getName().substring("BOOT-INF/lib/".length()));
                    if (!file.getParentFile().exists()) {
                        Files.createDirectories(file.getParentFile().toPath());
                    }
                    try (InputStream in = jar.getInputStream(entry);
                         OutputStream out = new FileOutputStream(file)) {
                        byte[] buffer = new byte[1024];
                        int len;
                        while ((len = in.read(buffer)) != -1) {
                            out.write(buffer, 0, len);
                        }
                    }
                }
            }
        }
        List<String> jarFiles = Arrays.stream(Objects.requireNonNull(tempDir.listFiles()))
                .filter(file -> file.getName().endsWith(".jar")).map(File::getAbsolutePath)
                .collect(Collectors.toList());
        jarFiles.add(jarFile.getAbsolutePath());
        return String.join(File.pathSeparator, jarFiles);
    }

    private void deleteTemporaryFile(Path tempFilePath) {
        try {
            Files.deleteIfExists(tempFilePath);
            LOGGER.info("deleteTemporaryFile :: Temporary DICOM file deleted: {}", tempFilePath.toAbsolutePath());
        } catch (IOException e) {
            LOGGER.error("deleteTemporaryFile :: Failed to delete temporary DICOM file: {}", tempFilePath.toAbsolutePath(), e);
        }
    }

    private void cleanUpTemporaryFiles() {
        Path tempDir = Paths.get("/tmp");
        try (Stream<Path> stream = Files.walk(tempDir)) {
            stream.filter(path -> !path.equals(tempDir))
                    .filter(path -> path.getFileName().toString().startsWith("storescu-") || path.getFileName().toString().endsWith(".dcm"))
                    .sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            if (Files.isDirectory(path)) {
                                deleteDirectoryRecursively(path);
                            } else {
                                Files.deleteIfExists(path);
                            }
                            Files.deleteIfExists(path);
                            LOGGER.info("cleanUpTemporaryFiles:: Deleted temporary file: {}", path);
                        } catch (IOException e) {
                            LOGGER.error("cleanUpTemporaryFiles :: Failed to delete temporary file: {}", path, e);
                        }
                    });
        } catch (IOException e) {
            LOGGER.error("cleanUpTemporaryFiles :: Failed to clean up temporary files", e);
        }
    }

    private void deleteDirectoryRecursively(Path path) throws IOException {
        try (Stream<Path> stream = Files.walk(path)) {
            stream.sorted(Comparator.reverseOrder())
                    .forEach(p -> {
                        try {
                            Files.deleteIfExists(p);
                        } catch (IOException e) {
                            LOGGER.error("deleteDirectoryRecursively :: Failed to delete file: {}", p, e);
                        }
                    });
        }
    }
}
