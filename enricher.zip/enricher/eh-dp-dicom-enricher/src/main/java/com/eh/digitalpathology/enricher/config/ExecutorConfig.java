package com.eh.digitalpathology.enricher.config;


import io.micrometer.core.instrument.util.NamedThreadFactory;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Configuration
public class ExecutorConfig {

    private static final Logger log = LoggerFactory.getLogger( ExecutorConfig.class );

    private ScheduledExecutorService stgcmtExecutorService;
    private ScheduledExecutorService dicomTrackerExecutorService;
    private ExecutorService exportExecutorService;
    private ExecutorService processingExecutorService;

    @Bean( name = "stgcmtExecutorService" )
    public ScheduledExecutorService stgcmtExecutorService ( ) {
        this.stgcmtExecutorService = Executors.newScheduledThreadPool( Math.max( 4, Runtime.getRuntime( ).availableProcessors( ) ), new NamedThreadFactory( "stgcmt-exec-", false ) );
        return this.stgcmtExecutorService;
    }

    @Bean( name = "dicomTrackerExecutorService" )
    public ScheduledExecutorService dicomTrackerExecutorService ( ) {
        this.dicomTrackerExecutorService = Executors.newScheduledThreadPool( Runtime.getRuntime( ).availableProcessors( ) , new NamedThreadFactory( "tracker-exec-", false ) );
        return this.dicomTrackerExecutorService;
    }

    @Bean(name = "processingExecutorService")
    public ExecutorService processingExecutorService() {
        this.processingExecutorService = Executors.newFixedThreadPool(Runtime.getRuntime( ).availableProcessors( ), new NamedThreadFactory("processing-exec-", false));
        return this.processingExecutorService;
    }

    @Bean( name = "exportExecutorService" )
    public ExecutorService exportExecutorService ( ) {
        this.exportExecutorService = Executors.newFixedThreadPool( Runtime.getRuntime( ).availableProcessors( ), new NamedThreadFactory( "export-exec-" , false) );
        return this.exportExecutorService;

    }


    @PreDestroy
    public void shutdownExecutors ( ) {

        shutdownExecutor( stgcmtExecutorService, "Stgcmt ExecutorService" );
        shutdownExecutor( dicomTrackerExecutorService, "Dicom Tracker ExecutorService" );
        shutdownExecutor( exportExecutorService, "Export  ExecutorService" );
        shutdownExecutor( processingExecutorService, "Processing Executor Service" );

    }

    private void shutdownExecutor ( ExecutorService executor, String name ) {
        if ( executor != null ) {
            executor.shutdown( );
            try {
                if ( !executor.awaitTermination( 60, TimeUnit.SECONDS ) ) {
                    executor.shutdownNow( );
                    if ( !executor.awaitTermination( 60, TimeUnit.SECONDS ) ) {
                        log.error( "{} did not terminate", name );
                    }
                }
            } catch ( InterruptedException ex ) {
                executor.shutdownNow( );
                Thread.currentThread( ).interrupt( );
            }
        }
    }


    static final class NamedThreadFactory implements ThreadFactory {
        private final AtomicInteger index = new AtomicInteger( 1 );
        private final String prefix;
        private final boolean daemon;

        NamedThreadFactory ( String prefix, boolean daemon ) {
            this.prefix = prefix;
            this.daemon = daemon;
        }

        @Override
        public Thread newThread ( Runnable r ) {
            Thread t = new Thread( r, prefix + index.getAndIncrement( ) );
            t.setDaemon( daemon );
            t.setPriority( Thread.NORM_PRIORITY );
            return t;
        }
    }


}


