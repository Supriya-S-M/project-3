package com.eh.digitalpathology.enricher.utils;

import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.LoaderOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

public class YamlReader {

    private static final Logger log = LoggerFactory.getLogger(YamlReader.class);

    private YamlReader(){}

    public static Map<String, Object> readYaml(String fileName) throws DicomEnrichmentServiceException{
        LoaderOptions loaderOptions = new LoaderOptions();
        Yaml yaml = new Yaml(loaderOptions);
        log.info("readYaml :: filename :: {}", fileName);
        try(InputStream inputStream = Files.newInputStream(Paths.get(fileName))){
            return yaml.load(inputStream);
        } catch (IOException ex){
            throw new DicomEnrichmentServiceException("Unable to read yaml file :: " + ex.getMessage());
        }
    }
}
