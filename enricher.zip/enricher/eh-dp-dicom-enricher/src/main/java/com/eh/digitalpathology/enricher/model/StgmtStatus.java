package com.eh.digitalpathology.enricher.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record StgmtStatus(String cmtReqId,String seriesInstanceUid, String status) {}