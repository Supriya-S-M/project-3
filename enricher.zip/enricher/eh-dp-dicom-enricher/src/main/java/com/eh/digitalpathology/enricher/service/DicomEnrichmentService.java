/**
 * DicomEnrichmentService is a class which processes the hl7 message received in pub sub notification
 * It also retrieves corresponding DICOM files, enriches them based on parsed HL7 segments,
 * and stores the enriched DICOM files into the final DICOM store.
 * Author: Pooja Kamble
 * Date: October 30, 2024
 */

package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.api.EnrichedDicomStorageStrategy;
import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.dataloader.YamlLoader;
import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import com.eh.digitalpathology.enricher.exceptions.DicomStorageException;
import com.eh.digitalpathology.enricher.model.*;
import com.eh.digitalpathology.enricher.utils.YamlReader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.dcm4che3.data.*;
import org.dcm4che3.io.DicomInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.nio.channels.Channels;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RefreshScope
public class DicomEnrichmentService {

    private static final Logger logger = LoggerFactory.getLogger( DicomEnrichmentService.class.getName( ) );

    public static final String ITEMS = "items";
    private final DatabaseService databaseService;
    private final EnrichedDicomStorageStrategy dicomStorageStrategy;
    private final GcpConfig gcpConfig;
    private final KafkaNotificationProducer kafkaNotificationProducer;

    @Value( "${dicom.mappings.base.path}" )
    private String dicomMappingsBasePath;

    @Value( "${kafka.topic.email}" )
    private String emailSvcTopic;

    private final EnrichInstance enrichInstance = new EnrichInstance( );
    private final YamlLoader yamlLoader;
    private static final ObjectMapper objectMapper = new ObjectMapper( );

    @Autowired
    public DicomEnrichmentService ( DatabaseService databaseService, EnrichedDicomStorageStrategy dicomStorageStrategy, GcpConfig gcpConfig, KafkaNotificationProducer kafkaNotificationProducer, YamlLoader yamlLoader ) {
        this.databaseService = databaseService;
        this.dicomStorageStrategy = dicomStorageStrategy;
        this.gcpConfig = gcpConfig;
        this.kafkaNotificationProducer = kafkaNotificationProducer;
        this.yamlLoader = yamlLoader;
    }


    public EnrichInstance fetchDataForEnrichment ( CaseInfo caseInfo, Map< String, String > additivesMapping, Map< String, Map< String, Object > > dynamicYamlCache ) {
        EnrichedResponse response = databaseService.fetchDataForEnrichment( caseInfo );
        logger.info( "fetchDataForEnrichment :: fetched Intermediate DICOM File path & HL7 parsed Data from Database for StudyInstanceUid:: {}", response.getOriginalStudyInstanceUid( ) );
        try {
            return enrichDicomInstance( response.getBarcode( ), response.getParsedData( ), response.getIntermediateStoragePath( ), caseInfo.getMessageType( ), additivesMapping, dynamicYamlCache, caseInfo.getDeviceSerialNumber( ) );
        } catch ( Exception e ) {
            logger.error( "fetchDataForEnrichment:: Error while enriching DICOM instance", e );
            enrichInstance.setActualStudyInstanceUid( response.getOriginalStudyInstanceUid( ) );
            enrichInstance.setSopInstanceUid( response.getSopInstanceUid( ) );
            enrichInstance.setSeriesInstanceUid( response.getSeriesInstanceUid( ) );
            enrichInstance.setBarcode( response.getBarcode( ) );
            enrichInstance.setStatus( DicomEnrichmentConstants.ENRICHMENT_FAILED );
            logger.info( "fetchDataForEnrichment :: Removing barcode: {}", response.getBarcode( ) );
            processStoredDicomInstance( enrichInstance );
            return enrichInstance;
        }
    }

    private EnrichInstance enrichDicomInstance ( String barcode, Map< String, String > parsedHl7Data, String gcsUri, String messageType, Map< String, String > additivesMapping, Map< String, Map< String, Object > > dynamicYamlCache, String deviceSerialNumber ) throws DicomEnrichmentServiceException {

        URI uri = URI.create( gcsUri );
        String bucketName = uri.getHost( ); // "your-bucket-name"
        String objectName = uri.getPath( ).substring( 1 ); // "path/to/your/file.dcm"
        logger.info( "enrichDicomInstance :: DICOM enrichment process initiated for DICOM File : {}. It will be enriched using HL7 messageType : {}", objectName, messageType );
        Storage storage = null;
        try {
            storage = StorageOptions.newBuilder( ).setCredentials( ServiceAccountCredentials.fromStream( new ByteArrayInputStream( gcpConfig.getCreds( ).getBytes( StandardCharsets.UTF_8 ) ) ) ).build( ).getService( );
        } catch ( IOException e ) {
            logger.error( "enrichDicomInstance :: unable to get access to storage :: {}", e.getMessage( ) );
        }
        if ( storage != null ) {
            Blob blob = storage.get( bucketName, objectName );


            try ( InputStream inputStream = Channels.newInputStream( blob.reader( ) ); DicomInputStream dis = new DicomInputStream( inputStream ) ) {
                Attributes dcmAttributes = dis.readDataset( );
                Attributes fmi = dis.readFileMetaInformation( );

                String specimenIdentifier = "";
                Sequence specimenSeq = dcmAttributes.getSequence( Tag.SpecimenDescriptionSequence );
                if ( specimenSeq != null && !specimenSeq.isEmpty( ) ) {
                    Attributes specimenItem = specimenSeq.get( 0 );
                    specimenIdentifier = specimenItem.getString( Tag.SpecimenIdentifier );
                    logger.info( "enrichDicomInstance :: Specimen Identifier from sequence ================================= : {}", specimenIdentifier );
                }

                if ( specimenIdentifier != null && !specimenIdentifier.isEmpty( ) ) {
                    parsedHl7Data.put( "SPI-1", specimenIdentifier );
                }

                // Read OUL/OML HL7 DICOM mapping file based on messageType
                Map< String, Object > hl7DicomMapper = YamlReader.readYaml( dicomMappingsBasePath + messageType.toLowerCase( ) + DicomEnrichmentConstants.DICOM_MAPPER_SUFFIX );
                if ( hl7DicomMapper.isEmpty( ) ) {
                    kafkaNotificationProducer.sendNotification( emailSvcTopic, "YAML_UNAVAILABLE", barcode );
                }
                DicomTags dicomTags = convertToDicomTags( hl7DicomMapper );
                applyDynamicInclusion( dicomTags, parsedHl7Data, dynamicYamlCache, additivesMapping, barcode );

                logger.debug( "enrichDicomInstance :: Before populating the values:: {}", dicomTags );
                populateValues( dicomTags.getTags( ), parsedHl7Data, barcode );
                logger.info( "enrichDicomInstance :: updating DICOM attributes with DICOM tags data" );
                setAttributes( dcmAttributes, dicomTags.getTags( ) );
                logger.info( "enrichDicomInstance :: DICOM enrichment process completed successfully." );            // Store the Enriched DICOM instance
                // Store the Enriched DICOM instance
                return storeDicomInstance( fmi, dcmAttributes, barcode, deviceSerialNumber );

            } catch ( Exception e ) {
                throw new DicomEnrichmentServiceException( "IOException occurred while enriching DICOM instance", e );
            }
        }
        return null;
    }

    private void applyDynamicInclusion ( DicomTags dicomTags, Map< String, String > parsedHl7Data, Map< String, Map< String, Object > > dynamicYamlCache, Map< String, String > additivesMapping, String barcode ) throws JsonProcessingException {
        Map< String, String > matchedTypesMap = new LinkedHashMap<>( );
        for ( Map.Entry< String, String > entry : parsedHl7Data.entrySet( ) ) {
            String key = entry.getKey( );
            String codeValue = entry.getValue( );

            if ( key.matches( "SPM-6\\[\\d+\\]" ) && !key.matches( "SPM-6\\[\\d+\\]\\." ) ) {
                String type = getCodeSetMapping( key, DicomEnrichmentConstants.CODE_TYPE, codeValue, null, barcode );
                matchedTypesMap.put( getAdditativeMappingKey( key ), type );
            }
        }
        mergeDynamicContent( dicomTags.getTags( ), dynamicYamlCache, additivesMapping, matchedTypesMap );
    }

    private void mergeDynamicContent ( List< TagItem > tags, Map< String, Map< String, Object > > dynamicYamlCache, Map< String, String > additivesMapping, Map< String, String > matchedTypesMap ) {
        List< TagItem > parallelItems = new ArrayList<>( );
        for ( TagItem tagItem : tags ) {
            if ( tagItem.isDynamicInclude( ) ) {
                for ( Map.Entry< String, String > matchedTypeMap : matchedTypesMap.entrySet( ) ) {
                    logger.info( "mergeDynamicContent:: HL7key : {} & Type of Mapping : {} ", matchedTypeMap.getKey( ), matchedTypeMap.getValue( ) );
                    String fileName = additivesMapping.get( matchedTypeMap.getValue( ) );
                    if ( fileName != null ) {
                        addDynamicContent( dynamicYamlCache, matchedTypeMap, tagItem, parallelItems );
                    }
                }
            }
        }
        // Add all parallel items to the main tags list
        tags.addAll( parallelItems );
        // Recursively merge dynamic content for nested items
        for ( TagItem tagItem : tags ) {
            if ( tagItem.getItems( ) != null ) {
                mergeDynamicContent( tagItem.getItems( ), dynamicYamlCache, additivesMapping, matchedTypesMap );
            }
        }
    }

    private void addDynamicContent ( Map< String, Map< String, Object > > dynamicYamlCache, Map.Entry< String, String > matchedTypeMap, TagItem tagItem, List< TagItem > parallelItems ) {
        Map< String, Object > dynamicYaml = dynamicYamlCache.get( matchedTypeMap.getValue( ) );
        if ( dynamicYaml != null ) {
            List< TagItem > dynamicItems = convertToTagItemList( (List< Map< String, Object > >) dynamicYaml.get( DicomEnrichmentConstants.TAGS ), Optional.of( matchedTypeMap.getKey( ) ) );
            if ( tagItem.getItems( ) == null && tagItem.getName( ).equals( dynamicItems.get( 0 ).getName( ) ) ) {
                tagItem.setItems( dynamicItems.get( 0 ).getItems( ) );
            } else {
                parallelItems.addAll( dynamicItems );
            }
        }
    }

    private DicomTags convertToDicomTags ( Map< String, Object > yamlMap ) {
        logger.debug( "convertToDicomTags :: Converting HL7 DICOM mapped data into DicomTags" );
        DicomTags dicomTags = new DicomTags( );
        List< TagItem > tags = convertToTagItemList( (List< Map< String, Object > >) yamlMap.get( DicomEnrichmentConstants.TAGS ), Optional.empty( ) );
        dicomTags.setTags( tags );
        return dicomTags;
    }

    private List< TagItem > convertToTagItemList ( List< Map< String, Object > > tagItemList, Optional< String > hl7Key ) {
        List< TagItem > tags = new ArrayList<>( );
        for ( Map< String, Object > tagItemMap : tagItemList ) {
            TagItem tagItem = new TagItem( );
            tagItem.setName( (String) tagItemMap.get( DicomEnrichmentConstants.NAME ) );
            tagItem.setVr( (String) tagItemMap.get( DicomEnrichmentConstants.VR ) );
            setTagValue( tagItem, tagItemMap, hl7Key );
            tagItem.setDefaultValue( (String) tagItemMap.get( DicomEnrichmentConstants.DEFAULT_VALUE ) );
            if ( tagItemMap.containsKey( ITEMS ) || tagItemMap.containsKey( DicomEnrichmentConstants.TAGS ) ) {
                setTagItems( tagItem, tagItemMap, hl7Key );
            } else if ( tagItemMap.containsKey( DicomEnrichmentConstants.INCLUDE ) && DicomEnrichmentConstants.DYNAMIC_TAG.equals( tagItemMap.get( DicomEnrichmentConstants.INCLUDE ) ) ) {
                setDynamicTag( tagItem );
            }
            tags.add( tagItem );
        }
        return tags;
    }

    private void setTagValue ( TagItem tagItem, Map< String, Object > tagItemMap, Optional< String > hl7Key ) {
        if ( tagItemMap.get( DicomEnrichmentConstants.VALUE ) instanceof String tagValue ) {
            if ( tagValue.contains( DicomEnrichmentConstants.SPM_6 ) && hl7Key.isPresent( ) ) {
                tagValue = tagValue.replace( DicomEnrichmentConstants.SPM_6, hl7Key.get( ) );
            }
            tagItem.setValue( tagValue );
        } else if ( tagItemMap.get( DicomEnrichmentConstants.VALUE ) instanceof List< ? > ) {
            tagItem.setValues( (List< String >) tagItemMap.get( DicomEnrichmentConstants.VALUE ) );
        }
    }

    private void setDynamicTag ( TagItem tagItem ) {
        tagItem.setDynamicInclude( true );
        if ( tagItem.getVr( ) == null ) {
            tagItem.setVr( DicomEnrichmentConstants.SQ );
        }
        if ( tagItem.getValue( ) == null ) {
            tagItem.setValue( DicomEnrichmentConstants.EMPTY_STRING );
        }
    }

    private void setTagItems ( TagItem tagItem, Map< String, Object > tagItemMap, Optional< String > hl7Key ) {
        List< Map< String, Object > > nestedList = (List< Map< String, Object > >) tagItemMap.getOrDefault( ITEMS, tagItemMap.get( DicomEnrichmentConstants.TAGS ) );
        if ( nestedList != null && !nestedList.isEmpty( ) ) {
            tagItem.setItems( convertToTagItemList( nestedList, hl7Key ) );
        }
    }

    private void populateValues ( final List< TagItem > tags, final Map< String, String > hl7ParsedData, String barcode ) throws JsonProcessingException {
        List< TagItem > itemsToRemove = new ArrayList<>( );
        Map< String, Map< ?, ? > > codeSeqMap = new HashMap<>( );
        for ( TagItem tagItem : tags ) {
            String tagValue = tagItem.getValue( );
            if ( hl7ParsedData.containsKey( tagValue ) ) {
                String hl7ParsedValue = hl7ParsedData.get( tagValue );
                hl7ParsedValue = populateHL7ParsedData( tagItem, tagValue, hl7ParsedValue, itemsToRemove, codeSeqMap, barcode );
                tagItem.setValue( hl7ParsedValue );
            } else if ( tagItem.getValues( ) != null && !tagItem.getValues( ).isEmpty( ) ) {
                // Code changed added when we have more than Value for one DICOM Tag
                populateMultiValuesMapping( tagItem, hl7ParsedData, codeSeqMap, barcode, itemsToRemove );
            } else if ( tagItem.getVr( ) != null && VR.valueOf( tagItem.getVr( ) ).equals( VR.PN ) ) {
                populatePatientName( tagItem, hl7ParsedData );
            } else {
                addEmptyTagItem( tagItem, itemsToRemove );
            }
            if ( tagItem.getItems( ) != null ) {
                populateTagItems( tagItem, hl7ParsedData, itemsToRemove, barcode );
            }

        }
        if ( itemsToRemove.stream( ).anyMatch( tagItem -> tagItem.getName( ).equalsIgnoreCase( "Text Value" ) ) ) {
            tags.clear( );
        } else {
            tags.removeAll( itemsToRemove );
        }
    }

    private void addEmptyTagItem ( TagItem tagItem, List< TagItem > itemsToRemove ) {
        if ( tagItem.getDefaultValue( ) != null && tagItem.getDefaultValue( ).isEmpty( ) ) {
            itemsToRemove.add( tagItem );
            logger.info( "populateValues:: Adding Empty tagItem in removal tags list ::: {}", tagItem );
        }
    }

    private void populatePatientName ( TagItem tagItem, Map< String, String > hl7ParsedData ) {
        String[] components = tagItem.getValue( ).split( "\\^" );
        List< String > updatedComponents = new ArrayList<>( );
        for ( String component : components ) {
            updatedComponents.add( hl7ParsedData.getOrDefault( component, "" ) );
        }
        tagItem.setValue( String.join( "^", updatedComponents ) );
    }

    private void populateTagItems ( TagItem tagItem, Map< String, String > hl7ParsedData, List< TagItem > itemsToRemove, String barcode ) throws JsonProcessingException {
        populateValues( tagItem.getItems( ), hl7ParsedData, barcode );
        // Code changes are added to handle Sequence when TagItems inside to it are Empty
        if ( tagItem.getVr( ) != null && VR.SQ.equals( VR.valueOf( tagItem.getVr( ) ) ) ) {
            boolean isTagItemSequenceEmpty = checkEmptySequence( tagItem );
            if ( isTagItemSequenceEmpty ) {
                logger.info( "populateTagItems:: Adding Empty TagItemSequence in removal tags list ::: {}", tagItem );
                itemsToRemove.add( tagItem );
            }
        }
    }

    private void populateMultiValuesMapping ( TagItem tagItem, Map< String, String > hl7ParsedData, Map< String, Map< ?, ? > > codeSeqMap, String barcode , List<TagItem> itemsToRemove) throws JsonProcessingException {
        // Iterate over each value and if we found HL7 parsed data set it in DICOM TagItem
        for ( String value : tagItem.getValues( ) ) {
            if ( hl7ParsedData.containsKey( value ) ) {
                String tagName = tagItem.getName( );
                String hl7ParsedValue = hl7ParsedData.get( value );
                if ( StringUtils.hasLength( value ) && StringUtils.hasLength( tagName ) && StringUtils.hasLength( hl7ParsedValue ) ) {
                    hl7ParsedValue = getCodeSetMapping( value, tagName, hl7ParsedValue, codeSeqMap, barcode );
                }
                tagItem.setValue( hl7ParsedValue );
                break;
            }
        }
        if (Objects.isNull(tagItem.getValue()) || tagItem.getValue().isEmpty()) {
            addEmptyTagItem(tagItem, itemsToRemove);
        }
    }

    private String populateHL7ParsedData ( TagItem tagItem, String tagValue, String hl7ParsedValue, List< TagItem > itemsToRemove, Map< String, Map< ?, ? > > codeSeqMap, String barcode ) throws JsonProcessingException {
        String tagName = tagItem.getName( );
        VR tagVR = VR.valueOf( tagItem.getVr( ) );
        if ( VR.DA.equals( tagVR ) || VR.TM.equals( tagVR ) ) {
            hl7ParsedValue = handleDateTime( tagItem, hl7ParsedValue, itemsToRemove );
        } else if ( Tag.SpecimenShortDescription == getTagCode( tagName ) && hl7ParsedValue.length( ) > 64 ) {
            itemsToRemove.add( tagItem );
        } else if ( Tag.SpecimenDetailedDescription == getTagCode( tagName ) && hl7ParsedValue.length( ) <= 64 ) {
            itemsToRemove.add( tagItem );
        } else if ( Tag.EthnicGroup == getTagCode( tagName ) && StringUtils.hasLength( tagValue ) && StringUtils.hasLength( tagName ) && StringUtils.hasLength( hl7ParsedValue ) ) {
            hl7ParsedValue = getCodeSetMapping( tagValue, tagName, hl7ParsedValue, codeSeqMap, barcode );
            hl7ParsedValue = truncateCharacters( hl7ParsedValue );
        } else if ( StringUtils.hasLength( tagValue ) && StringUtils.hasLength( tagName ) && StringUtils.hasLength( hl7ParsedValue ) ) {
            hl7ParsedValue = getCodeSetMapping( tagValue, tagName, hl7ParsedValue, codeSeqMap, barcode );
        }
        return hl7ParsedValue;
    }

    private String truncateCharacters ( String hl7ParsedValue ) {
        if ( hl7ParsedValue == null || hl7ParsedValue.isEmpty( ) ) {
            return "";
        }
        // Ensure that the input is within the 16-character limit
        if ( hl7ParsedValue.length( ) <= 16 ) {
            return hl7ParsedValue;
        }
        // Split the input by spaces to handle words
        String[] words = hl7ParsedValue.split( " " );
        StringBuilder result = new StringBuilder( );

        for ( String word : words ) {
            if ( ( result.length( ) + word.length( ) + 1 ) > 16 ) {
                break;
            }
            if ( !result.isEmpty( ) ) {
                result.append( " " );
            }
            result.append( word );
        }

        return result.toString( );
    }


    private String handleDateTime ( TagItem tagItem, String hl7ParsedValue, List< TagItem > itemsToRemove ) {
        if ( Tag.StudyDate == getTagCode( tagItem.getName( ) ) ) {
            hl7ParsedValue = hl7ParsedValue.substring( 0, 8 );
        }
        if ( Tag.StudyTime == getTagCode( tagItem.getName( ) ) && hl7ParsedValue.length( ) > 8 ) {
            hl7ParsedValue = hl7ParsedValue.substring( 8 );
        }
        if ( Tag.PatientBirthDate == getTagCode( tagItem.getName( ) ) ) {
            // Need to make Date time Validation either while doing HL7 Data parsing or hereud
            hl7ParsedValue = hl7ParsedValue.substring( 0, 8 );
        }
        if ( Tag.PatientBirthTime == getTagCode( tagItem.getName( ) ) ) {
            if ( hl7ParsedValue.length( ) > 8 ) {
                hl7ParsedValue = hl7ParsedValue.substring( 8 );
            } else {
                itemsToRemove.add( tagItem );
            }
        }
        return hl7ParsedValue;
    }

    private boolean checkEmptySequence ( TagItem tagItemSequence ) {
        tagItemSequence.getItems( ).removeIf( tagItem -> ( tagItem.getItems( ) != null && tagItem.getItems( ).isEmpty( ) ) && !StringUtils.hasLength( tagItem.getName( ) ) && !StringUtils.hasLength( tagItem.getVr( ) ) && !StringUtils.hasLength( tagItem.getValue( ) ) );

        return tagItemSequence.getItems( ).isEmpty( );

    }


    private void setAttributes ( Attributes attributes, List< TagItem > tags ) {
        for ( TagItem tag : tags ) {
            if ( tag.getName( ) == null ) {
                if ( tag.getItems( ) != null ) {
                    setAttributes( attributes, tag.getItems( ) );
                }
                continue;
            }
            int tagCode = getTagCode( tag.getName( ) );
            VR vr = VR.valueOf( tag.getVr( ) );
            if ( vr == VR.SQ ) {
                setAttributeSequence( attributes, tag, tagCode );
            } else if ( vr == VR.PN ) {
                String formattedPN = formatPNValue( tag.getValue( ) );
                attributes.setString( tagCode, vr, formattedPN );
            } else {
                attributes.setString(tagCode, vr, tag.getValue());
            }
        }
    }

    private void setAttributeSequence ( Attributes attributes, TagItem tag, int tagCode ) {
        if ( tagCode == Tag.SpecimenPreparationStepContentItemSequence ) {
            addSpecimenPreparationStepContentItemSequence( attributes, tag );
        } else {
            Sequence sequence = attributes.ensureSequence( tagCode, 0 );
            if ( tag.getItems( ) != null ) {
                for ( TagItem item : tag.getItems( ) ) {
                    setNestedAttributes( attributes, sequence, tag, item, tagCode );
                }
            }
        }
        if ( tagCode == Tag.SpecimenPreparationSequence ) {
            removeEmptyItem( attributes, tagCode );
        }
        mergeSpecimenDescSeqItems( attributes );
    }

    private void setNestedAttributes ( Attributes attributes, Sequence sequence, TagItem tag, TagItem tagItem, int tagCode ) {
        Attributes nestedAttributes = new Attributes( );
        sequence.add( nestedAttributes );
        if ( tagItem.getItems( ) != null && !tagItem.getItems( ).isEmpty( ) ) {
            setAttributes( nestedAttributes, tagItem.getItems( ) );
        }
        if ( tagCode == Tag.ContainerTypeCodeSequence ) {
            overrideSequenceData( attributes, nestedAttributes, tag );
        }
    }


    private void overrideSequenceData ( Attributes attributes, Attributes nestedAttributes, TagItem tag ) {
        Sequence seq = attributes.getSequence( getTagCode( tag.getName( ) ) );
        if ( !nestedAttributes.isEmpty( ) ) {
            seq.clear( );
            seq.add( nestedAttributes );
        }
    }

    private void addSpecimenPreparationStepContentItemSequence ( Attributes attributes, TagItem tag ) {
        Sequence specimenPreparationSequence = attributes.getParent( ).ensureSequence( Tag.SpecimenPreparationSequence, 1 );
        Attributes stepAttributes = new Attributes( );
        Sequence stepContentItemSequence = stepAttributes.newSequence( Tag.SpecimenPreparationStepContentItemSequence, 0 );

        if ( tag.getItems( ) != null ) {
            for ( TagItem item : tag.getItems( ) ) {
                Attributes nestedAttributes = new Attributes( );
                stepContentItemSequence.add( nestedAttributes );
                setAttributes( nestedAttributes, item.getItems( ) );
            }
        }
        specimenPreparationSequence.add( stepAttributes );
    }


    private void mergeSpecimenDescSeqItems ( Attributes attributes ) {
        Sequence seq = attributes.getSequence( Tag.SpecimenDescriptionSequence );
        Attributes mergedAttr = new Attributes( );

        if ( seq != null && !seq.isEmpty( ) ) {

            for ( Attributes atr : seq ) {
                mergedAttr.addAll( atr );
            }
            seq.clear( );
            seq.add( mergedAttr );
        }
    }


    private String formatPNValue ( String value ) {
        if ( value == null || value.isEmpty( ) ) {
            return "";
        }
        String[] components = value.split( "\\^", -1 );
        List< String > cleanedComponents = new ArrayList<>( );
        for ( String component : components ) {
            if ( !component.isEmpty( ) ) {
                cleanedComponents.add( component );
            } else {
                cleanedComponents.add( "" );
            }
        }
        cleanedComponents.removeIf( String::isEmpty );
        String formattedPN = String.join( "^", cleanedComponents );
        if ( formattedPN.endsWith( "^" ) ) {
            formattedPN = formattedPN.substring( 0, formattedPN.length( ) - 1 );
        }
        return formattedPN;
    }

    private int getTagCode ( String tagName ) {
        try {
            Field field = Tag.class.getField( tagName.replace( " ", "" ) );
            return field.getInt( null );
        } catch ( NoSuchFieldException | IllegalAccessException e ) {
            throw new IllegalArgumentException( "Unknown tag name: " + tagName, e );
        }
    }


    private EnrichInstance storeDicomInstance ( Attributes fmi, Attributes dcmAttributes, String barcode, String deviceSerialNumber ) throws DicomEnrichmentServiceException {
        enrichInstance.setActualStudyInstanceUid( dcmAttributes.getString( Tag.StudyInstanceUID ) );
        enrichInstance.setSopInstanceUid( dcmAttributes.getString( Tag.SOPInstanceUID ) );
        enrichInstance.setSeriesInstanceUid( dcmAttributes.getString( Tag.SeriesInstanceUID ) );
        enrichInstance.setCaseNumber( dcmAttributes.getString( Tag.AccessionNumber ) );
        enrichInstance.setBarcode( barcode );
        try {
            // Store the enriched DICOM file
            dicomStorageStrategy.storeEnrichedDicomInstance( fmi, dcmAttributes, deviceSerialNumber );
            enrichInstance.setStatus( DicomEnrichmentConstants.ENRICHMENT_COMPLETED );
            logger.info( "storeDicomInstance :: Barcode: {}", barcode );
            processStoredDicomInstance( enrichInstance );
            logger.info( "storeDicomInstance:: Successfully stored enriched DICOM file and updated status to COMPLETED - StudyInstanceUID: {}, SeriesInstanceUID: {}, SOPInstanceUID: {}, Barcode: {}", enrichInstance.getActualStudyInstanceUid( ), enrichInstance.getSeriesInstanceUid( ), enrichInstance.getSopInstanceUid( ), enrichInstance.getBarcode( ) );
        } catch ( DicomStorageException | DicomEnrichmentServiceException e ) {
            throw new DicomEnrichmentServiceException( "Failed to store enriched DICOM file ", e );
        }
        return enrichInstance;
    }

    private void processStoredDicomInstance ( EnrichInstance enrichInstance ) {
        logger.info( "processStoredDicomInstance:: Updating enrichment status in the database - Status: {}, StudyInstanceUID: {}, SeriesInstanceUID: {}, SOPInstanceUID: {}, Barcode: {}", enrichInstance.getStatus( ), enrichInstance.getActualStudyInstanceUid( ), enrichInstance.getSeriesInstanceUid( ), enrichInstance.getSopInstanceUid( ), enrichInstance.getBarcode( ) );
        try {
            String status = databaseService.updateEnrichmentStatus( enrichInstance );
            logger.info( "processStoredDicomInstance:: Successfully updated enrichment status in db for sop :  {}, and barcode : {} and status of db :: {}", enrichInstance.getSopInstanceUid( ), enrichInstance.getBarcode( ), status );
        } catch ( Exception e ) {
            logger.error( "processStoredDicomInstance:: Failed to update enrichment status in db for sop :: {}, and barcode : {}, Error: {}", enrichInstance.getSopInstanceUid( ), enrichInstance.getBarcode( ), e.getMessage( ), e );
        }
    }

    private void removeEmptyItem ( Attributes attributes, int tagCode ) {
        Sequence sequence = attributes.getSequence( tagCode );
        if ( sequence != null && !sequence.isEmpty( ) ) {
            sequence.removeIf( attr -> attr.isEmpty( ) );
        }
    }

    private String getCodeSetMapping ( String tagValue, String tagName, String hl7ParsedValue, Map< String, Map< ?, ? > > codeSeqMap, String barcode ) throws JsonProcessingException {
        logger.info( "getCodeSetMapping:: Inside getCodeSetMapping for tagValue: {} ,tagName: {} ", tagValue, tagName );
        String yamlMappingKey = getCodeSetYAMLMappingKey( tagValue );
        if ( codeSeqMap != null && !codeSeqMap.isEmpty( ) && codeSeqMap.get( yamlMappingKey ) != null ) {
            Map< String, Object > dicomMap = (Map< String, Object >) codeSeqMap.get( yamlMappingKey );
            String dicomData = (String) dicomMap.get( tagName );
            logger.debug( "getCodeSetMapping ::Fetching data from codeSeqMap : Code Set Mapping for HL7 Field: {} ====> [ DICOM Tag Name: {} ]", tagValue, tagName );
            hl7ParsedValue = dicomData;
        } else {
            Object codeSetMapObject = yamlLoader.getYamlDataMaps( ).get( yamlMappingKey );
            if ( codeSetMapObject instanceof Map< ?, ? > hl7FieldMapping ) {
                Object dicomObject = hl7FieldMapping.get( hl7ParsedValue );
                if ( dicomObject instanceof String dicomMappedData ) {
                    logger.debug( "getCodeSetMapping ::Code Set Mapping found for HL7 Field: {}  ====> [ DICOM Tag Name: {} ]", tagValue, tagName );
                    hl7ParsedValue = dicomMappedData;
                } else if ( dicomObject instanceof Map< ?, ? > dicomMap ) {
                    String dicomData = Optional.ofNullable( dicomMap.get( tagName ) ).map( Object::toString ).orElse( null );
                    logger.debug( "getCodeSetMapping : Code Set Mapping found for HL7 Field: {}  ====> [ DICOM Tag Name: {} ]", tagValue, tagName );
                    hl7ParsedValue = dicomData;
                    if ( codeSeqMap != null ) {
                        codeSeqMap.put( yamlMappingKey, dicomMap );
                    }
                } else {
                    logger.info( "getCodeSetMapping :: Code Set Mapping doesn't exist for HL7 Field: {} ", tagValue );
                    triggerEmailForMissingTag( yamlMappingKey, tagValue, barcode );
                    if ( tagName.equalsIgnoreCase( "Coding Scheme Designator" ) ) {
                        hl7ParsedValue = "";
                    }
                }
            }
        }
        return hl7ParsedValue;
    }

    private void triggerEmailForMissingTag ( String yamlMappingKey, String tagValue, String barcode ) throws JsonProcessingException {
        Set< String > notifiedKeys = MissingKeysNotificationData.getNotifiedMissingKeys( ).computeIfAbsent( barcode, k -> ConcurrentHashMap.newKeySet( ) );
        if ( notifiedKeys.add( yamlMappingKey ) ) {
            MissingCodeSetFieldData missingCodeSetFieldData = new MissingCodeSetFieldData( barcode, tagValue );
            kafkaNotificationProducer.sendNotification( emailSvcTopic, "CODE_SET_MAPPING_FIELD_MISSING", objectMapper.writeValueAsString( missingCodeSetFieldData ) );
        }
    }


    private String getCodeSetYAMLMappingKey ( String tagValue ) {
        logger.info( "Inside getCodeSetYAMLMappingKey for : {} ", tagValue );
        if ( StringUtils.hasLength( tagValue ) ) {
            if ( tagValue.contains( DicomEnrichmentConstants.COMPONENT_REPETITION_SEPARATOR ) ) {
                tagValue = tagValue.substring( 0, tagValue.indexOf( DicomEnrichmentConstants.COMPONENT_REPETITION_SEPARATOR ) );
            } else if ( tagValue.contains( DicomEnrichmentConstants.FIELD_DOT_SEPARATOR ) ) {
                tagValue = tagValue.substring( 0, tagValue.indexOf( DicomEnrichmentConstants.FIELD_DOT_SEPARATOR ) );
            }
        }
        return tagValue;
    }

    private String getAdditativeMappingKey ( String hl7Key ) {
        if ( hl7Key.contains( DicomEnrichmentConstants.FIELD_DOT_SEPARATOR ) ) {
            hl7Key = hl7Key.substring( 0, hl7Key.lastIndexOf( DicomEnrichmentConstants.FIELD_DOT_SEPARATOR ) );
        }
        return hl7Key;
    }

}
