package com.eh.digitalpathology.enricher.model;

public class EnrichInstance extends BaseEntity {

    private String actualStudyInstanceUid;
    private String status;
    private String caseNumber;


    public String getActualStudyInstanceUid() {
        return actualStudyInstanceUid;
    }

    public void setActualStudyInstanceUid(String actualStudyInstanceUid) {
        this.actualStudyInstanceUid = actualStudyInstanceUid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCaseNumber ( ) {
        return caseNumber;
    }

    public void setCaseNumber ( String caseNumber ) {
        this.caseNumber = caseNumber;
    }
}
