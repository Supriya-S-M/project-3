package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.model.BarcodeInstanceRequest;
import com.eh.digitalpathology.enricher.model.InstancesMeta;
import com.eh.digitalpathology.enricher.utils.GCPUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class QidoRsService {
    private final GcpConfig gcpConfig;
    private final DatabaseService databaseService;

    private static final Logger logger = LoggerFactory.getLogger(QidoRsService.class.getName());
    private static final HttpClient httpClient = HttpClient.newHttpClient();
    public QidoRsService(GcpConfig gcpConfig, DatabaseService databaseService) {
        this.gcpConfig = gcpConfig;
        this.databaseService = databaseService;
    }

    public JsonNode qidoRsCall(String seriesUid, List<InstancesMeta> instances, String dicomWebUrl) throws IOException, InterruptedException {
        String uri = String.format("%s/%s/dicomWeb/instances", this.gcpConfig.getDicomWebUrl(), dicomWebUrl);
        String fullUrl = uri + "?SeriesInstanceUID=" + URLEncoder.encode(seriesUid, StandardCharsets.UTF_8);
        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(fullUrl))
                .header("Authorization", "Bearer " + GCPUtils.getAccessToken(gcpConfig))
                .header("Accept", "application/dicom+json,multipart/related; transfer-syntax=* type=application/dicom+xml")
                .GET().build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        databaseService.saveQidoRsResponse(response.statusCode(), response.body(), seriesUid);
        logger.info("qidoRsCall :: saved qido rs response :: {}", seriesUid);
        if (response.statusCode() == 200) {
            for(InstancesMeta instancesMeta:instances) {
                BarcodeInstanceRequest barcodeInstanceRequest=new BarcodeInstanceRequest(instancesMeta.barcode(),instancesMeta.sopInstanceUid());
                databaseService.updateStatus(barcodeInstanceRequest);
            }
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readTree(response.body());
        }
        return null;
    }
}
