package com.eh.digitalpathology.enricher.model;

import java.util.Map;


public class EnrichedResponse extends BaseEntity {

    private String intermediateStoragePath;
    private Map<String, String> parsedData;
    private String originalStudyInstanceUid;

    public String getIntermediateStoragePath() {
        return intermediateStoragePath;
    }

    public void setIntermediateStoragePath(String intermediateStoragePath) {
        this.intermediateStoragePath = intermediateStoragePath;
    }

    public Map<String, String> getParsedData() {
        return parsedData;
    }

    public void setParsedData(Map<String, String> parsedData) {
        this.parsedData = parsedData;
    }

    public String getOriginalStudyInstanceUid() {
        return originalStudyInstanceUid;
    }

    public void setOriginalStudyInstanceUid(String originalStudyInstanceUid) {
        this.originalStudyInstanceUid = originalStudyInstanceUid;
    }

    @Override
    public String toString() {
        return "EnrichedResponse{" +
                "intermediateStoragePath='" + intermediateStoragePath + '\'' +
                ", originalStudyInstanceUid='" + originalStudyInstanceUid + '\'' +
                '}';
    }
}
