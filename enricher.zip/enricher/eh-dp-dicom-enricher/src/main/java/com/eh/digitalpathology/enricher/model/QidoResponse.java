package com.eh.digitalpathology.enricher.model;

public record QidoResponse(String seriesUid, String response, int statusCode) {
}
