/**
 * DicomEnrichmentConstants holds all constant values used in the DICOM enrichment process.
 * Author: Pooja Kamble
 * Date: October 30, 2024
 */

package com.eh.digitalpathology.enricher.constants;

public final class DicomEnrichmentConstants {

    // Private constructor to prevent instantiation
    private DicomEnrichmentConstants() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }

    public static final String DICOM_MAPPER_SUFFIX = "-dicom-mapper.yml";

    public static final String DICOM_ENRICHMENT = "dicom-enriched";

    //Enrichment workflow status
    public static final String ENRICHMENT_COMPLETED = "completed";
    public static final String ENRICHMENT_FAILED = "failed";

    public static final String ENRICHMENT_COMPLETED_STATUS = "ENRICHMENT_COMPLETED";
    public static final String ENRICHMENT_FAILED_STATUS = "ENRICHMENT_FAILED";

    public static final String DICOM_DIR = "DICOM_DIR_CREATED";
    public static final String STORAGE_COMMITMENT = "STORAGE_COMMITMENT";

    public static final String COMMITTED = "committed";
    public static final String COMMITTED_STATUS = "COMMITTED";
    public static final String EXPORTED_STATUS = "EXPORTED";

    public static final String FIELD_DOT_SEPARATOR = ".";
    public static final String COMPONENT_REPETITION_SEPARATOR = "[";

    public static final String CODE_TYPE = "Type";

    public static final String SPM_6 = "SPM-6";

    public static final String TAGS = "tags";

    public static final String NAME = "name";

    public static final String VR = "vr";

    public static final String VALUE = "value";

    public static final String DEFAULT_VALUE = "defaultValue";

    public static final String SQ = "SQ";

    public static final String INCLUDE = "include";

    public static final String EMPTY_STRING = "";

    public static final String DYNAMIC_TAG = "dynamic";

    public static final String MAPPING_YAML = "mapping.yml";

    public static final String INVALID_ERROR = "INVALID_ERROR";

}
