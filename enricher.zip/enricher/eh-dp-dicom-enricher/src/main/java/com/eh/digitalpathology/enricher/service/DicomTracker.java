package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.model.CaseInfo;
import com.eh.digitalpathology.enricher.model.SeriesState;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.RemovalCause;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;

@Component
@RefreshScope
public class DicomTracker {

    @Value( "${app.export.task-timeout-minutes}" )
    private long taskTimeoutMinutes;

    private final ScheduledExecutorService schedular;
    private BiFunction< String, SeriesState, CompletableFuture< Void > > onSeriesTimeOutCallback;
    private final Cache< String, SeriesState > seriesTracker;
    private static final Logger log = LoggerFactory.getLogger( DicomTracker.class.getName( ) );

    public DicomTracker ( @Qualifier( "dicomTrackerExecutorService" ) ScheduledExecutorService schedular ) {
        this.schedular = schedular;
        this.seriesTracker = Caffeine.newBuilder( ).expireAfterAccess( 60, TimeUnit.MINUTES ).maximumSize( 1000 ).removalListener( ( String key, SeriesState state, RemovalCause cause ) -> {
            if ( state != null && state.getTimerTask( ) != null ) {
                state.getTimerTask( ).cancel( false );
            }
        } ).build( );
    }

    public void setOnSeriesTimeOutCallback ( BiFunction< String, SeriesState, CompletableFuture< Void > > callback ) {
        log.info( "setOnSeriesTimeOutCallback :: timeout callback is called:: {}", callback );
        this.onSeriesTimeOutCallback = callback;
    }


    public void handleInstances ( String seriesUid, CaseInfo caseInfo ) {
        log.info( "handleInstances:: series id :: {}, sop instance uid :: {}", seriesUid, caseInfo.getSopInstanceUid( ) );
        seriesTracker.asMap( ).compute( seriesUid, ( uid, state ) -> {
            log.info( "State value is: {}", state );
            if ( state == null ) {
                state = new SeriesState( seriesUid );
            }
            if ( !state.receivedInstances.contains( caseInfo.getSopInstanceUid( ) ) ) {
                state.receivedInstances.add( caseInfo.getSopInstanceUid( ) );
            }
            if ( state.commitmentReceived.get( ) ) {
                log.info( "handleInstances :: instances received after commitment for series:: {}", caseInfo.getSeriesInstanceUid( ) );
                return state;

            }
            if ( state.getTimerTask( ) != null ) {
                log.info( "handleInstances :: Timer reset for seriesId: {}", seriesUid );
                state.getTimerTask( ).cancel( false );
            }
            SeriesState finalState = state;
            state.setTimerTask( (ScheduledFuture< Void >) schedular.schedule( ( ) -> {
                log.info( "handleInstances:: timer stopped for instances :: {}", caseInfo.getSopInstanceUid( ) );
                if ( !finalState.commitmentReceived.get( ) ) {
                    onSeriesTimeOutCallback.apply( seriesUid, finalState ).exceptionally( ex -> {
                        log.error( "Timeout callback failed for seriesUid: {}", seriesUid, ex );
                        return null;
                    } );
                }

            }, taskTimeoutMinutes, TimeUnit.MINUTES ) );
            return state;
        } );
    }

    public void markCommitmentReceived ( String seriesUid ) {
        log.info( "markCommitmentReceived :: commitment received for series:: {}", seriesUid );
        seriesTracker.asMap( ).compute( seriesUid, ( uid, state ) -> {
            if ( state == null ) {
                state = new SeriesState( seriesUid );
            }
            state.commitmentReceived.set( true );
            if ( state.getTimerTask( ) != null ) {
                state.getTimerTask( ).cancel( false );
            }
            return state;
        } );

    }

    public SeriesState getState ( String seriesUid ) {
        return seriesTracker.getIfPresent( seriesUid );
    }

    public void invalidate ( String seriesUid ) {
        seriesTracker.invalidate( seriesUid );
    }


}