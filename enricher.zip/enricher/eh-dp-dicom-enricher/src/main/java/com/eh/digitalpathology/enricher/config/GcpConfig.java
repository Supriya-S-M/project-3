package com.eh.digitalpathology.enricher.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "gcp-config")
public class GcpConfig {
    private String creds;
    private String dicomWebUrl;

    public String getDicomWebUrl() {
        return dicomWebUrl;
    }

    public void setDicomWebUrl(String dicomWebUrl) {
        this.dicomWebUrl = dicomWebUrl;
    }

    public String getCreds ( ) {
        return creds;
    }

    public void setCreds ( String creds ) {
        this.creds = creds;
    }
}