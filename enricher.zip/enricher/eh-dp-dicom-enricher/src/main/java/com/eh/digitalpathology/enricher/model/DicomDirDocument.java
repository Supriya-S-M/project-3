package com.eh.digitalpathology.enricher.model;

public class DicomDirDocument{
    private String id;
    private String studyId;
    private String seriesId;
    private int imageCount;
    private byte[] dicomDirFile;

    public String getId ( ) {
        return id;
    }

    public void setId ( String id ) {
        this.id = id;
    }

    public String getSeriesId ( ) {
        return seriesId;
    }

    public void setSeriesId ( String seriesId ) {
        this.seriesId = seriesId;
    }

    public String getStudyId ( ) {
        return studyId;
    }

    public void setStudyId ( String studyId ) {
        this.studyId = studyId;
    }

    public int getImageCount ( ) {
        return imageCount;
    }

    public void setImageCount ( int imageCount ) {
        this.imageCount = imageCount;
    }

    public byte[] getDicomDirFile ( ) {
        return dicomDirFile;
    }

    public void setDicomDirFile ( byte[] dicomDirFile ) {
        this.dicomDirFile = dicomDirFile;
    }
}

