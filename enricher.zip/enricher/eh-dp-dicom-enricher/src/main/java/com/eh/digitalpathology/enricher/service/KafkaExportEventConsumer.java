package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.GcpConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.model.*;
import com.eh.digitalpathology.enricher.utils.DicomDirUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RefreshScope
public class KafkaExportEventConsumer {

    private final ObjectMapper objectMapper = new ObjectMapper( );

    @Value( "${kafka.topic.export}" )
    private String exportTopic;

    @Value( "${retry.max.attempts}" )
    private int maxRetryAttempts;

    @Value( "${retry.delay.milliseconds}" )
    private int retryDelayInMilliseconds;

    @Value( "${app.export.sleep-time-seconds}" )
    private long sleepTimeSeconds;

    @Value( "${app.export.wait-time-minutes}" )
    private long waitTimeMinutes;

    @Value( "${app.export.sop-check-interval-minutes}" )
    private long sopCheckIntervalMinutes;

    @Value( "${app.export.delete-series-delay-minutes}" )
    private long deleteSeriesDelayMinutes;

    @Value( "${app.export.enrichment-status-check-interval-ms}" )
    private long enrichmentStatusCheckIntervalMs;

    @Value( "${app.export.enrichment-timeout-minutes}" )
    private long enrichmentTimeout;

    @Value( "${kafka.topic.email}" )
    private String emailSvcTopic;

    @Value( "${kafka.topic.enrich}" )
    private String enrichSvcTopic;

    private final DicomTracker tracker;
    private final DatabaseService databaseService;
    private final QidoRsService qidoRsService;
    private final GcpConfig gcpConfig;
    private final KafkaNotificationProducer kafkaNotificationProducer;
    private final ScheduledExecutorService scheduledExecutorService;
    private final ExecutorService cpuExecutor;
    private final ExecutorService ioExecutor;
    private static final Logger logger = LoggerFactory.getLogger( KafkaExportEventConsumer.class.getName( ) );
    Set< String > allowedStatuses = Set.of( DicomEnrichmentConstants.ENRICHMENT_COMPLETED_STATUS, DicomEnrichmentConstants.COMMITTED_STATUS, DicomEnrichmentConstants.EXPORTED_STATUS );

    public KafkaExportEventConsumer ( DicomTracker tracker, DatabaseService databaseService, QidoRsService qidoRsService, GcpConfig gcpConfig, KafkaNotificationProducer kafkaNotificationProducer, @Qualifier( "stgcmtExecutorService" ) ScheduledExecutorService scheduledExecutorService, @Qualifier( "exportExecutorService" ) ExecutorService cpuExecutor, @Qualifier( "processingExecutorService" ) ExecutorService ioExecutor ) {
        this.tracker = tracker;
        this.gcpConfig = gcpConfig;
        this.scheduledExecutorService = scheduledExecutorService;
        this.cpuExecutor = cpuExecutor;
        this.ioExecutor = ioExecutor;
        this.tracker.setOnSeriesTimeOutCallback( this::onSeriesTimeOut );
        this.databaseService = databaseService;
        this.qidoRsService = qidoRsService;
        this.kafkaNotificationProducer = kafkaNotificationProducer;
    }

    @KafkaListener( topics = "${kafka.topic.stgcmt}", groupId = "storage-commitment-group", containerFactory = "kafkaListenerContainerFactory" )
    public void listen ( ConsumerRecord< String, String > consumerRecord, Acknowledgment ack ) {
        logger.info( "listen :: consumer record value :: {}", consumerRecord.value( ) );
        try {
            StgmtStatus stgmtStatus = objectMapper.readValue( consumerRecord.value( ), StgmtStatus.class );
            CompletableFuture< Void > future = CompletableFuture.completedFuture( null );

            if ( DicomEnrichmentConstants.DICOM_DIR.equals( stgmtStatus.status( ) ) ) {
                logger.info( "listen :: dicom dir handle is called :: {}", stgmtStatus.status( ) );
                future = handleDicomDirStatus( stgmtStatus );
            } else if ( DicomEnrichmentConstants.STORAGE_COMMITMENT.equals( stgmtStatus.status( ) ) ) {
                future = handleStgCmtStatus( stgmtStatus );
            }
            future.thenRun( ( ) -> {
                logger.error( "consumer is acknowledged" );
                ack.acknowledge( );
            } ).exceptionally( ex -> {
                logger.error( "Error processing storage commitment message", ex );
                ack.acknowledge( );
                return null;
            } );
        } catch ( Exception ex ) {
            logger.error( "listen:: error while processing the request:: {}", ex.getMessage( ) );
        }
    }

    private CompletableFuture< Void > handleDicomDirStatus ( StgmtStatus stgmtStatus ) {
        logger.info( "Submitting handleDicomDirStatus to executor={} for series={}", cpuExecutor, stgmtStatus.seriesInstanceUid( ) );
        return CompletableFuture.supplyAsync( ( ) -> {
            logger.info( "handleDicomDirStatus :: series id:: {} (thread={})", stgmtStatus.seriesInstanceUid( ), Thread.currentThread( ).getName( ) );
            tracker.markCommitmentReceived( stgmtStatus.seriesInstanceUid( ) );
            SeriesState state = tracker.getState( stgmtStatus.seriesInstanceUid( ) );

            if ( state != null ) {
                state.setCommitmentStatus( DicomEnrichmentConstants.DICOM_DIR );
                DicomDirDocument dicomDoc = databaseService.fetchMetaData( stgmtStatus.seriesInstanceUid( ) );
                if ( dicomDoc == null ) {
                    logger.error( "handleDicomDirStatus:: DicomDirDocument is null for seriesInstanceUid: {}", stgmtStatus.seriesInstanceUid( ) );
                    return CompletableFuture.< Void >completedFuture( null );
                }
                // Return the export future
                return validateAndTriggerExport( stgmtStatus.seriesInstanceUid( ), dicomDoc.getImageCount( ), dicomDoc, state, System.currentTimeMillis( ) );
            }

            return CompletableFuture.< Void >completedFuture( null );
        }, cpuExecutor ).thenCompose( Function.identity( ) );
    }


    private CompletableFuture< Void > handleStgCmtStatus ( StgmtStatus stgmtStatus ) {
        return CompletableFuture.supplyAsync( ( ) -> databaseService.fetchInstancesByRequestId( stgmtStatus.cmtReqId( ) ), ioExecutor ).thenCompose( sopInstanceIds -> scheduleSopCheck( sopInstanceIds ).thenCompose( seriesId -> {
            if ( seriesId != null ) {
                tracker.markCommitmentReceived( seriesId );
                SeriesState seriesState = tracker.getState( seriesId );
                if ( seriesState != null ) {
                    seriesState.setCommitmentStatus( DicomEnrichmentConstants.STORAGE_COMMITMENT );
                    return validateAndTriggerExport( seriesId, sopInstanceIds.size( ), null, seriesState, System.currentTimeMillis( ) );
                }
            }
            return CompletableFuture.completedFuture( null );
        } ) );
    }


    private CompletableFuture< Void > validateAndTriggerExport ( String seriesUid, int expectedImageCount, DicomDirDocument dicomDirDocument, SeriesState state, long startTimeMillis ) {
        long now = System.currentTimeMillis( );
        if ( now - startTimeMillis > TimeUnit.MINUTES.toMillis( waitTimeMinutes ) ) {
            logger.info( "validateAndTriggerExport :: Timeout reached for seriesUid: {}", seriesUid );
            return CompletableFuture.completedFuture( null );
        }
        return CompletableFuture.supplyAsync( ( ) -> {
            logger.info( "validateAndTriggerExport :: fetching instances for seriesUid={}", seriesUid );
            return databaseService.fetchInstancesOfSeries( seriesUid );
        }, ioExecutor ).thenApplyAsync( instances -> {
            logger.info( "validateAndTriggerExport :: expected images count :: {}", expectedImageCount );
            logger.info( "validateAndTriggerExport :: count of instances from db :: {}", instances.size( ) );
            logInstanceStatus( instances );
            return instances;
        }, cpuExecutor ).thenComposeAsync( instances -> {
            if ( expectedImageCount != instances.size( ) ) {
                logger.info( "validateAndTriggerExport :: count mismatch (expected={}, actual={}); scheduling recheck", expectedImageCount, instances.size( ) );
                Executor delayed = CompletableFuture.delayedExecutor( enrichmentStatusCheckIntervalMs, TimeUnit.MILLISECONDS, scheduledExecutorService );
                return CompletableFuture.runAsync( ( ) -> {/* noop */}, delayed ).thenComposeAsync( v -> validateAndTriggerExport( seriesUid, expectedImageCount, dicomDirDocument, state, startTimeMillis ), cpuExecutor );
            }

            logger.info( "validateAndTriggerExport :: proceeding to process instances for seriesUid: {}", seriesUid );

            // Aggregate per-instance async results (no blocking)
            return aggregateInstancesAsync( instances, enrichmentTimeout, sleepTimeSeconds * 1000L ).thenComposeAsync( allInstances -> {
                List< InstancesMeta > failedInstances = allInstances.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_FAILED, List.of( ) );
                logger.info( "validateAndTriggerExport :: failed instance count :: {}", failedInstances.size( ) );

                if ( failedInstances.isEmpty( ) ) {
                    logger.info( "validateAndTriggerExport :: all instances enriched; triggering export" );
                    return triggerQidoRsAndExport( state, seriesUid, instances.size( ), instances, dicomDirDocument ).thenRunAsync( ( ) -> {
                        tracker.invalidate( seriesUid );
                        logger.info( "validateAndTriggerExport :: tracker invalidated for seriesId: {}", seriesUid );
                        if ( !instances.isEmpty( ) ) {
                            MissingKeysNotificationData.clearBarcode( instances.get( 0 ).barcode( ) );
                        }
                    }, cpuExecutor );
                } else {
                    logger.info( "validateAndTriggerExport :: some instances failed; starting retryRecursive" );
                    return retryOnFailure( allInstances, state );
                }
            }, cpuExecutor );
        }, cpuExecutor );
    }

    private CompletableFuture< Map< String, List< InstancesMeta > > > aggregateInstancesAsync ( List< InstancesMeta > instances, long perInstanceTimeoutMinutes, long intervalMillis ) {
        logger.info( "aggregateInstancesAsync :: processing {} instances ----", instances.size( ) );

        List< InstancesMeta > completed = Collections.synchronizedList( new ArrayList<>( ) );
        List< InstancesMeta > failed = Collections.synchronizedList( new ArrayList<>( ) );

        List< CompletableFuture< Boolean > > futures = instances.stream( ).map( instance -> processInstanceAsync( instance, perInstanceTimeoutMinutes, intervalMillis ).thenApplyAsync( done -> {
            if ( Boolean.TRUE.equals( done ) ) {
                completed.add( instance );
            } else {
                failed.add( instance );
            }
            return done;
        }, cpuExecutor ) ).toList( );

        return CompletableFuture.allOf( futures.toArray( new CompletableFuture[ 0 ] ) ).thenApplyAsync( v -> {
            Map< String, List< InstancesMeta > > statusTracker = new ConcurrentHashMap<>( );
            statusTracker.put( DicomEnrichmentConstants.ENRICHMENT_COMPLETED, completed );
            statusTracker.put( DicomEnrichmentConstants.ENRICHMENT_FAILED, failed );

            logger.info( "aggregateInstancesAsync :: counts -> completed={}, failed={}", completed.size( ), failed.size( ) );
            return statusTracker;
        }, cpuExecutor );
    }

    private CompletableFuture< Void > retryOnFailure ( Map< String, List< InstancesMeta > > allInstances, SeriesState state ) {
        List< InstancesMeta > failedInstances = allInstances.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_FAILED, List.of( ) );
        List< InstancesMeta > enrichedInstances = allInstances.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_COMPLETED, List.of( ) );
        Set< String > completedInstances = enrichedInstances.stream( ).map( InstancesMeta::sopInstanceUid ).collect( Collectors.toSet( ) );

        return retryRecursive( failedInstances, completedInstances, state );
    }

    private CompletableFuture< Void > retryRecursive ( List< InstancesMeta > failedInstances, Set< String > completedInstances, SeriesState state ) {
        if ( state == null ) {
            return CompletableFuture.completedFuture( null );
        }
        // Stop if max retries reached, or nothing left to retry
        if ( state.getRetryCount( ) >= maxRetryAttempts || failedInstances.isEmpty( ) ) {
            return handleRetryCompletion( failedInstances, state );
        }
        state.incrementRetryCount( );
        logger.info( "retryRecursive :: Retry attempt #{} for series {}", state.getRetryCount( ), state.seriesUid );

        // Send notifications for instances that are still failed and not newly completed
        failedInstances.stream( ).filter( instance -> !completedInstances.contains( instance.sopInstanceUid( ) ) ).forEach( instance -> {
            LisResponse lisResponse = new LisResponse( );
            lisResponse.setSopInstanceUID( instance.sopInstanceUid( ) );
            lisResponse.setSeriesInstanceUID( instance.seriesInstanceUid( ) );
            lisResponse.setBarcode( instance.barcode( ) );
            lisResponse.setDeviceSerialNumber( instance.deviceSerialNumber( ) );
            sendRetryNotification( lisResponse );
        } );
        // Non-blocking delay before the next recheck
        Executor delayed = CompletableFuture.delayedExecutor( retryDelayInMilliseconds, TimeUnit.MILLISECONDS, scheduledExecutorService );
        return CompletableFuture.runAsync( ( ) -> { /* noop */ }, delayed ).thenComposeAsync( v -> CompletableFuture.supplyAsync( ( ) -> databaseService.fetchInstancesOfSeries( state.seriesUid ), ioExecutor ), cpuExecutor ).thenComposeAsync( instances -> aggregateInstancesAsync( instances, enrichmentTimeout, sleepTimeSeconds * 1000L ), cpuExecutor ).thenComposeAsync( refreshedStatusTracker -> {
            List< InstancesMeta > newFailed = refreshedStatusTracker.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_FAILED, List.of( ) );
            Set< String > newCompleted = refreshedStatusTracker.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_COMPLETED, List.of( ) ).stream( ).map( InstancesMeta::sopInstanceUid ).collect( Collectors.toSet( ) );
            return retryRecursive( newFailed, newCompleted, state );
        }, cpuExecutor );
    }

    private CompletableFuture< Void > handleRetryCompletion ( List< InstancesMeta > failedInstances, SeriesState state ) {
        if ( !failedInstances.isEmpty( ) && state.getRetryCount( ) >= maxRetryAttempts ) {
            String barcode = failedInstances.get( 0 ).barcode( );
            return CompletableFuture.runAsync( ( ) -> {
                kafkaNotificationProducer.sendNotification( emailSvcTopic, "MAX_RETRIES_REACHED", barcode );
                state.markExportTriggered( );
                tracker.invalidate( state.seriesUid );
                MissingKeysNotificationData.clearBarcode( failedInstances.get( 0 ).barcode( ) );
            }, cpuExecutor );
        } else if ( state.commitmentReceived.get( ) ) {
            // Await export completion
            return handleExportIfCommitmentReceived( state, failedInstances.get( 0 ).barcode( ) );
        } else {
            // Await timeout handling completion
            return onSeriesTimeOut( state.seriesUid, state );
        }
    }


    private CompletableFuture< String > scheduleSopCheck ( List< String > sopInstanceIds ) {
        CompletableFuture< String > future = new CompletableFuture<>( );
        scheduledExecutorService.schedule( ( ) -> {
            try {
                String seriesId = databaseService.checkForSopPresence( sopInstanceIds );
                if ( seriesId != null ) {
                    logger.info( "scheduleSopCheck :: Series ID {} found after {} mins.", seriesId, sopCheckIntervalMinutes );
                } else {
                    logger.warn( "scheduleSopCheck :: No unique series id found after {} mins for SOP instance ids: {}", sopCheckIntervalMinutes, sopInstanceIds );
                }
                future.complete( seriesId );
            } catch ( Exception e ) {
                logger.error( "scheduleSopCheck :: Exception occurred while checking for SOP presence", e );
                future.completeExceptionally( e );
            }
        }, sopCheckIntervalMinutes, TimeUnit.MINUTES );
        return future;
    }


    private void logInstanceStatus ( List< InstancesMeta > instances ) {
        for ( InstancesMeta instancesMeta : instances ) {
            logger.info( "validatedAndTriggerExport :: status of instances :: {}", instancesMeta.status( ) );
        }
    }

    private CompletableFuture< Void > triggerQidoRsAndExport ( SeriesState state, String seriesId, int enrichedCount, List< InstancesMeta > instances, DicomDirDocument dicomDirDocument ) {
        String dicomWebUrl = databaseService.getDicomStroreUrl( instances.get( 0 ).deviceSerialNumber( ) );
        logger.info( "triggerQidoRsAndExport :: dicom web url :: {}", dicomWebUrl );
        return CompletableFuture.supplyAsync( ( ) -> {
            try {
                return qidoRsService.qidoRsCall( seriesId, instances, dicomWebUrl );
            } catch ( IOException | InterruptedException e ) {
                Thread.currentThread( ).interrupt( );
                logger.error( "triggerQidoRsAndExport :: IOException occurred while doing QIDO-RS ", e );
                return null;
            }
        }, cpuExecutor ).thenCompose( qidoRsRes -> {
            if ( qidoRsRes == null ) return CompletableFuture.completedFuture( null );

            Pair< String, Set< String > > studyIdAndInstanceCount = extractStudyIdAndInstanceCount( qidoRsRes );
            Set< String > completedSet = studyIdAndInstanceCount.getRight( );
            int qidoRsInstanceCount = completedSet.size( );
            String studyId = studyIdAndInstanceCount.getLeft( );

            logger.info( "triggerQidoRsAndExport :: qido rs instance count :: {}", qidoRsInstanceCount );
            logger.info( "triggerQidoRsAndExport :: study id :: {}", studyId );

            if ( dicomDirDocument != null && !dicomDirDocument.getStudyId( ).equalsIgnoreCase( studyId ) ) {
                byte[] dicomDir = DicomDirUtils.modifyStudyIdInDicomDir( dicomDirDocument, studyId );
                dicomDirDocument.setStudyId( studyId );
                dicomDirDocument.setDicomDirFile( dicomDir );
                databaseService.updateDicomDir( dicomDirDocument );
            }

            byte[] dicomDirBytes = dicomDirDocument == null ? null : dicomDirDocument.getDicomDirFile( );

            if ( enrichedCount == qidoRsInstanceCount ) {
                ExportMessage exportMessage = new ExportMessage( instances.get( 0 ).barcode( ), seriesId, studyId, qidoRsInstanceCount, instances.stream( ).map( InstancesMeta::sopInstanceUid ).toList( ), dicomDirBytes, dicomWebUrl );
                try {
                    logger.info( "triggerQidoRsAndExport :: kafka notification will be sent to topic :: {}", exportTopic );
                    kafkaNotificationProducer.sendNotification( exportTopic, seriesId, objectMapper.writeValueAsString( exportMessage ) );
                    state.markExportTriggered( );
                } catch ( JsonProcessingException e ) {
                    logger.error( "triggerQidoRsAndExport :: JsonProcessingException occurred ", e );
                }
                logger.info( "triggerQidoRsAndExport :: delete series from intermediate storage :: {}", instances );
                deleteSeriesFromIntermediateStorage( instances );
                return CompletableFuture.completedFuture( null );
            } else {
                logger.debug( "triggerQidoRsAndExport :: QIDO-RS count is less than enriched count in db." );
                logger.info( "triggerQidoRsAndExport :: QIDO-RS count {}", qidoRsInstanceCount );
                logger.info( "triggerQidoRsAndExport :: DB count {}", enrichedCount );

                List< InstancesMeta > remainingIds = instances.stream( ).filter( instance -> !completedSet.contains( instance.sopInstanceUid( ) ) ).toList( );
                Map< String, List< InstancesMeta > > remainingIdsMap = new HashMap<>( );
                remainingIdsMap.put( DicomEnrichmentConstants.ENRICHMENT_FAILED, remainingIds );
                return retryOnFailure( remainingIdsMap, state );
            }
        } );
    }

    private void deleteSeriesFromIntermediateStorage ( List< InstancesMeta > instances ) {
        for ( InstancesMeta instancesMeta : instances ) {
            scheduledExecutorService.schedule( ( ) -> {
                URI uri = URI.create( instancesMeta.intermediatePath( ) );
                String bucketName = uri.getHost( ); // "your-bucket-name"
                String objectName = uri.getPath( ).substring( 1 ); // "path/to/file.dcm"

                Storage storage;
                try {
                    storage = StorageOptions.newBuilder( ).setCredentials( ServiceAccountCredentials.fromStream( new ByteArrayInputStream( gcpConfig.getCreds( ).getBytes( StandardCharsets.UTF_8 ) ) ) ).build( ).getService( );
                    logger.info( "deleteSeriesFromIntermediateStorage :: Attempting to delete from bucket: {}, object: {}", bucketName, objectName );
                    boolean deleted = storage.delete( BlobId.of( bucketName, objectName ) );
                    if ( deleted ) {
                        logger.info( "deleteSeriesFromIntermediateStorage :: Successfully deleted the instances files: {}", instancesMeta.intermediatePath( ) );
                    } else {
                        logger.error( "deleteSeriesFromIntermediateStorage :: Failed to delete: {}", instancesMeta.intermediatePath( ) );
                    }
                } catch ( IOException e ) {
                    logger.error( "deleteSeriesFromIntermediateStorage :: unable to read credentials:: {}", e.getMessage( ) );
                }

            }, deleteSeriesDelayMinutes, TimeUnit.MINUTES );
        }
    }

    private Pair< String, Set< String > > extractStudyIdAndInstanceCount ( JsonNode qidoRes ) {
        Set< String > instanceUids = new HashSet<>( );
        String studyInstanceUid = null;
        for ( JsonNode instance : qidoRes ) {
            extractSopInstanceUid( instance ).ifPresent( instanceUids::add );

            if ( studyInstanceUid == null ) {
                studyInstanceUid = extractStudyInstanceUid( instance ).orElse( null );
            }
        }
        return new ImmutablePair<>( studyInstanceUid, instanceUids );
    }

    private Optional< String > extractStudyInstanceUid ( JsonNode instance ) {
        JsonNode studyUidNode = instance.get( "0020000D" );
        return extractValueFromNode( studyUidNode );
    }

    private Optional< String > extractSopInstanceUid ( JsonNode instance ) {
        JsonNode sopNode = instance.get( "00080018" );
        return extractValueFromNode( sopNode );
    }

    private Optional< String > extractValueFromNode ( JsonNode node ) {
        if ( node != null ) {
            JsonNode valueNode = node.get( "Value" );
            if ( valueNode != null && valueNode.isArray( ) && !valueNode.isEmpty( ) ) {
                return Optional.ofNullable( valueNode.get( 0 ).asText( ) );
            }
        }
        return Optional.empty( );
    }

    private CompletableFuture< Boolean > processInstanceAsync ( InstancesMeta instance, long perInstanceTimeoutMinutes, long intervalMillis ) {
        // Fast-path terminal statuses (CPU-bound)
        return CompletableFuture.supplyAsync( ( ) -> {
                    String status = instance.status( );
                    logger.info( "processInstanceAsync :: instance status :: {}", status );
                    if ( allowedStatuses.contains( status ) ) {
                        logger.info( "processInstanceAsync :: fast-path completed instance: {} (seriesId: {})", instance.sopInstanceUid( ), instance.seriesInstanceUid( ) );
                        return Boolean.TRUE;
                    }
                    if ( DicomEnrichmentConstants.ENRICHMENT_FAILED_STATUS.equalsIgnoreCase( status ) ) {
                        logger.error( "processInstanceAsync :: fast-path failed instance: {} (seriesId: {})", instance.sopInstanceUid( ), instance.seriesInstanceUid( ) );
                        return Boolean.FALSE;
                    }
                    return null; // need to poll DB
                }, cpuExecutor )

                // If not terminal, poll DB until timeout (I/O inside helper)
                .thenComposeAsync( fastPath -> {
                    if ( fastPath != null ) {
                        return CompletableFuture.completedFuture( fastPath );
                    }
                    return waitForEnrichmentCompletionAsync( instance, perInstanceTimeoutMinutes, intervalMillis );
                }, cpuExecutor );
    }

    public CompletableFuture< Boolean > waitForEnrichmentCompletionAsync ( InstancesMeta instance, long timeoutMinutes, long intervalMillis ) {
        final long deadlineNanos = System.nanoTime( ) + TimeUnit.MINUTES.toNanos( timeoutMinutes );
        return waitForEnrichmentCompletionWithDeadlineAsync( instance, deadlineNanos, intervalMillis );
    }

    private CompletableFuture< Boolean > waitForEnrichmentCompletionWithDeadlineAsync ( InstancesMeta instance, long deadlineNanos, long intervalMillis ) {
        logger.info( "waitForEnrichmentCompletionAsync :: deadline nanos: {}", deadlineNanos );

        // One status check (blocking I/O → ioExecutor)
        CompletableFuture< Boolean > check = CompletableFuture.supplyAsync( ( ) -> {
            String status = databaseService.getStatusOfInstance( instance.seriesInstanceUid( ), instance.sopInstanceUid( ) );

            if ( allowedStatuses.contains( status ) ) {
                logger.info( "waitForEnrichmentCompletionAsync :: enrichment completed after recheck for instance: {}", instance.sopInstanceUid( ) );
                return Boolean.TRUE;
            }
            if ( DicomEnrichmentConstants.ENRICHMENT_FAILED_STATUS.equalsIgnoreCase( status ) ) {
                logger.error( "waitForEnrichmentCompletionAsync :: enrichment failed after recheck for instance: {}", instance.sopInstanceUid( ) );
                return Boolean.FALSE;
            }
            return null; // not ready yet
        }, ioExecutor );

        return check.thenComposeAsync( result -> {
            if ( Boolean.TRUE.equals( result ) ) return CompletableFuture.completedFuture( true );
            if ( Boolean.FALSE.equals( result ) ) return CompletableFuture.completedFuture( false );

            long remainingNanos = deadlineNanos - System.nanoTime( );
            if ( remainingNanos <= 0 ) {
                logger.info( "waitForEnrichmentCompletionAsync :: not completed within deadline for instance {}", instance.sopInstanceUid( ) );
                return CompletableFuture.completedFuture( false );
            }
            // Non-blocking delay, then retry
            Executor delayed = CompletableFuture.delayedExecutor( intervalMillis, TimeUnit.MILLISECONDS, scheduledExecutorService );
            return CompletableFuture.runAsync( ( ) -> { /* noop */ }, delayed ).thenComposeAsync( v -> waitForEnrichmentCompletionWithDeadlineAsync( instance, deadlineNanos, intervalMillis ), cpuExecutor );
        }, cpuExecutor );
    }

    private void sendRetryNotification ( LisResponse lisResponse ) {
        try {
            kafkaNotificationProducer.sendNotification( enrichSvcTopic, "RETRY", objectMapper.writeValueAsString( lisResponse ) );
        } catch ( JsonProcessingException e ) {
            logger.error( "sendRetryNotification:: Json parse exception :: {}", e.getMessage( ) );
        }
    }

    public CompletableFuture< Void > onSeriesTimeOut ( String seriesUid, SeriesState state ) {
        if ( state == null ) {
            return CompletableFuture.completedFuture( null );
        }

        return CompletableFuture.supplyAsync( ( ) -> {
                    logger.info( "onSeriesTimeOut :: fetching instances for seriesUid={}", state.seriesUid );
                    return databaseService.fetchInstancesOfSeries( state.seriesUid );
                }, ioExecutor )
                // Process instances asynchronously (no blocking)
                .thenComposeAsync( instances -> {
                    logger.info( "onSeriesTimeOut :: fetched {} instances; starting async processing", instances.size( ) );
                    return aggregateInstancesAsync( instances, enrichmentTimeout, sleepTimeSeconds * 1000L );
                }, cpuExecutor )
                // Decide next action
                .thenComposeAsync( allInstances -> {
                    List< InstancesMeta > failedInstances = allInstances.getOrDefault( DicomEnrichmentConstants.ENRICHMENT_FAILED, List.of( ) );

                    if ( failedInstances.isEmpty( ) ) {
                        logger.info( "onSeriesTimeOut :: all instances enriched for seriesId: {}", state.seriesUid );

                        List< InstancesMeta > instancesForExport = allInstances.values( ).stream( ).flatMap( List::stream ).toList( );

                        return triggerQidoRsAndExport( state, state.seriesUid, instancesForExport.size( ), instancesForExport, null ).thenRunAsync( ( ) -> {
                            tracker.invalidate( seriesUid );
                            logger.info( "onSeriesTimeOut :: tracker invalidated for seriesId: {}", seriesUid );
                            if ( !instancesForExport.isEmpty( ) ) {
                                MissingKeysNotificationData.clearBarcode( instancesForExport.get( 0 ).barcode( ) );
                            }
                        }, cpuExecutor );
                    } else {
                        logger.info( "onSeriesTimeOut :: some instances failed enrichment (count={}); retrying...", failedInstances.size( ) );
                        return retryOnFailure( allInstances, state );
                    }
                }, cpuExecutor );

    }



    private CompletableFuture< Void > handleExportIfCommitmentReceived ( SeriesState state, String barcode ) {
        String status = state.getCommitmentStatus( );

        if ( status.equals( DicomEnrichmentConstants.DICOM_DIR ) ) {
            return CompletableFuture.supplyAsync( ( ) -> databaseService.fetchMetaData( state.seriesUid ), ioExecutor ).thenCompose( dicomDoc -> validateAndTriggerExport( state.seriesUid, dicomDoc.getImageCount( ), dicomDoc, state, System.currentTimeMillis( ) ) ).thenRun( ( ) -> {
                tracker.invalidate( state.seriesUid );
                MissingKeysNotificationData.clearBarcode( barcode );
            } );
        } else if ( status.equals( DicomEnrichmentConstants.STORAGE_COMMITMENT ) ) {
            return CompletableFuture.supplyAsync( ( ) -> databaseService.fetchInstancesOfSeries( state.seriesUid ), ioExecutor ).thenCompose( instanceMeta -> {
                List< String > sopInstanceIds = instanceMeta.stream( ).map( InstancesMeta::sopInstanceUid ).toList( );
                return validateAndTriggerExport( state.seriesUid, sopInstanceIds.size( ), null, state, System.currentTimeMillis( ) );
            } ).thenRun( ( ) -> {
                tracker.invalidate( state.seriesUid );
                MissingKeysNotificationData.clearBarcode( barcode );
            } );
        }

        return CompletableFuture.completedFuture( null );
    }
}