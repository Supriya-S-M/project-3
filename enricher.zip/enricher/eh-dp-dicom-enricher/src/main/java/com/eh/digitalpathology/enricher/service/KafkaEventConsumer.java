package com.eh.digitalpathology.enricher.service;

import com.eh.digitalpathology.enricher.config.ExternalConfig;
import com.eh.digitalpathology.enricher.constants.DicomEnrichmentConstants;
import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import com.eh.digitalpathology.enricher.mapper.CaseInfoMapper;
import com.eh.digitalpathology.enricher.model.CaseInfo;
import com.eh.digitalpathology.enricher.model.EnrichInstance;
import com.eh.digitalpathology.enricher.model.LisResponse;
import com.eh.digitalpathology.enricher.utils.YamlReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@RefreshScope
public class KafkaEventConsumer {

    private static final Logger logger = LoggerFactory.getLogger(KafkaEventConsumer.class);

    @Value("${dicom.mappings.base.path}")
    private String dicomMappingsBasePath;

    @Value("${kafka.topic.email}")
    private String emailSvcTopic;

    private final ExternalConfig configuration;
    private final DicomEnrichmentService dicomEnrichmentService;
    private final DicomTracker dicomTracker;
    private Map<String, String> additivesMapping;
    private Map<String, Map<String, Object>> dynamicYamlCache;
    private final KafkaNotificationProducer kafkaNotificationProducer;

    @PostConstruct
    public void init() {
        Map<String, Object> additivesMappingData = YamlReader.readYaml(dicomMappingsBasePath + DicomEnrichmentConstants.MAPPING_YAML);
        if (additivesMappingData.isEmpty()) {
            kafkaNotificationProducer.sendNotification(emailSvcTopic, "YAML_UNAVAILABLE", null);
        }
        this.additivesMapping = (Map<String, String>) additivesMappingData.get("mappings");

        this.dynamicYamlCache = new HashMap<>();
        for (Map.Entry<String, String> entry : additivesMapping.entrySet()) {
            String key = entry.getKey();
            String fileName = entry.getValue();
            dynamicYamlCache.put(key, YamlReader.readYaml(dicomMappingsBasePath + fileName));
        }
        logger.debug("YAML mappings loaded in PostConstruct.");
    }

    @Autowired
    public KafkaEventConsumer(ExternalConfig configuration, DicomEnrichmentService dicomEnrichmentService, DicomTracker dicomTracker, KafkaNotificationProducer kafkaNotificationProducer) {
        this.configuration = configuration;
        this.dicomEnrichmentService = dicomEnrichmentService;
        this.dicomTracker = dicomTracker;
        this.kafkaNotificationProducer = kafkaNotificationProducer;
    }

    /**
     * Kafka listener method that processes incoming event messages.
     *
     * @param consumerRecord The Kafka consumer record containing the HL7 message.
     */
    @KafkaListener(topics = "${kafka.topic.enrich}", groupId = "dicom-enrich-group", containerFactory = "kafkaListenerContainerFactory")
    public void listen( ConsumerRecord<String, String> consumerRecord, Acknowledgment  ack) throws DicomEnrichmentServiceException {
        try {
            logger.info("listen :: Received event ::: eventKey : {} & eventData {}", consumerRecord.key(), consumerRecord.value());
            LisResponse lisResponse = extractData(consumerRecord);
            CaseInfo caseInfo = CaseInfoMapper.INSTANCE.toCaseInfo(lisResponse);
            logger.info("listen:: case information :: {}", caseInfo.getBarcode());
            caseInfo.setMessageType(configuration.getLisMessageResponse());
            processEvent(caseInfo);
            ack.acknowledge();
        } catch (Exception e) {
            logger.error("listen :: Error while processing the message ",e);
            ack.acknowledge();
        }
    }

    public LisResponse extractData(ConsumerRecord<String, String> consumerRecord) throws DicomEnrichmentServiceException {
        logger.info("extractData :: for eventKey : {}", consumerRecord.key());
        String eventData = consumerRecord.value();
        if (eventData == null || eventData.isEmpty()) {
            logger.error("extractData :: Received empty message");
            throw new DicomEnrichmentServiceException("Received empty message");
        }
        ObjectMapper objectMapper = new ObjectMapper();
        LisResponse lisResponse;
        try {
            lisResponse = objectMapper.readValue(eventData, LisResponse.class);
            logger.info("extractData :: lisResponse :: {}", lisResponse);
        } catch (Exception e) {
            throw new DicomEnrichmentServiceException("Unable to extract data from message");
        }
        return lisResponse;
    }

    public void processEvent(CaseInfo caseInfo) {
        logger.info("processEvent :: Processing event for seriesInstanceUid ::: {}", caseInfo.getSeriesInstanceUid());
        EnrichInstance enrichInstance = dicomEnrichmentService.fetchDataForEnrichment(caseInfo, additivesMapping, dynamicYamlCache);
        dicomTracker.handleInstances(enrichInstance.getSeriesInstanceUid(), caseInfo);

    }
}





