package com.eh.digitalpathology.enricher.model;

public record MissingCodeSetFieldData (String barcode,String missingTag){
}
