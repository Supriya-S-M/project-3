package com.eh.digitalpathology.enricher.model;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class MissingKeysNotificationData {
    private MissingKeysNotificationData(){

    }

    private static final Map<String, Set<String>> notifiedMissingKeys = new ConcurrentHashMap<>();

    public static Map<String, Set<String>> getNotifiedMissingKeys(){
        return notifiedMissingKeys;
    }

    public static void clearBarcode(String barcode){
        notifiedMissingKeys.remove(barcode);
    }


}
