package com.eh.digitalpathology.enricher.model;

import java.util.List;

public class DicomTags {
    private List<TagItem> tags;

    public List<TagItem> getTags() {
        return tags;
    }

    public void setTags(List<TagItem> tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "DicomTags [tags=" + tags + "]";
    }
}
