package com.eh.digitalpathology.enricher.mapper;

import com.eh.digitalpathology.enricher.model.CaseInfo;
import com.eh.digitalpathology.enricher.model.LisResponse;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper( componentModel = "spring" )
public interface CaseInfoMapper {

    CaseInfoMapper INSTANCE = Mappers.getMapper( CaseInfoMapper.class );

    @Mapping( source = "sopInstanceUID", target = "sopInstanceUid" )
    @Mapping( source = "seriesInstanceUID", target = "seriesInstanceUid" )
    @Mapping( target = "messageType", ignore = true )
    CaseInfo toCaseInfo ( LisResponse lisResponse );

}
