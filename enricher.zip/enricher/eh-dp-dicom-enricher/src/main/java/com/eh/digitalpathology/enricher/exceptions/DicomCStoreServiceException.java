package com.eh.digitalpathology.enricher.exceptions;

public class DicomCStoreServiceException extends DicomStorageException{
    public DicomCStoreServiceException(String message) {
        super(message);
    }

    public DicomCStoreServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
