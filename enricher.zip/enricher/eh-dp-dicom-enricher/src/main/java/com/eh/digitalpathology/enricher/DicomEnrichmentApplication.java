package com.eh.digitalpathology.enricher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DicomEnrichmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(DicomEnrichmentApplication.class, args);
    }



}
