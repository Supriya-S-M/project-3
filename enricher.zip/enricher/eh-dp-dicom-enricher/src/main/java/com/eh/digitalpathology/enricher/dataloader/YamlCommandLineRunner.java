package com.eh.digitalpathology.enricher.dataloader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class YamlCommandLineRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(YamlCommandLineRunner.class);

    private final YamlLoader yamlLoader;

    public YamlCommandLineRunner(YamlLoader yamlLoader) {
        this.yamlLoader = yamlLoader;
    }

    @Override
    public void run(String... args) throws Exception {
        logger.info("Inside YAMLLoader to load YAML Files ");
        yamlLoader.loadAllYAMLFiles();
    }
}
