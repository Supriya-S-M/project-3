package com.eh.digitalpathology.enricher.config;

import com.eh.digitalpathology.enricher.healthcareapi.DicomHealthcareApiClient;
import com.eh.digitalpathology.enricher.service.DicomCStoreService;
import com.eh.digitalpathology.enricher.api.*;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import com.eh.digitalpathology.enricher.enums.*;

@Configuration
@RefreshScope
public class EnrichedDicomStorageConfig {
    @Value("${enriched-dicom-storage-config.storage-mode}")
    private String storageMode;

    @Bean
    public EnrichedDicomStorageStrategy dicomStorageStrategy(DicomHealthcareApiClient dicomHealthcareApiClient,
                                                             DicomCStoreService dicomCStoreService) {
        EnrichedDicomStorageMode mode = EnrichedDicomStorageMode.fromString(storageMode);
        return switch (mode) {
            case STOW_RS -> dicomHealthcareApiClient;
            case C_STORE -> dicomCStoreService;
        };
    }
}
