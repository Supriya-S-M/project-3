package com.eh.digitalpathology.enricher.model;


public record BarcodeInstanceRequest(String barcode, String sopInstanceUid){}

