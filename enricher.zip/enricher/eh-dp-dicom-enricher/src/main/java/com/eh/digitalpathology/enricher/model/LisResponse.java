package com.eh.digitalpathology.enricher.model;

public class LisResponse {

    private String barcode;
    private String sopInstanceUID;
    private String seriesInstanceUID;
    private String deviceSerialNumber;

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getSopInstanceUID() {
        return sopInstanceUID;
    }

    public void setSopInstanceUID(String sopInstanceUID) {
        this.sopInstanceUID = sopInstanceUID;
    }

    public String getSeriesInstanceUID() {
        return seriesInstanceUID;
    }

    public void setSeriesInstanceUID(String seriesInstanceUID) {
        this.seriesInstanceUID = seriesInstanceUID;
    }

    public String getDeviceSerialNumber ( ) {
        return deviceSerialNumber;
    }

    public void setDeviceSerialNumber ( String deviceSerialNumber ) {
        this.deviceSerialNumber = deviceSerialNumber;
    }

    @Override
    public String toString() {
        return "LisResponse{" +
                "barcode='" + barcode + '\'' +
                ", sopInstanceUID='" + sopInstanceUID + '\'' +
                ", seriesInstanceUID='" + seriesInstanceUID + '\'' +
                '}';
    }
}
