/**
 * Custom exception class to handle errors specific to the DICOM Enrichment Service.
 * This exception is thrown when there are issues during the enrichment process,
 * providing a way to encapsulate error messages and underlying causes.
 * Author: Pooja Kamble
 * Date: October 30, 2024
 * */

package com.eh.digitalpathology.enricher.exceptions;

public class DicomEnrichmentServiceException extends RuntimeException {

    public DicomEnrichmentServiceException(String message) {
        super(message);
    }

    public DicomEnrichmentServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}