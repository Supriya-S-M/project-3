package com.eh.digitalpathology.enricher.exceptions;

public class StorageCommitmentException extends RuntimeException{
    public StorageCommitmentException(String message) {
        super(message);
    }

    public StorageCommitmentException(String message, Throwable cause) {
        super(message, cause);
    }
}
