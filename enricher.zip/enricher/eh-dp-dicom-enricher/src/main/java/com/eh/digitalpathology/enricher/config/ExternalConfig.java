package com.eh.digitalpathology.enricher.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@Configuration
@RefreshScope
public class ExternalConfig {
    @Value("${app.message.lis-response}")
    private String lisMessageResponse;

    public String getLisMessageResponse() {
        return lisMessageResponse;
    }

    public void setLisMessageResponse ( String lisMessageResponse ) {
        this.lisMessageResponse = lisMessageResponse;
    }
}

