package com.eh.digitalpathology.enricher.enums;

public enum EnrichedDicomStorageMode {
    STOW_RS("STOW-RS"),
    C_STORE("C-STORE");

    private final String mode;

    EnrichedDicomStorageMode(String mode) {
        this.mode = mode;
    }

    public String getMode() {
        return mode;
    }

    public static EnrichedDicomStorageMode fromString(String mode) {
        for (EnrichedDicomStorageMode storageMode : EnrichedDicomStorageMode.values()) {
            if (storageMode.getMode().equalsIgnoreCase(mode)) {
                return storageMode;
            }
        }
        throw new IllegalArgumentException("Invalid storage mode: " + mode);
    }
}
