package com.eh.digitalpathology.enricher.dataloader;

import com.eh.digitalpathology.enricher.service.KafkaNotificationProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
@RefreshScope
public class YamlLoader {

    private static final Logger logger = LoggerFactory.getLogger(YamlLoader.class);

    private static final Map<String, Object> YAML_DATA_MAPS = new ConcurrentHashMap<>();
    private final KafkaNotificationProducer kafkaNotificationProducer;

    @Value("${yaml.folder.base.location}")
    private String yamlFolder;

    @Value("${kafka.topic.email}")
    private String emailSvcTopic;

    public YamlLoader(KafkaNotificationProducer kafkaNotificationProducer) {
        this.kafkaNotificationProducer = kafkaNotificationProducer;
    }

    public Map<String,Object> getYamlDataMaps(){
        return YAML_DATA_MAPS;
    }

    public void loadAllYAMLFiles() {
        logger.info("loadAllYAMLFiles :: Loading All YAML Files from location : {}", yamlFolder);
        try {
            Set<Path> yamlFiles = getYamlFiles();
            logger.info("loadAllYAMLFiles:: yamlFiles {}", yamlFiles);
            if(yamlFiles.isEmpty()) {
                kafkaNotificationProducer.sendNotification(emailSvcTopic, "YAML_UNAVAILABLE", null);
                logger.info("loadAllYAMLFiles:: YAML Files doesn't exist at : {}", yamlFolder);
            }
            loadYAMLFiles(yamlFiles);
        } catch (Exception e) {
            logger.error("Error while loading data from YAML Files ", e);

        }
    }

    private void loadYAMLFiles(Set<Path> yamlFiles){
        Yaml yaml = new Yaml();
        for (Path yamlFile : yamlFiles) {
            logger.info("loadYAMLFiles:: Loading.... YAML data for : {}", yamlFile);
            try (InputStream inputStream = Files.newInputStream(yamlFile)) {
                Object data = yaml.load(inputStream);
                String yamlMappingKey = getYamlMappingKey(yamlFile);
                YAML_DATA_MAPS.put(yamlMappingKey, data);
                logger.info("loadYAMLFiles:: YAML data loaded for : {}", yamlFile);
            } catch (Exception e) {
                logger.error("Exception occurred while loading yaml file {} ", yamlFile, e);
            }
        }
    }


    private String getYamlMappingKey(Path yamlFile){
        int pos = yamlFile.getFileName().toString().lastIndexOf(".");
        return (pos == -1) ? yamlFile.getFileName().toString() : yamlFile.getFileName().toString().substring(0, pos);
    }

    private Set<Path> getYamlFiles() {
        logger.info("getYamlFiles:: Inside getYamlFiles : {}", yamlFolder);
        try (Stream<Path> paths = Files.walk(Paths.get(yamlFolder))) {
            return paths.filter(Files:: isRegularFile)
                    .filter(path -> path.toString().endsWith(".yaml") || path.toString().endsWith(".yml"))
                    .collect(Collectors.toSet());

        } catch (Exception e) {
            logger.error("Exception occurred while walking on yaml files Folder {} ", yamlFolder, e);
        }
        return Set.of();
    }


}
