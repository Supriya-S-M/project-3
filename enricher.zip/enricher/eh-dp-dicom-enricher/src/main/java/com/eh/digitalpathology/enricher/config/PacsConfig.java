package com.eh.digitalpathology.enricher.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "enriched-dicom-storage-config.pacs-config")
public class PacsConfig {
    private String remoteHost;
    private String remoteAETitle;
    private int remotePort;

    public String getRemoteHost() {
        return remoteHost;
    }

    public void setRemoteHost(String remoteHost) {
        this.remoteHost = remoteHost;
    }

    public String getRemoteAETitle() {
        return remoteAETitle;
    }

    public void setRemoteAETitle(String remoteAETitle) {
        this.remoteAETitle = remoteAETitle;
    }

    public int getRemotePort() {
        return remotePort;
    }

    public void setRemotePort(int remotePort) {
        this.remotePort = remotePort;
    }
}
