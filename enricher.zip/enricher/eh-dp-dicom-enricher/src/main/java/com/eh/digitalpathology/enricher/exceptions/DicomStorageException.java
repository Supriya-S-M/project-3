package com.eh.digitalpathology.enricher.exceptions;

public class DicomStorageException extends RuntimeException {
    public DicomStorageException(String message) {
        super(message);
    }

    public DicomStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
