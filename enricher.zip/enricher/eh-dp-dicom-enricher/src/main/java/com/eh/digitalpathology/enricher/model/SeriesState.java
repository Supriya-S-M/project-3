package com.eh.digitalpathology.enricher.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.atomic.AtomicBoolean;

public class SeriesState {

    public final String seriesUid;
    public final List<String> receivedInstances = Collections.synchronizedList(new ArrayList<>());
    public final AtomicBoolean commitmentReceived = new AtomicBoolean(false);
    private ScheduledFuture<Void> timerTask;
    private int retryCount = 0;
    private String commitmentStatus;
    private volatile boolean exportTriggered = false;

    public ScheduledFuture<Void> getTimerTask() {
        return timerTask;
    }

    public void setTimerTask(ScheduledFuture<Void> timerTask) {
        this.timerTask = timerTask;
    }

    public boolean isExportTriggered() {
        return exportTriggered;
    }

    public void markExportTriggered() {
        this.exportTriggered = true;
    }

    public SeriesState(String seriesUid) {
        this.seriesUid = seriesUid;
    }

    public int getRetryCount() {
        return retryCount;
    }

    // Increment method
    public void incrementRetryCount() {
        retryCount++;
    }

    // Optional: Reset method if needed
    public void resetRetryCount() {
        retryCount = 0;
    }

    public String getCommitmentStatus() {
        return commitmentStatus;
    }

    public void setCommitmentStatus(String commitmentStatus) {
        this.commitmentStatus = commitmentStatus;
    }
}