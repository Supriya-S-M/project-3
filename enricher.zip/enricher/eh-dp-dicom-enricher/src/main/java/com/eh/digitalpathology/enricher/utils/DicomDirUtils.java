package com.eh.digitalpathology.enricher.utils;

import com.eh.digitalpathology.enricher.exceptions.DicomEnrichmentServiceException;
import com.eh.digitalpathology.enricher.model.DicomDirDocument;
import org.dcm4che3.data.*;
import org.dcm4che3.io.DicomInputStream;
import org.dcm4che3.io.DicomOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class DicomDirUtils {

    private DicomDirUtils(){}

    private static final Logger log = LoggerFactory.getLogger( DicomDirUtils.class.getName() );

    public static byte[] modifyStudyIdInDicomDir ( DicomDirDocument dicomDirDocument, String studyId ) {
        log.info( "modifyStudyIdInDicomDir :: dicom dir document :: {}", dicomDirDocument );
        Attributes dicomAttributes;
        Attributes fmi;
        try ( DicomInputStream dicomInputStream = new DicomInputStream( new ByteArrayInputStream( dicomDirDocument.getDicomDirFile( ) ) ) ) {
            dicomAttributes = dicomInputStream.readDataset( -1 );
            fmi = dicomInputStream.getFileMetaInformation( );
        } catch ( IOException e ) {
            throw new DicomEnrichmentServiceException( "Error while reading dicomdir bytes ::" + e.getMessage( ) );
        }

        Sequence directoryRecords = dicomAttributes.getSequence( Tag.DirectoryRecordSequence );
        if ( directoryRecords != null ) {
            for ( Attributes attRecord : directoryRecords ) {
                String recordType = attRecord.getString( Tag.DirectoryRecordType );
                log.info( "modifyStudyIdInDicomDir :: Updating Study ID for record type::  {}", recordType );
                if ( "STUDY".equalsIgnoreCase( recordType ) ) {
                    attRecord.setString( Tag.StudyInstanceUID, VR.UI, studyId );
                }
            }
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );

        try ( DicomOutputStream dicomOutputStream = new DicomOutputStream( outputStream, UID.ExplicitVRLittleEndian ) ) {
            dicomOutputStream.writeDataset( fmi, dicomAttributes );
        } catch ( IOException ex ) {
            throw new DicomEnrichmentServiceException(  "Error while writing dicom dir :: " + ex.getMessage( ) );
        }
        return outputStream.toByteArray( );

    }
}
